export const  uploadClient = {
    upload: function (data : any , file : any, uploadSuccess: ()=> void, uploadFailure: ()=> void) {
        const uploadXhr = new XMLHttpRequest();
        uploadXhr.open("PUT", data.sas);
        uploadXhr.setRequestHeader("x-ms-blob-type", "BlockBlob");
        uploadXhr.setRequestHeader("x-ms-meta-" + data.uploadTypeKey, data.uploadTypeValue);

        for (const index in data.customMetadata) {
            uploadXhr.setRequestHeader('x-ms-meta-'+data.customMetadata[index].key.charAt(0).toLowerCase()+data.customMetadata[index].key.slice(1), data.customMetadata[index].value );
        };
        uploadXhr.setRequestHeader("Content-Type", file.type);
        uploadXhr.onload = function () {
            if (uploadXhr.status !== 200 && uploadXhr.status !== 201) {
                uploadFailure();
                return;
            } else {
                uploadSuccess();
                return;
            }
        };
        uploadXhr.onerror = function () {
            uploadFailure();
            return;
        }
       uploadXhr.send(file);
    }
}