import { gql } from "@apollo/client";

export const GET_CATEGORIES = gql`
  query Category(
    $categoryCode: String
    $searchTerm: String
    $sort: SortInput
    $filters: [FilterInput]
    $count:Int
    $skip: Int
  ) {
    contentListByCategory(
      categoryCode: $categoryCode
      searchTerm: $searchTerm
      sort: $sort
      filters: $filters
      skip: $skip
      count:$count
    ) {
      contents {
        id
        name
        summary
        contentType
        studyModes
        durationDisplay
        percentageComplete
        createdOnDisplay
        dueDate
        price
        isNew
        isEnrolled
        isAutoEnrolled
        hasActivities
        hasCertificate
        tags
        imageUrl
        statusCode
        rating
        numberOfPeopleWhoRated
        source
        numberOfChildContents
      }
      contentCount
    }
  }
`;

export const GET_COURSE_BY_ID = gql`
  query Course($courseId: String) {
    courseDetailsById(courseId: $courseId) {
      id
      name
      summary
      description
      percentageComplete
      createdOnDisplay
      tags
      imageUrl
      duration
      durationDisplay
      isNew
      isEnrolled
      isEnrollmentAvailable
      isMandatory
      canUnenroll
      canEnroll
      hasCertificate
      hasTranscript
      hasActivities
      hasAssessment
      objectives
      studyModes
      statusCode
      rating
      numberOfPeopleWhoRated
      source
      dueDate
      canExpressInterest
      allowSelfEnrol
    }
  }
`;

export const GET_COURSE_RELATED_CONTENTS_BY_ID = gql`
  query RelatedCourses($courseId: String) {
    relatedContents(courseId: $courseId) {
      contents {
        id
        name
        summary
        contentType
        studyModes
        durationDisplay
        percentageComplete
        dueDate
        price
        isNew
        isEnrolled
        hasActivities
        tags
        imageUrl
        rating
        numberOfPeopleWhoRated
        statusCode
        source
        hasCertificate
      }
    }
  }
`;

export const GET_ACTIVITIES = gql`
  query Activities($courseId: String) {
    activities(courseId: $courseId) {
      id
      name
      type
      statusCode
      description
      hasSessionInfo
      hasLaunchUrl
      hasContent
      url
      availableSessions {
        id
        name
        code
        description
        startDateTimeDisplay
        endDateTimeDisplay
        location
        noOfSeatsAvailable
      }
      bookedSession {
        id
        externalSessionId
        startDateTimeDisplay
        endDateTimeDisplay
        duration
        location
        address {
          name
          streetAddress1
          streetAddress2
          city
          state
          country
          postalCode
        }
      }
    }
  }
`;

export const GET_ACTIVITY_URL = gql`
  query ActivityURL($activityId: String, $activityType: String, $courseId: String!) {
    activityUrl(activityId: $activityId, activityType: $activityType, courseId: $courseId)
  }
`;

export const GET_COURSE_ENROLLMENT_DATA = gql`
  query CourseEnrollment($courseId: String!) {
    enrollmentData(courseId: $courseId) {
      activities {
        id
        name
        availableSessions {
          id
          startDateTimeDisplay
          endDateTimeDisplay
          location
          noOfSeatsAvailable
          startDateTime
          endDateTime
        }
      }
      learnerDetails {
        firstName
        lastName
        email
        managersEmail
        reasonableAdjusmentRequest
      }
      termsandConditions
      preRequisites
      isTermsAndConditionAvailable
      isPreRequisitesAvailable
      captureManagerEmail
      captureSpecialRequirements
    }
  }
`;

export const GET_COURSE_UNENROLLMENT_DATA = gql`
  query CourseUnenrollment($courseId: String!) {
    unenrollmentData(courseId: $courseId) {
      courseName
      lineManagerEmail
      cancellationPolicy
      cancellationReasons
    }
  }
`;

export const GET_USER_CONTEXT = gql`
  query UserContext {
    userContext {
      firstName
      lastName
      userDisplayName
      dateDisplayFormat
      roles
      permissions
      chatBotUrl
      showSurvey
      isSurveySkipped
      surveyId
      learnerId
      learnerEmail
      isLineManager
      canEditLineManagerEmail
      surveyStartDate
      showTopicsOfInterest
    }
  }
`;

export const GET_WELCOME_MESSAGE = gql`
  query Welcome {
    message {
      welcomeText
    }
  }
`;

export const GET_LEARNER_METRICS = gql`
  query LearnersMetrics {
    learnersMetrics {
      requiredLearning {
        total
        enrolled
        inProgress
        complete
      }
      certifications {
        total
        enrolled
        inProgress
        complete
      }
      otherLearnings {
        total
        enrolled
        inProgress
        complete
      }
    }
  }
`;

export const GET_LEARNER_PROFILE = gql`
  query LearnerProfile {
    learnerProfile {
      metaData {
        dataPoints {
          displayLabel
          code
          canEdit
          type
          items {
            code
            name
          }
        }
        topics {
          id
          code
          name
          description
        }
      }
      userProfile {
        firstName
        lastName
        userDisplayName
        designation
        department
        email
        dataPoints {
          displayLabel
          code
          value
          values
        }
        topicOfInterest {
          id
          isAutoEnrolled
        }
      }
    }
  }
`;

export const UPDATE_EMAIL_ADDRESS = gql`
  mutation UpdateEmailId($emailId: String) {
    updateEmailId(emailId: $emailId)
  }
`;

export const UPDATE_USER_PROFILE = gql`
  mutation UpdateUserProfile($profile: UserProfileUpdateInput) {
    updateUserProfile(profile: $profile)
  }
`;

export const COMPLETE_ENROLLMENT = gql`
  mutation CompleteEnrollment($courseEnroll: CourseEnrollInput, $attendeesInput: AttendeesInput) {
    completeEnrollment(courseEnroll: $courseEnroll, attendeesInput: $attendeesInput) {
      messages
      hasError
    }
  }
`;

export const COMPLETE_UNENROLLMENT = gql`
  mutation CompleteUnenrollment($courseUnenroll: CourseUnenrollInput) {
    completeUnenrollment(courseUnenroll: $courseUnenroll) {
      messages
      hasError
    }
  }
`;

export const SEARCH_LEARNER = gql`
  query learnerSearch($searchText: String!, $isRoleBasedSearch: Boolean!) {
    learnerSearch(searchText: $searchText, isRoleBasedSearch: $isRoleBasedSearch) {
      id
      firstName
      lastName
      fullName
      email
    }
  }
`;

export const SAVE_SURVEY = gql`
  mutation saveSurveyAnswer($surveyAnswer: SaveSurveyInput) {
    saveSurvey(payload: $surveyAnswer)
  }
`;

export const GET_CONTENT_LIST = gql`
  query ContentContainer($parentId: String, $parentType: String, $sort: SortInput) {
    contentListById(parentId: $parentId, parentType: $parentType, sort: $sort) {
      id
      name
      summary
      description
      createdOn
      updatedOn
      updatedOnDisplay
      tags
      contentMetrics {
        numberOfCourses
        numberOfPathways
        numberOfCertifications
        numberOfCoursesCompleted
        numberOfPathwaysCompleted
        numberOfCertificationsCompleted
      }
      hasCertificate
      isEnrolled
      isNew
      percentageComplete
      rating
      numberOfPeopleWhoRated
      statusCode
      isAutoEnrolled
      contents {
        id
        name
        summary
        contentType
        studyModes
        durationDisplay
        percentageComplete
        createdOn
        updatedOn
        dueDate
        price
        isNew
        isEnrolled
        hasActivities
        tags
        imageUrl
        statusCode
        hasCertificate
        rating
        numberOfPeopleWhoRated
        source
        children {
          id
          name
          summary
          contentType
          studyModes
          durationDisplay
          percentageComplete
          createdOn
          updatedOn
          dueDate
          price
          isNew
          isEnrolled
          hasActivities
          tags
          imageUrl
          statusCode
          hasCertificate
          rating
          numberOfPeopleWhoRated
          source          
        }
      }
    }
  }
`;

export const COMPLETE_PATHWAY_ENROLLMENT = gql`
  mutation CompletePathwayEnrollment($pathwayId: String) {
    completePathwayEnrollment(pathwayId: $pathwayId) {
      courseId
      courseName
      canEnroll
      isEnrolled
    }
  }
`;

export const COMPLETE_PATHWAY_UNENROLLMENT = gql`
  mutation CompletePathwayUnenrollment($pathwayId: String) {
    completePathwayUnenrollment(pathwayId: $pathwayId) {
      messages
      hasError
    }
  }
`;

export const COMPLETE_CHANNEL_ENROLLMENT = gql`
  mutation CompleteChannelEnrollment($channelId: String) {
    completeChannelEnrollment(channelId: $channelId) {
      messages
      hasError
    }
  }
`;

export const COMPLETE_CHANNEL_UNENROLLMENT = gql`
  mutation CompleteChannelUnenrollment($channelId: String) {
    completeChannelUnenrollment(channelId: $channelId) {
      messages
      hasError
    }
  }
`;

export const SURVEY_DATA = gql`
  query SurveyData {
    survey {
      surveyId
      answeredDate
      title
      htmlText
      questions {
        questionId
        htmlText
        options {
          optionId
          htmlText
          isSelected
        }
      }
    }
  }
`;

export const GET_DIRECT_LINE_TOKEN = gql`
query DirectLineToken {
  directLineToken {
    token
  }
}
`;
export const EMAIL_UPDATE_STATUS = gql`
  query IsUpdateEmailRequestPending {
    isUpdateEmailRequestPending
  }
`;

export const CONTENT_RATING = gql`
  query ContentRating($contentId: String, $contentType: ContentType!) {
    contentRating(contentId: $contentId, contentType: $contentType)
  }
`;

export const LEARNER_CONTENT_RATING = gql`
  query LearnerRatingForContent($contentId: String, $contentType: ContentType!) {
    learnerRatingForContent(contentId: $contentId, contentType: $contentType)
  }
`;

export const SAVE_PLAYLIST = gql`
  mutation SavePlaylist($payload: SavePlaylistParametersInput) {
    savePlaylist(payload: $payload) {
      messages
      hasError
    }
  }
`;

export const EDIT_PLAYLIST = gql`
  mutation EditPlaylist($payload: EditPlaylistParametersInput) {
    editPlaylist(payload: $payload) {
      messages
      hasError
    }
  }
`;

export const DELETE_PLAYLIST = gql`
  mutation DeletePlaylist($playlistId: Uuid!) {
    deletePlaylist(playlistId: $playlistId) {
      messages
      hasError
    }
  }
`;

export const ADD_CONTENT_TO_PLAYLIST = gql`
  mutation AddContentToPlaylist($playlistId: Uuid!, $contentId: String, $contentType: PlaylistContentType!) {
    addContentToPlaylist(playlistId: $playlistId, contentId: $contentId, contentType: $contentType ) {
      messages
      hasError
    }
  }
`;

export const REMOVE_CONTENT_FROM_PLAYLIST = gql`
  mutation RemoveContentFromPlaylist($playlistId: Uuid!, $contentId: String) {
    removeContentFromPlaylist(playlistId: $playlistId, contentId: $contentId) {
      messages
      hasError
    }
  }
`;

export const SAVE_LEARNER_CONTENT_RATING = gql`
  mutation SaveLearnerRatingForContent($contentId: String, $contentType: ContentType!, $rating: Int! ) {
    saveLearnerRatingForContent(contentId: $contentId, contentType: $contentType, rating: $rating) {
      messages
      hasError
    }
  }
`;

export const SKIP_SURVEY = gql`
  mutation SkipSurvey($surveyId: String) {
    skipSurvey(surveyId: $surveyId) {
      messages
      hasError
    }
  }
`;

export const PLAYLISTS = gql`
  query Playlist($courseId: String)  {
    playlists(courseId: $courseId) {
      id
      title
      contentIds
    }
  }
`;

export const SHARE_CONTENT = gql`
  mutation ShareContent($payload: ShareContentPayloadInput) {
    shareContent(payload: $payload) {
      messages
      hasError
    }
  }
`;

export const EXPRESS_INTEREST = gql`
  mutation expressInterest($expressInterestInputData: ExpressInterestInput) {
    expressInterest(expressInterestInputData: $expressInterestInputData) {
      messages
      hasError
    }
  }
`;

export const GET_LEARNERS_BY_LINEMANAGER = gql`
  query LearnersByLineManager {
    learnersByLineManager {
      id
      fullName
      email
    }
  }
`;


export const GET_FACETOFACE_ACTIVITIES = gql`
  query FaceToFaceActivities($courseId: String!) {
    faceToFaceActivities(courseId: $courseId) {
      id
      name
    }
  }
`;

export const GET_COURSES_PATHWAYS_BY_LEARNER = gql`
  query CoursesAndPathwaysByLearner($learnerId: Uuid!) {
    coursesAndPathwaysByLearner(learnerId: $learnerId) {
      id
      name
      contentType
      statusCode
      dueDate
      isReminderEnabled
      hasCertificate
    }
  }
`;

export const GET_EXPRESS_INTEREST_DATA = gql`
  query ExpressInterestData {
    customerExpressInterests {
      dates {
        interestedDate
        displayText
      }
      locations
    }
  }
`;

export const SEND_REMINDER = gql`
  mutation SendReminder($overdueReminderRequest: OverdueReminderRequestInput) {
    sendLearnerOverdueContentReminder(overdueReminderRequest: $overdueReminderRequest) {
      messages
      hasError
    }
  }
`;

export const GET_LAST_REMINDER_DATE = gql`
  query LastReminderDate($learnerId: Uuid!, $contentId: String, $contentType: ContentType!) {
    lastReminderDateTime(learnerId: $learnerId, contentId: $contentId, contentType: $contentType)
  }
`;

export const GET_LTI_LAUNCH_PARAMS = gql`
  query LTILaunchParameters($courseId: String, $activityId: String, $source: LTIContentSource!) {
    ltiLaunchParameters(courseId: $courseId, activityId: $activityId, source: $source) {
      learnerId
      contentUrl
      consumerKey
      nonce
      signature
      signatureMethod
      timestamp
      version
      ltiVersion
      ltiMessageType
    }
  }
`;

export const GET_SAS = gql`
  query SAS($parameters: AssignmentUploadParametersInput) {
    sas(parameters: $parameters) {
      sas
      uploadTypeKey
      uploadTypeValue
      fileRelativePath
      customMetadata {
        key
        value
      }
    }
  }
`;

export const SCAN_UPLOADED_FILE = gql`
  mutation ScanUploadedFile($fileRelativePath: String!) {
    scanUploadedFile(fileRelativePath: $fileRelativePath)
  }
`;

export const GET_EMBEDDED_PBI_PARAMS = gql`
  query EmbedParams {
    embedParams {
      reportId
      reportName
      embedUrl
      embedToken
    }
  }
`;

export const CAN_LAUNCH_COURSE_BY_PATHWAY = gql`
  query CanLaunchCourseBySequencialPathway($courseId: String!){
    canLaunchCourseBySequencialPathway(courseId: $courseId) {
      canLaunch
      enrolledPathwayId
      blockingPathways {
			  id
        name
      }
    }
  }
`;

export const CAN_CHANGE_COMPLETE_TO_ENROLL = gql`
  query CanChangeCompletedStatusToEnroll($pathwayId: String!){
    canChangeCompletedStatusToEnroll(pathwayId: $pathwayId)
  }
`;

export const GET_ASSIGNMENT_TEMPLATE = gql`
  query AssignmentTemplate($programmeId: String!, $activityId: String!) {
    assignmentTemplateUri(programmeId: $programmeId, activityId: $activityId)
  }
`;

export const GET_NOTIFICATIONS = gql`
  query Notifications {
    notificationByLearnerId {
      body
      createdOn
      id
      metadata
      readOn
      title
      type
    }
  }
`;

export const DELETE_ALL_NOTIFICATIONS = gql`
  mutation DeleteAllNotifications {
    deleteAllNotificationsByLearnerId {
      messages
      hasError
    }
  }
`;

export const DELETE_NOTIFICATION = gql`
  mutation DeleteNotification ($notificationId: Uuid!) {
    deleteNotificationById(notificationId: $notificationId) {
      messages
      hasError
    }
  }
`;

export const MARK_NOTIFICATIONS_AS_READ = gql`
  mutation SetNotificationReadOn {
    setNotificationReadOn {
      messages
      hasError
    }
  }
`;

export const PORTAL_DISPLAY_INFO = gql`
  query PortalDisplayInfo {
    portalDisplayInformation {
      category
      settings {
        item
        attributesJson
      }
    }
  }
`;

export const LOCALIZATION = gql`
  query Localization {
    localizationData {
      code
      localText
    }
  }
`;


export const GET_ALL_SESSIONS = gql`
  query AllSessions($skip: Int!, $count: Int!, $searchTerm: String!){
    allSessions(
      skip: $skip
      count: $count
      searchTerm: $searchTerm
    ){
      totalCount
      data{
        sessionId
        programmeName
        activityName
        startDate
        endDate
        location
        externalSessionId        
        sessionName
      }
    }
  }
`;

export const GET_ATTENDANCES = gql`
    query SessionAttendees($sessionId: String){
       sessionAttendees(sessionId: $sessionId)
        {
            attendees
            {
                learnerId
                firstName
                lastName
                email
                attendanceStatus
            }
            sessionId
            programmeId
            externalSessionId
            programmeName
            activityName
            startDate
            endDate
            location
            activityId
            activityType
            sessionName
        }
    }
`;

export const UPDATE_ATTENDANCE = gql`
  mutation UpdateAttendance($model: UpdateSessionAttendanceModelInput) {
    saveAttendance(model: $model) {
      messages
      hasError
    }
  }
`;

export const GET_CONTENT_SUGGESTION = gql`
  query SuggestContent($searchTerm: String) {
    suggestContents(searchTerm: $searchTerm) {
      id
      name
      contentType
    }
  }
`;

export const GET_COURSE_PLAYER = gql`
  query CoursePlayer ($programmeId: String, $activityId: String) {
    player (programmeId: $programmeId, activityId: $activityId) {
      loadSuccessful
      sessionRefreshInterval
      playerHeaderModel {
        id
        name
      }
      playerBodyModel {
        id
        uri
        audioPosterUrl
        encryptedTenantId
        scormDataModel
        learnerModel {
          id
          email
          firstName
          lastName
        }
        activityModel {
          id
          name
          url
          type
          typeName
        }
        scormPaths {
          portHoleJSPath
          bundleJSPath
          proxyHtmlPath
          contentWrapperHtmlPath
        }
      }
    }
  }
`;

export const COMPLETE_ACTIVITY = gql`
  mutation CompleteActivity ($model: CompleteLearnersActivityInput) {
    completeLearnersActivity(model: $model){
      messages
      hasError
    }
  }
`;

export const GET_ACTIVITY_ATTENDEES = gql`
  query ActivityAttendees ($activityId: String, $searchTerm: String, $skip: Int, $count: Int) {
    activityAttendees(activityId: $activityId, searchTerm: $searchTerm, skip: $skip, count: $count) {
      numberOfAttendees
      numberOfCompletedAttendees
      programmeId
      programmeName
      activityId
      activityName
      activityType
      attendees {
        learnerId
        firstName
        lastName
        completionDate
      }
    }
  }
`;

export const GET_ALL_ACTIVITIES = gql`
  query AllActivities ($searchTerm: String, $skip: Int, $count: Int) {
    allActivities (searchTerm: $searchTerm, skip: $skip, count: $count) {
      totalCount
      data {
        programmeName
        activityId
        activityName
      }
    }
  }
`;

export const GET_NOTIFICATIONS_METRICS = gql`
  query NotificationMetrics {
    notificationsMetrics{
      unreadNotificationsCount
      totalNotificationsCount
    }
  }
`;

export const GET_REPORTS = gql`
  query Reports {
    diagnosticReports {
      id
      title
      url
      date
      status
    }  
  }
`;

export const GET_MY_WORKSHOPS = gql`
  query LearnerWorkshops ($sort: LearnerWorkshopActivitiesSortInput, $skip: Int!, $count: Int!) {
    learnerWorkshopActivities(sort:$sort, skip:$skip,count: $count) {
      totalLearnerWorkshopActivitiesCount 
      activities {
        programmeId
        programmeName
        activityName
        startDate
        location
      }
    }
  }
`;

export const GET_LEARNER_SKILL_ASSESSMENTS = gql`
  query LearnerSkillAssessments {
    learnerSkillAssessments {
      skillAssessmentId
      skillName
      externalAssesmentId
      status
      skillRating     
    }
  }
`;
