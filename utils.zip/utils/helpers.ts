import {
  SORT_ALPHABETICAL_ASCENDING,
  SORT_ALPHABETICAL_DESCENDING,
  SORT_DEFAULT,
  SORT_DURATION_ASCENDING,
  SORT_DURATION_DESCENDING,
  SORT_PRICE_ASCENDING,
  SORT_PRICE_DESCENDING,
} from "utils/constants";
import { SortType } from "utils/types";
import { ContentType, SortBy } from "./graphql/Global";
import portalSettingsManager from "utils/portalSettingsManager";

export const parseSortType = (
  sort: SortType
): { sortBy: SortBy.NAME | SortBy.DURATION | SortBy.PRICE | SortBy.DEFAULT; isAscending: boolean } => {
  switch (sort) {
    case SORT_ALPHABETICAL_ASCENDING:
      return { sortBy: SortBy.NAME, isAscending: true };
    case SORT_ALPHABETICAL_DESCENDING:
      return { sortBy: SortBy.NAME, isAscending: false };
    case SORT_DURATION_ASCENDING:
      return { sortBy: SortBy.DURATION, isAscending: true };
    case SORT_DURATION_DESCENDING:
      return { sortBy: SortBy.DURATION, isAscending: false };
    case SORT_PRICE_ASCENDING:
      return { sortBy: SortBy.PRICE, isAscending: true };
    case SORT_PRICE_DESCENDING:
      return { sortBy: SortBy.PRICE, isAscending: false };
    case SORT_DEFAULT:
      return { sortBy: SortBy.DEFAULT, isAscending: true };
    default:
      return { sortBy: SortBy.NAME, isAscending: true };
  }
};

export const emailRegex =
  /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

export const getContentType = (key: string): ContentType | undefined => {
  switch (key.toLowerCase()) {
    case "pathway":
      return ContentType.PATHWAY;
    case "channel":
      return ContentType.CHANNEL;
    case "course":
      return ContentType.COURSE;
    case "playlist":
      return ContentType.PLAYLIST;
    default:
      break;
  }
};

// returns date formatted in DD MMM, YYYY
// example: 24 Oct, 2020
export const mobileDateString = (date: Date): string => {
  const [, month, day, year] = date.toString().split(" ");
  return `${day} ${month}, ${year}`;
};

export const dueDateFormat = (date: string): string => {
  if (date?.toLowerCase().indexOf("z") > -1) {
    const utcInputDate = new Date(date);
    const year = utcInputDate.getUTCMonth() < 11 ? utcInputDate.getUTCFullYear() : utcInputDate.getUTCFullYear() + 1;
    const month = utcInputDate.getUTCMonth() < 11 ? utcInputDate.getUTCMonth() + 1 : 0;
    const day = utcInputDate.getUTCDate();
    return `${month}.${day}.${year}`;
  } else {
    const today = new Date(date);
    const day = String(today.getDate()).padStart(2, '0');
    const month = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    const year = today.getFullYear().toString().substring(2);;
    return `${month}.${day}.${year}`;
  }
};

export const formatTime = (inputTimeString = ''): string => {
  if (inputTimeString && inputTimeString.includes('hrs')) {
    const hrPrefix: string = inputTimeString.split(' ')[0];
    if (hrPrefix && Number(hrPrefix) && Number(hrPrefix) < 1) {
      const numberInMin = (Number(hrPrefix) * 60).toFixed(2);
      const decimalValue = ((numberInMin + '').split('.'))[1];
      return `${decimalValue === '00' ? parseFloat(numberInMin) : numberInMin} mins`;
    }
    return inputTimeString;
  }
  return inputTimeString;
}

export const openContactUs = (): void => {
  const { emailId, body = "", subject = "" } = portalSettingsManager.application?.common?.contactUs || {};
  const mailToUrl = `mailto:${emailId}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  window.location.href = mailToUrl;
}
