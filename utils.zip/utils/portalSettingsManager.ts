/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import { PortalDisplayInfo_portalDisplayInformation } from "utils/graphql/PortalDisplayInfo";
import { SESSION_STOREAGE_KEYS } from "./constants";
interface ElementColorSettings {
    back: string | undefined;
    text: string | undefined;
    border: string | undefined;
}

interface ElementFontSettings {
    name: string | undefined;
    size: string | undefined;
    color: string | undefined;
}

interface SectionFontSettings {
    titleFont: ElementFontSettings | undefined;
    summaryFont: ElementFontSettings | undefined;
}

interface ModeColorSettings {
    active: ElementColorSettings | undefined;
    inactive: ElementColorSettings | undefined;
    hover: ElementColorSettings | undefined;
}

interface EmailSettings {
    emailId: string | undefined;
    body: string | undefined;
    subject: string | undefined;
}

interface CommonSettings {
    applicationName: string | undefined;
    themeColor: string | undefined;
    contactUs: EmailSettings | undefined;
    uiDirection: string | undefined;
    isWelcomeMessagePersistent: boolean | undefined;
    greetLearnerByName: boolean | undefined;
    landingPageSectionsOrder: string[] | undefined;
    showMyLearningSectionAsCarousal: boolean | undefined;
}

interface FeatureSettings {
    showLearnerMetricsOnProfilePage: boolean | undefined;
    allowCreatePlaylist: boolean | undefined;
    allowShareContent: boolean | undefined;
    allowChat: boolean | undefined;
    allowContentSearch: boolean | undefined;
    showPersonalDetails: boolean | undefined;
    showProfessionalDetails: boolean | undefined;
    canChangeEmailAddress: boolean | undefined;
    enableContentRating: boolean | undefined;
    enableCatalogFilter: boolean | undefined;
    hasProfileReport: boolean | undefined;
    isLineManagerRequiredInF2FEnrollment: boolean | undefined;
    hasSkillAssessment: boolean | undefined;
    launchLinkedInWithLTI: boolean | undefined;
}

interface LogoSettings {
    url: string | undefined;
    widthInPixel: number | undefined;
    heightInPixel: number | undefined;
}

interface HeaderColorSettings {
    base: ElementColorSettings | undefined;
    search: ElementColorSettings | undefined;
    searchIcon: ModeColorSettings | undefined;
    bellIcon: ElementColorSettings | undefined;
    profileIcon: ElementColorSettings | undefined;
    notificationCountBadge: ElementColorSettings | undefined;
    searchBoxCrossIcon: string | undefined;
    searchBoxPlaceholder: string | undefined;
}

interface ApplicationSettings {
    common?: CommonSettings | undefined;
    features?: FeatureSettings | undefined;
}

interface TileSettings {
    colors?: ModeColorSettings | undefined;
}

interface HeaderSettings {
    logo?: LogoSettings | undefined;
    colors?: HeaderColorSettings | undefined;
}

interface LandingPageSubHeaderSettings {
    colors?: LandingPageSubHeaderColorSettings | undefined;
}

interface QualnateSettings {
    routeIdentifiers?: RouteIdentifiersSettings | undefined;
}

interface RouteIdentifiersSettings {
    course: string | undefined;
    skill: string | undefined;
    url: string | undefined;
}

interface LandingPageSubHeaderColorSettings {
    base: ElementColorSettings | undefined;
    requiredIcon: ElementColorSettings | undefined;
    certificateIcon: ElementColorSettings | undefined;
    completeIcon: ElementColorSettings | undefined;
    welcomeText: ElementColorSettings | undefined;
    metricsNumbers: MetricsNumbersColorSettings | undefined;
}

interface MetricsNumbersColorSettings {
    complete: string | undefined;
    required: string | undefined;
    certificate: string | undefined;
}

interface FooterSettings {
    logo?: LogoSettings | undefined;
    links?: LinkSettings[] | undefined;
}

interface LinkSettings {
    type: string | undefined;
    url: string | undefined;    
}

interface ButtonColorSettings {
    normal?: ModeColorSettings | undefined;
    dark?: ModeColorSettings | undefined;
    enroll?: ModeColorSettings | undefined;
    showHideWelcomeText?:  ModeColorSettings | undefined;
    unenroll?: ModeColorSettings | undefined;
    themed?: ModeColorSettings | undefined;
}

interface StatusColorSettings {
    enrolled?: ElementColorSettings | undefined;
    inprogress?: ElementColorSettings | undefined;
    completed?: ElementColorSettings | undefined;
}
interface FontSettings {
    tile?: SectionFontSettings | undefined;
    wideTile?: SectionFontSettings | undefined;
    learningSection?: SectionFontSettings | undefined;
    toaster?: SectionFontSettings | undefined;
}

export interface PortalSettingsProps {
    application: ApplicationSettings | undefined;
    header: HeaderSettings | undefined;
    landingPageSubHeader: LandingPageSubHeaderSettings | undefined;
    qualnate: QualnateSettings | undefined;
    buttonColors: ButtonColorSettings | undefined;
    statusColors: StatusColorSettings | undefined;
    fonts: FontSettings | undefined;
    tile: TileSettings | undefined;
    footer: FooterSettings | undefined
}

class PortalSettings {
    private _application: ApplicationSettings = {};
    private _header: HeaderSettings = {};
    private _landingPageSubHeader: LandingPageSubHeaderSettings = {};
    private _qualnate: QualnateSettings = {};
    private _statusColors: StatusColorSettings = {};
    private _buttonColors: ButtonColorSettings = {};
    private _fonts: FontSettings = {};
    private _tile: TileSettings = {};
    private _footer: FooterSettings = {}

    private static _instance: PortalSettings;

    get application(): ApplicationSettings | undefined {
        return this._application;
    }
    get header(): HeaderSettings | undefined {
        return this._header;
    }
    get landingPageSubHeader(): LandingPageSubHeaderSettings | undefined {
        return this._landingPageSubHeader;
    }
    get qualnate(): QualnateSettings | undefined {
        return this._qualnate
    }
    get statusColors(): StatusColorSettings | undefined {
        return this._statusColors;
    }
    get buttonColors(): ButtonColorSettings | undefined {
        return this._buttonColors;
    }
    get fonts(): FontSettings | undefined {
        return this._fonts;
    }
    get tile(): TileSettings | undefined {
        return this._tile;
    }
    get footer(): FooterSettings | undefined {
        return this._footer;
    }

    private constructor() { }
    public static get Instance(): PortalSettings {
        if (!PortalSettings._instance) {
            PortalSettings._instance = new PortalSettings();
        }
        return PortalSettings._instance;
    }

    public Initialize(portalSettingsApiResponse: (PortalDisplayInfo_portalDisplayInformation | null)[] | null): PortalSettingsProps {
        if (portalSettingsApiResponse) {
            this.loadApplicationSettings(portalSettingsApiResponse);
            this.loadHeaderSettings(portalSettingsApiResponse);
            this.loadLandingPageSubHeaderSettings(portalSettingsApiResponse);
            this.loadQualnateSettings(portalSettingsApiResponse);
            this.loadButtonColorsSettings(portalSettingsApiResponse);
            this.loadStatusColorsSettings(portalSettingsApiResponse);
            this.loadFontsSettings(portalSettingsApiResponse);
            this.loadTileSettings(portalSettingsApiResponse);
            this.loadFooterSettings(portalSettingsApiResponse);
        }
        return this.GetSettings();
    }

    loadTileSettings(settings: any) {
        try {
            const tile = settings.find((c: { category: string; }) => c.category == "Tile");
            this._tile = tile;
            if (this._tile) {
                this._tile.colors = JSON.parse(tile?.settings?.find((i: { item: string; }) => i.item === "Colors").attributesJson || '{}') as ModeColorSettings;
            }
        } catch {
            console.error('Error Loading Tile Settings', settings);
        }
    }

    private loadStatusColorsSettings(settings: (PortalDisplayInfo_portalDisplayInformation | null)[] | null) {
        const statusColors = settings?.find((c => c?.category === "StatusColors"));
        if (statusColors) {
            ["enrolled", "inprogress", "completed"].forEach((status) => {
                this._statusColors[status as keyof StatusColorSettings] = JSON.parse(statusColors?.settings?.find(i => i?.item?.toLocaleLowerCase() === status.toLowerCase())?.attributesJson || '{}') as ElementColorSettings;
            });
        }
    }

    private loadButtonColorsSettings(settings: (PortalDisplayInfo_portalDisplayInformation | null)[] | null) {
        const btnColors = settings?.find((c => c?.category === "ButtonColors"));
        if (btnColors) {
            ["normal", "dark", "enroll", "showHideWelcomeText", "unenroll", "themed"].forEach((mode) => {
                this._buttonColors[mode as keyof ButtonColorSettings] = JSON.parse(btnColors?.settings?.find(i => i?.item?.toLocaleLowerCase() === mode.toLowerCase())?.attributesJson || '{}') as ModeColorSettings;
            });
        }
    }

    private loadHeaderSettings(settings: (PortalDisplayInfo_portalDisplayInformation | null)[] | null) {
        try {
            const header = settings?.find((c => c?.category === "Header"));
            if (header) {
                this._header.colors = JSON.parse(header?.settings?.find(i => i?.item?.toLocaleLowerCase() === "colors")?.attributesJson || '{}') as HeaderColorSettings;
                this._header.logo = JSON.parse(header?.settings?.find(i => i?.item?.toLocaleLowerCase() === "logo")?.attributesJson || '{}') as LogoSettings;
            }
        } catch {
            console.error('Error Loading Header Settings', settings);
        }
    }

    private loadLandingPageSubHeaderSettings(settings: (PortalDisplayInfo_portalDisplayInformation | null)[] | null) {
        try {
            const landingpagesubheader = settings?.find((c => c?.category === "LandingPageSubHeader"));
            if (landingpagesubheader) {
                this._landingPageSubHeader.colors = JSON.parse(landingpagesubheader?.settings?.find(i => i?.item?.toLocaleLowerCase() === "colors")?.attributesJson || '{}') as LandingPageSubHeaderColorSettings;
            }
        } catch {
            console.error('Error Loading Landing Page Sub Header Settings', settings);
        }
    }

    private loadQualnateSettings(settings: (PortalDisplayInfo_portalDisplayInformation | null)[] | null) {
        try {
            const qualnate = settings?.find((c => c?.category === "Qualnate"));
            if (qualnate) {
                this._qualnate.routeIdentifiers  = JSON.parse(qualnate?.settings?.find(i => i?.item?.toLocaleLowerCase() === "routeidentifiers")?.attributesJson || '{}') as RouteIdentifiersSettings;
            }
        } catch {
            console.error('Error Loading Qualnate Settings', settings);
        }
    }

    private loadFooterSettings(settings: (PortalDisplayInfo_portalDisplayInformation | null)[] | null) {
        try {
            const footer = settings?.find((c => c?.category === "Footer"));
            if (footer) {
                this._footer.logo = JSON.parse(footer?.settings?.find(i => i?.item?.toLocaleLowerCase() === "logo")?.attributesJson || '{}') as LogoSettings;
                this._footer.links = JSON.parse(footer?.settings?.find(i => i?.item?.toLocaleLowerCase() === "links")?.attributesJson || '[]') as LinkSettings[];
            }
        } catch {
            console.error('Error Loading Footer Settings', settings);
        }
    }

    private loadApplicationSettings(settings: (PortalDisplayInfo_portalDisplayInformation | null)[] | null) {
        try {
            const application = settings?.find((c => c?.category === "Application"));
            if (application) {
                this._application.common = JSON.parse(application?.settings?.find(i => i?.item?.toLocaleLowerCase() === "common")?.attributesJson || '{}') as CommonSettings;
                this._application.features = JSON.parse(application?.settings?.find(i => i?.item?.toLocaleLowerCase() === "features")?.attributesJson || '{}') as FeatureSettings;
                sessionStorage.setItem(SESSION_STOREAGE_KEYS.THEME_COLOR, this._application?.common?.themeColor);
            }
        } catch {
            console.error('Error Loading Application Settings', settings);
        }
    }

    private loadFontsSettings(settings: (PortalDisplayInfo_portalDisplayInformation | null)[] | null) {
        try {
            const fonts = settings?.find((c => c?.category === "Fonts"));
            if (fonts) {
                this._fonts.learningSection = JSON.parse(fonts?.settings?.find(i => i?.item?.toLocaleLowerCase() === "learningsection")?.attributesJson || '{}') as SectionFontSettings;
                this._fonts.tile = JSON.parse(fonts?.settings?.find(i => i?.item?.toLocaleLowerCase() === "tile")?.attributesJson || '{}') as SectionFontSettings;
                this._fonts.wideTile = JSON.parse(fonts?.settings?.find(i => i?.item?.toLocaleLowerCase() === "widetile")?.attributesJson || '{}') as SectionFontSettings;
                this._fonts.toaster = JSON.parse(fonts?.settings?.find(i => i?.item?.toLocaleLowerCase() === "toaster")?.attributesJson || '{}') as SectionFontSettings;
            }
        } catch {
            console.error('Error Loading Font Settings', settings);
        }
    }

    public GetSettings(): PortalSettingsProps {
        return {
            application: this.application,
            header: this.header,
            landingPageSubHeader: this.landingPageSubHeader,
            qualnate: this.qualnate,
            buttonColors: this.buttonColors,
            statusColors: this.statusColors,
            fonts: this.fonts,
            tile: this.tile,
            footer: this.footer
        };
    }    
}

export default PortalSettings.Instance;