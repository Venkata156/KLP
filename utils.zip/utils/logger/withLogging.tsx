/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import React, { ErrorInfo, ReactNode } from 'react';
import { withAITracking } from '@microsoft/applicationinsights-react-js';
import { reactPlugin, isTelemetryEnabled, appInsights } from './appInsights';
import { SeverityLevel, ApplicationInsights } from "@microsoft/applicationinsights-web";
export default function withLogging(Component: any): any {
    return (
        <AppInsightsErrorBoundary onError={() => <h1>I believe something went wrong</h1>} appInsights={appInsights} isTelemetryEnabled={isTelemetryEnabled}>
            {isTelemetryEnabled ? withAITracking(reactPlugin, Component, "Root") : Component}
        </AppInsightsErrorBoundary>
    );
};
withLogging.displayName = 'withLogging';

type AppInsightsErrorBoundaryProps = {
    onError: () => ReactNode;
    appInsights: ApplicationInsights;
    isTelemetryEnabled: boolean;
}

type AppInsightsErrorBoundaryState = {
    hasError: boolean;
}

class AppInsightsErrorBoundary extends React.Component<AppInsightsErrorBoundaryProps, AppInsightsErrorBoundaryState> {
    state = { hasError: false };

    componentDidCatch(error: Error, info: ErrorInfo): void {
        this.setState({ hasError: true });
        this.props.isTelemetryEnabled && this.props.appInsights.trackException({
            error: error,
            exception: error,
            severityLevel: SeverityLevel.Error,
            properties: { ...info }
        });
    }

    render(): ReactNode {
        if (this.state.hasError) {
            const { onError } = this.props;
            return typeof onError === "function"
                ? onError()
                : React.createElement(onError);
        }
        return React.createElement(this.props.children as React.ComponentType);
    }
}