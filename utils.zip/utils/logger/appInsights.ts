/* eslint-disable @typescript-eslint/no-explicit-any */
import { ApplicationInsights, ITelemetryPlugin } from '@microsoft/applicationinsights-web';
import { ReactPlugin } from '@microsoft/applicationinsights-react-js';
import { createBrowserHistory } from "history";
import { tenantSettings } from "utils/authentication/tenantSettings";
let reactPlugin: any = {};
let appInsights: any = {};
const browserHistory = createBrowserHistory({ basename: '' });

export const isTelemetryEnabled = tenantSettings.customConfig?.aiKey && tenantSettings.customConfig?.aiKey.length > 0 && tenantSettings.customConfig?.enableTelemetry;

const telemetryInitializer = (envelope) => {
    if (envelope.data) {
        envelope.data["tenantId"] = tenantSettings?.adConfiguration?.auth?.clientId;
    }
};

if (isTelemetryEnabled) {
    reactPlugin = new ReactPlugin();
    appInsights = new ApplicationInsights({
        config: {
            instrumentationKey: tenantSettings.customConfig.aiKey,
            // doing this to avoid type error: https://github.com/microsoft/ApplicationInsights-JS/issues/1324
            extensions: [reactPlugin as unknown as ITelemetryPlugin],
            enableAutoRouteTracking: true,
            extensionConfig: {
                [reactPlugin.identifier]: { history: browserHistory }
            }
        }
    });
    appInsights.loadAppInsights();
    appInsights.addTelemetryInitializer(telemetryInitializer);
}

export { reactPlugin, appInsights };