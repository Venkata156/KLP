import { appInsights, isTelemetryEnabled } from './appInsights';
import { SeverityLevel } from "@microsoft/applicationinsights-web";
import { ICustomProperties } from "@microsoft/applicationinsights-core-js";
import { noop } from 'lodash';

class Logger {
    private static trace(message: string, severityLevel: SeverityLevel, properties: ICustomProperties = {}) {
        appInsights.trackTrace({
            message,
            severityLevel,
        }, properties);
    }

    static log(message: string, additionalInfo: ICustomProperties = {}): void {
        this.trace(message, SeverityLevel.Verbose, additionalInfo);
    }

    static info(info: string, additionalInfo: ICustomProperties = {}): void {
        this.trace(info, SeverityLevel.Information, additionalInfo);
    }

    static warn(warningMessage: string, additionalInfo: ICustomProperties = {}): void {
        this.trace(warningMessage, SeverityLevel.Warning, additionalInfo);
    }

    static error(error: string, info: ICustomProperties = {}): void {
        this.exception(new Error(error), info);
    }

    static critical(error: string, info: ICustomProperties = {}): void {
        this.exception(new Error(error), info, SeverityLevel.Critical);
    }

    static exception(error: Error, info: ICustomProperties = {}, severityLevel: SeverityLevel = SeverityLevel.Error): void {
        appInsights.trackException({
            error,
            exception: error,
            severityLevel,
            properties: { ...info }
        });
    }

    static setAuthenticatedUserContext(userEmail: string, userId: string, storeInCookie = true): void {
        appInsights.setAuthenticatedUserContext(userEmail, userId, storeInCookie);
    }
}
declare global {
    interface Console {
        critical: (error: string, info: ICustomProperties) => void;
        setAuthenticatedUserContext: (userEmail: string, userId: string, storeInCookie: boolean) => void;
    }
}

console.critical = console.error;
console.setAuthenticatedUserContext = noop;

export default isTelemetryEnabled ? Logger : console;