interface SessionManagerProps {
  timeout: number;
  onTimeout: () => void;
  onExpired: () => void;
  onAutoRenew?: () => void;
}
export interface TimeProps {
  minutes: number;
  seconds: number;
}
class SessionManager {
  timeout!: number;
  onTimeout?: () => void;
  onAutoRenew?: () => void;
  eventHandler!: () => void;
  interval!: NodeJS.Timeout;
  autoRenewEnabled = false;
  tokenLastFetchedAt = 0;

  timeoutTracker!: NodeJS.Timeout;

  constructor() {
    this.eventHandler = this.updateExpiredTime.bind(this);
    this.cleanUp = this.cleanUp.bind(this);
    this.tracker = this.tracker.bind(this);
    this.startInterval = this.startInterval.bind(this);
    this.shouldForceFetchToken = this.shouldForceFetchToken.bind(this);
  }

  startInterval(): void {
    this.updateExpiredTime();
    this.interval = setInterval(() => {
      const isExpiredTimeExist = sessionStorage.getItem("_expiredTime") !== null;
      const expTime: string = sessionStorage.getItem("_expiredTime") ?? "0";
      const expiredTime = parseInt(expTime, 10);
      if (this.shouldForceFetchToken()) {
        this.renew(false);
      } else if (isExpiredTimeExist && expiredTime < Date.now() && this.onTimeout) {
        if (this.autoRenewEnabled) {
          this.renew();
        } else {
          this.onTimeout();
          this.cleanUp();
        }
      }
    }, 1000);
  }

  shouldForceFetchToken = () => {
    // if token was fetched in last 15 minutes, don't fetch again
    return this.tokenLastFetchedAt + (15 * 60000) < Date.now();
  }

  get forceLogoutAt(): number {
    return parseInt(sessionStorage.getItem("_expiredTime") ?? "0", 10) + (5 * 60000);
  }

  get isExpired(): boolean {
    const isExpiredTimeExist = sessionStorage.getItem("_expiredTime") !== null;
    return isExpiredTimeExist && this.forceLogoutAt < Date.now();
  }

  get timeLeft(): TimeProps {
    const reminaingTimeInSeconds = (this.forceLogoutAt - Date.now()) / 1000;
    return { minutes: Math.floor(reminaingTimeInSeconds / 60), seconds: Math.floor(reminaingTimeInSeconds % 60) };
  }

  async renew(updateExpiredTime = true): Promise<void> {
    if (updateExpiredTime) {
      this.updateExpiredTime();
    }
    this.updateTokenLastFetchedAt();
    return this.onAutoRenew?.();
  }

  enableAutoRenewal(): void {
    this.autoRenewEnabled = true;
  }

  disableAutoRenewal(): void {
    this.autoRenewEnabled = false;
  }

  updateExpiredTime(): void {
    sessionStorage.setItem("_expiredTime", (Date.now() + this.timeout * 1000).toString());
  }

  tracker(): void {
    window.addEventListener("mousemove", this.eventHandler);
    window.addEventListener("scroll", this.eventHandler);
    window.addEventListener("keydown", this.eventHandler);
  }

  cleanUp(): void {
    clearInterval(this.interval);
    window.removeEventListener("mousemove", this.eventHandler);
    window.removeEventListener("scroll", this.eventHandler);
    window.removeEventListener("keydown", this.eventHandler);
  }

  initialize(props: SessionManagerProps): void {
    const expiredTime = parseInt(sessionStorage.getItem("_expiredTime") ?? "0", 10);
    this.timeout = props.timeout;
    this.onTimeout = props.onTimeout;
    if (expiredTime > 0 && expiredTime < Date.now()) {
      props.onExpired();
      return;
    }
    this.tracker();
    this.startInterval();
  }

  updateTokenLastFetchedAt(): void {
    this.tokenLastFetchedAt = Date.now();
  }
}

const sessonManager: SessionManager = new SessionManager();

export default sessonManager;
