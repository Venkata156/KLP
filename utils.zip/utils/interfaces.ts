export interface GenericNumberMap {
  [key: number]: number | null;
}
