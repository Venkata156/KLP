import { isEmpty, startCase } from "lodash";

declare global {
  interface String {
    toAddPostFix(postfixStrArr: Array<string>): string;
    format(...replacements: string[]): string;
    toTitleCase(): string;
  }
}

String.prototype.toAddPostFix = function (postfixStrArr: Array<string>) {
  let retStr = "";

  if (isEmpty(this))
    return retStr;

  const lastChar = this.charAt(this.length - 1);

  postfixStrArr.includes(lastChar)
    ? retStr = startCase(`${this}`) + `${lastChar}`
    : retStr = startCase(`${this}`);

  return retStr;
}

String.prototype.toTitleCase = function () {
  return this.split(' ').map((txt: string) => `${txt?.charAt(0)?.toUpperCase()}${txt?.substr(1)?.toLowerCase()}`).join(' ')
}

if (!String.prototype.format) {
  /**
   * String.format
   * usage: 'first arguments {0} second Argument {1}'.format('a', 'b');
   * @param {comma separated strings} ...args
   * @returns {string}
   */
  String.prototype.format = function (...args) {
    return this.replace(/{(\d+)}/g, function (match, number) {
      return typeof args[number] != 'undefined'
        ? args[number]
        : match
        ;
    });
  };
}
