export type CategoryCodeRequired = "MyLearning";
export type CategoryCodeRecommended = "Recommendations";
export type CategoryCodePopular = "Popular";
export type CategoryCodeMyInterest = "Playlist";
export type CategoryCodeChannel = "Channel";
export type CategoryCodeParentPathway = "ParentPathway";
export type CategoryCodeAll = "All";
export type CategoryCode =
  | CategoryCodeRequired
  | CategoryCodeRecommended
  | CategoryCodePopular
  | CategoryCodeMyInterest
  | CategoryCodeChannel
  | CategoryCodeParentPathway
  | CategoryCodeAll;

export type SortTypeAlphabeticalAscending = "SORT_ALPHABETICAL_ASCENDING";
export type SortTypeAlphabeticalDescending = "SORT_ALPHABETICAL_DESCENDING";
export type SortTypeDurationAscending = "SORT_DURATION_ASCENDING";
export type SortTypeDurationDescending = "SORT_DURATION_DESCENDING";
export type SortTypePriceAscending = "SORT_PRICE_ASCENDING";
export type SortTypePriceDescending = "SORT_PRICE_DESCENDING";
export type SortTypeNone = "SORT_NONE";
export type SortTypeDefault = "SORT_DEFAULT";

export type SortType =
  | SortTypeAlphabeticalAscending
  | SortTypeAlphabeticalDescending
  | SortTypeDurationAscending
  | SortTypeDurationDescending
  | SortTypePriceAscending
  | SortTypePriceDescending
  | SortTypeNone
  | SortTypeDefault;

export type ProfileFieldTypeSingleLineText = "SingleLineText";
export type ProfileFieldTypeNumber = "number";
export type ProfileFieldTypeSingleSelectDropdown = "SingleSelectDropdown";
export type ProfileFieldType =
  | ProfileFieldTypeSingleLineText
  | ProfileFieldTypeNumber
  | ProfileFieldTypeSingleSelectDropdown;

export type ProfileTabTypeDetails = 0;
export type ProfileTabTypeTopics = 1;
export type ProfileTabTypeCouncelees = 2;
export type ProfileTabTypeLearner = 3;
export type ProfileTabTypeCalendar = 4;
export type ProfileTabTypeSkills = 5;
export type ProfileTabType = ProfileTabTypeDetails | ProfileTabTypeTopics | ProfileTabTypeCouncelees | ProfileTabTypeLearner | ProfileTabTypeCalendar | ProfileTabTypeSkills;

export type EnrollmentStepTypeWorkshops = "WORKSHOPS";
export type EnrollmentStepTypeEnrollee = "ENROLLEE";
export type EnrollmentStepTypeTerms = "TERMS";
export type EnrollmentStepTypePrerequisites = "PREREQUISITES";
export type AdminEnrollStep = "ADMIN_ENROLL";
export type AdminConfirmStep = "ADMIN_CONFIRM";
export type EnrollmentStepType =
  | EnrollmentStepTypeWorkshops
  | EnrollmentStepTypeEnrollee
  | EnrollmentStepTypeTerms
  | EnrollmentStepTypePrerequisites
  | AdminConfirmStep
  | AdminEnrollStep;

export const enum PathwayType {
  playlist = "playlist",
  channel = "channel",
  pathway = "pathway",
  parentpathway = 'parentpathway'
};
