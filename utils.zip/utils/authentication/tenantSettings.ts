import { Configuration } from "@azure/msal-browser";
import { cloneDeep, isEmpty } from 'lodash';
import { AUTH_PROVIDERS, TOKENS } from "utils/constants";
import { IAuthenticationService } from "./IAuthenticationService";
import { AzureAuthenticationService } from "./AzureAuthenticationService";
import { OptimalAuthenticationService } from "./OptimalAuthenticationService";

export enum AuthenticationMode {
    AZURE_AD = "AzureAD",
    B2C = "B2C"
}
interface Api {
    baseUrl: string;
    scopes: string[];
}
interface TenantSettings {
    hostname: string;
    clientId: string;
    authenticationMode: string;
    authority: string;
    resetPasswordUrl: string;
    timeout: number;
    serviceNowUrl: string;
    api: Api;
    aiKey: string;
    enableTelemetry: boolean;
    idp: string;
    requestHeaders: IRequestHeader[]
}
export interface TenantConfiguration {
    customConfig: {
        timeout: number,
        api: Api,
        serviceNowUrl: string,
        authenticationMode: string;
        resetPasswordUrl: string;
        aiKey?: string;
        enableTelemetry?: boolean;
        requestHeaders?: IRequestHeader[]
        getRequestHeaders?(idToken: string, accessToken: string): { [key: string]: number }
    },
    idp: string,
    adConfiguration: Configuration,
    authService?: IAuthenticationService
}
interface IRequestHeader {
    keyName: string,
    valueName: string
}
interface ConfigMapper {
    [key: string]: TenantConfiguration
}

const GetTenantConfigurations = (): ConfigMapper => {
    const configurationsString = process.env.REACT_APP_TENANT_CONFIGURATIONS as string;
    let configurations: TenantSettings[] = [];
    const configMapper: ConfigMapper = {};
    try {
        configurations = JSON.parse(configurationsString) as TenantSettings[];
    }
    catch {
        console.error('Invalid tenant configurations');
        return configMapper;
    }
    configurations.forEach(configuration => {
        const config = cloneDeep(defaultConfig);
        config.adConfiguration.auth.clientId = configuration.clientId;
        config.adConfiguration.auth.authority = configuration.authority;

        if (configuration.authenticationMode === AuthenticationMode.B2C) {
            config.adConfiguration.auth.knownAuthorities = [configuration.authority];
        }

        config.customConfig.authenticationMode = configuration.authenticationMode;
        config.customConfig.api = configuration.api;
        config.customConfig.aiKey = configuration.aiKey;
        config.customConfig.enableTelemetry = configuration.enableTelemetry;
        config.customConfig.timeout = configuration.timeout;
        config.customConfig.serviceNowUrl = configuration.serviceNowUrl;
        config.customConfig.resetPasswordUrl = configuration.resetPasswordUrl;
        config.idp = AUTH_PROVIDERS[configuration.idp] || AUTH_PROVIDERS.AZURE;
        config.customConfig.requestHeaders = configuration.requestHeaders;
        configMapper[configuration.hostname] = config
    })
    return configMapper;
}

const defaultConfig: TenantConfiguration = {
    adConfiguration: {
        auth: {
            clientId: "",
            authority: "",
            redirectUri: process.env.REACT_APP_MSAL_REDIRECTURI,
            postLogoutRedirectUri: process.env.REACT_APP_MSAL_LOGOUTURI,
            navigateToLoginRequestUrl: true,
        },
        cache: {
            cacheLocation: process.env.REACT_APP_MSAL_CACHE_LOCATION,
            storeAuthStateInCookie: Boolean(process.env.REACT_APP_MSAL_STORE_IN_COOKIE),
        }
    },
    idp: "",
    customConfig: {
        timeout: 1800,
        serviceNowUrl: "",
        authenticationMode: "",
        resetPasswordUrl: "",
        api: {
            baseUrl: "",
            scopes: []
        },
    }
};

const getTenantConfig = (): TenantConfiguration => {
    const hostname = window.location.hostname;
    const configMapper = GetTenantConfigurations();
    const currentTenantConfig = configMapper[hostname];
    if (isEmpty(currentTenantConfig)) {
        console.error(`No tenant configuration found for hostname: ${hostname}`);
        return currentTenantConfig;
    }
    currentTenantConfig.authService = getAuthService(currentTenantConfig)
    currentTenantConfig.customConfig.getRequestHeaders = getRequestHeaders
    return currentTenantConfig;
}

const getRequestHeaders = (idToken: string, accessToken: string): { [key: string]: number } => {
    const headers = {};
    tenantSettings.customConfig.requestHeaders.forEach(requestHeader => {
        headers[requestHeader.keyName] = requestHeader.valueName === TOKENS.ACCESS_TOKEN ? accessToken : idToken;
        if (requestHeader.keyName.toLowerCase() === "authorization") {
            headers[requestHeader.keyName] = `Bearer ${headers[requestHeader.keyName]}`
        }
    })
    return headers;
}

const getAuthService = (tenantConfig: TenantConfiguration): IAuthenticationService => {
    let authService: IAuthenticationService;
    if (tenantConfig.idp === AUTH_PROVIDERS.AZURE) {
        authService = new AzureAuthenticationService(tenantConfig);
    }
    if (tenantConfig.idp === AUTH_PROVIDERS.OPTIMAL) {
        authService = new OptimalAuthenticationService(tenantConfig);
    }
    return authService;
}

export const tenantSettings = getTenantConfig();
