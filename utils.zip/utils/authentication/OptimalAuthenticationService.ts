import { isEmpty } from "lodash";
import { AuthProviderProps } from "react-oidc-context";
import { IAuthenticationService } from "./IAuthenticationService";
import { TenantConfiguration } from "./tenantSettings";

export class OptimalAuthenticationService implements IAuthenticationService {
    private _config!: AuthProviderProps;


    constructor(tenantConfig: TenantConfiguration) {
        this._config = this.boostrapConfiguration(tenantConfig);
    }
    signOut(): void {
        window.location.href = `${this._config.authority}/pages/public/_SignOut.aspx`;
    }
    getConfig(): AuthProviderProps {
        return this._config;
    }

    private boostrapConfiguration(tenantConfig: TenantConfiguration) {
        if (isEmpty(tenantConfig)) {
            throw new Error("No tenant configuration found");
        }
        return {
            authority: tenantConfig.adConfiguration.auth.authority,
            client_id: tenantConfig.adConfiguration.auth.clientId,
            redirect_uri: `${window.location.origin}`,
            response_type: "code",
            scope: 'openid profile email offline_access',
            extraQueryParams: {
                "access_type": "offline"
            }
        } as AuthProviderProps;
    }
}