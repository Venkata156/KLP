import { EventType, PublicClientApplication } from "@azure/msal-browser";
import { isEmpty } from "lodash";
import { IAuthenticationService } from "./IAuthenticationService";
import { AuthenticationMode, TenantConfiguration } from "./tenantSettings";

export class AzureAuthenticationService implements IAuthenticationService {
    private _config!: PublicClientApplication;
    constructor(tenantConfig: TenantConfiguration) {
        this._config = this.boostrapConfiguration(tenantConfig);
    }
    signOut(): void {
        this._config.logoutRedirect();
    }
    getConfig(): PublicClientApplication {
        return this._config;
    }

    private boostrapConfiguration(tenantConfig: TenantConfiguration) {
        if (isEmpty(tenantConfig)) {
            throw new Error("No tenant configuration found");
        }
        const msalInstance = new PublicClientApplication(tenantConfig.adConfiguration)
        if (tenantConfig.customConfig.authenticationMode === AuthenticationMode.B2C) {
            msalInstance.addEventCallback((message) => {
                if (message.eventType === EventType.LOGIN_FAILURE) {
                    if (message.error?.message.includes("AADB2C90118")) {
                        const authority = tenantConfig.customConfig.resetPasswordUrl;
                        msalInstance.loginRedirect({ authority: authority, scopes: tenantConfig.customConfig.api.scopes })
                    }
                }
            });
        }
        return msalInstance
    }
}