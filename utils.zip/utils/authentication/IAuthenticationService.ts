export interface IAuthenticationService {
    getConfig();
    signOut();
}