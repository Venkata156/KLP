/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

//==============================================================
// START Enums and Input Objects
//==============================================================

export enum ActivityType {
  ASSESSMENT = "ASSESSMENT",
  ASSIGNMENT = "ASSIGNMENT",
  AUDIO = "AUDIO",
  DIVIDER = "DIVIDER",
  EXTERNAL_CONTENT = "EXTERNAL_CONTENT",
  E_LEARNING = "E_LEARNING",
  FACE_TO_FACE = "FACE_TO_FACE",
  LITERATURE = "LITERATURE",
  NONE = "NONE",
  VIDEO = "VIDEO",
  VIRTUAL_CLASS_ROOM = "VIRTUAL_CLASS_ROOM",
}

export enum AssessmentStatus {
  COMPLETED = "COMPLETED",
  IN_PROGRESS = "IN_PROGRESS",
  NONE = "NONE",
  NOT_STARTED = "NOT_STARTED",
}

export enum AttendanceStatus {
  ATTENDED = "ATTENDED",
  DID_NOT_ATTEND = "DID_NOT_ATTEND",
  NONE = "NONE",
}

export enum ContentSource {
  KLP = "KLP",
  LINKED_IN = "LINKED_IN",
  NONE = "NONE",
  OPEN_SESAME = "OPEN_SESAME",
}

export enum ContentType {
  CHANNEL = "CHANNEL",
  COURSE = "COURSE",
  NONE = "NONE",
  PARENT_PATHWAY = "PARENT_PATHWAY",
  PATHWAY = "PATHWAY",
  PLAYLIST = "PLAYLIST",
}

export enum LTIContentSource {
  LINKED_IN = "LINKED_IN",
  NONE = "NONE",
  OPEN_SESAME = "OPEN_SESAME",
}

export enum LearnerWorkshopActivitiesSortBy {
  ACTIVITY_NAME = "ACTIVITY_NAME",
  LOCATION = "LOCATION",
  NONE = "NONE",
  PROGRAMME_NAME = "PROGRAMME_NAME",
  START_DATE = "START_DATE",
}

export enum NotificationType {
  CHANNEL = "CHANNEL",
  NONE = "NONE",
  PATHWAY = "PATHWAY",
  PROGRAMME = "PROGRAMME",
  SURVEY = "SURVEY",
}

export enum PlaylistContentType {
  COURSE = "COURSE",
  NONE = "NONE",
}

export enum PlaylistPermission {
  NONE = "NONE",
  PRIVATE = "PRIVATE",
  PUBLIC = "PUBLIC",
}

export enum SortBy {
  CREATED_ON = "CREATED_ON",
  DEFAULT = "DEFAULT",
  DURATION = "DURATION",
  NAME = "NAME",
  PRICE = "PRICE",
}

export interface ActivityEnrollInput {
  activityId?: string | null;
  sessionId?: string | null;
}

export interface AssignmentUploadParametersInput {
  programmeId?: string | null;
  activityId?: string | null;
}

export interface AttendeeInput {
  learnerId: any;
  emailAddress?: string | null;
  lineManagerEmail?: string | null;
  specialRequirements?: string | null;
}

export interface AttendeesInput {
  attendees?: (AttendeeInput | null)[] | null;
  dueDate?: any | null;
}

export interface BaseRootInput {
  id?: string | null;
  name?: string | null;
  code?: string | null;
  description?: string | null;
  summary?: string | null;
}

export interface CompleteLearnersActivityInput {
  activityId?: string | null;
  activityType: ActivityType;
  programmeId?: string | null;
  learnerIdCompletionDate?: KeyValuePairOfGuidAndNullableOfDateTimeInput[] | null;
}

export interface CourseEnrollInput {
  courseId?: string | null;
  activityEnrolls?: (ActivityEnrollInput | null)[] | null;
  orderId?: any | null;
}

export interface CourseUnenrollInput {
  courseId?: string | null;
  lineManagerEmail?: string | null;
  cancellationReason?: string | null;
}

export interface EditPlaylistParametersInput {
  playlistId?: any | null;
  title?: string | null;
  summary?: string | null;
}

export interface ExpressInterestInput {
  activityId?: string | null;
  interestedDate?: any | null;
  programmeId?: string | null;
  location?: string | null;
}

export interface FilterInput {
  type?: string | null;
  items?: (BaseRootInput | null)[] | null;
  minimumNumber?: number | null;
  maximumNumber?: number | null;
  minimumDate?: any | null;
  maximumDate?: any | null;
  isTrue?: boolean | null;
  id?: string | null;
  name?: string | null;
  code?: string | null;
  description?: string | null;
  summary?: string | null;
}

export interface KeyValuePairOfGuidAndAttendanceStatusInput {
  key: any;
  value: AttendanceStatus;
}

export interface KeyValuePairOfGuidAndGuidInput {
  key: any;
  value: any;
}

export interface KeyValuePairOfGuidAndNullableOfDateTimeInput {
  key: any;
  value?: any | null;
}

export interface LearnerInput {
  firstName?: string | null;
  lastName?: string | null;
  email?: string | null;
}

export interface LearnerWorkshopActivitiesSortInput {
  sortBy: LearnerWorkshopActivitiesSortBy;
  isAscending: boolean;
}

export interface OverdueReminderRequestInput {
  learnerId: any;
  contentId?: string | null;
  contentType: ContentType;
  contentTitle?: string | null;
  dueDate?: any | null;
}

export interface SavePlaylistContentInput {
  contentId?: string | null;
  contentType: PlaylistContentType;
}

export interface SavePlaylistParametersInput {
  permission: PlaylistPermission;
  contents?: (SavePlaylistContentInput | null)[] | null;
  playlistId?: any | null;
  title?: string | null;
  summary?: string | null;
}

export interface SaveSurveyInput {
  surveyId: any;
  questionIdOptionId?: KeyValuePairOfGuidAndGuidInput[] | null;
}

export interface ShareContentPayloadInput {
  recipients?: (LearnerInput | null)[] | null;
  contentName?: string | null;
  contentSummary?: string | null;
  contentPortalUri?: string | null;
}

export interface SortInput {
  sortBy: SortBy;
  isAscending: boolean;
}

export interface UpdateSessionAttendanceModelInput {
  activityId?: string | null;
  activityType: ActivityType;
  deletedLearnerIds?: any[] | null;
  externalSessionId?: string | null;
  programmeId?: string | null;
  sessionId?: string | null;
  updatedAttendanceByLearnerId?: KeyValuePairOfGuidAndAttendanceStatusInput[] | null;
}

export interface UserProfileInput {
  code?: string | null;
  value?: string | null;
}

export interface UserProfileUpdateInput {
  userProfileInput?: (UserProfileInput | null)[] | null;
  subscribedChannelIds?: (string | null)[] | null;
  unsubscribedChannelIds?: (string | null)[] | null;
}

//==============================================================
// END Enums and Input Objects
//==============================================================
