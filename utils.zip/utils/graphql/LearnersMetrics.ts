/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: LearnersMetrics
// ====================================================

export interface LearnersMetrics_learnersMetrics_requiredLearning {
  __typename: "MetricsBase";
  total: number;
  enrolled: number;
  inProgress: number;
  complete: number;
}

export interface LearnersMetrics_learnersMetrics_certifications {
  __typename: "MetricsBase";
  total: number;
  enrolled: number;
  inProgress: number;
  complete: number;
}

export interface LearnersMetrics_learnersMetrics_otherLearnings {
  __typename: "MetricsBase";
  total: number;
  enrolled: number;
  inProgress: number;
  complete: number;
}

export interface LearnersMetrics_learnersMetrics {
  __typename: "LearnerMetrics";
  requiredLearning: LearnersMetrics_learnersMetrics_requiredLearning | null;
  certifications: LearnersMetrics_learnersMetrics_certifications | null;
  otherLearnings: LearnersMetrics_learnersMetrics_otherLearnings | null;
}

export interface LearnersMetrics {
  learnersMetrics: LearnersMetrics_learnersMetrics | null;
}
