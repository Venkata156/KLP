/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ContentType } from "./Global";

// ====================================================
// GraphQL query operation: LastReminderDate
// ====================================================

export interface LastReminderDate {
  lastReminderDateTime: any | null;
}

export interface LastReminderDateVariables {
  learnerId: any;
  contentId?: string | null;
  contentType: ContentType;
}
