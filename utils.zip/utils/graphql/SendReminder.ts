/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { OverdueReminderRequestInput } from "./Global";

// ====================================================
// GraphQL mutation operation: SendReminder
// ====================================================

export interface SendReminder_sendLearnerOverdueContentReminder {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface SendReminder {
  sendLearnerOverdueContentReminder: SendReminder_sendLearnerOverdueContentReminder | null;
}

export interface SendReminderVariables {
  overdueReminderRequest?: OverdueReminderRequestInput | null;
}
