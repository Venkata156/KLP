/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CompleteChannelEnrollment
// ====================================================

export interface CompleteChannelEnrollment_completeChannelEnrollment {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface CompleteChannelEnrollment {
  completeChannelEnrollment: CompleteChannelEnrollment_completeChannelEnrollment | null;
}

export interface CompleteChannelEnrollmentVariables {
  channelId?: string | null;
}
