/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ActivityType } from "./Global";

// ====================================================
// GraphQL query operation: ActivityAttendees
// ====================================================

export interface ActivityAttendees_activityAttendees_attendees {
  __typename: "Attendee";
  learnerId: any;
  firstName: string | null;
  lastName: string | null;
  completionDate: any | null;
}

export interface ActivityAttendees_activityAttendees {
  __typename: "ActivityAttendees";
  numberOfAttendees: number;
  numberOfCompletedAttendees: number;
  programmeId: string | null;
  programmeName: string | null;
  activityId: string | null;
  activityName: string | null;
  activityType: ActivityType;
  attendees: (ActivityAttendees_activityAttendees_attendees | null)[] | null;
}

export interface ActivityAttendees {
  activityAttendees: ActivityAttendees_activityAttendees | null;
}

export interface ActivityAttendeesVariables {
  activityId?: string | null;
  searchTerm?: string | null;
  skip?: number | null;
  count?: number | null;
}
