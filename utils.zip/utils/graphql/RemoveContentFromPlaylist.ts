/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: RemoveContentFromPlaylist
// ====================================================

export interface RemoveContentFromPlaylist_removeContentFromPlaylist {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface RemoveContentFromPlaylist {
  removeContentFromPlaylist: RemoveContentFromPlaylist_removeContentFromPlaylist | null;
}

export interface RemoveContentFromPlaylistVariables {
  playlistId: any;
  contentId?: string | null;
}
