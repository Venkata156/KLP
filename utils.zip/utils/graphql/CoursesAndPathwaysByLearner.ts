/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: CoursesAndPathwaysByLearner
// ====================================================

export interface CoursesAndPathwaysByLearner_coursesAndPathwaysByLearner {
  __typename: "CounseeleContent";
  id: string | null;
  name: string | null;
  contentType: string | null;
  statusCode: string | null;
  dueDate: any | null;
  isReminderEnabled: boolean;
  hasCertificate: boolean;
}

export interface CoursesAndPathwaysByLearner {
  coursesAndPathwaysByLearner: (CoursesAndPathwaysByLearner_coursesAndPathwaysByLearner | null)[] | null;
}

export interface CoursesAndPathwaysByLearnerVariables {
  learnerId: any;
}
