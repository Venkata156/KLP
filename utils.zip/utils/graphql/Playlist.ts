/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: Playlist
// ====================================================

export interface Playlist_playlists {
  __typename: "PlaylistModel";
  id: any;
  title: string | null;
  contentIds: (string | null)[] | null;
}

export interface Playlist {
  playlists: (Playlist_playlists | null)[] | null;
}

export interface PlaylistVariables {
  courseId?: string | null;
}
