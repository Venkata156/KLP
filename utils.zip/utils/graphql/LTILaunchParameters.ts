/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { LTIContentSource } from "./Global";

// ====================================================
// GraphQL query operation: LTILaunchParameters
// ====================================================

export interface LTILaunchParameters_ltiLaunchParameters {
  __typename: "LTILaunchParameters";
  learnerId: string | null;
  contentUrl: string | null;
  consumerKey: string | null;
  nonce: string | null;
  signature: string | null;
  signatureMethod: string | null;
  timestamp: string | null;
  version: string | null;
  ltiVersion: string | null;
  ltiMessageType: string | null;
}

export interface LTILaunchParameters {
  ltiLaunchParameters: LTILaunchParameters_ltiLaunchParameters | null;
}

export interface LTILaunchParametersVariables {
  courseId?: string | null;
  activityId?: string | null;
  source: LTIContentSource;
}
