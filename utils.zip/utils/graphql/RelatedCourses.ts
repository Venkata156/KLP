/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ActivityType, ContentSource } from "./Global";

// ====================================================
// GraphQL query operation: RelatedCourses
// ====================================================

export interface RelatedCourses_relatedContents_contents {
  __typename: "Content";
  id: string | null;
  name: string | null;
  summary: string | null;
  contentType: string | null;
  studyModes: ActivityType[] | null;
  durationDisplay: string | null;
  percentageComplete: any | null;
  dueDate: any | null;
  price: any;
  isNew: boolean;
  isEnrolled: boolean;
  hasActivities: boolean;
  tags: (string | null)[] | null;
  imageUrl: string | null;
  rating: any;
  numberOfPeopleWhoRated: number;
  statusCode: string | null;
  source: ContentSource;
  hasCertificate: boolean;
}

export interface RelatedCourses_relatedContents {
  __typename: "UIContentCategory";
  contents: (RelatedCourses_relatedContents_contents | null)[] | null;
}

export interface RelatedCourses {
  relatedContents: RelatedCourses_relatedContents | null;
}

export interface RelatedCoursesVariables {
  courseId?: string | null;
}
