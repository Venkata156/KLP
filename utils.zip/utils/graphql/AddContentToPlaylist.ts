/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { PlaylistContentType } from "./Global";

// ====================================================
// GraphQL mutation operation: AddContentToPlaylist
// ====================================================

export interface AddContentToPlaylist_addContentToPlaylist {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface AddContentToPlaylist {
  addContentToPlaylist: AddContentToPlaylist_addContentToPlaylist | null;
}

export interface AddContentToPlaylistVariables {
  playlistId: any;
  contentId?: string | null;
  contentType: PlaylistContentType;
}
