/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: AllActivities
// ====================================================

export interface AllActivities_allActivities_data {
  __typename: "ActivityInfo";
  programmeName: string | null;
  activityId: string | null;
  activityName: string | null;
}

export interface AllActivities_allActivities {
  __typename: "CataloguePagingResponseOfActivityInfo";
  totalCount: number;
  data: (AllActivities_allActivities_data | null)[] | null;
}

export interface AllActivities {
  allActivities: AllActivities_allActivities | null;
}

export interface AllActivitiesVariables {
  searchTerm?: string | null;
  skip?: number | null;
  count?: number | null;
}
