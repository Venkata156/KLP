/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { CourseUnenrollInput } from "./Global";

// ====================================================
// GraphQL mutation operation: CompleteUnenrollment
// ====================================================

export interface CompleteUnenrollment_completeUnenrollment {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface CompleteUnenrollment {
  completeUnenrollment: CompleteUnenrollment_completeUnenrollment | null;
}

export interface CompleteUnenrollmentVariables {
  courseUnenroll?: CourseUnenrollInput | null;
}
