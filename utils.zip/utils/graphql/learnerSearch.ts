/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: learnerSearch
// ====================================================

export interface learnerSearch_learnerSearch {
  __typename: "LearnerBase";
  id: any;
  firstName: string | null;
  lastName: string | null;
  fullName: string | null;
  email: string | null;
}

export interface learnerSearch {
  learnerSearch: (learnerSearch_learnerSearch | null)[] | null;
}

export interface learnerSearchVariables {
  searchText: string;
  isRoleBasedSearch: boolean;
}
