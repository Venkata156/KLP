/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: FaceToFaceActivities
// ====================================================

export interface FaceToFaceActivities_faceToFaceActivities {
  __typename: "BaseRoot";
  id: string | null;
  name: string | null;
}

export interface FaceToFaceActivities {
  faceToFaceActivities: (FaceToFaceActivities_faceToFaceActivities | null)[] | null;
}

export interface FaceToFaceActivitiesVariables {
  courseId: string;
}
