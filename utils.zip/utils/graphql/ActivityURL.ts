/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: ActivityURL
// ====================================================

export interface ActivityURL {
  activityUrl: string | null;
}

export interface ActivityURLVariables {
  activityId?: string | null;
  activityType?: string | null;
  courseId: string;
}
