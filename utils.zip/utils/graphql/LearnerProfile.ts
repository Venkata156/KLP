/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: LearnerProfile
// ====================================================

export interface LearnerProfile_learnerProfile_metaData_dataPoints_items {
  __typename: "BaseRoot";
  code: string | null;
  name: string | null;
}

export interface LearnerProfile_learnerProfile_metaData_dataPoints {
  __typename: "DataPoint";
  displayLabel: string | null;
  code: string | null;
  canEdit: boolean;
  type: string | null;
  items: (LearnerProfile_learnerProfile_metaData_dataPoints_items | null)[] | null;
}

export interface LearnerProfile_learnerProfile_metaData_topics {
  __typename: "BaseRoot";
  id: string | null;
  code: string | null;
  name: string | null;
  description: string | null;
}

export interface LearnerProfile_learnerProfile_metaData {
  __typename: "MetaData";
  dataPoints: (LearnerProfile_learnerProfile_metaData_dataPoints | null)[] | null;
  topics: (LearnerProfile_learnerProfile_metaData_topics | null)[] | null;
}

export interface LearnerProfile_learnerProfile_userProfile_dataPoints {
  __typename: "DataPoint";
  displayLabel: string | null;
  code: string | null;
  value: string | null;
  values: (string | null)[] | null;
}

export interface LearnerProfile_learnerProfile_userProfile_topicOfInterest {
  __typename: "ChannelInterest";
  id: string | null;
  isAutoEnrolled: boolean;
}

export interface LearnerProfile_learnerProfile_userProfile {
  __typename: "UserProfile";
  firstName: string | null;
  lastName: string | null;
  userDisplayName: string | null;
  designation: string | null;
  department: string | null;
  email: string | null;
  dataPoints: (LearnerProfile_learnerProfile_userProfile_dataPoints | null)[] | null;
  topicOfInterest: (LearnerProfile_learnerProfile_userProfile_topicOfInterest | null)[] | null;
}

export interface LearnerProfile_learnerProfile {
  __typename: "LearnerProfile";
  metaData: LearnerProfile_learnerProfile_metaData | null;
  userProfile: LearnerProfile_learnerProfile_userProfile | null;
}

export interface LearnerProfile {
  learnerProfile: LearnerProfile_learnerProfile | null;
}
