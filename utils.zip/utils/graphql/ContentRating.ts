/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ContentType } from "./Global";

// ====================================================
// GraphQL query operation: ContentRating
// ====================================================

export interface ContentRating {
  contentRating: any;
}

export interface ContentRatingVariables {
  contentId?: string | null;
  contentType: ContentType;
}
