/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { SavePlaylistParametersInput } from "./Global";

// ====================================================
// GraphQL mutation operation: SavePlaylist
// ====================================================

export interface SavePlaylist_savePlaylist {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface SavePlaylist {
  savePlaylist: SavePlaylist_savePlaylist | null;
}

export interface SavePlaylistVariables {
  payload?: SavePlaylistParametersInput | null;
}
