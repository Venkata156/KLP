/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ActivityType, ContentSource } from "./Global";

// ====================================================
// GraphQL query operation: Course
// ====================================================

export interface Course_courseDetailsById {
  __typename: "Course";
  id: string | null;
  name: string | null;
  summary: string | null;
  description: string | null;
  percentageComplete: any | null;
  createdOnDisplay: string | null;
  tags: (string | null)[] | null;
  imageUrl: string | null;
  duration: number;
  durationDisplay: string | null;
  isNew: boolean;
  isEnrolled: boolean;
  isEnrollmentAvailable: boolean;
  isMandatory: boolean;
  canUnenroll: boolean;
  canEnroll: boolean;
  hasCertificate: boolean;
  hasTranscript: boolean;
  hasActivities: boolean;
  hasAssessment: boolean;
  objectives: (string | null)[] | null;
  studyModes: ActivityType[] | null;
  statusCode: string | null;
  rating: any;
  numberOfPeopleWhoRated: number;
  source: ContentSource;
  dueDate: any | null;
  canExpressInterest: boolean;
  allowSelfEnrol: boolean;
}

export interface Course {
  courseDetailsById: Course_courseDetailsById | null;
}

export interface CourseVariables {
  courseId?: string | null;
}
