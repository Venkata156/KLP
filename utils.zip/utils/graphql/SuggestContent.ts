/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ContentType } from "./Global";

// ====================================================
// GraphQL query operation: SuggestContent
// ====================================================

export interface SuggestContent_suggestContents {
  __typename: "SuggestContent";
  id: string | null;
  name: string | null;
  contentType: ContentType;
}

export interface SuggestContent {
  suggestContents: (SuggestContent_suggestContents | null)[] | null;
}

export interface SuggestContentVariables {
  searchTerm?: string | null;
}
