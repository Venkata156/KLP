/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ExpressInterestInput } from "./Global";

// ====================================================
// GraphQL mutation operation: expressInterest
// ====================================================

export interface expressInterest_expressInterest {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface expressInterest {
  expressInterest: expressInterest_expressInterest | null;
}

export interface expressInterestVariables {
  expressInterestInputData?: ExpressInterestInput | null;
}
