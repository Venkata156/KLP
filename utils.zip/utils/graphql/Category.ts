/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { SortInput, FilterInput, ActivityType, ContentSource } from "./Global";

// ====================================================
// GraphQL query operation: Category
// ====================================================

export interface Category_contentListByCategory_contents {
  __typename: "Content";
  id: string | null;
  name: string | null;
  summary: string | null;
  contentType: string | null;
  studyModes: ActivityType[] | null;
  durationDisplay: string | null;
  percentageComplete: any | null;
  createdOnDisplay: string | null;
  dueDate: any | null;
  price: any;
  isNew: boolean;
  isEnrolled: boolean;
  isAutoEnrolled: boolean;
  hasActivities: boolean;
  hasCertificate: boolean;
  tags: (string | null)[] | null;
  imageUrl: string | null;
  statusCode: string | null;
  rating: any;
  numberOfPeopleWhoRated: number;
  source: ContentSource;
  numberOfChildContents: number | null;
}

export interface Category_contentListByCategory {
  __typename: "UIContentCategory";
  contents: (Category_contentListByCategory_contents | null)[] | null;
  contentCount: number;
}

export interface Category {
  contentListByCategory: Category_contentListByCategory | null;
}

export interface CategoryVariables {
  categoryCode?: string | null;
  searchTerm?: string | null;
  sort?: SortInput | null;
  filters?: (FilterInput | null)[] | null;
  count?: number | null;
  skip?: number | null;
}
