/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: CourseUnenrollment
// ====================================================

export interface CourseUnenrollment_unenrollmentData {
  __typename: "Unenrollment";
  courseName: string | null;
  lineManagerEmail: string | null;
  cancellationPolicy: string | null;
  cancellationReasons: (string | null)[] | null;
}

export interface CourseUnenrollment {
  unenrollmentData: CourseUnenrollment_unenrollmentData | null;
}

export interface CourseUnenrollmentVariables {
  courseId: string;
}
