/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: SurveyData
// ====================================================

export interface SurveyData_survey_questions_options {
  __typename: "Option";
  optionId: any;
  htmlText: string | null;
  isSelected: boolean | null;
}

export interface SurveyData_survey_questions {
  __typename: "Question";
  questionId: any;
  htmlText: string | null;
  options: (SurveyData_survey_questions_options | null)[] | null;
}

export interface SurveyData_survey {
  __typename: "Survey";
  surveyId: any;
  answeredDate: any;
  title: string | null;
  htmlText: string | null;
  questions: (SurveyData_survey_questions | null)[] | null;
}

export interface SurveyData {
  survey: SurveyData_survey | null;
}
