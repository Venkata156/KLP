/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { AssessmentStatus } from "./Global";

// ====================================================
// GraphQL query operation: LearnerSkillAssessments
// ====================================================

export interface LearnerSkillAssessments_learnerSkillAssessments {
  __typename: "LearnerSkillAssessment";
  skillAssessmentId: any;
  skillName: string | null;
  externalAssesmentId: number;
  status: AssessmentStatus;
  skillRating: number | null;
}

export interface LearnerSkillAssessments {
  learnerSkillAssessments: (LearnerSkillAssessments_learnerSkillAssessments | null)[] | null;
}
