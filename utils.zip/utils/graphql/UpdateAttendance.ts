/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { UpdateSessionAttendanceModelInput } from "./Global";

// ====================================================
// GraphQL mutation operation: UpdateAttendance
// ====================================================

export interface UpdateAttendance_saveAttendance {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface UpdateAttendance {
  saveAttendance: UpdateAttendance_saveAttendance | null;
}

export interface UpdateAttendanceVariables {
  model?: UpdateSessionAttendanceModelInput | null;
}
