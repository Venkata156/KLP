/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: DeleteAllNotifications
// ====================================================

export interface DeleteAllNotifications_deleteAllNotificationsByLearnerId {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface DeleteAllNotifications {
  deleteAllNotificationsByLearnerId: DeleteAllNotifications_deleteAllNotificationsByLearnerId | null;
}
