/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: AllSessions
// ====================================================

export interface AllSessions_allSessions_data {
  __typename: "SessionDetails";
  sessionId: string | null;
  programmeName: string | null;
  activityName: string | null;
  startDate: any | null;
  endDate: any | null;
  location: string | null;
  externalSessionId: string | null;
  sessionName: string | null;
}

export interface AllSessions_allSessions {
  __typename: "CataloguePagingResponseOfSessionDetails";
  totalCount: number;
  data: (AllSessions_allSessions_data | null)[] | null;
}

export interface AllSessions {
  allSessions: AllSessions_allSessions | null;
}

export interface AllSessionsVariables {
  skip: number;
  count: number;
  searchTerm: string;
}
