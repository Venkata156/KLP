/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { LearnerWorkshopActivitiesSortInput } from "./Global";

// ====================================================
// GraphQL query operation: LearnerWorkshops
// ====================================================

export interface LearnerWorkshops_learnerWorkshopActivities_activities {
  __typename: "SessionDetails";
  programmeId: string | null;
  programmeName: string | null;
  activityName: string | null;
  startDate: any | null;
  location: string | null;
}

export interface LearnerWorkshops_learnerWorkshopActivities {
  __typename: "LearnerWorkshopActivities";
  totalLearnerWorkshopActivitiesCount: number;
  activities: (LearnerWorkshops_learnerWorkshopActivities_activities | null)[] | null;
}

export interface LearnerWorkshops {
  learnerWorkshopActivities: LearnerWorkshops_learnerWorkshopActivities | null;
}

export interface LearnerWorkshopsVariables {
  sort?: LearnerWorkshopActivitiesSortInput | null;
  skip: number;
  count: number;
}
