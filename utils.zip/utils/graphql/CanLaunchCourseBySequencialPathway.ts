/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: CanLaunchCourseBySequencialPathway
// ====================================================

export interface CanLaunchCourseBySequencialPathway_canLaunchCourseBySequencialPathway_blockingPathways {
  __typename: "BlockingPathway";
  id: string | null;
  name: string | null;
}

export interface CanLaunchCourseBySequencialPathway_canLaunchCourseBySequencialPathway {
  __typename: "CanLaunchCourseResponse";
  canLaunch: boolean;
  enrolledPathwayId: string | null;
  blockingPathways: (CanLaunchCourseBySequencialPathway_canLaunchCourseBySequencialPathway_blockingPathways | null)[] | null;
}

export interface CanLaunchCourseBySequencialPathway {
  canLaunchCourseBySequencialPathway: CanLaunchCourseBySequencialPathway_canLaunchCourseBySequencialPathway | null;
}

export interface CanLaunchCourseBySequencialPathwayVariables {
  courseId: string;
}
