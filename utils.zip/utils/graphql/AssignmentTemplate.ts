/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: AssignmentTemplate
// ====================================================

export interface AssignmentTemplate {
  assignmentTemplateUri: string | null;
}

export interface AssignmentTemplateVariables {
  programmeId: string;
  activityId: string;
}
