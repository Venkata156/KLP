/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: LearnersByLineManager
// ====================================================

export interface LearnersByLineManager_learnersByLineManager {
  __typename: "LearnerBase";
  id: any;
  fullName: string | null;
  email: string | null;
}

export interface LearnersByLineManager {
  learnersByLineManager: (LearnersByLineManager_learnersByLineManager | null)[] | null;
}
