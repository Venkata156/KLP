/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: NotificationMetrics
// ====================================================

export interface NotificationMetrics_notificationsMetrics {
  __typename: "NotificationsMetrics";
  unreadNotificationsCount: number;
  totalNotificationsCount: number;
}

export interface NotificationMetrics {
  notificationsMetrics: NotificationMetrics_notificationsMetrics | null;
}
