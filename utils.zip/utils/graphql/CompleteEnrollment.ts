/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { CourseEnrollInput, AttendeesInput } from "./Global";

// ====================================================
// GraphQL mutation operation: CompleteEnrollment
// ====================================================

export interface CompleteEnrollment_completeEnrollment {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface CompleteEnrollment {
  completeEnrollment: CompleteEnrollment_completeEnrollment | null;
}

export interface CompleteEnrollmentVariables {
  courseEnroll?: CourseEnrollInput | null;
  attendeesInput?: AttendeesInput | null;
}
