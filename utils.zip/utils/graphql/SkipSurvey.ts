/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: SkipSurvey
// ====================================================

export interface SkipSurvey_skipSurvey {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface SkipSurvey {
  skipSurvey: SkipSurvey_skipSurvey | null;
}

export interface SkipSurveyVariables {
  surveyId?: string | null;
}
