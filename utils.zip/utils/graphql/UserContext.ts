/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: UserContext
// ====================================================

export interface UserContext_userContext {
  __typename: "UserContext";
  firstName: string | null;
  lastName: string | null;
  userDisplayName: string | null;
  dateDisplayFormat: string | null;
  roles: (string | null)[] | null;
  permissions: (string | null)[] | null;
  chatBotUrl: string | null;
  showSurvey: boolean;
  isSurveySkipped: boolean;
  surveyId: string | null;
  learnerId: any;
  learnerEmail: string | null;
  isLineManager: boolean;
  canEditLineManagerEmail: boolean;
  surveyStartDate: any | null;
  showTopicsOfInterest: boolean;
}

export interface UserContext {
  userContext: UserContext_userContext | null;
}
