/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CompleteChannelUnenrollment
// ====================================================

export interface CompleteChannelUnenrollment_completeChannelUnenrollment {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface CompleteChannelUnenrollment {
  completeChannelUnenrollment: CompleteChannelUnenrollment_completeChannelUnenrollment | null;
}

export interface CompleteChannelUnenrollmentVariables {
  channelId?: string | null;
}
