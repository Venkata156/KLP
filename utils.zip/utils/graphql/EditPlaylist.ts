/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { EditPlaylistParametersInput } from "./Global";

// ====================================================
// GraphQL mutation operation: EditPlaylist
// ====================================================

export interface EditPlaylist_editPlaylist {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface EditPlaylist {
  editPlaylist: EditPlaylist_editPlaylist | null;
}

export interface EditPlaylistVariables {
  payload?: EditPlaylistParametersInput | null;
}
