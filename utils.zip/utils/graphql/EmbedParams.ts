/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: EmbedParams
// ====================================================

export interface EmbedParams_embedParams {
  __typename: "PBIEmbedContent";
  reportId: any;
  reportName: string | null;
  embedUrl: string | null;
  embedToken: string | null;
}

export interface EmbedParams {
  embedParams: EmbedParams_embedParams | null;
}
