/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CompletePathwayUnenrollment
// ====================================================

export interface CompletePathwayUnenrollment_completePathwayUnenrollment {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface CompletePathwayUnenrollment {
  completePathwayUnenrollment: CompletePathwayUnenrollment_completePathwayUnenrollment | null;
}

export interface CompletePathwayUnenrollmentVariables {
  pathwayId?: string | null;
}
