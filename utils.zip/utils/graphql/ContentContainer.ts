/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { SortInput, ActivityType, ContentSource } from "./Global";

// ====================================================
// GraphQL query operation: ContentContainer
// ====================================================

export interface ContentContainer_contentListById_contentMetrics {
  __typename: "ContentMetrics";
  numberOfCourses: number;
  numberOfPathways: number;
  numberOfCertifications: number;
  numberOfCoursesCompleted: number;
  numberOfPathwaysCompleted: number;
  numberOfCertificationsCompleted: number;
}

export interface ContentContainer_contentListById_contents_children {
  __typename: "Content";
  id: string | null;
  name: string | null;
  summary: string | null;
  contentType: string | null;
  studyModes: ActivityType[] | null;
  durationDisplay: string | null;
  percentageComplete: any | null;
  createdOn: any;
  updatedOn: any;
  dueDate: any | null;
  price: any;
  isNew: boolean;
  isEnrolled: boolean;
  hasActivities: boolean;
  tags: (string | null)[] | null;
  imageUrl: string | null;
  statusCode: string | null;
  hasCertificate: boolean;
  rating: any;
  numberOfPeopleWhoRated: number;
  source: ContentSource;
}

export interface ContentContainer_contentListById_contents {
  __typename: "Content";
  id: string | null;
  name: string | null;
  summary: string | null;
  contentType: string | null;
  studyModes: ActivityType[] | null;
  durationDisplay: string | null;
  percentageComplete: any | null;
  createdOn: any;
  updatedOn: any;
  dueDate: any | null;
  price: any;
  isNew: boolean;
  isEnrolled: boolean;
  hasActivities: boolean;
  tags: (string | null)[] | null;
  imageUrl: string | null;
  statusCode: string | null;
  hasCertificate: boolean;
  rating: any;
  numberOfPeopleWhoRated: number;
  source: ContentSource;
  children: (ContentContainer_contentListById_contents_children | null)[] | null;
}

export interface ContentContainer_contentListById {
  __typename: "UIContentCategory";
  id: string | null;
  name: string | null;
  summary: string | null;
  description: string | null;
  createdOn: any;
  updatedOn: any;
  updatedOnDisplay: string | null;
  tags: (string | null)[] | null;
  contentMetrics: ContentContainer_contentListById_contentMetrics | null;
  hasCertificate: boolean;
  isEnrolled: boolean;
  isNew: boolean;
  percentageComplete: any | null;
  rating: any;
  numberOfPeopleWhoRated: number;
  statusCode: string | null;
  isAutoEnrolled: boolean;
  contents: (ContentContainer_contentListById_contents | null)[] | null;
}

export interface ContentContainer {
  contentListById: ContentContainer_contentListById | null;
}

export interface ContentContainerVariables {
  parentId?: string | null;
  parentType?: string | null;
  sort?: SortInput | null;
}
