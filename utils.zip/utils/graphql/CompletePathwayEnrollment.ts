/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: CompletePathwayEnrollment
// ====================================================

export interface CompletePathwayEnrollment_completePathwayEnrollment {
  __typename: "EnrollmentStatus";
  courseId: string | null;
  courseName: string | null;
  canEnroll: boolean;
  isEnrolled: boolean;
}

export interface CompletePathwayEnrollment {
  completePathwayEnrollment: (CompletePathwayEnrollment_completePathwayEnrollment | null)[] | null;
}

export interface CompletePathwayEnrollmentVariables {
  pathwayId?: string | null;
}
