/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: ScanUploadedFile
// ====================================================

export interface ScanUploadedFile {
  scanUploadedFile: boolean;
}

export interface ScanUploadedFileVariables {
  fileRelativePath: string;
}
