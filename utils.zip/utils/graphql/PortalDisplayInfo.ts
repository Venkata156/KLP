/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: PortalDisplayInfo
// ====================================================

export interface PortalDisplayInfo_portalDisplayInformation_settings {
  __typename: "Setting";
  item: string | null;
  attributesJson: string | null;
}

export interface PortalDisplayInfo_portalDisplayInformation {
  __typename: "PortalDisplayInformation";
  category: string | null;
  settings: (PortalDisplayInfo_portalDisplayInformation_settings | null)[] | null;
}

export interface PortalDisplayInfo {
  portalDisplayInformation: (PortalDisplayInfo_portalDisplayInformation | null)[] | null;
}
