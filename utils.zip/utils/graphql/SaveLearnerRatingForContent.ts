/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ContentType } from "./Global";

// ====================================================
// GraphQL mutation operation: SaveLearnerRatingForContent
// ====================================================

export interface SaveLearnerRatingForContent_saveLearnerRatingForContent {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface SaveLearnerRatingForContent {
  saveLearnerRatingForContent: SaveLearnerRatingForContent_saveLearnerRatingForContent | null;
}

export interface SaveLearnerRatingForContentVariables {
  contentId?: string | null;
  contentType: ContentType;
  rating: number;
}
