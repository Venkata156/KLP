/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { CompleteLearnersActivityInput } from "./Global";

// ====================================================
// GraphQL mutation operation: CompleteActivity
// ====================================================

export interface CompleteActivity_completeLearnersActivity {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface CompleteActivity {
  completeLearnersActivity: CompleteActivity_completeLearnersActivity | null;
}

export interface CompleteActivityVariables {
  model?: CompleteLearnersActivityInput | null;
}
