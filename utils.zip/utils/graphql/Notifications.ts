/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { NotificationType } from "./Global";

// ====================================================
// GraphQL query operation: Notifications
// ====================================================

export interface Notifications_notificationByLearnerId {
  __typename: "NotificationModel";
  body: string | null;
  createdOn: any;
  id: any;
  metadata: string | null;
  readOn: any | null;
  title: string | null;
  type: NotificationType;
}

export interface Notifications {
  notificationByLearnerId: (Notifications_notificationByLearnerId | null)[] | null;
}
