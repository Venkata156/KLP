/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: Welcome
// ====================================================

export interface Welcome_message {
  __typename: "Message";
  welcomeText: string | null;
}

export interface Welcome {
  message: Welcome_message | null;
}
