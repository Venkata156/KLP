/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ActivityType } from "./Global";

// ====================================================
// GraphQL query operation: CoursePlayer
// ====================================================

export interface CoursePlayer_player_playerHeaderModel {
  __typename: "PlayerHeaderModel";
  id: string | null;
  name: string | null;
}

export interface CoursePlayer_player_playerBodyModel_learnerModel {
  __typename: "LearnerModel";
  id: any;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
}

export interface CoursePlayer_player_playerBodyModel_activityModel {
  __typename: "Activity";
  id: string | null;
  name: string | null;
  url: string | null;
  type: ActivityType;
  typeName: string | null;
}

export interface CoursePlayer_player_playerBodyModel_scormPaths {
  __typename: "ScormPaths";
  portHoleJSPath: string | null;
  bundleJSPath: string | null;
  proxyHtmlPath: string | null;
  contentWrapperHtmlPath: string | null;
}

export interface CoursePlayer_player_playerBodyModel {
  __typename: "PlayerBodyModel";
  id: string | null;
  uri: string | null;
  audioPosterUrl: string | null;
  encryptedTenantId: string | null;
  scormDataModel: string | null;
  learnerModel: CoursePlayer_player_playerBodyModel_learnerModel | null;
  activityModel: CoursePlayer_player_playerBodyModel_activityModel | null;
  scormPaths: CoursePlayer_player_playerBodyModel_scormPaths | null;
}

export interface CoursePlayer_player {
  __typename: "PlayerModel";
  loadSuccessful: boolean;
  sessionRefreshInterval: number;
  playerHeaderModel: CoursePlayer_player_playerHeaderModel | null;
  playerBodyModel: CoursePlayer_player_playerBodyModel | null;
}

export interface CoursePlayer {
  player: CoursePlayer_player | null;
}

export interface CoursePlayerVariables {
  programmeId?: string | null;
  activityId?: string | null;
}
