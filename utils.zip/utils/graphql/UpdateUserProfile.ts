/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { UserProfileUpdateInput } from "./Global";

// ====================================================
// GraphQL mutation operation: UpdateUserProfile
// ====================================================

export interface UpdateUserProfile {
  updateUserProfile: boolean;
}

export interface UpdateUserProfileVariables {
  profile?: UserProfileUpdateInput | null;
}
