/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: Localization
// ====================================================

export interface Localization_localizationData {
  __typename: "LocalizationModel";
  code: string | null;
  localText: string | null;
}

export interface Localization {
  localizationData: (Localization_localizationData | null)[] | null;
}
