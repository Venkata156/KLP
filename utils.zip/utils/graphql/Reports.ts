/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: Reports
// ====================================================

export interface Reports_diagnosticReports {
  __typename: "DiagnosticReport";
  id: string | null;
  title: string | null;
  url: string | null;
  date: any;
  status: string | null;
}

export interface Reports {
  diagnosticReports: (Reports_diagnosticReports | null)[] | null;
}
