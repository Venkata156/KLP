/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: UpdateEmailId
// ====================================================

export interface UpdateEmailId {
  updateEmailId: boolean;
}

export interface UpdateEmailIdVariables {
  emailId?: string | null;
}
