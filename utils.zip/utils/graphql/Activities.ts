/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ActivityType } from "./Global";

// ====================================================
// GraphQL query operation: Activities
// ====================================================

export interface Activities_activities_availableSessions {
  __typename: "Session";
  id: string | null;
  name: string | null;
  code: string | null;
  description: string | null;
  startDateTimeDisplay: string | null;
  endDateTimeDisplay: string | null;
  location: string | null;
  noOfSeatsAvailable: number;
}

export interface Activities_activities_bookedSession_address {
  __typename: "Address";
  name: string | null;
  streetAddress1: string | null;
  streetAddress2: string | null;
  city: string | null;
  state: string | null;
  country: string | null;
  postalCode: string | null;
}

export interface Activities_activities_bookedSession {
  __typename: "Session";
  id: string | null;
  externalSessionId: string | null;
  startDateTimeDisplay: string | null;
  endDateTimeDisplay: string | null;
  duration: string | null;
  location: string | null;
  address: Activities_activities_bookedSession_address | null;
}

export interface Activities_activities {
  __typename: "Activity";
  id: string | null;
  name: string | null;
  type: ActivityType;
  statusCode: string | null;
  description: string | null;
  hasSessionInfo: boolean;
  hasLaunchUrl: boolean;
  hasContent: boolean;
  url: string | null;
  availableSessions: (Activities_activities_availableSessions | null)[] | null;
  bookedSession: Activities_activities_bookedSession | null;
}

export interface Activities {
  activities: (Activities_activities | null)[] | null;
}

export interface ActivitiesVariables {
  courseId?: string | null;
}
