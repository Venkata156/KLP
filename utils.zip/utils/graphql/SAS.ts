/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { AssignmentUploadParametersInput } from "./Global";

// ====================================================
// GraphQL query operation: SAS
// ====================================================

export interface SAS_sas_customMetadata {
  __typename: "CustomMetadata";
  key: string | null;
  value: string | null;
}

export interface SAS_sas {
  __typename: "AssignmentUploadSas";
  sas: string | null;
  uploadTypeKey: string | null;
  uploadTypeValue: string | null;
  fileRelativePath: string | null;
  customMetadata: (SAS_sas_customMetadata | null)[] | null;
}

export interface SAS {
  sas: SAS_sas | null;
}

export interface SASVariables {
  parameters?: AssignmentUploadParametersInput | null;
}
