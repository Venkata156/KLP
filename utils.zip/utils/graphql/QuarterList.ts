/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: QuarterList
// ====================================================

export interface QuarterList_quarterList {
  __typename: "Quarter";
  id: string | null;
  name: string | null;
  code: string | null;
  isSelected: boolean;
  startDate: any;
  endDate: any;
}

export interface QuarterList {
  quarterList: (QuarterList_quarterList | null)[] | null;
}
