/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: CanChangeCompletedStatusToEnroll
// ====================================================

export interface CanChangeCompletedStatusToEnroll {
  canChangeCompletedStatusToEnroll: boolean;
}

export interface CanChangeCompletedStatusToEnrollVariables {
  pathwayId: string;
}
