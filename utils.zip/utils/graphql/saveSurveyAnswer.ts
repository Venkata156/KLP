/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { SaveSurveyInput } from "./Global";

// ====================================================
// GraphQL mutation operation: saveSurveyAnswer
// ====================================================

export interface saveSurveyAnswer {
  saveSurvey: boolean;
}

export interface saveSurveyAnswerVariables {
  surveyAnswer?: SaveSurveyInput | null;
}
