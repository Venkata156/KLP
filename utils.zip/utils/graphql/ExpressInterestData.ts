/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: ExpressInterestData
// ====================================================

export interface ExpressInterestData_customerExpressInterests_dates {
  __typename: "ExpressInterestDate";
  interestedDate: any;
  displayText: string | null;
}

export interface ExpressInterestData_customerExpressInterests {
  __typename: "ExpressInterestData";
  dates: (ExpressInterestData_customerExpressInterests_dates | null)[] | null;
  locations: (string | null)[] | null;
}

export interface ExpressInterestData {
  customerExpressInterests: ExpressInterestData_customerExpressInterests | null;
}
