/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ShareContentPayloadInput } from "./Global";

// ====================================================
// GraphQL mutation operation: ShareContent
// ====================================================

export interface ShareContent_shareContent {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface ShareContent {
  shareContent: ShareContent_shareContent | null;
}

export interface ShareContentVariables {
  payload?: ShareContentPayloadInput | null;
}
