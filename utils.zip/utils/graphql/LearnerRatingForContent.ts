/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { ContentType } from "./Global";

// ====================================================
// GraphQL query operation: LearnerRatingForContent
// ====================================================

export interface LearnerRatingForContent {
  learnerRatingForContent: number | null;
}

export interface LearnerRatingForContentVariables {
  contentId?: string | null;
  contentType: ContentType;
}
