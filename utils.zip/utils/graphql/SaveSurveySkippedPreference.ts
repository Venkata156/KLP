/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: SaveSurveySkippedPreference
// ====================================================

export interface SaveSurveySkippedPreference_saveSurveySkippedPreference {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface SaveSurveySkippedPreference {
  saveSurveySkippedPreference: SaveSurveySkippedPreference_saveSurveySkippedPreference | null;
}
