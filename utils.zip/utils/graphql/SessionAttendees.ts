/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

import { AttendanceStatus, ActivityType } from "./Global";

// ====================================================
// GraphQL query operation: SessionAttendees
// ====================================================

export interface SessionAttendees_sessionAttendees_attendees {
  __typename: "LearnerAttendanceModel";
  learnerId: any;
  firstName: string | null;
  lastName: string | null;
  email: string | null;
  attendanceStatus: AttendanceStatus;
}

export interface SessionAttendees_sessionAttendees {
  __typename: "SessionAttendeesModel";
  attendees: (SessionAttendees_sessionAttendees_attendees | null)[] | null;
  sessionId: string | null;
  programmeId: string | null;
  externalSessionId: string | null;
  programmeName: string | null;
  activityName: string | null;
  startDate: any | null;
  endDate: any | null;
  location: string | null;
  activityId: string | null;
  activityType: ActivityType;
  sessionName: string | null;
}

export interface SessionAttendees {
  sessionAttendees: SessionAttendees_sessionAttendees | null;
}

export interface SessionAttendeesVariables {
  sessionId?: string | null;
}
