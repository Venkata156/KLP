/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: DirectLineToken
// ====================================================

export interface DirectLineToken_directLineToken {
  __typename: "DirectLineTokenResponseModel";
  token: string | null;
}

export interface DirectLineToken {
  directLineToken: DirectLineToken_directLineToken | null;
}
