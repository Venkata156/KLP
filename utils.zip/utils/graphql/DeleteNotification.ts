/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL mutation operation: DeleteNotification
// ====================================================

export interface DeleteNotification_deleteNotificationById {
  __typename: "ResponseMessage";
  messages: (string | null)[] | null;
  hasError: boolean;
}

export interface DeleteNotification {
  deleteNotificationById: DeleteNotification_deleteNotificationById | null;
}

export interface DeleteNotificationVariables {
  notificationId: any;
}
