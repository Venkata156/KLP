/* tslint:disable */
/* eslint-disable */
// @generated
// This file was automatically generated and should not be edited.

// ====================================================
// GraphQL query operation: CourseEnrollment
// ====================================================

export interface CourseEnrollment_enrollmentData_activities_availableSessions {
  __typename: "Session";
  id: string | null;
  startDateTimeDisplay: string | null;
  endDateTimeDisplay: string | null;
  location: string | null;
  noOfSeatsAvailable: number;
  startDateTime: any;
  endDateTime: any;
}

export interface CourseEnrollment_enrollmentData_activities {
  __typename: "Activity";
  id: string | null;
  name: string | null;
  availableSessions: (CourseEnrollment_enrollmentData_activities_availableSessions | null)[] | null;
}

export interface CourseEnrollment_enrollmentData_learnerDetails {
  __typename: "LearnerDetails";
  firstName: string | null;
  lastName: string | null;
  email: string | null;
  managersEmail: string | null;
  reasonableAdjusmentRequest: string | null;
}

export interface CourseEnrollment_enrollmentData {
  __typename: "EnrollmentData";
  activities: (CourseEnrollment_enrollmentData_activities | null)[] | null;
  learnerDetails: CourseEnrollment_enrollmentData_learnerDetails | null;
  termsandConditions: string | null;
  preRequisites: string | null;
  isTermsAndConditionAvailable: boolean;
  isPreRequisitesAvailable: boolean;
  captureManagerEmail: boolean;
  captureSpecialRequirements: boolean;
}

export interface CourseEnrollment {
  enrollmentData: CourseEnrollment_enrollmentData | null;
}

export interface CourseEnrollmentVariables {
  courseId: string;
}
