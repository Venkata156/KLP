import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import { SESSION_STOREAGE_KEYS } from "./constants";

export const local_keys = [
  SESSION_STOREAGE_KEYS.LOGOUT_COMPLETE_LABEL, 
  SESSION_STOREAGE_KEYS.LOGOUT_COMPLETE_DIALOG,
  SESSION_STOREAGE_KEYS.LOGIN_BACK, 
  SESSION_STOREAGE_KEYS.HERE, 
  SESSION_STOREAGE_KEYS.NOT_AUTHORIZED, 
  SESSION_STOREAGE_KEYS.NOT_AUTHORIZED_DIALOG
];

export const TRANSLATION_STORAGE_KEY = "_translations";

const resources = {
  "en": {
    "translation": {
      ...JSON.parse(sessionStorage.getItem(TRANSLATION_STORAGE_KEY) || '{}'),
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: "en",
    interpolation: {
      escapeValue: false
    },
    react: {
      bindI18nStore: 'added'
    }
  });

export default i18n;