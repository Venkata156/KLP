import {
  AdminConfirmStep,
  AdminEnrollStep,
  CategoryCodeAll,
  CategoryCodeChannel,
  CategoryCodeParentPathway,
  CategoryCodeMyInterest,
  CategoryCodePopular,
  CategoryCodeRecommended,
  CategoryCodeRequired,
  EnrollmentStepTypeEnrollee,
  EnrollmentStepTypePrerequisites,
  EnrollmentStepTypeTerms,
  EnrollmentStepTypeWorkshops,
  ProfileFieldTypeNumber,
  ProfileFieldTypeSingleLineText,
  ProfileFieldTypeSingleSelectDropdown,
  ProfileTabTypeCouncelees,
  ProfileTabTypeDetails,
  ProfileTabTypeTopics,
  ProfileTabTypeLearner,
  ProfileTabTypeCalendar,
  SortTypeAlphabeticalAscending,
  SortTypeAlphabeticalDescending,
  SortTypeDefault,
  SortTypeDurationAscending,
  SortTypeDurationDescending,
  SortTypeNone,
  SortTypePriceAscending,
  SortTypePriceDescending,
  ProfileTabTypeSkills
} from "utils/types";

export const CATEGORY_CODE_REQUIRED: CategoryCodeRequired = "MyLearning";
export const CATEGORY_CODE_RECOMMENDED: CategoryCodeRecommended = "Recommendations";
export const CATEGORY_CODE_POPULAR: CategoryCodePopular = "Popular";
export const CATEGORY_CODE_MYINTEREST: CategoryCodeMyInterest = "Playlist";
export const CATEGORY_CODE_CHANNEL: CategoryCodeChannel = "Channel";
export const CATEGORY_CODE_PARENTPATHWAY: CategoryCodeParentPathway = "ParentPathway";
export const CATEGORY_CODE_ALL: CategoryCodeAll = "All";

export const SORT_DEFAULT: SortTypeDefault =
  "SORT_DEFAULT";
export const SORT_ALPHABETICAL_ASCENDING: SortTypeAlphabeticalAscending =
  "SORT_ALPHABETICAL_ASCENDING";
export const SORT_ALPHABETICAL_DESCENDING: SortTypeAlphabeticalDescending =
  "SORT_ALPHABETICAL_DESCENDING";
export const SORT_DURATION_ASCENDING: SortTypeDurationAscending = "SORT_DURATION_ASCENDING";
export const SORT_DURATION_DESCENDING: SortTypeDurationDescending = "SORT_DURATION_DESCENDING";
export const SORT_PRICE_ASCENDING: SortTypePriceAscending = "SORT_PRICE_ASCENDING";
export const SORT_PRICE_DESCENDING: SortTypePriceDescending = "SORT_PRICE_DESCENDING";
export const SORT_NONE: SortTypeNone = "SORT_NONE";

export const PROFILE_FIELD_TYPE_SINGLE_LINE_TEXT: ProfileFieldTypeSingleLineText = "SingleLineText";
export const PROFILE_FIELD_TYPE_NUMBER: ProfileFieldTypeNumber = "number";
export const PROFILE_FIELD_TYPE_SINGLE_SELECT_DROPDOWN: ProfileFieldTypeSingleSelectDropdown =
  "SingleSelectDropdown";

export const PROFILE_TAB_DETAILS: ProfileTabTypeDetails = 0;
export const PROFILE_TAB_TOPICS: ProfileTabTypeTopics = 1;
export const PROFILE_TAB_COUNSELEES: ProfileTabTypeCouncelees = 2;
export const PROFILE_TAB_LEARNER: ProfileTabTypeLearner = 3;
export const PROFILE_TAB_CALENDAR: ProfileTabTypeCalendar = 4;
export const PROFILE_TAB_SKILLS: ProfileTabTypeSkills = 5;

export const ENROLLMENT_STEP_WORKSHOPS: EnrollmentStepTypeWorkshops = "WORKSHOPS";
export const ENROLLMENT_STEP_ENROLLEE: EnrollmentStepTypeEnrollee = "ENROLLEE";
export const ENROLLMENT_STEP_TERMS: EnrollmentStepTypeTerms = "TERMS";
export const ENROLLMENT_STEP_PREREQUISITES: EnrollmentStepTypePrerequisites = "PREREQUISITES";

export const ADMIN_ENROLL_STEP: AdminEnrollStep = "ADMIN_ENROLL";
export const ADMIN_CONFIRM_STEP: AdminConfirmStep = "ADMIN_CONFIRM";

export const FILTER_ENROLLED = "Enrolled";
export const FILTER_IN_PROGRESS = "InProgress";
export const FILTER_PROCESSING = "PaymentAwaited";

export const REQUIRED_LEARNING = "Required Learning";
export const COURSES_COMPLETE = "Courses Complete";
export const CERTIFICATIONS_ACQUIRED = "Certifications Acquired";
export const HEADER_CLICK_TYPES = {
  "REPORT": "Report",
  "LOGOUT": "Logout",
  "SERVICENOW": "ServiceNow",
  "CONTACTUS": "ContactUs",
  "SURVEY": "survey"
}
export const KLP_COURSE_WINDOW_NAME = "KLP_COURSE_WINDOW";
export const KLP_SERVICE_NOW_WINDOW_NAME = "KLP_SERVICE_NOW_WINDOW";

export const TILE_TYPES = {
  MY_LEARNING: "MY_LEARNING",
  POPULAR: "POPULAR",
  RECOMMENDED: "RECOMMENDED",
}
export const ATTENDANCE = 'Attendance';

export const EXCEPTIONS_CODES = {
  UnAuthorized: 'UnAuthorized'
}

export const SUB_HEADER_CONTENT_TYPE = {
  ATTENDANCE_CONFIRMATION: "ATTENDANCE_CONFIRMATION",
  ACTIVITY_COMPLETION: "ACTIVITY_COMPLETION",
}

export const PERMISSIONS = {
  CAN_VIEW_REPORT: "CanViewReport",
  CAN_MANAGE_ATTENDANCE: "CanManageAttendance",
  CAN_ENROLL_USERS: "CanEnrollUsers"
}

export const ENROLLMENT_DIALOG_TYPES = {
  COURSE: "Course",
  PATHWAY: "Pathway",
  ADMIN: "Admin"
}

export const SESSION_STOREAGE_KEYS = {
  LOGOUT_COMPLETE_LABEL: "logout_complete_label",
  LOGOUT_COMPLETE_DIALOG: "logout_complete_dialog",
  LOGIN_BACK: "loginback",
  HERE: "here",
  NOT_AUTHORIZED: "not_authorized",
  NOT_AUTHORIZED_DIALOG: "not_authorized_dialog",
  THEME_COLOR: "theme_name"
}

export const AUTH_PROVIDERS = {
  AZURE: "AZURE",
  OPTIMAL: "OPTIMAL"
}

export const TOKENS = {
  ACCESS_TOKEN: "ACCESS_TOKEN",
  ID_TOKEN: "ID_TOKEN"
}
export const SKILL_STATUS = {
  COMPLETED: "COMPLETED",
  NOT_STARTED: "NOT_STARTED",
  IN_PROGRESS: "IN_PROGRESS"
}
