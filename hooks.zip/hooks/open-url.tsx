import { useAppDispatch } from "store";
import { useTranslation } from "react-i18next";

const openUrlUtil = () => {
  const dispatch = useAppDispatch();
  const { t } = useTranslation();
  const openUrl = (url: string, target?: string) => {
    const windowEvent = window.open(url, target);

    if (!windowEvent || windowEvent.closed || typeof windowEvent.closed == "undefined") {
      dispatch({
        type: "alert/show",
        payload: {
          type: "error",
          title: t("popup_blocked_title"),
          message: t("popup_blocked_message"),
        },
      });
      return { isSuccess: false, windowEvent };
    }
    return { isSuccess: true, windowEvent };
  };
  return { openUrl };
};
export { openUrlUtil };
