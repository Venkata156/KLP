import { useEffect } from "react";
export const usePageTitle = (title: string | null) => {
    useEffect(() => {
        if (title) {
            document.title = title;
        } else {
            document.title = 'Learning Platform'
        }

    }, [title])
}