import { makeStyles } from "@material-ui/core";
import portalSettingsManager from "utils/portalSettingsManager";

export const useFocusStyles = makeStyles((theme) => ({
    focusItem: {
        "&:focus": { border: "2px solid #000000 !important" }
    },
    borderItem: {
        "border": `1px solid ${theme.palette.primary.main}`
    },
    greyBorder: {
        "border": `1px solid ${theme.palette.grey["A100"]}`,
    },
    border500: {
        "border": `1px solid ${theme.palette.grey["500"]}`
    },
    border800: { border: `1px solid ${theme.palette.grey["800"]}` },
    secondaryHover: {
        "&:hover": { backgroundColor: `${portalSettingsManager.buttonColors?.normal?.hover?.back} !important` }
    },
    primaryHover: {
        "&:hover": { border: `2px solid ${portalSettingsManager.buttonColors?.themed?.hover?.border || theme.palette.primary.main} !important` }
    },
}));

