import { useLazyQuery, useMutation } from "@apollo/client";
import { useAppDispatch } from "store";
import * as LastReminderDate from "utils/graphql/LastReminderDate";
import { GET_LAST_REMINDER_DATE, SEND_REMINDER } from "utils/queries";
import { useTranslation } from "react-i18next";

export function useLearningRecords(learnerId: any, contentId: any, contentType: string, contentTitle: string, dueDate: Date) {
  const dispatch = useAppDispatch();
  const { t } = useTranslation();
  const [sendNotification] = useMutation(SEND_REMINDER);

  const [getresult, { data: result, refetch: refreshReminder }] = useLazyQuery<LastReminderDate.LastReminderDateVariables>(
    GET_LAST_REMINDER_DATE,
    {
      fetchPolicy: "no-cache",
      variables: {
        learnerId: learnerId,
        contentId: contentId,
        contentType: contentType,
      },
    }
  );

  const sendReminder = () => {
    sendNotification({
      variables: {
        overdueReminderRequest: {
          learnerId: learnerId,
          contentId: contentId,
          contentType: contentType,
          contentTitle: contentTitle,
          dueDate: dueDate
        }
      }
    })
      .then(() => {
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('remind_counselee'),
            message: t('remind_counselee_success'),
          },
        });
      })
      .catch(() => {
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('remind_counselee'),
            message: t('remind_counselee_error'),
          },
        });
      });
  };

  return {
    getresult,
    result,
    refreshReminder,
    sendReminder
  }
}
