
import { useLazyQuery, useMutation } from "@apollo/client";
import { useEffect } from "react";
import { useState } from "react";
import { useAppDispatch } from "store";
import { CourseEnrollment } from "utils/graphql/CourseEnrollment";
import { COMPLETE_ENROLLMENT, COMPLETE_PATHWAY_ENROLLMENT, GET_COURSE_ENROLLMENT_DATA } from "utils/queries";
import { ENROLLMENT_DIALOG_TYPES } from "utils/constants";
import { useTranslation } from "react-i18next";

export function useEnrollment(handleEnroll: any) {
    const [enrollmentResult, setEnrollmentResult] = useState<any>(null)
    const [pathwayEnrollResult, setPathwayEnrollResult] = useState<any>(null)
    const [showLoader, setShowLoader] = useState(false);
    const { t } = useTranslation();

    const dispatch = useAppDispatch();

    const [loadEnrollmentData, { data }] = useLazyQuery<CourseEnrollment>(
        GET_COURSE_ENROLLMENT_DATA
    );

    const [completePathwayEnrollment, { data: pathwayData }] = useMutation(COMPLETE_PATHWAY_ENROLLMENT);
    const [completeEnrollment] = useMutation(COMPLETE_ENROLLMENT);

    useEffect(() => {
        if (data) {
            setEnrollmentResult(data)
        }
    }, [data])


    useEffect(() => {
        if (pathwayData) {
            setPathwayEnrollResult(pathwayData)
        }
    }, [pathwayData])
    const handleEnrollmentData = (courseId: any) => {
        loadEnrollmentData({ variables: { courseId: courseId } });
    }

    const handleCompleteEnrollment = (type: string, data: any, attendees: any) => {
        if (type === ENROLLMENT_DIALOG_TYPES.PATHWAY) {
            const enrollRes = { ...pathwayEnrollResult }
            const objIndex = enrollRes.completePathwayEnrollment.findIndex(((obj: any) => obj.courseId == data.courseId));
            Object.assign(enrollRes.completePathwayEnrollment[objIndex], { canEnroll: false, isEnrolled: true })
            setPathwayEnrollResult(enrollRes)
            setShowLoader(true)
            completeEnrollment({ variables: { courseEnroll: data, attendeesInput: attendees } })
                .then(() => {
                    dispatch({
                        type: "alert/show",
                        payload: {
                            type: "success",
                            title: t('course_enrolled_alert_title'),
                            message: t('course_enrolled_alert_message'),
                        },
                    });
                    setShowLoader(false)
                })
                .catch(() => {
                    dispatch({
                        type: "alert/show",
                        payload: {
                            type: "error",
                            title: t('course_enrolled_alert_title'),
                            message: t('course_enroll_error_alert_message'),
                        },
                    });
                    setShowLoader(false)
                });
        }
        else if (type === ENROLLMENT_DIALOG_TYPES.COURSE) {
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('enrolling') } });
            completeEnrollment({ variables: { courseEnroll: data, attendeesInput: attendees } })
                .then(() => {
                    dispatch({ type: "loader/showandhide", payload: { show: false, message: t('enrolling') } });
                    dispatch({
                        type: "alert/show",
                        payload: {
                            type: "success",
                            title: t('course_enrolled_alert_title'),
                            message: t('course_enrolled_alert_message'),
                        },
                    });
                    handleEnroll()
                })
                .catch((e) => {
                    dispatch({ type: "loader/showandhide", payload: { show: false, message: t('enrolling') } });
                    dispatch({
                        type: "alert/show",
                        payload: {
                            type: "error",
                            title: t('course_enrolled_alert_title'),
                            message: t('course_enroll_error_alert_message'),
                        },
                    });
                });
        } else {
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('enrolling') } });
            completeEnrollment({
                variables: { courseEnroll: data, attendeesInput: attendees },
            }).then(() => {
                dispatch({ type: "loader/showandhide", payload: { show: false, message: t('enrolling') } });
                dispatch({
                    type: "alert/show",
                    payload: {
                        type: "success",
                        title: t('course_enrolled_alert_title'),
                        message: t('course_enrolled_alert_message'),
                    },
                });
                handleEnroll()
            })
                .catch(() => {
                    dispatch({ type: "loader/showandhide", payload: { show: false, message: t('enrolling') } });
                    dispatch({
                        type: "alert/show",
                        payload: {
                            type: "error",
                            title: t('course_enrolled_alert_title'),
                            message: t('error_alert_message'),
                        },
                    });
                });
        }
    }

    const handlePathwayEnrollment = (id: string) => {
        completePathwayEnrollment({ variables: { pathwayId: id } })
            .then(() => {
                dispatch({ type: "loader/showandhide", payload: { show: false, message: t('add_to_mylearning') } });
            })
            .catch(() => {
                dispatch({ type: "loader/showandhide", payload: { show: false, message: t('add_to_mylearning') } });
            });

    }
    return {
        handleEnrollmentData,
        enrollmentResult,
        pathwayEnrollResult,
        handleCompleteEnrollment,
        handlePathwayEnrollment,
        setShowLoader,
        showLoader,
        setEnrollmentResult
    }
}
