/* eslint-disable @typescript-eslint/no-explicit-any */

import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { RootState } from "store";
import { useTranslation } from "react-i18next";

const getBreadCrumbsData = (): string => {
    return sessionStorage.getItem("breadCrumbs");
}

export function useBreadCrumbs() {

    const history = useHistory();
    const { t } = useTranslation();
    const initialSearchTerm = useSelector((state: RootState) => state.core.searchText);
    const breadCrumbObj = Boolean(getBreadCrumbsData()) ? getBreadCrumbsData() : JSON.stringify({ data: [{ title: `${t('home')}`, path: "/", type: "home" }], searchString: initialSearchTerm, category: "" });
    const [breadCrumbData, setBreadcrumbData] = useState(breadCrumbObj);

    if (!getBreadCrumbsData()) {
        sessionStorage.setItem("breadCrumbs", breadCrumbObj);
    }

    const setBreadcrumb = (data: any) => {
        if (typeof data !== "string") {
            data = JSON.stringify(data);
        }
        setBreadcrumbData(data);
        sessionStorage.setItem("breadCrumbs", data);
    };

    useEffect(() => {
        if (breadCrumbData) {
            const parsedData = [...JSON.parse(breadCrumbData).data]
            sessionStorage.setItem("breadCrumbs", JSON.stringify({ data: parsedData, searchString: initialSearchTerm }));
            setBreadcrumb(JSON.stringify({ data: parsedData, searchString: initialSearchTerm }))
        }
    }, [initialSearchTerm])
    const handleBreadCrumb = (data: any, type: string, searchString: string) => {
        if (breadCrumbData) {
            if (type === "override") {
                sessionStorage.setItem("breadCrumbs", JSON.stringify({ data: data, searchString: "" }));
                setBreadcrumb(JSON.stringify({ data: data, searchString: "" }))
                return;
            }
            let parsedData = [...JSON.parse(getBreadCrumbsData()).data]
            const findIndex = parsedData.findIndex((i: any) => i.path === data.path)
            if ((findIndex === -1 && sessionStorage.getItem("relatedItemClick") !== 'true')) {
                parsedData.push(data)
            } else if (type === "profile" || type === "playlist") {
                if (findIndex === -1) {
                    parsedData.push(data)

                } else {
                    parsedData[findIndex] = data

                }
            }
            else if (sessionStorage.getItem("relatedItemClick") !== 'true') {
                parsedData = parsedData.slice(0, findIndex + 1)
            } else {
                parsedData[findIndex] = data
            }

            if (type === "home") {
                sessionStorage.setItem("breadCrumbs", JSON.stringify({ data: [data], searchString: "" }));
                setBreadcrumb(JSON.stringify({ data: [data], searchString: "" }))
            }
            else if (type === "catalog") {
                sessionStorage.setItem("breadCrumbs", JSON.stringify({ data: parsedData, searchString: searchString ? searchString : "" }));
                setBreadcrumb(JSON.stringify({ data: parsedData, searchString: searchString ? searchString : "" }))
            } else if (type === "search") {
                sessionStorage.setItem("breadCrumbs", JSON.stringify({ data: [{ title: `${t('home')}`, path: "/" }, { title: `${t('search')}`, path: "/catalog" }], searchString: searchString ? searchString : "" }));
                setBreadcrumb(JSON.stringify({ data: [{ title: `${t('home')}`, path: "/" }, { title: `${t('search')}`, path: "/catalog" }], searchString: searchString ? searchString : "" }))
            }
            else {
                setBreadcrumb(JSON.stringify({
                    data: parsedData, searchString: JSON.parse(getBreadCrumbsData()).searchString ? JSON.parse(getBreadCrumbsData()).searchString : ""
                }))
                sessionStorage.setItem("breadCrumbs", JSON.stringify({
                    data: parsedData, searchString: JSON.parse(getBreadCrumbsData()).searchString ? JSON.parse(getBreadCrumbsData()).searchString : ""
                }));
            }
        }
    }
    const handleBreadCrumbNavigation = (path: string, index: any) => {
        if (breadCrumbData) {
            const result = [...JSON.parse(getBreadCrumbsData()).data]
            sessionStorage.setItem("relatedItemClick", "false")
            sessionStorage.setItem("breadCrumbs", JSON.stringify({ data: result.slice(0, index + 1), searchString: JSON.parse(getBreadCrumbsData()).searchString }));
            setBreadcrumb(JSON.stringify({ data: result.slice(0, index + 1), searchString: JSON.parse(getBreadCrumbsData()).searchString }))
            if (path?.toLocaleLowerCase() !== location.pathname?.toLocaleLowerCase()) {
                history.push(path)
            }
        }
    }

    return {
        handleBreadCrumb,
        breadCrumbData,
        handleBreadCrumbNavigation,
        setBreadcrumb
    }
}
