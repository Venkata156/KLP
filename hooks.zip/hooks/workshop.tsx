import { useMutation, useLazyQuery } from "@apollo/client";
import { useAppDispatch } from "store";
import { GET_EXPRESS_INTEREST_DATA, EXPRESS_INTEREST } from "utils/queries";
import { useTranslation } from "react-i18next";

export function useWorkshop() {
    const { t } = useTranslation();
    const dispatch = useAppDispatch();
    const [saveExpressInterest] = useMutation(EXPRESS_INTEREST);
    const [loadWorkshopData, { data: workshopData }] = useLazyQuery(
        GET_EXPRESS_INTEREST_DATA
    );

    const expressInterest = (expressObj: any) => {
        dispatch({ type: "loader/showandhide", payload: { show: true, message: t('refreshing_content') } });
        saveExpressInterest({ variables: { expressInterestInputData: expressObj } })
            .then(() => {
                dispatch({ type: "loader/showandhide", payload: { show: false, message: t('refreshing_content') } });
                dispatch({
                    type: "alert/show",
                    payload: {
                        type: "success",
                        title: t('submitted'),
                        message: t('submitted_successfully'),
                    },
                });
            })
            .catch(() => {
                dispatch({ type: "loader/showandhide", payload: { show: false, message: t('refreshing_content') } });
                dispatch({
                    type: "alert/show",
                    payload: {
                        type: "error",
                        title: t('submitted'),
                        message: t('submitted_error'),
                    },
                });
            });
    }
    return {
        loadWorkshopData,
        expressInterest,
        workshopData
    }
}
