import React, { useEffect, useState } from "react";
import { useLazyQuery, useMutation } from "@apollo/client";
import * as RatingTypes from "utils/graphql/LearnerRatingForContent";
import { useAppDispatch } from "store";
import { LEARNER_CONTENT_RATING, SAVE_LEARNER_CONTENT_RATING } from "utils/queries";
import { useTranslation } from "react-i18next";

export function useRating(
  contentId: any,
  contentType: any,
  refetch: any,
  isCompleted: any
) {
  const [saveLearnerRatingForContent] = useMutation(SAVE_LEARNER_CONTENT_RATING);
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const [needToOpenConf, setNeedToOpenConf] = useState<boolean>(false);
  const [isEditRatingOpen, setIsEditRatingOpen] = useState(false);
  const [isConfirmationOpen, setIsConfirmationOpen] = React.useState(false);
  const [rating, setRating] = useState<number>(0);
  const allowToSubmit = isCompleted === "Completed" || isCompleted === null;

  const [loadContent, { data }] = useLazyQuery<RatingTypes.LearnerRatingForContent>(
    LEARNER_CONTENT_RATING,
    {
      fetchPolicy: "no-cache",
      notifyOnNetworkStatusChange: true,
    }
  );

  const closeConfirmationDialog = () => {
    setIsConfirmationOpen(false);
  };
  const closeEditRatingDialog = () => {
    setIsEditRatingOpen(false);
  };

  useEffect(() => {
    if (data) {
      setIsEditRatingOpen(true);
      if (data.learnerRatingForContent !== null && data?.learnerRatingForContent >= 1) {
        setRating(data.learnerRatingForContent);
        setNeedToOpenConf(true);
      } else {
        setRating(0);
      }
      dispatch({ type: "loader/showandhide", payload: { show: false } });
    }
  }, [data]);

  const openEditRating = () => {
    if (allowToSubmit) {
      if (!isEditRatingOpen) {
        dispatch({ type: "loader/showandhide", payload: { show: true } });
        loadContent({
          variables: {
            contentId: contentId,
            contentType: contentType,
          },
        });
      } else {
        setIsEditRatingOpen(!isEditRatingOpen);
      }
    }
  };

  const onSubmit = (updateRating: any) => {
    if (needToOpenConf && !isConfirmationOpen) {
      setRating(updateRating);
      setIsConfirmationOpen(true);
    } else {
      submitRating(updateRating ? updateRating : rating);
    }
  };

  const submitRating = (updateRating: any) => {
    dispatch({ type: "loader/showandhide", payload: { show: true, message: t('refreshing_content') } });
    setIsEditRatingOpen(false);
    setIsConfirmationOpen(false);
    saveLearnerRatingForContent({
      variables: { contentId: contentId, contentType: contentType, rating: updateRating },
    })
      .then(() => {
        if (refetch) {
          refetch();
        }
        dispatch({ type: "loader/showandhide", payload: { show: false, message: t('refreshing_content') } });
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('rating_submitted'),
            message: t('rating_submitted_success'),
          },
        });
      })
      .catch(() => {
        dispatch({ type: "loader/showandhide", payload: { show: false, message: t('refreshing_content') } });
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('rating_submitted'),
            message: t('rating_submitted_error'),
          },
        });
      });
  };

  return {
    rating,
    openRating: allowToSubmit ? openEditRating : false,
    onSubmit,
    isEditRatingOpen,
    closeEditRatingDialog,
    isConfirmationOpen,
    closeConfirmationDialog,
  };
}
