import { ActivityType } from 'utils/graphql/Global';
import { Activities_activities } from '../../utils/graphql/Activities';
export const availableActivities: Activities_activities[] = [
    
        {
          "id": "1184",
          "name": "Theory of Accounting ",
          "type": ActivityType.AUDIO,
          "statusCode": "InProgress",
          "description": "\u003Cp\u003EIn this activity you will see some videos to how you can master on accounting\u003C/p\u003E",
          "hasSessionInfo": false,
          "hasLaunchUrl": true,
          "hasContent": true,
          "availableSessions": [],
          "bookedSession": null,
          "url": "/player/5366/1184",
          "__typename": "Activity"
        },
        {
          "id": "1228",
          "name": "Revenue Service",
          "type": ActivityType.ASSESSMENT,
          "statusCode": "Enrolled",
          "description": "\u003Cp\u003EIn this activity you would get some on experience in Revenue service and its details\u003C/p\u003E",
          "hasSessionInfo": false,
          "hasLaunchUrl": false,
          "hasContent": false,
          "availableSessions": [],
          "bookedSession": null,
          "url": null,
          "__typename": "Activity"
        },
        {
          "id": "5372",
          "name": "IIEST -Elearning new",
          "type": ActivityType.AUDIO,
          "statusCode": "Enrolled",
          "description": "\u003Cp\u003EIIEST -Elearning new desc\u003C/p\u003E",
          "hasSessionInfo": false,
          "hasLaunchUrl": true,
          "hasContent": true,
          "availableSessions": [],
          "bookedSession": null,
          "url": "/player/5366/5372",
          "__typename": "Activity"
        },
        {
          "id": "1354",
          "name": "Big Data",
          "type": ActivityType.ASSIGNMENT,
          "statusCode": "Enrolled",
          "description": "\u003Cp\u003EBig data is a field that treats ways to analyze, systematically extract information from, or otherwise deal with data sets that are too large or complex to be dealt with by traditional data-processing application software. Data with many fields (columns) offer greater statistical power, while data with higher complexity (more attributes or columns) may lead to a higher false discovery rate. Big data analysis challenges include capturing data, data storage, data analysis, search, sharing, transfer, visualization, querying, updating, information privacy, and data source. Big data was originally associated with three key concepts: volume, variety, and velocity. The analysis of big data presents challenges in sampling, and thus previously allowing for only observations and sampling. Therefore, big data often includes data with sizes that exceed the capacity of traditional software to process within an acceptable time and value.\u003C/p\u003E",
          "hasSessionInfo": false,
          "hasLaunchUrl": false,
          "hasContent": true,
          "availableSessions": [],
          "bookedSession": null,
          "__typename": "Activity",
          "url": null
        },
        {
          "id": "5370",
          "name": "Sample Audio",
          "type": ActivityType.AUDIO,
          "statusCode": "Enrolled",
          "description": "Sample Audio",
          "hasSessionInfo": false,
          "hasLaunchUrl": false,
          "hasContent": true,
          "availableSessions": [],
          "bookedSession": null,
          "url": "/player/5366/5370",
          "__typename": "Activity"
        },
        {
          "id": "9999",
          "name": "Sample Litrature",
          "type": ActivityType.LITERATURE,
          "statusCode": "Enrolled",
          "description": "Sample Litrature",
          "hasSessionInfo": false,
          "hasLaunchUrl": false,
          "hasContent": true,
          "availableSessions": [],
          "bookedSession": null,
          "url": "https://glb-portal-global-dev.klp.kpmgdevcloud.kpmg.com/media/pldlswg2/csl-cognisco-release_901bcbe2af4448c88f00ef6e2965daf1-050521-1558-142.pdf?sv=2019-07-07&sr=b&sig=zO2PhDC%2FCJV%2BKKbW%2Fb%2Fndj8NMwBz7JDVGtJn0CGD8k4%3D&st=2022-04-20T16%3A26%3A31Z&se=2022-04-20T17%3A31%3A31Z&sp=r%22",
          "__typename": "Activity"
        }
        
]

export const activities = [
    {
        "id": "2",
        "name": "ActivityName2",
        "Type": "FACE_TO_FACE",
        "TypeName": "Face To Face",
        "Description": "Activity Details",
        "hasLaunchUrl": true,
        "hasSessionInfo": true,
        "url": "https://www.youtube.com/watch?v=4UZrsTqkcW4",
        "statusCode": "Completed",
        "statusText": "Completed",
        "bookedSession": {
            "id": "22222",
            "startDateTime": "03/03/2021 03:00:00 PM",
            "endDateTime": "03/03/2021 04:00:00 PM",
            "startDateTimeDisplay": "03/03/2021 3:00 PM",
            "endDateTimeDisplay": "03/03/2021 4:00 PM",
            "duration": "1 hour",
            "location": "London",
            "address": {
                "name": "Battersea Station",
                "streetAddress1": "address1",
                "streetAddress2": "address2",
                "City": "City",
                "State": "NY",
                "PostalCode": "12345"
            }
        }
    }
]