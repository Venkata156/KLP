import { graphql } from 'msw';
import { ActivityURL, ActivityURLVariables } from '../../utils/graphql/ActivityURL';

export const activityUrl = "https://www.youtube.com/watch?v=4UZrsTqkcW4";

export const getActivityUrl = graphql.query<ActivityURL, ActivityURLVariables>('ActivityURL', (req, res, ctx) => {
    return res(
        ctx.data({
            activityUrl: req.variables.activityType ? activityUrl : null,
        }),
    )
});