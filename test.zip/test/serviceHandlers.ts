// this is put into here so I can share these same handlers between my tests
// as well as my development in the browser. Pretty sweet!
import { getActivityUrl } from './mocks/GetActivityUrl';

const handlers = [
    getActivityUrl
]

export { handlers }