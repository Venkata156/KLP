import React, { ComponentType, ReactElement } from 'react'
import { render, RenderResult, Queries, RenderOptions } from '@testing-library/react'
import { Provider } from "react-redux";
import { ThemeProvider } from "@material-ui/core/styles";
import store from "../store";
import { theme } from "components"; import {
    ApolloClient,
    ApolloProvider,
    DefaultOptions,
    createHttpLink,
    from,
    InMemoryCache,
    NormalizedCacheObject,
} from "@apollo/client";

const defaultOptions: DefaultOptions = {
    watchQuery: {
        fetchPolicy: 'no-cache'
    },
    query: {
        fetchPolicy: 'no-cache'
    },
}
const httpLink = createHttpLink({
    uri: process.env.REACT_APP_API_HOSTNAME,
});
const client: ApolloClient<NormalizedCacheObject> = new ApolloClient({
    cache: new InMemoryCache({}),
    link: from([httpLink]),
    defaultOptions: defaultOptions
});

const AllTheProviders = ({ children }: { children: React.ReactNode }): ReactElement => (
    <Provider store={store}>
        <ThemeProvider theme={theme}>
            <ApolloProvider client={client}>
                {children}
            </ApolloProvider>
        </ThemeProvider>
    </Provider>
);

const customRender = (ui: React.ReactElement, options: RenderOptions<Queries, HTMLElement> = {}): RenderResult<Queries, HTMLElement> =>
    render(ui, { wrapper: AllTheProviders as ComponentType, ...options });

export * from '@testing-library/react';
import userEvent from '@testing-library/user-event';

export { customRender as render, userEvent, theme }