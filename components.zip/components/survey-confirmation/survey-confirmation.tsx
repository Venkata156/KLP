import { Typography, useMediaQuery } from "@material-ui/core";
import MuiButton from "@material-ui/core/Button";
import MuiDialogActions from "@material-ui/core/DialogActions";
import { Theme, withStyles, useTheme } from "@material-ui/core/styles";
import { Dialog, DialogContent, Action } from "components";
import { useTranslation } from "react-i18next";
import { useFocusStyles } from "hooks/focusBorder";
import portalSettingsManager from "utils/portalSettingsManager";

const DialogActions = withStyles(() => ({
  root: {
    display: "flex",
    padding: "40px 38px 25px 40px",
    height: "42px",
  },
}))(MuiDialogActions);

const Button = withStyles((theme: Theme) => ({
  root: {
    borderRadius: 0,
    color: portalSettingsManager.application?.common?.themeColor || theme.palette.grey["A400"],
  },
  label: {
    fontSize: 12,
    fontWeight: 700,
  },
  outlined: {
    border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]}`,
  },
  disabled: {
    color: theme.palette.grey["500"],
  },
}))(MuiButton);

export const SurveyConfirmation = ({
  open,
  handleShowSurvey,
  handleClose,
  handleSkipSurvey,
  userDisplayName,
}: {
  open?: boolean;
  handleShowSurvey: () => void;
  handleClose: () => void;
  handleSkipSurvey: () => void;
  userDisplayName: string;
}): JSX.Element => {
  const theme = useTheme();
  const { t } = useTranslation();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const handleDialogClose = () => {
    handleClose();
  };

  const handleCustomization = (type: "continue" | "skip") => {
    if (type === "continue") {
      handleShowSurvey();
    } else if (type === "skip") {
      handleDialogClose();
      handleSkipSurvey();
    }
  };
  const contentHeaderStyle = {
    fontSize: isMobile ? "20px" : "30px",
    lineHeight: isMobile ? "25px" : "45px",
  };
  const focusClass = useFocusStyles();

  
  return (
    <Dialog
      id="surveydialog"    
      onClose={handleDialogClose}
      aria-labelledby="dialog1_label" aria-describedby="dialog1_label"
      open={Boolean(open)}
      minWidth={!isMobile ? 820 : undefined}
      minHeight={!isMobile ? 430 : undefined}
      maxHeight={430}
      fullScreen={isMobile}
      showCloseIcon
      aria-modal={true}
      role="dialog"
      {...{
        disableBackdropClick: true,
        disableEscapeKeyDown: true        
      }}
    >
      <DialogContent style={{ padding: "8px 38px 8px 40px" }}>
        <div id="dialog1_label">
          <Typography style={{ color: theme.palette.grey["800"], ...contentHeaderStyle }} component="h2">
            {t('hi')}, {userDisplayName}.
        </Typography>
          <Typography  aria-level={2} role="heading" style={{ color: portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main, ...contentHeaderStyle }} >
            {t('welcome_message')}
          </Typography>
        </div>
        <Typography
          style={{
            fontSize: isMobile ? "16px" : "18px",
            color: theme.palette.grey["800"],
            lineHeight: isMobile ? "24px" : "27px",
            marginTop: "30px",
          }}
          component="h3"
        >
          {t('survey_confirmation_description')}
        </Typography>
      </DialogContent>
      <DialogActions style={{ marginBottom: isMobile ? "20px" : undefined }}>
        <Action type="dialog-alt-contrast" onClick={() => handleCustomization("skip")}>
          {t('skip_customization_jumpin')}
        </Action>
        <Button
          variant="outlined"
          onClick={() => handleCustomization("continue")}
          style={{
            padding: "30px 0px 30px",
            width: "267px",
            height: "42px",
          }}
          className={focusClass.secondaryHover}
        >
          {t('continue_with_customization')}
        </Button>
      </DialogActions>
    </Dialog>
  );
};
