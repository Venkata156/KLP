import React, { useEffect } from "react";
import { AUTH_PROVIDERS } from "utils/constants";
import { MsalProvider } from "@azure/msal-react";
import { tenantSettings } from "utils/authentication/tenantSettings";
import { AuthProvider, useAuth, hasAuthParams } from "react-oidc-context";
import { AzureApolloConnection } from "./AzureApolloConnection";
import { OptimalApolloConnection } from "./OptimalApolloConnection";
export interface IReactNodeProps {
    children: React.ReactNode
}

export type TenantAuthProviderProps = IReactNodeProps
export type OidcWrapperProps = IReactNodeProps

const OidcWrapper = ({ children }: OidcWrapperProps): JSX.Element => {
    const auth = useAuth();
    useEffect(() => {
        const canRedirect = !hasAuthParams() &&
            !auth.isAuthenticated &&
            !auth.activeNavigator &&
            !auth.isLoading;
        if (canRedirect) {
            //capture the url user is trying to access?
            window.sessionStorage.setItem(
                'redirectTo',
                `${location.pathname}${location.search}`,
            );
            auth.signinRedirect({ redirectMethod: "replace" });
        }
    }, [auth]);

    if (auth.error) {
        return <div>Oops... {auth.error.message}</div>;
    }
    if (auth.isAuthenticated) {
        return (
            <>
                {children}
            </>
        );
    }
    return (<></>)
}

const onSigninCallback = (): void => {
    window.history.replaceState(
        {},
        document.title,
        window.location.pathname
    )
    const redirectToUrl = sessionStorage.getItem("redirectTo")
    if (redirectToUrl) {
        sessionStorage.removeItem("redirectTo");
        window.location.href = redirectToUrl;
    }
}

export const TenantAuthProvider: React.FC<TenantAuthProviderProps> = (): JSX.Element => {
    const type = tenantSettings.idp;
    switch (type) {
        case AUTH_PROVIDERS.AZURE:
            const instance = tenantSettings.authService.getConfig();
            return (
                <MsalProvider instance={instance}>
                    <AzureApolloConnection />
                </MsalProvider>
            )
        case AUTH_PROVIDERS.OPTIMAL:
            const config = tenantSettings.authService.getConfig();;
            config.onSigninCallback = onSigninCallback;
            return (
                <AuthProvider {...config}>
                    <OidcWrapper>
                        <OptimalApolloConnection />
                    </OidcWrapper>
                </AuthProvider>
            )
        default:
            return null;
    }
};
