import {
  ApolloClient,
  ApolloProvider,
  createHttpLink,
  DefaultOptions,
  from,
  InMemoryCache,
  NormalizedCacheObject,
  ApolloLink,
  ServerError,
} from "@apollo/client";
import { setContext } from "@apollo/client/link/context";
import { useIsAuthenticated } from "@azure/msal-react";
import {
  InteractionRequiredAuthError,
  SilentRequest,
} from "@azure/msal-browser";
import { useAccount, useMsal } from "@azure/msal-react";
import { onError } from "apollo-link-error";
import { useHistory } from "react-router-dom";
import SessionManager from "utils/sessionManager";
import { tenantSettings } from "utils/authentication/tenantSettings";
import App from "App";

export const AzureApolloConnection = (): JSX.Element => {
  const { instance, accounts, inProgress } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  const account = useAccount(accounts[0] || {});
  const AsyncTokenLookup = async (forceRefresh = false) => {
    const loginRequest = {
      scopes: tenantSettings.customConfig.api.scopes as string[],
    } as SilentRequest;
    if (forceRefresh) {
      loginRequest.forceRefresh = true as boolean;
    }

    if (account && inProgress === "none") {
      try {
        const result = await instance.acquireTokenSilent({
          ...loginRequest,
          account,
        });
        if (!result.fromCache) {
          // record when the token was last fetched (now)
          SessionManager.updateTokenLastFetchedAt();
        }
        return result;
      } catch (err) {
        if (err instanceof InteractionRequiredAuthError) {
          return instance.acquireTokenRedirect(loginRequest);
        }
      }
    } else if (!account && inProgress === "none") {
      return instance.acquireTokenRedirect(loginRequest);
    }
    return null;
  };

  const withToken = setContext(async (_, { headers }) => {
    const authenticationResult = await AsyncTokenLookup();
    const { accessToken, idToken } = authenticationResult || {};
    const authHeaders = tenantSettings.customConfig.getRequestHeaders?.(idToken, accessToken) || {};
    return {
      headers: {
        ...headers,
        ...authHeaders
      },
    };
  });

  const httpLink = createHttpLink({
    uri: tenantSettings.customConfig.api.baseUrl,
  });

  const history = useHistory();

  const errorLink = onError(({ networkError }) => {
    if (networkError) {
      if ((networkError as ServerError)?.statusCode === 403) {
        history.push("/unauthorized");
        console.warn(`server returned 403`);
      } else {
        console.log(`[Network error]: ${networkError}`);
      }
    }
  });

  const defaultOptions: DefaultOptions = {
    watchQuery: {
      fetchPolicy: "no-cache",
    },
    query: {
      fetchPolicy: "no-cache",
    },
  };

  const client: ApolloClient<NormalizedCacheObject> = new ApolloClient({
    cache: new InMemoryCache({}),
    link: from([errorLink as unknown as ApolloLink, withToken, httpLink]),
    defaultOptions: defaultOptions,
  });

  const onSilentRenew = async () => {
    await AsyncTokenLookup(true);
  };

  const onLogout = async () => {
    await tenantSettings.authService.signOut();
  };

  return (
    <ApolloProvider client={client}>
      <App
        onSilentRenew={onSilentRenew}
        isAuthenticated={isAuthenticated}
        onLogout={onLogout} />
    </ApolloProvider>
  );
};
