import {
  ApolloClient,
  ApolloProvider,
  createHttpLink,
  DefaultOptions,
  from,
  InMemoryCache,
  NormalizedCacheObject,
  ApolloLink,
  ServerError,
} from "@apollo/client";
import { tenantSettings } from "utils/authentication/tenantSettings";
import { setContext } from "@apollo/client/link/context";
import App from "App";
import { onError } from "apollo-link-error";
import { useHistory } from "react-router-dom";
import { useAuth } from "react-oidc-context";
import sessonManager from "utils/sessionManager";
import { useCallback, useMemo } from "react";

export const OptimalApolloConnection = (): JSX.Element => {
  const auth = useAuth()
  const AsyncTokenLookup = async () => {
    if (auth.isAuthenticated) {
      const user = auth.user;
      return {
        accessToken: user?.access_token,
        idToken: user?.id_token
      }
    } else {
      auth.signinRedirect();
      return null;
    }
  };

  const withToken = setContext(async (_, { headers }) => {
    const authenticationResult = await AsyncTokenLookup();
    const { accessToken, idToken } = authenticationResult || {};
    const authHeaders = tenantSettings.customConfig.getRequestHeaders?.(idToken, accessToken) || {};
    return {
      headers: {
        ...headers,
        ...authHeaders
      },
    };
  });

  const httpLink = createHttpLink({
    uri: tenantSettings.customConfig.api.baseUrl,
  });

  const history = useHistory();

  const errorLink = onError(({ networkError }) => {
    if (networkError) {
      if ((networkError as ServerError)?.statusCode === 403) {
        history.push("/unauthorized");
        console.warn(`server returned 403`);
      } else {
        console.log(`[Network error]: ${networkError}, isFromIframe: ${window.location !== window.parent.location}`);
      }
    }
  });

  const defaultOptions: DefaultOptions = {
    watchQuery: {
      fetchPolicy: "no-cache",
    },
    query: {
      fetchPolicy: "no-cache",
    },
  };

  const client = useMemo<ApolloClient<NormalizedCacheObject>>(() => {
    return new ApolloClient({
      cache: new InMemoryCache({}),
      link: from([errorLink as unknown as ApolloLink, withToken, httpLink]),
      defaultOptions: defaultOptions,
    });
  }, []);

  const onSilentRenew = async () => {
    await auth.signinSilent();
    sessonManager.updateTokenLastFetchedAt();
  };

  const onLogout = async () => {
    tenantSettings.authService.signOut();
  }

  const onSilenRenewCallback = useCallback(onSilentRenew, []);
  const onLogoutCallback = useCallback(onLogout, []);
  return (
    <ApolloProvider client={client}>
      <App onSilentRenew={onSilenRenewCallback} isAuthenticated={true} onLogout={onLogoutCallback} />
    </ApolloProvider>
  );
};
