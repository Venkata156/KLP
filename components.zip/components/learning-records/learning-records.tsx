import { cloneElement, FC, useState } from "react";
import { KeyboardArrowDown } from "@material-ui/icons";
import { EmailIcon, CertificationIcon } from "components";

import { orderBy } from "@progress/kendo-data-query";
import { Grid, GridColumn } from "@progress/kendo-react-grid";
import { Box, IconButton, withStyles, useTheme } from "@material-ui/core";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";

const initCounSort = [
  {
    field: "ProductName",
    // dir: "asc",
  },
];
const rowRender = (trElement: any, props: any) => {
  const available = props?.dataItem?.isReminderEnabled;
  const red = {
    color: "#d82d42",
  };
  const black = {
    color: "#333333",
  };
  const trProps = {
    style: available ? red : black,
    tabIndex: 0
  };
  return cloneElement(trElement, { ...trProps }, trElement.props.children);
};

interface IconProps {
  sendReminder: any;
  setLearnerName: any;
  props: any;
}
const CellReminderWithIcon: FC<IconProps> = ({ props, setLearnerName, sendReminder }) => {
  const style = {
    color: "#fff",
    fontSize: "13px",
    "text-align": "center",
  };
  if (!props?.dataItem?.isReminderEnabled) {
    return <td style={style}></td>;
  }
  return (
    <td style={style} tabIndex={0}>
      <EmailIcon
        stroke={props.stroke || '#333333'}
        style={{ color: "#0091da", fontSize: "1.3rem", cursor: "pointer" }}
        onClick={() => { sendReminder(props); setLearnerName() }}
      />
    </td>
  );
};

const CellReminderHasCertificate = ({ props }: any) => {
  const style = {
    color: "#fff",
    fontSize: "13px",
    "text-align": "left",
  };
  if (!props?.dataItem?.hasCertificate) {
    return <td style={style}></td>;
  }
  return (
    <td style={style} tabIndex={0}>
      <CertificationIcon width="16px" height="16px" stroke="#333333" />
    </td>
  );
};
const CellStatusWithColor = (props: any) => {
  let color = "#2da5e1";
  const { t } = useTranslation();
  if (props.dataItem.statusCode === "Enrolled") {
    color = "#cd228f";
  }
  if (props.dataItem.isReminderEnabled) {
    color = "#d82d42";
  }
  const style = {
    color: color,
  };
  return <td style={style}>{t(props.dataItem.statusCode?.toLowerCase())}</td>;
};

interface GridProps {
  data: any;
  sendReminder: any;
  setLearnerName: any;
}
export const LearningRecords: FC<GridProps> = ({ data, setLearnerName, sendReminder }) => {
  const { t } = useTranslation();
  const [counSort, setCounSort] = useState(initCounSort);
  const theme = useTheme();

  const Container = withStyles(() => ({
    root: {
      height: "100%",
      "& .k-grid": {
        border: "none",
      },
      "& .k-grid > .k-grid-header > .k-grid-header-wrap": {
        borderWidth: "0",
      },
      "& .k-grid > .k-grid-header > .k-grid-container > .k-grid-content, .k-grid-content": {
        overflowY: "auto",
      },
      "& .k-grid > .k-grid-container > .k-grid-content table.k-grid-table": {
        fontSize: "12px",
      },
      "& table > thead th.k-header": {
        color: "#000",
      },
      "& .k-widget.k-grid":{
        [theme.breakpoints.down("xs")]: {
          width: "calc(600px - 200px)",
          overflow:"auto"
        },
      }
    },
  }))(Box);

  return (
    <Container tabIndex={0}>
      <Grid
        data={orderBy(data, counSort)}
        sortable={true}
        sort={counSort}
        onSortChange={(e) => {
          setCounSort(e.sort);
        }}
        rowRender={rowRender}
      >
        <GridColumn
          width={39}
          cell={(props) => <CellReminderHasCertificate tabIndex={0} props={{ ...props }} />}
        />
        <GridColumn width={200} field="name" title={t('item')} sortable={true} />
        <GridColumn width={140} field="contentType" title={t('type')} sortable={true} />
        <GridColumn width={140} field="statusCode" title={t('status')} cell={CellStatusWithColor} />
        <GridColumn width={140} field="dueDate" title={t('required_by')} sortable={true} />
        <GridColumn
          width={110}
          field="isReminderEnabled"
          title={t('reminder')}
          cell={(props) => (
            <CellReminderWithIcon
              props={{ ...props }}
              setLearnerName={setLearnerName}
              sendReminder={(params: any) => sendReminder(params)}
            />
          )}
        />
      </Grid>
    </Container>
  );
};

interface Props {
  data: any;
  counseleeItemDetail: any;
  sendReminder: any;
  counseleeItems: any;
  setLearnerName: any;
  setExpanded: any;
  expanded: any
}

export const CounseleeAccordion: FC<Props> = ({
  data,
  counseleeItemDetail,
  counseleeItems,
  setLearnerName,
  sendReminder,
  setExpanded,
  expanded,
}): JSX.Element => {
  const { t } = useTranslation();
  const ToggleCounselee = withStyles(() => ({
    root: (props: any) =>
      props.className == "expanded"
        ? {
          borderRadius: "50%",
          background: `${portalSettingsManager.application?.common?.themeColor}`,
          color: "#ffffff",
          "& svg": {
            transform: "rotate(180deg)",
          },
          "&:hover": {
            background: "#0091da",
          }
        }
        : {
          color: "#333333",
          "& svg": {
            transform: "none",
          },
        },
  }))(IconButton);

  const items = counseleeItems?.coursesAndPathwaysByLearner;
  return (
    <Box>
      <Box
        paddingRight="10px"
        borderBottom="1px solid #d8d8d8"
        className={`${expanded ? "expanded" : ""}`}
      >
        <Box
          display="flex"
          alignItems="center"
          minHeight="30px"
          m="10px 0"
          style={{ fontSize: "12px", color: `${expanded ? portalSettingsManager.application?.common?.themeColor : "#333333"}` }}
        >
          <Box flex="1" position="relative" style={{ fontWeight: 400 }}>
            <span style={{ paddingLeft: "44px" }}>{data?.fullName}</span>
            <ToggleCounselee
              aria-label={t('aria_label_click_to_toggle')}
              size="small"
              onClick={() => {
                setExpanded(expanded === data.id ? "" : data.id);
                // refreshCounsleeItems({ learnerId: data?.id });
                (!expanded || expanded !== data.id) && counseleeItemDetail();
              }}
              style={{ position: "absolute", top: "-6px", right: "0" }}
              className={`${expanded === data.id ? "expanded" : ""}`}
            >
              <KeyboardArrowDown />
            </ToggleCounselee>
          </Box>
        </Box>
        {expanded === data.id && (
          <>
            <Box>
              <Box
                m="10px 0 30px 0"
                style={{ fontSize: "13px", color: "#333333", lineHeight: "21px" }}
              >
                <LearningRecords data={items} setLearnerName={() => setLearnerName(data?.fullName)} sendReminder={(params: any) => sendReminder(params)} />
              </Box>
            </Box>
          </>
        )}
      </Box>
    </Box>
  );
};
