import React from 'react'
import { Box, useTheme, Button, useMediaQuery } from "@material-ui/core";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";
import styles from "./learning-carousel.module.css";
import { useFocusStyles } from "hooks/focusBorder";
import { useEffect, useState } from "react";
interface LearningCarouselHeaderProps {
    showViewAll: boolean,
    handleViewAll: () => void,
    title: string,
    showHeaderCount: boolean,
    showHeaderWithZeroCount?: boolean,
    contentCount: number | undefined
}

export const LearningCarouselHeader = ({
    showHeaderCount = true,
    handleViewAll,
    showViewAll = true,
    showHeaderWithZeroCount = false,
    title,
    contentCount = 0
}: LearningCarouselHeaderProps): JSX.Element => {
    const theme = useTheme();
    const isSmallMobile = useMediaQuery(theme.breakpoints.down("xs"));
    const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
    const { t } = useTranslation();
    const focusClass = useFocusStyles();
    const [headerTitle, setHeaderTitleTitle] = useState(title);

    useEffect(() => {
        if (showHeaderCount && contentCount && contentCount > 0) {
            setHeaderTitleTitle(`${title} (${contentCount})`);
        } else {
            setHeaderTitleTitle(title);
        }
    }, [title, showHeaderCount, contentCount]);

    return (
        <>
            {contentCount > 0 || showHeaderWithZeroCount ? 
            <Box style={{ display: "flex" }} flexDirection={isSmallMobile?"column":"row"} justifyContent={isSmallMobile?"center":"flex-start"} alignItems={isSmallMobile?"center":"flex-start"}>
                <Box style={{ flex: 1 }} textAlign={{ xs: "center", sm: "left" }}>
                    <h2
                        style={{
                            fontSize: `${portalSettingsManager.fonts?.learningSection?.titleFont?.size || "18px"
                                }`,
                            fontWeight: "bold",
                            display: "block",
                            fontFamily:
                                portalSettingsManager.fonts?.learningSection?.titleFont?.name || "inherit",
                            color:
                                portalSettingsManager.fonts?.learningSection?.titleFont?.color ||
                                theme.palette.grey["800"],
                        }}
                    >
                        {headerTitle}
                        </h2>
                </Box>
                {showViewAll &&
                    <Box>
                        <Button
                            style={{
                                width: "116px",
                                height: "38px",
                                border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]}`,
                                borderRadius: 0,
                                color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
                                backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back,
                                fontSize: "12px",
                                fontWeight: 700,
                                marginLeft: "20px",
                                marginRight: isMobile ? "0px" : "66px"
                            }}
                            className={`${focusClass.focusItem} ${styles.focusOnly} ${focusClass.secondaryHover}`}
                            onClick={handleViewAll}
                            role="link"
                            aria-label={title +' - '+t("view_all_button_text")}
                        >
                            {t("view_all_button_text")}
                        </Button>
                    </Box>
                }
            </Box> 
            :
             <></>}
        </>
    )
}
