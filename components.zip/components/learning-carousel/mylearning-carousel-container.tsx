/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useEffect, useCallback } from "react";
import { Box, Button, useTheme, useMediaQuery } from "@material-ui/core";
import { LearningCarouselHeader } from "./learning-carousel-header";
import { LearningCarousel } from "./learning-carousel";
import {
  CATEGORY_CODE_REQUIRED,
  CATEGORY_CODE_MYINTEREST,
  CATEGORY_CODE_CHANNEL,
  CATEGORY_CODE_PARENTPATHWAY,
  SORT_ALPHABETICAL_ASCENDING,
  SORT_ALPHABETICAL_DESCENDING,
  SORT_DURATION_ASCENDING,
  SORT_DURATION_DESCENDING,
  SORT_PRICE_ASCENDING,
  SORT_PRICE_DESCENDING,
  SORT_DEFAULT,
} from "utils/constants";
import { useTranslation } from "react-i18next";
import { useFocusStyles } from "hooks/focusBorder";
import { isNumber } from "lodash";
import {
  Tabs,
  TabPanel,
  Select
} from "components";
import portalSettingsManager from "utils/portalSettingsManager";
import styles from "./learning-carousel.module.css";
import { useAppDispatch } from "store";
import { useHistory } from "react-router-dom";
import { BorderColor } from "@material-ui/icons";

export const MyLearningCarouselContainer = (props: any): JSX.Element => {
  const isMyLearningTileView: boolean | undefined = portalSettingsManager.application?.common?.showMyLearningSectionAsCarousal;
  const component = !isMyLearningTileView ? (
    <TileView title={props.title} {...props} />
  ) : (
    <CarouselView title={props.title} {...props} />
  );

  return component;
};

const CarouselView = (props: any): JSX.Element => {
  const renderOrder = [CATEGORY_CODE_REQUIRED, CATEGORY_CODE_PARENTPATHWAY, CATEGORY_CODE_CHANNEL, CATEGORY_CODE_MYINTEREST];
  const [activeTab, setActiveTab] = useState<any>(renderOrder[0]);
  const activeTabIndex = renderOrder.indexOf(activeTab); 
  const [contentCount, setContentCount] = useState<number | undefined>();
  const [contentCountMapper, setContentCountMapper] = useState<any>({
    [CATEGORY_CODE_REQUIRED]: 0,
    [CATEGORY_CODE_MYINTEREST]: 0,
    [CATEGORY_CODE_CHANNEL]: 0,
    [CATEGORY_CODE_PARENTPATHWAY]: 0
  });
  const [sortMapper, setSortMapper] = useState<any>({
    [CATEGORY_CODE_REQUIRED]: SORT_DEFAULT,
    [CATEGORY_CODE_MYINTEREST]: SORT_DEFAULT,
    [CATEGORY_CODE_CHANNEL]: SORT_DEFAULT,
    [CATEGORY_CODE_PARENTPATHWAY]: SORT_DEFAULT
  }); 
  const { t } = useTranslation();
  const dispatch = useAppDispatch();
  const history = useHistory();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const isSmallerMobile = useMediaQuery(theme.breakpoints.down("xs"));
  const isMD = useMediaQuery(theme.breakpoints.down("md"));
  const handleSort = (sort: any) => {
    setSortMapper((prevState: any) => {
      const newState = {
        ...prevState,
        [activeTab]: sort,
      };
      return newState;
    });
  };

  const updateListCallback = useCallback((list: any, contentCount: number | undefined, code: string): void => {
    setContentCountMapper((prevState: any) => {
      const newState = {
        ...prevState,
        [code]: isNumber(contentCount) ? contentCount : 0
      }
      return newState;
    })
  }, []);

  useEffect(() => {
    const total = Object.values(contentCountMapper).reduce((count, value) => Number(count) + Number(value), 0);
    setContentCount(Number(total));
  }, [contentCountMapper]);

  const learningSections: any = {};
  learningSections[CATEGORY_CODE_REQUIRED] = {
    code: CATEGORY_CODE_REQUIRED,
    title: t('learningsection_my_enrollments_title')
  };
  learningSections[CATEGORY_CODE_MYINTEREST] = {
    code: CATEGORY_CODE_MYINTEREST,
    title: t('learningsection_my_playlists_title')
  };
  learningSections[CATEGORY_CODE_CHANNEL] = {
    code: CATEGORY_CODE_CHANNEL,
    title: t('learningsection_my_channels_title')
  };
  learningSections[CATEGORY_CODE_PARENTPATHWAY] = {
    code: CATEGORY_CODE_PARENTPATHWAY,
    title: t('learningsection_my_parentpathway_title')
  };

  const filterEmptySection = (section: string): boolean => {
    if (contentCountMapper[section] && contentCountMapper[section] > 0) {
      return true;
    } else {
      return section === CATEGORY_CODE_REQUIRED;
    }
  };

  const handleViewAll = (): void => {
    dispatch({
      type: "search/setSearchFilters",
      payload: {
        sort: SORT_DEFAULT,
        text: "",
        code: activeTab === CATEGORY_CODE_CHANNEL ? CATEGORY_CODE_REQUIRED : activeTab
      },
    });
    history.push(`/catalog/${activeTab}`);
    window.scrollTo(0, 0);
  };

  const handleTabChange = (event: React.ChangeEvent<unknown>, newValue: any) => {
    setActiveTab(newValue);    
  };
  const getTabTitle = (code: string): string => {   
    const count = contentCountMapper[code];
    if (count && count > 0) {
      return `${learningSections[code].title} (${count})`;
    }   
    return learningSections[code].title;
  };
  
  return (
    <>
      <Box marginTop={{ xs: "10px", sm: "25px" }}>
        <LearningCarouselHeader
          title={props.title}
          showViewAll={false}
          handleViewAll={props.handleViewAll}
          showHeaderCount
          showHeaderWithZeroCount
          contentCount={contentCount}
        />
      </Box>
      <Box flexDirection={`${isSmallerMobile ? "column" : "row"}`} margin={`${isSmallerMobile ? "0 -10px" : "0"}`} style={{
        display: "flex",
        justifyContent: "space-between",

      }}>
        <Box style={{ width: `${isSmallerMobile ? "100%" : isMobile ? "calc(100% - 215px)" : ""}` }}>
          <Tabs
            value={activeTab}
            aria-label={t("aria_label_my_learning_tabs")}
            tabs={renderOrder.filter(filterEmptySection).map((section: string) => {
              const tabData: any = {};
              tabData.label = getTabTitle(section);
              tabData.value = section;
              return tabData;
            })}
            onChange={handleTabChange}
            height={40}
          />
        </Box>
        {contentCountMapper && contentCountMapper[activeTab] > 0 ? (
          <Box style={{ display: "flex", alignItems: "flex-end" }} marginTop={`${isSmallerMobile ? "10px" : "0"}`} 
          justifyContent={`${isSmallerMobile ? "flex-end" : "flex-start"}`}>
            <Box display={{ xs: "none", sm: "block" }}>
              <Select
                title={t("sort_by")}
                arialabel={activeTab+' section '}
                options={[
                  { title: t("sort_by_name_asc"), id: SORT_ALPHABETICAL_ASCENDING },
                  { title: t("sort_by_name_desc"), id: SORT_ALPHABETICAL_DESCENDING },
                  { title: t("sort_by_duration_asc"), id: SORT_DURATION_ASCENDING },
                  { title: t("sort_by_duration_desc"), id: SORT_DURATION_DESCENDING },
                  { title: t("sort_by_price_asc"), id: SORT_PRICE_ASCENDING },
                  { title: t("sort_by_price_desc"), id: SORT_PRICE_DESCENDING },
                ]}
                value={sortMapper[activeTab]}
                onChange={handleSort}
              />
            </Box>
            {!isSmallerMobile ? <ViewAll title={activeTab} handleViewAll={handleViewAll} /> : <></>}
          </Box>
        ) : (
          <></>
        )}
      </Box>
      {renderOrder.map((section: string, index: number) => (
        <TabPanel
          key={section}
          value={activeTab}
          index={section}
          persistInDom
          style={{ padding: "10px 0 0 0" }}
        >
          <>
            <LearningCarousel
              key={section}
              isActive={activeTabIndex === index}
              {...learningSections[section]}
              selectTileHandler={props.selectTileHandler}
              setOpenActivity={props.setOpenActivity}
              setOpenShareContent={props.setOpenShareContent}
              setIsOpenPlaylist={props.setIsOpenPlaylist}
              onDataFetch={updateListCallback}
              sort={sortMapper[section]}
              showDivider={props.showDivider}
              {...props.subCategoryProps[section] || {}}
            />
          </>
        </TabPanel>
      ))}
      {isSmallerMobile ?
        <Box style={{
          padding: "5px 0 30px 0",
          borderBottom: `1px solid ${theme.palette.grey["300"]}`
        }}>
          <ViewAll handleViewAll={handleViewAll} />
        </Box>
        :
        <></>}

      <hr
        style={{
          color: theme.palette.grey["300"],
          width: "100vw",
          marginLeft: isMobile ? "-25px" : "-70px",
        }}
      />
    </>
  );
};

const TileView = (props: any): JSX.Element => {
  const dispatch = useAppDispatch();
  const history = useHistory();
  const [contentCount, setContentCount] = useState<number | undefined>();

  const updateListCallback = useCallback(
    (list: any, contentCount: number | undefined, code: string): void => {
      setContentCount(contentCount);
    },
    []
  );

  const handleViewAll = (): void => {
    dispatch({
      type: "subheader/title",
      payload: "mylearning",
    });
    history.push(`/catalog/mylearning`);
    window.scrollTo(0, 0);
  };

  return (
    <>
      <Box display="flex" justifyContent={"space-between"} marginTop={{ xs: "10px", sm: "25px" }}>
        <LearningCarouselHeader
          title={props.title}
          showViewAll={false}
          handleViewAll={handleViewAll}
          showHeaderCount
          showHeaderWithZeroCount
          contentCount={contentCount}
        />
        {contentCount > 0 && <ViewAll title={props.title} handleViewAll={handleViewAll} />}
      </Box>
      <LearningCarousel
        key={CATEGORY_CODE_REQUIRED}
        isActive={true}
        code={CATEGORY_CODE_REQUIRED}
        onDataFetch={updateListCallback}
        selectTileHandler={props.selectTileHandler}
        setOpenActivity={props.setOpenActivity}
        setOpenShareContent={props.setOpenShareContent}
        setIsOpenPlaylist={props.setIsOpenPlaylist}
        showDivider={props.showDivider}
      />
    </>
  );
};

const ViewAll = (props: any): JSX.Element => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const isSmallScreen = useMediaQuery(theme.breakpoints.down("xs"));
  const focusClass = useFocusStyles();
  const { t } = useTranslation();

  return (
    <Button
      style={{
        width: `${isSmallScreen ? "100%" : "116px"}`,
        height: "38px",
        border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]
          }`,
        borderRadius: 0,
        color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
        backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back,
        fontSize: "12px",
        fontWeight: 700,
        marginLeft: `${isSmallScreen ? "0px" : "20px"}`,
        marginRight: `${isMobile ? "0px" : "66px"}`
      }}
      className={`${focusClass.focusItem} ${styles.focusOnly} ${focusClass.secondaryHover}`}
      onClick={props.handleViewAll}
      role="link"
      aria-label={props.title +' - '+t("view_all_button_text")}
    >
      {t("view_all_button_text")} </Button>
  );
};