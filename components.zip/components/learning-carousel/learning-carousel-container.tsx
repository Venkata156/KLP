/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState } from "react";
import { LearningCarouselHeader } from "./learning-carousel-header";
import { LearningCarousel } from "./learning-carousel";
import { useAppDispatch } from "store";
import { useHistory } from "react-router-dom";
import { SORT_DEFAULT } from "utils/constants";
import { Box, useTheme, Button, useMediaQuery } from "@material-ui/core";
import portalSettingsManager from "../../utils/portalSettingsManager";
import { useFocusStyles } from "../../hooks/focusBorder";
import { useTranslation } from "react-i18next";
export const LearningCarouselContainer = (props: any): JSX.Element => {
  const dispatch = useAppDispatch();
  const history = useHistory();
  const theme = useTheme();
  const isSmallMobile = useMediaQuery(theme.breakpoints.down("xs"));
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const focusClass = useFocusStyles();
  const { t } = useTranslation();
  const { code } = props;
  const [contentCount, setContentCount] = useState<number | undefined>();
  const updateList = (list: any, contentCount: number | undefined): void => {
    setContentCount(contentCount);
  };
  const handleViewAll = () => {
    dispatch({
      type: "search/setSearchFilters",
      payload: {
        sort: SORT_DEFAULT,
        text: "",
        code
      },
    });
    history.push(`/catalog/${code}`);
    window.scrollTo(0, 0);
  }
  return (
    <>
      <Box marginTop={{ xs: "10px", sm: "25px" }}>
        <LearningCarouselHeader
          title={props.title}
          showViewAll={isSmallMobile ? false : true}
          handleViewAll={handleViewAll}
          showHeaderCount
          contentCount={contentCount}
        />
      </Box>
      <LearningCarousel {...props} sort={SORT_DEFAULT} onDataFetch={updateList} showDivider={props.showDivider} />
      {isSmallMobile && contentCount > 0 ?
        <Box style={{
          padding: "5px 0 30px 0",
          borderBottom: `1px solid ${theme.palette.grey["300"]}`
        }}>
          <Button
            style={{
              width: "100%",
              height: "38px",
              border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]}`,
              borderRadius: 0,
              color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
              fontSize: "12px",
              fontWeight: 700,
            }}
            className={`${focusClass.focusItem}  ${focusClass.secondaryHover}`}
            onClick={handleViewAll}
          >
            {t("view_all_button_text")}
          </Button>
        </Box> :
        <></>}
      {contentCount > 0 && (
        <hr
          style={{
            color: theme.palette.grey["300"],
            width: "100vw",
            marginLeft: isMobile ? "-25px" : "-70px",
          }}
        />
      )}
    </>
  );
};