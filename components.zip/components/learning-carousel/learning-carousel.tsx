/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useLazyQuery } from "@apollo/client";
import { Box, IconButton, useMediaQuery, useTheme } from "@material-ui/core";
import { setCustomCatalogTitle } from "store/core";
import {
  RecommendationsContentTile,
  ExpandableContentTile,
  ArrowIcon,
  ChannelIcon,
  CourseIcon,
  PathwayIcon,
  LandingArrowIcon,
} from "components";

import { useEffect, useState, useRef, useCallback } from "react";
import { useHistory } from "react-router-dom";
import { useAppDispatch } from "store";
import Tooltip from "@material-ui/core/Tooltip";

import {
  CATEGORY_CODE_ALL,
  CATEGORY_CODE_POPULAR,
  CATEGORY_CODE_RECOMMENDED,
  CATEGORY_CODE_REQUIRED,
  CATEGORY_CODE_CHANNEL,
  CATEGORY_CODE_PARENTPATHWAY,
  FILTER_ENROLLED,
  FILTER_IN_PROGRESS,
  CATEGORY_CODE_MYINTEREST,
  SORT_DEFAULT,
  TILE_TYPES,
} from "utils/constants";

import * as CategoryTypes from "utils/graphql/Category";
import { parseSortType } from "utils/helpers";
import { GET_CATEGORIES } from "utils/queries";
import { styled } from "@material-ui/core/styles";
import styles from "./learning-carousel.module.css";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";

const Figure = styled("figure")({
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
});

const FigureCaption = styled("figcaption")(({ theme }) => ({
  fontSize: "12px",
  color: theme.palette.grey["800"],
  fontWeight: 700,
  textTransform: "uppercase",
  marginTop: "10px",
  letterSpacing: "2.4px",
}));

const DefaultIcons = styled("div")(({ theme }) => ({
  "&:before, &:after": {
    position: "absolute",
    background: theme.palette.grey["300"],
    width: "0.5px",
    height: "20px",
    content: "''",
    bottom: 0,
  },
  "&:after": {
    right: 0,
  },
}));

const LearningCarouselDefault = () => {
  const theme = useTheme();

  const dispatch = useAppDispatch();
  const history = useHistory();
  const { t } = useTranslation();
  const handleAddToMyLearning = () => {
    dispatch(setCustomCatalogTitle(true));
    dispatch({
      type: "subheader/title",
      payload: "",
    });
    dispatch({
      type: "search/setSearchFilters",
      payload: {
        sort: SORT_DEFAULT,
        text: "",
        code: CATEGORY_CODE_ALL,
      },
    });
    history.push("/catalog");
  };

  return (
    <Box
      style={{
        display: "flex",
        padding: "40px 30px",
        justifyContent: "space-between",
        boxShadow: "0 4px 14px 0 rgba(0,0,0,0.10)",
        margin: "16px 66px 50px 0px",
      }}
    >
      <Box style={{ maxWidth: "375px", marginRight: "48px" }}>
        <span
          style={{
            display: "block",
            textAlign: "center",
            fontSize: "28px",
            color: portalSettingsManager.application?.common?.themeColor,
          }}
        >
          {t("add_to_mylearning")}
        </span>
        <span
          style={{
            display: "block",
            textAlign: "center",
            fontSize: "14px",
            color: theme.palette.grey["500"],
            lineHeight: "21px",
            paddingTop: "8px",
          }}
        >
          {t("learning_section_description")}
        </span>
      </Box>
      <DefaultIcons
        style={{
          display: "flex",
          borderBottom: `1px solid ${theme.palette.grey["300"]}`,
          position: "relative",
        }}
      >
        <Figure>
          <CourseIcon width="32px" height="32px" stroke={theme.palette.grey["A100"]} />
          <FigureCaption>{t("courses")}</FigureCaption>
        </Figure>
        <Figure>
          <PathwayIcon width="32px" height="32px" stroke={theme.palette.grey["A100"]} />
          <FigureCaption>{t("pathways")}</FigureCaption>
        </Figure>
        <Figure>
          <ChannelIcon width="32px" height="32px" stroke={theme.palette.grey["A100"]} />
          <FigureCaption>{t("channels")}</FigureCaption>
        </Figure>
      </DefaultIcons>
      <Box
        style={{ display: "flex", flexDirection: "column", justifyContent: "center" }}
        onClick={handleAddToMyLearning}
      >
        <IconButton
          aria-label={t("aria_label_click_to_share")}
          style={{
            border: `1px solid ${portalSettingsManager.application?.common?.themeColor}`,
            padding: "6px",
            margin: "auto",
          }}
        >
          <ArrowIcon
            stroke={portalSettingsManager.application?.common?.themeColor}
            style={{ transform: "translate(20%, 25%)" }}
          />
        </IconButton>
        <span
          style={{
            display: "block",
            fontSize: "12px",
            color: portalSettingsManager.application?.common?.themeColor,
            letterSpacing: "2.4px",
            fontWeight: 700,
            textTransform: "uppercase",
          }}
        >
          {t("catalog")}
        </span>
      </Box>
    </Box>
  );
};

export const LearningCarousel = ({
  code,
  isActive,
  list,
  reload,
  setReload,
  selectTileHandler,
  setIsOpenPlaylist,
  setOpenShareContent,
  setOpenActivity,
  handleTileClick,
  onDataFetch,
  sort,
  showDivider,
}: any): JSX.Element | null => {
  const dispatch = useAppDispatch();
  const { t } = useTranslation();
  const theme = useTheme();
  const isSmallMobile = useMediaQuery(theme.breakpoints.down("xs"));
  const [courses, setCourses] = useState<CategoryTypes.Category_contentListByCategory_contents[]>(
    list || []
  );

  const [contentCount, setContentCount] = useState(0);
  const categoryCode = [CATEGORY_CODE_REQUIRED, CATEGORY_CODE_CHANNEL].includes(code)
    ? CATEGORY_CODE_REQUIRED
    : code;

  const onDataFetchCallback = useCallback(
    (courseList, totalConentCount) => {
      onDataFetch?.(courseList, totalConentCount, code);
    },
    [onDataFetch]
  );

  const variablesMapper: any = {
    [CATEGORY_CODE_REQUIRED]: {
      filters: [
        {
          items: [{ code: FILTER_ENROLLED }, { code: FILTER_IN_PROGRESS }],
          type: "MultiSelect",
          code: "Status",
        },
        {
          type: "MultiSelect",
          code: "ContentCategory",
          items: [{ code: "Programme" }, { code: "Pathway" }],
        },
      ],
    },
    [CATEGORY_CODE_CHANNEL]: {
      filters: [
        {
          items: [{ code: FILTER_ENROLLED }],
          type: "MultiSelect",
          code: "Status",
        },
        {
          type: "MultiSelect",
          code: "ContentCategory",
          items: [{ code: "Channel" }],
        },
      ],
    },
    [CATEGORY_CODE_PARENTPATHWAY]: {
      filters: [
        {
          items: [{ code: FILTER_ENROLLED }],
          type: "MultiSelect",
          code: "Status"
        },
        {
          type: "MultiSelect",
          code: "ContentCategory",
          items: [{ code: "ParentPathway" }]
        }
      ]
    }
  };
  
  const variables = {
    categoryCode,
    sort: parseSortType(sort),
    count: Number(process.env.REACT_APP_CATEGORY_COUNT),
  };
  if ([CATEGORY_CODE_REQUIRED, CATEGORY_CODE_CHANNEL, CATEGORY_CODE_PARENTPATHWAY].includes(code)) {
    Object.assign(variables, {
      filters: variablesMapper[code].filters,
    });
  }

  const [loadCourses, { loading, data, refetch }] = useLazyQuery<CategoryTypes.Category>(
    GET_CATEGORIES,
    {
      // extremely bizarre that this is necessary, but all LearningSections show the same content without this
      fetchPolicy: "no-cache",
      variables,
      notifyOnNetworkStatusChange: true,
    }
  );

  useEffect(() => {
    if (!list || !list.length) {
      loadCourses();
    } else {
      setCourses(list);
    }
  }, [list, loadCourses]);

  useEffect(() => {
    if (reload && refetch) {
      refetch({
        categoryCode: CATEGORY_CODE_MYINTEREST,
        sort: parseSortType(sort),
        count: Number(process.env.REACT_APP_CATEGORY_COUNT),
      });
      setReload(false);
    }
  }, [reload, refetch]);

  useEffect(() => {
    if (data) {
      // remove null values
      if (data.contentListByCategory && data.contentListByCategory?.contents) {
        setCourses(
          data.contentListByCategory.contents.flatMap((course) => (course ? [course] : []))
        );
        setContentCount(data.contentListByCategory?.contentCount);
      }
    }
  }, [data]);

  useEffect(() => {
    onDataFetchCallback(courses, contentCount);
  }, [onDataFetchCallback, courses, contentCount]);

  useEffect(() => {
    if (refetch) {
      refetch({
        categoryCode,
        sort: parseSortType(sort),
        count: Number(process.env.REACT_APP_CATEGORY_COUNT),
      });
    }
  }, [code, refetch, sort]);

  useEffect(() => {
    if (code === CATEGORY_CODE_REQUIRED) {
      dispatch({
        type: "loader/showandhide",
        payload: { show: loading, message: t('please_wait') },
      });
    }
  }, [loading, code]);

  const isMyLearning = code !== CATEGORY_CODE_POPULAR && code !== CATEGORY_CODE_RECOMMENDED;
  const isMyLearningTileView: boolean | undefined =
    portalSettingsManager.application?.common?.showMyLearningSectionAsCarousal;
  const showTileView =
    code !== CATEGORY_CODE_RECOMMENDED && code !== CATEGORY_CODE_POPULAR && !isMyLearningTileView;

  return (
    <Box>
      {showTileView ? (
        <TileView
          courses={courses}
          code={code}
          selectTileHandler={selectTileHandler}
          setIsOpenPlaylist={setIsOpenPlaylist}
          setOpenShareContent={setOpenShareContent}
          setOpenActivity={setOpenActivity}
          handleTileClick={handleTileClick}
          loading={loading}
        />
      ) : (
        <CarouselView
          courses={courses}
          code={code}
          isActive={isActive}
          list={list}
          loading={loading}
          selectTileHandler={selectTileHandler}
          setIsOpenPlaylist={setIsOpenPlaylist}
          setOpenShareContent={setOpenShareContent}
          setOpenActivity={setOpenActivity}
          handleTileClick={handleTileClick}
        />
      )}
    </Box>
  );
};

const CarouselView = ({
  courses,
  code,
  isActive,
  list,
  loading,
  selectTileHandler,
  setIsOpenPlaylist,
  setOpenShareContent,
  setOpenActivity,
  handleTileClick,
}: any): JSX.Element => {
  const theme = useTheme();
  const focusClass = useFocusStyles();
  const { t } = useTranslation();
  const [page, setPage] = useState(0);
  const cardsContainerRef = useRef<any>();
  const [tilesPerRow, setTilesPerRow] = useState(400);
  const [activeTile, setActiveTile] = useState(-1);

  const getTileData = () => {
    // FYI: tileSpace = tile width + 2 * padding(15px)
    if (code === CATEGORY_CODE_RECOMMENDED) {
      return {
        tileType: TILE_TYPES.RECOMMENDED,
        tileSpace: 610,
        selectorOffset: "50px",
        tilesGap: "30px",
      };
    }
    const tileType = code === CATEGORY_CODE_POPULAR ? TILE_TYPES.POPULAR : TILE_TYPES.MY_LEARNING;
    return {
      tileType: tileType,
      tileSpace: 380,
      caraouselHeight: "300px",
      selectorOffset: "25px",
      tilesGap: "0px",
    };
  };

  const { tileType, tileSpace, caraouselHeight, selectorOffset, tilesGap } = getTileData();

  const cardsContainerRefCallback = useCallback((node) => {
    if (node !== null) {
      cardsContainerRef.current = node;
    }
  }, []);

  useEffect(() => {
    const { clientWidth = 1200 } = cardsContainerRef.current || {};
    const tilesPerRow = Math.floor(clientWidth / tileSpace);
    setTilesPerRow(tilesPerRow);
  }, [cardsContainerRef.current?.clientWidth, isActive]);

  const [scrollPercent, setScrollPercent] = useState(0);

  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const isSmallMobile = useMediaQuery(theme.breakpoints.down("xs"));
  const scrollTimeout = useRef(0);

  const handlePrev = () => {
    if (page > 0) {
      setPage(page - 1);
    }
  };

  const handleNext = () => {
    const isLastPage = page + 1 >= courses.length / tilesPerRow;
    if (isLastPage) {
      setPage(0);
    } else {
      setPage(page + 1);
    }
  };

  const handleIsActiveChanged = (index: number) => {
    setActiveTile(index);
  };

  const getTileComponent = (
    item: CategoryTypes.Category_contentListByCategory_contents,
    idx: number
  ) => {
    //const shouldBeOpaque = idx > (page + 1) * tilesPerRow - 1;
    const shouldNotFocus = idx < page * tilesPerRow || idx > (page + 1) * tilesPerRow - 1;
    const shouldBeHidden = isSmallMobile
      ? false
      : idx < page * tilesPerRow || idx > (page + 1) * tilesPerRow;
    var isExpandableTile = [TILE_TYPES.MY_LEARNING, TILE_TYPES.POPULAR].includes(tileType);

    const tile = isExpandableTile ? (
      <ExpandableContentTile
        item={item}
        handleClick={handleTileClick}
        selectTile={selectTileHandler}
        setIsOpenPlaylist={setIsOpenPlaylist}
        setOpenShareContent={setOpenShareContent}
        setOpenActivity={setOpenActivity}
        tileType={tileType}
        index={idx}
        handleIsActiveChanged={handleIsActiveChanged}
        isTileView={false}
        tabIndex={shouldNotFocus ? -1 : undefined}
      />
    ) : (
      <RecommendationsContentTile
        item={item}
        handleClick={handleTileClick}
        selectTile={selectTileHandler}
        setIsOpenPlaylist={setIsOpenPlaylist}
        setOpenShareContent={setOpenShareContent}
        setOpenActivity={setOpenActivity}
        tileType={tileType}
        tabIndex={shouldNotFocus ? -1 : undefined}
      />
    );

    return (
      <Box
        visibility={shouldBeHidden ? "Hidden" : "Visible"}
        key={idx}
        marginLeft={{
          xs: idx > 0 && idx < courses.length ? "0px" : 0,
          sm: idx > 0 && idx < courses.length ? tilesGap : 0,
        }}
        style={{
          //opacity: isExpandableTile && shouldBeOpaque ? 0.5 : 1,
          zIndex: idx === activeTile ? 100 : undefined,
        }}
      >
        {tile}
      </Box>
    );
  };

  return (
    <>
      <Box>
        {(code === CATEGORY_CODE_REQUIRED ||
          (list && list.length) ||
          ([
            CATEGORY_CODE_RECOMMENDED,
            CATEGORY_CODE_MYINTEREST,
            CATEGORY_CODE_POPULAR,
            CATEGORY_CODE_CHANNEL,
            CATEGORY_CODE_PARENTPATHWAY
          ].includes(code) &&
            courses &&
            courses.length > 0)) && (
          <Box paddingBottom="30px" marginTop={code === CATEGORY_CODE_RECOMMENDED && "16px"}>
            {courses && courses.length === 0 && !loading && <LearningCarouselDefault />}
            <Box display="flex">
              <Box
                style={{
                  display: "flex",
                  alignItems: "center",
                  position: "relative",
                  width: "100%",
                }}
              >
                <div>
                  <Box
                    style={{
                      position: "absolute",
                      width: "42px",
                      top: 0,
                      bottom: 0,
                      alignItems: "center",
                      left: `${isMobile ? "-10px" : "-45px"}`,
                    }}
                    display={{ xs: "none", sm: "flex" }}
                  >
                    <Tooltip title={t("arrowicon_tooltip_previouspage")}>
                      <IconButton
                        tabIndex={0}
                        className={`${focusClass.greyBorder} ${focusClass.focusItem} ${styles.focusOnly} abc  `}
                        style={{
                          padding: "6px",
                          zIndex: 99,
                          opacity: page <= 0 ? 0 : 1,
                          backgroundColor:
                            portalSettingsManager.buttonColors?.normal?.active?.back || "#ffffff",
                          boxShadow: theme.shadows[1],
                        }}
                        aria-label={t("aria_label_click_previous_page")}
                        color="primary"
                        onClick={handlePrev}
                        disabled={page <= 0}
                      >
                        <LandingArrowIcon
                          stroke={
                            portalSettingsManager.buttonColors?.normal?.active?.text ||
                            theme.palette.grey["500"]
                          }
                          style={{ transform: "translate(-25%, -25%) rotate(180deg)" }}
                          contentType={t("arrowicon_tooltip_previouspage")}
                          position="right"
                        />
                      </IconButton>
                    </Tooltip>
                  </Box>
                </div>
                {courses && courses.length > 0 && (
                  <div
                    style={{
                      width: "100%",
                      maxHeight: `${isSmallMobile ? "100%" : caraouselHeight}`,
                      height: `${isSmallMobile ? "100%" : caraouselHeight}`,
                    }}
                    ref={cardsContainerRefCallback}
                  >
                    <Box
                      className={styles.carousel}
                      overflow={{ xs: "auto", sm: "visible" }}
                      style={{
                        display: "flex",
                        width: "100%",
                        whiteSpace: "nowrap",
                        transition: "transform 0.2s",
                        transform: `translateX(calc(-${page * tileSpace * tilesPerRow}px))`,
                        maxHeight: `${isSmallMobile ? "100%" : "270px"}`,
                      }}
                      onScroll={(e) => {
                        const _scrollPercent =
                          e.currentTarget.scrollLeft / e.currentTarget.scrollWidth;
                        clearTimeout(scrollTimeout.current);
                        scrollTimeout.current = window.setTimeout(
                          () => setScrollPercent(_scrollPercent),
                          100
                        );
                      }}
                    >
                      {courses.map((item: any, idx: number) => {
                        return getTileComponent(item, idx);
                      })}
                    </Box>
                  </div>
                )}
                {courses.length > tilesPerRow && (
                  <div>
                    <Box
                      style={{
                        position: "absolute",
                        width: "76px",
                        top: 0,
                        right: "-24px",
                        bottom: 0,
                        alignItems: "center",
                        background: "rgba(255, 255, 255, 0.6)",
                      }}
                      display={{ xs: "none", sm: "flex" }}
                    >
                      <Tooltip title={t("arrowicon_tooltip_nextpage")}>
                        <IconButton
                          tabIndex={0}
                          style={{
                            padding: "6px",
                            opacity: !courses || courses.length === 0 ? 0 : 1,
                            marginLeft: "22px",
                            backgroundColor:
                              portalSettingsManager.buttonColors?.normal?.active?.back || "#ffffff",
                            boxShadow: theme.shadows[1],
                          }}
                          aria-label={t("aria_label_click_next_page")}
                          color="primary"
                          onClick={handleNext}
                          disabled={!courses || courses.length === 0 ? true : false}
                          className={`${focusClass.focusItem} ${styles.focusOnly}`}
                        >
                          <LandingArrowIcon
                            stroke={
                              portalSettingsManager.buttonColors?.normal?.active?.text ||
                              theme.palette.grey["500"]
                            }
                            style={{ transform: "translate(20%, 25%)" }}
                            contentType={t("arrowicon_tooltip_nextpage")}
                            position="left"
                          />
                        </IconButton>
                      </Tooltip>
                    </Box>
                  </div>
                )}
              </Box>
            </Box>
            {[
              CATEGORY_CODE_REQUIRED,
              CATEGORY_CODE_RECOMMENDED,
              CATEGORY_CODE_POPULAR,
              CATEGORY_CODE_MYINTEREST,
              CATEGORY_CODE_CHANNEL,
              CATEGORY_CODE_PARENTPATHWAY
            ].includes(code) &&
              courses &&
              courses.length > 0 && (
                <Box
                  marginTop={{ xs: "10px", sm: selectorOffset }}
                  style={{ display: "flex", justifyContent: "center" }}
                >
                  <Box width={{ xs: "100%", sm: "auto" }}>
                    {courses && courses.length > tilesPerRow && (
                      <Box
                        display={{ xs: "flex", sm: "flex" }}
                        justifyContent={{ xs: "center", sm: "flex-end" }}
                        style={{ flex: 1, alignItems: "flex-end" }}
                      >
                        {isSmallMobile ? (
                          <Box
                            style={{
                              zIndex: -3,
                              backgroundColor: theme.palette.grey["300"],
                              maxWidth: "300px",
                              overflowX: "hidden",
                              height: "5px",
                              position: "relative",
                            }}
                          >
                            <Box
                              style={{
                                backgroundColor: theme.palette.grey["800"],
                                width: "12px",
                                height: "5px",
                                position: "absolute",
                                transition: "left 0.2s ease",
                                left: `${Math.ceil(scrollPercent * (courses.length * 12))}px`,
                                zIndex: -2,
                              }}
                            ></Box>
                            {courses.map((course: any, idx: number) => (
                              <Box
                                key={idx}
                                style={{
                                  display: "inline-block",
                                  position: "relative",
                                  color: "white",
                                  backgroundColor: "white",
                                  minWidth: "2px",
                                  width: "2px",
                                  minHeight: "5px",
                                  height: "50px",
                                  marginLeft: "10px",
                                }}
                              ></Box>
                            ))}
                          </Box>
                        ) : (
                          courses
                            .filter((item: any, idx: number) => idx % tilesPerRow === 0)
                            .map((item: any, idx: number) => {
                              return (
                                <Box
                                  key={idx}
                                  width="20px"
                                  marginRight="2px"
                                  style={{ cursor: "pointer" }}
                                  onClick={() => setPage(idx)}
                                >
                                  <Box
                                    style={{
                                      width: "100%",
                                      height: "5px",
                                      backgroundColor: `${
                                        idx === page
                                          ? theme.palette.grey["800"]
                                          : theme.palette.grey["300"]
                                      }`,
                                    }}
                                  />
                                </Box>
                              );
                            })
                        )}
                      </Box>
                    )}
                  </Box>
                </Box>
              )}
          </Box>
        )}
      </Box>
    </>
  );
};

const TileView = ({
  courses,
  code,
  selectTileHandler,
  setIsOpenPlaylist,
  setOpenShareContent,
  setOpenActivity,
  handleTileClick,
  loading,
}: any): JSX.Element => {
  const theme = useTheme();
  const tileType = code === CATEGORY_CODE_REQUIRED ? TILE_TYPES.MY_LEARNING : undefined;
  const [activeTile, setActiveTile] = useState(-1);

  const handleIsActiveChanged = (index: number) => {
    setActiveTile(index);
  };

  return (
    <>
      {courses && courses.length === 0 && !loading && <LearningCarouselDefault />}
      <Box display="flex" flexWrap="wrap" style={{ width: "100%" }} paddingBottom="30px">
        {courses.map((course: any, idx: number) => {
          return (
            <Box zIndex={idx === activeTile ? 999 : undefined} paddingBottom="60px">
              <ExpandableContentTile
                item={course}
                handleClick={handleTileClick}
                selectTile={selectTileHandler}
                setIsOpenPlaylist={setIsOpenPlaylist}
                setOpenShareContent={setOpenShareContent}
                setOpenActivity={setOpenActivity}
                tileType={tileType}
                index={idx}
                handleIsActiveChanged={handleIsActiveChanged}
                isTileView={true}
              />
            </Box>
          );
        })}
        <Box
          style={{
            backgroundColor: theme.palette.grey["300"],
            width: "100vw",
            height: "1px",
            marginLeft: "-70px",
            marginRight: "-70px",
          }}
        ></Box>
      </Box>
    </>
  );
};
