import { useLazyQuery } from "@apollo/client";
import {
  Box,
  IconButton,
  Tooltip
} from "@material-ui/core";
import { makeStyles, Theme, withStyles } from "@material-ui/core/styles";
import { find, first, uniq } from "lodash";
import React, { useEffect, useState } from "react";
import { SEARCH_LEARNER } from "utils/queries";
import CloseIcon from "@material-ui/icons/Close";
import { AutoComplete, AutoCompleteChangeEvent, ListItemProps } from "@progress/kendo-react-dropdowns";
import SearchIcon from "@material-ui/icons/Search";
import { useTranslation } from "react-i18next";
import { useFocusStyles } from "hooks/focusBorder";
import portalSettingsManager from "utils/portalSettingsManager";

const RequiredLabel = withStyles((theme: Theme) => ({
  root: {
    display: "block",
    fontSize: "12px",
    color: theme.palette.grey['500'],
    marginTop: "29px",
    marginBottom: "10px",
    "&:after": {
      content: `" *"`,
      color: "red",
    },
  },
}))(Box);

const SelectedEnroll = withStyles((theme: Theme) => ({
  root: {
    display: 'flex',
    justifyContent: 'space-around',
    alignItems: 'center',
    fontSize: '12px',
    color: theme.palette.grey['800'],
    fontWeight: 400,
    paddingLeft: '12px',
    height: '27px',
    marginRight: '12px',
    marginBottom: '12px',
    "& .MuiSvgIcon-root": {
      width: "20px",
    }
  }
}))(Box);

const Close = withStyles(() => ({
  root: {
    paddingRight: '4px',
    "&:hover": {
      backgroundColor: 'transparent',
    }
  },

}))(IconButton);

const LightTooltip = withStyles((theme: Theme) => ({
  tooltip: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
    boxShadow: theme.shadows[1],
    fontSize: 12,
    top: 70,
  },
  tooltipPlacementTop: {
    margin: 5,
  }
}))(Tooltip);
const ChipPopover = ({ item, handleRemoveEnrollment, index }: any): JSX.Element => {
  const { t } = useTranslation();
  const color = ['#BBE1F4', '#D5F9CD', '#FFE9AD', '#C2FFFE', '#ECD1FA', '#FFF8A8', '#BBE1F4', '#D5F9CD', '#FFE9AD', '#C2FFFE', '#ECD1FA', '#FFF8A8'];
  const focusClass = useFocusStyles();
  return (
    <Box>
      <LightTooltip title={item.email} placement="top" >
        <SelectedEnroll style={{ backgroundColor: color[index % color.length] }}>
          <Box> {item.firstName + ' ' + item.lastName} </Box>
          <Close className={focusClass.focusItem} aria-label={`${t('aria_label_click_to_close_usersearchdialog')}  ${item.firstName} ${item.lastName}`} onClick={() => handleRemoveEnrollment(item)}>
            <CloseIcon />
          </Close>
        </SelectedEnroll>
      </LightTooltip>
    </Box>
  );
};

const getInitials = (name: string) => {
  const nameList = name.split(' ');
  let fullName = '';
  for (let i = 0; i < nameList.length - 1; i++) {
    fullName += first(nameList[i]) || "";
  }
  fullName += nameList[nameList.length - 1] || "";
  return fullName;
};


const useStyles = makeStyles(() => ({
  root: {
    padding: '5px 0px',
    border: '2px solid gray',
    '&:hover': {
      border: '2px solid black'
    },
    '&:focus': {
      border: `2px solid ${portalSettingsManager.buttonColors?.themed?.active?.border}`
    },
    "& div": {
      borderRadius: "0px"
    },
    "& input": {
      color: `${portalSettingsManager.buttonColors?.themed?.active?.text}`,
      padding: '15px',
      "&::placeholder": {
        color: "gray",
      },
    },
  },
  popup: {
    zIndex: 2900,
    paddingTop: '10px',
    "& li": {
      zIndex: 2900,
      marginLeft: '-8px',
    },
    "& div>ul": {
      "&:focus": {
        "& li": {
          backgroundColor: '#rgba(0,0,0,0.5)'
        }
      },
      "&:hover": {
        "& li": {
          backgroundColor: '#rgba(0,0,0,0.5)'
        }
      }
    }
  }
}));
export const UserSearch = ({
  selectedUsers,
  setSelectedUsers,
  outputHandler,
  label,
  placeHolder,
  isRoleBased,
}: any) => {
  const classes = useStyles();
  const [userData, setUserdata] = useState<any | null>([]);
  const [searchValue, setSearchValue] = useState<any | null>("");
  const [suggestions, setSuggestions] = useState<any[]>(userData);
  const [holdBackValue, setHoldBackValue] = useState('');
  const [currentValue, setCurrentValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [border, setBorder] = useState(false);
  const [open, setOpen] = useState(false);
  const { t } = useTranslation();
  const [
    search,
    { loading: isUserLoading, data: userList, refetch },
  ] = useLazyQuery<any>(SEARCH_LEARNER);
  React.useEffect(() => {
    if (!searchValue) return;
    if (refetch) {
      refetch({ searchText: searchValue, isRoleBasedSearch: isRoleBased });
    } else {
      setSuggestions([]);
      search({ variables: { searchText: searchValue, isRoleBasedSearch: isRoleBased } });
    }
  }, [search, refetch]);

  React.useEffect(() => {
    search({ variables: { searchText: searchValue, isRoleBasedSearch: isRoleBased } });
  }, []);

  React.useEffect(() => {
    if (searchValue.length < 2) setSuggestions([]);
    else {
      search({ variables: { searchText: searchValue, isRoleBasedSearch: isRoleBased } });
      if (suggestions.length !== 0) setOpen(true);
    }
  }, [searchValue]);

  React.useEffect(() => {
    if (userList) {
      const userDetails = userList.learnerSearch?.map((item: any) => {
        return {
          name: item.fullName ? item.fullName : item.firstName,
          id: item.id,
          firstName: item.firstName,
          lastName: item.lastName,
        };
      });
      setUserdata(userDetails);
    }
  }, [userList]);

  const debounceFunction = (func: any, delay: any) => {
    let timer: any;
    timer = 0;
    return function (args: any) {
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (args !== searchValue) {
          func(args);
        }
      }, delay);
    };
  };
  const debounceDropDown = React.useCallback(
    debounceFunction((nextValue: any) => setSearchValue(nextValue), 1000),
    []
  );

  const filterData = (valueType: string = searchValue) => {
    if (valueType.length > 0 && userData) {
      setSuggestions(userData || []);
      setOpen(true);
    }
  };

  useEffect(() => {
    filterData(searchValue);
  }, [userData])

  useEffect(() => {
    if (searchValue === '' && holdBackValue !== '' && currentValue === '') {
      const selectedSuggestion = suggestions.find((item) => item.id.toLowerCase() === holdBackValue.toLowerCase());
      if (selectedSuggestion) {
        onChangeVal(selectedSuggestion)
      }
    }
  }, [holdBackValue])

  const handleSearch = (e: AutoCompleteChangeEvent) => {
    setOpen(false);
    setLoading(true);
    e.value ? debounceDropDown(e.value) : setSearchValue("");
    setCurrentValue(e.value);
    if (e.value.length > 0) {
      setHoldBackValue(e.value);
    }
    setTimeout(() => {
      setLoading(false)
    }, 300)
  };


  const onChangeVal = (value: any) => {
    if (!value) return;
    let addUser: any = [];
    if (userList) {
      addUser = find(userList.learnerSearch, ["id", value.id]);
      if (!selectedUsers.find((user: any) => user.id === addUser.id)) {
        setSelectedUsers(uniq([...selectedUsers, addUser]));
        outputHandler(2);
      }
    }
  };
  document.getElementById("user-search-box")?.setAttribute("aria-label", t('searchenrolleename _required_alert'));
  return (
    <Box display="flex" flexDirection="column" style={{ marginTop: '-25px' }}>
      <Box>
        <RequiredLabel>{label}</RequiredLabel>
        <Box className={classes.root} id={'AutoCompleteContainer'} style={{ position: 'relative', border: border ? `2px solid ${portalSettingsManager.buttonColors?.themed?.active?.border}` : "" }} aria-required={true}>
          {currentValue.length === 0 && <SearchIcon style={{ position: 'absolute', right: '10px', top: '10px', color: 'gray' }} />}
          <AutoComplete            
            id="user-search-box"
            aria-required='true'
            ariaLabelledBy='mandate'           
            data={suggestions}          
            style={{ width: '100%', border: '0px' }}
            popupSettings={{ appendTo: document.body, className: classes.popup }}
            itemRender={(
              li: React.ReactElement<HTMLLIElement>,
              itemProps: ListItemProps
            ) => {
              const index = itemProps.index;

              const itemChildren = (
                <span>
                  {suggestions[index].firstName} <strong>{suggestions[index].lastName}</strong>{" "}({getInitials(suggestions[index].name)}){" "}
                  <span hidden={true}>{suggestions[index].id}</span>
                </span>                
              );
              return React.cloneElement(li, li.props, itemChildren);
            }}
            textField={t('id')}
            value={currentValue}
            listNoDataRender={() => {
              return (
                <span style={{ paddingLeft: '10px' }}>
                  {t('no_records_found')}
                </span>
              )
            }}
            opened={currentValue.length >= 2 && open}
            placeholder={placeHolder ? placeHolder : ''}
            onChange={handleSearch}
            onFocus={() => { setBorder(true) }}
            onBlur={() => { setBorder(false) }}
            onClose={() => { setSearchValue(''); setCurrentValue('') }}
            loading={searchValue.length > 0 && (loading || isUserLoading)}
            
          />
          <span hidden={true} id="mandate">{t('searchenrolleename _required_alert')}</span>
        </Box>
      </Box>
    </Box>
  );
};
export const UserSelected = ({
  selectedUsers,
  handleRemoveEnrollment,
  maxHeight
}: any): JSX.Element => {
  return (
    <Box maxHeight={maxHeight || "250px"}
      style={{ margin: "20px 0 0 0", overflowX: "hidden", overflowY: "auto" }}>
      <Box display="flex" style={{ maxWidth: 500, flexWrap: 'wrap' }}>
        {selectedUsers.map((item: any, index: any) => {
          return (
            <ChipPopover key={index} index={index} item={item} handleRemoveEnrollment={handleRemoveEnrollment} />
          );
        })}
      </Box>
    </Box>
  );
};
