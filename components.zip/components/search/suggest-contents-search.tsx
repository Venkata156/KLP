import { useLazyQuery } from "@apollo/client";
import { Box } from "@material-ui/core";
import { useHistory } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import React, { useEffect, useState } from "react";
import { GET_CONTENT_SUGGESTION } from "utils/queries";
import {
  AutoComplete,
  AutoCompleteChangeEvent,
  ListItemProps,
} from "@progress/kendo-react-dropdowns";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";
import { useBreadCrumbs } from "hooks";

const useStyles = makeStyles(() => ({
  root: {
    padding: "3px 0px",
    "& div": {
      borderRadius: "0px",
    },
    "& input": {
      color: "#0091da",
      padding: "15px",
      "&::placeholder": {
        color: "gray",
      },
    },
  },
  popup: {
    zIndex: 2900,
    paddingTop: "10px",
    "& li": {
      zIndex: 2900,
      marginLeft: "-8px",
    },
    "& div>ul": {
      "&:focus": {
        "& li": {
          backgroundColor: "#rgba(0,0,0,0.5)",
        },
      },
      "&:hover": {
        "& li": {
          backgroundColor: "#rgba(0,0,0,0.5)",
        },
      },
    },
  },
  autocomplete: {
    "& .k-searchbar ::placeholder": {
      color: portalSettingsManager.header.colors.searchBoxPlaceholder
    },
    "& .k-clear-value": {
      color: `${portalSettingsManager.header.colors.searchBoxCrossIcon} !important`
    }
  }
}));

export const SuggestContentsSearch = ({ updateSearchText, placeHolder }: any) => {
  const classes = useStyles();
  const [userData, setUserdata] = useState<any | null>([]);
  const [searchValue, setSearchValue] = useState<any | null>("");
  const [suggestions, setSuggestions] = useState<any[]>(userData);
  const [currentValue, setCurrentValue] = useState("");
  const [previousValue, setPreviousValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const { t } = useTranslation();
  const history = useHistory();
  const { setBreadcrumb } = useBreadCrumbs();

  const [search, { loading: isUserLoading, data: contentList, refetch }] =
    useLazyQuery<any>(GET_CONTENT_SUGGESTION);

  React.useEffect(() => {
    if (searchValue.length < 3) setSuggestions([]);
    else {
      search({ variables: { searchTerm: searchValue } });
      if (suggestions.length !== 0) setOpen(true);
    }
  }, [searchValue]);

  React.useEffect(() => {
    if (contentList) {
      const userDetails = contentList.suggestContents?.map((item: any) => {
        return {
          id: item.id,
          name: item.name,
          contentType: item.contentType,
        };
      });
      setUserdata(userDetails);
    }
  }, [contentList]);

  const debounceFunction = (func: any, delay: any) => {
    let timer: any;
    timer = 0;
    return function (args: any) {
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (args !== searchValue) {
          func(args);
        }
      }, delay);
    };
  };
  const debounceDropDown = React.useCallback(
    debounceFunction((nextValue: any) => setSearchValue(nextValue), 1000),
    []
  );

  const filterData = (valueType: string = searchValue) => {
    if (valueType.length > 0 && userData) {
      setSuggestions(userData || []);
      setOpen(true);
      setPreviousValue(searchValue);
    }
  };

  useEffect(() => {
    filterData(searchValue);
  }, [userData]);

  const handleSearch = (e: AutoCompleteChangeEvent) => {
    const matchingSuggestion = suggestions.find((s) => s.name == e.value);
    if (matchingSuggestion) {
      resetBreadcrumbs();
      history.push(`/${matchingSuggestion.contentType}/${matchingSuggestion.id}`);
    }
    setOpen(false);
    setLoading(true);
    e.value ? debounceDropDown(e.value) : setSearchValue("");
    setCurrentValue(e.value);
    updateSearchText(e.value);
    setTimeout(() => {
      setLoading(false);
    }, 300);
  };

  const resetBreadcrumbs = () => {
    setBreadcrumb(JSON.stringify({
      data: [{
        title: `${t('home')}`,
        path: "/",
        type: "home"
      }]
    }));
  }

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      setSearchValue('');
      setCurrentValue("");
      setOpen(false);
    }
  };

  return (
    <Box display="flex" flexDirection="column">
      <Box>
        <Box
          className={classes.root}
          id={"AutoCompleteContainer"}
          style={{
            position: "relative",
            backgroundColor: portalSettingsManager.header?.colors?.search?.back || "none",
            borderColor: portalSettingsManager.header?.colors?.search?.border || "none",
          }}
          onKeyDown={handleKeyDown}
        >
          <AutoComplete
            id="user-search-box"
            focusedItemIndex={() => -1}
            data={suggestions}
            tabIndex={0}
            className={classes.autocomplete}
            style={{ width: "100%", border: "0px" }}
            popupSettings={{ appendTo: document.body, className: classes.popup, width:"720px"}}
            itemRender={(li: React.ReactElement<HTMLLIElement>, itemProps: ListItemProps) => {
              const index = itemProps.index;

              const itemChildren = (
                <div style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {suggestions[index].name}{" "}
                </div>
              );
              return React.cloneElement(li, li.props, itemChildren);
            }}
            textField="name"
            listNoDataRender={() => {
              return <span style={{ paddingLeft: "10px" }}>{t("no_records_found")}</span>;
            }}
            opened={currentValue.length >= 2 && open}
            placeholder={placeHolder ? placeHolder : ""}
            onChange={handleSearch}
            onClose={() => {
              setSearchValue("");
              setCurrentValue("");
              setOpen(false);
            }}
            loading={searchValue.length > 0 && (loading || isUserLoading)}
          />
        </Box>
      </Box>
    </Box>
  );
};
