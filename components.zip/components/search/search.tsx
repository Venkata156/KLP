import { Box, IconButton, InputBase, Paper, SvgIcon } from "@material-ui/core";
import { Theme, withStyles } from "@material-ui/core/styles";
import { ReactComponent as searchIcon } from "assets/icons/icon-search.svg";
import CloseIcon from "@material-ui/icons/Close";
import banner from "assets/images/banner.jpg";
import { FormEvent, useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "store";
import { CATEGORY_CODE_ALL } from "utils/constants";
import { clearSearch } from "store/core";
import { useFocusStyles } from "hooks/focusBorder";
import styles from "./search.module.css";
import { style } from "d3";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";
import { SuggestContentsSearch } from "./suggest-contents-search";

// const BackgroundImage = styled.div<{ background: boolean }>`
//   width: 100%;
//   position: absolute;
//   left: 0;
//   top: 0;
//   background: ${(props) => (props.background ? "url(" + banner + ")" : "none")};
//   height: ${(props) => (props.background ? "150px" : "auto")};
// `;

const SearchIconButton = withStyles((theme: Theme) => ({
  root: {
    backgroundColor: portalSettingsManager.header?.colors?.searchIcon?.active?.back || "none",
    "& g#Desktop-HD": {
        stroke: portalSettingsManager.header?.colors?.searchIcon?.active?.text || "#ffffff",
      },
      "&:hover": {
        backgroundColor: portalSettingsManager.header?.colors?.searchIcon?.hover?.back || theme.palette.grey["300"],
        color: portalSettingsManager.header?.colors?.searchIcon?.hover?.text || "none",
        "& g#Desktop-HD": {
          stroke: portalSettingsManager.header?.colors?.searchIcon?.hover?.text || "#ffffff",
        },
    }
  },
}))(IconButton);

const BackgroundImage = withStyles(() => ({
  root: {
    width: "100%",
    position: "absolute",
    left: 0,
    top: 0,
    backgroundImage: (props: any) => (props.background ? "url(" + banner + ")" : "none"),
    height: (props: any) => (props.background ? "150px" : "auto"),
    backgroundSize: "cover",
    backgroundRepeat: "no-repeat",
    backgroundPositionY: "-102px"
  },
}))(Box);

const Container = withStyles((theme: Theme) => ({
  root: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    height: (props: any) => (props.background ? "150px" : "auto"),
    position: "relative",
    marginLeft: (props: any) => (props.background || props.mobile ? "0" : "0"),
    zIndex: 1,
    "& > div": {
      background: "transparent",
    },
    "& form": {
      display: "flex",
      alignItems: "center",
      backgroundColor: (props: any) => (props.background ? "rgba(255, 255, 255, 0.8)" : "#F5F5F5"),
      backgroundPosition: "center center",
      backgroundSize: "cover",
      backgroundRepeat: "no-repeat",
      width: "90%",
      maxWidth: (props: any) => (props.background ? "1240px" : "800px"),
      height: (props: any) => (props.background ? "70px" : "100%"),
      borderRadius: 0,
      margin: "auto",
      "& > div": {
        width: "100%",
        "& > div": {
          width: (props: any) => (props.background ? "calc(100% - 65px)" : ""),
          "& input": {
            padding: "0 20px",
            fontSize: (props: any) => (props.background ? "22px" : "16px"),
            color: portalSettingsManager.header?.colors?.search?.text || theme.palette.grey["800"],
            position: "relative",
            top: "3px",
            "&::placeholder": {
              opacity: (props: any) => (props.background ? 1 : 0.4),
              color: "#F5F5F5",
            },
          },
          "& input::-webkit-search-cancel-button ": {
            "-webkit-appearance": "none",
            appearance: "none",
            height: 10,
            width: 10,
            backgroundImage: "url(data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgMTUgMTUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPg0KICAgIDxnIGlkPSJQYWdlLTEiIHN0cm9rZT0id2hpdGUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4NCiAgICAgICAgPGcgaWQ9IkRlc2t0b3AtSEQiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xODYuMDAwMDAwLCAtMjAzLjAwMDAwMCkiIGZpbGw9IiMwMDAwMDAiPg0KICAgICAgICAgICAgPGcgaWQ9IlJlY3RhbmdsZSIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTg2LjAwMDAwMCwgMjAzLjAwMDAwMCkiPg0KICAgICAgICAgICAgICAgIDxyZWN0IHRyYW5zZm9ybT0idHJhbnNsYXRlKDcuNDk1Njg5LCA3LjE4MTk4MSkgcm90YXRlKC00NS4wMDAwMDApIHRyYW5zbGF0ZSgtNy40OTU2ODksIC03LjE4MTk4MSkgIiB4PSI3LjAzNDE1MDU1IiB5PSItMi4zMTgwMTk0OCIgd2lkdGg9IjEiIGhlaWdodD0iMTkiPjwvcmVjdD4NCiAgICAgICAgICAgICAgICA8cG9seWdvbiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg3LjQ5NTY4OSwgNy4xODE5ODEpIHJvdGF0ZSgtMTM1LjAwMDAwMCkgdHJhbnNsYXRlKC03LjQ5NTY4OSwgLTcuMTgxOTgxKSAiIHBvaW50cz0iNy4wMzQxNTA1NSAtMi4zMTgwMTk0OCA3Ljk1NzIyNzQ4IC0yLjMxODAxOTQ4IDcuOTU3MjI3NDggMTYuNjgxOTgwNSA3LjAzNDE1MDU1IDE2LjY4MTk4MDUiPjwvcG9seWdvbj4NCiAgICAgICAgICAgIDwvZz4NCiAgICAgICAgPC9nPg0KICAgIDwvZz4NCjwvc3ZnPg0K)",
            backgroundSize: "10px 10px",
            color: "#ffffff",
          },
          "& .k-autocomplete .k-clear-value": {
            color: portalSettingsManager.header?.colors?.search?.text || "#ffffff",
          }
        },
      },
    },
  },
}))(Box);


export const Search = ({ background, onSubmit, mobile = false, height }: any): JSX.Element => {
  const dispatch = useAppDispatch();
  const focusClass = useFocusStyles()

  const initialSearchTerm = useSelector((state: RootState) => state.core.searchText);

  const [searchText, setSearchText] = useState(initialSearchTerm);

  const captureIntitialSearch = useSelector((state: RootState) => state.core.captureSearch);
  const [captureSearch, setCaptureSearch] = useState(captureIntitialSearch);
  const { t } = useTranslation();
  const [redirectSearch, setRedirectSearch] = useState(false);

  const updateSearchText = (value: string) => {
    setSearchText(value);
    if (location.pathname === "/") {
      dispatch(clearSearch());
    }
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    sessionStorage.setItem("breadCrumbs", JSON.stringify({ data: [{ title: `${t('home')}`, path: "/" }, { title: `${t('search')}`, path: "/catalog" }], searchString: searchText, category: "" }));
    setRedirectSearch(true);
    setCaptureSearch(!captureSearch);
  };
  useEffect(() => {
    if (onSubmit && redirectSearch) {
      sessionStorage.setItem("relatedItemClick", "false")
      sessionStorage.setItem("breadCrumbs", JSON.stringify({ data: [{ title: `${t('home')}`, path: "/" }, { title: `${t('search')}`, path: "/catalog" }], searchString: searchText, category: "" }));
      dispatch({
        type: "subheader/title",
        payload: "",
      });
      dispatch({
        type: "search/setSearchFilters",
        payload: { code: CATEGORY_CODE_ALL, captureSearch: captureSearch },
      });
      dispatch({
        type: "search/setSearchFilters",
        payload: { text: searchText, captureSearch: captureSearch },
      });
      dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
      onSubmit();
    }
  }, [captureSearch]);

  return (
    <div style={{ width: "100%", position: "relative" }}>
      <BackgroundImage background={background} />
      <Container background={!!background} mobile={mobile}>
        <Paper style={{ width: "100%" }} elevation={0}>
          <form noValidate onSubmit={handleSubmit}
            aria-label={t('Global_Search_Bar')}
            aria-describedby= "searchdesc"
            style={{
              backgroundColor: portalSettingsManager.header?.colors?.search?.back || "none",
              borderColor: portalSettingsManager.header?.colors?.search?.border || "none"
            }}>
            <span id="searchdesc" hidden={true}>{t('Global_Search_Bar_Desc')}</span>
            <SuggestContentsSearch
              updateSearchText={updateSearchText}
              placeHolder={t("search_placeholder")}
            />
            {mobile && searchText ? (
              <IconButton
                type="button"
                className={focusClass.focusItem}
                aria-label={t("aria_label_clear_search")}
                onClick={(e) => {
                  e.preventDefault();
                  updateSearchText("");
                }}
              >
                <CloseIcon fontSize={background ? "large" : "inherit"} />
              </IconButton>
            ) : (
              <SearchIconButton type="submit" aria-label={t('search').toLowerCase()} style={{ height: "40px", width: "40px" }} className={focusClass.focusItem}>
                <SvgIcon
                  style={{
                    margin: "16px 6px 8px 10px",
                    fontSize: background ? "30px" : "22px",
                  }}
                >
                  <g id="Page-1" strokeWidth="1" fill="none" fillRule="evenodd">
                    <g id="Desktop-HD" transform="translate(-255.000000, -200.000000)">
                      <g id="Group" transform="translate(259.000000, 199.000000)">
                        <g
                          id="icon.search-sml"
                          transform="translate(6.500000, 11.000000) rotate(-45.000000) translate(-6.500000, -11.000000) "
                        >
                          <circle id="Oval" cx="6.5" cy="6.5" r="6"></circle>
                          <line x1="6.5" y1="12.5" x2="6.5" y2="21.5" id="Path-3"></line>
                        </g>
                      </g>
                    </g>
                  </g>
                </SvgIcon>
              </SearchIconButton>
            )}
          </form>
        </Paper>
      </Container>
    </div>
  );
};
