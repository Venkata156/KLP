import { Box, IconButton, SvgIcon, Button, withStyles, Typography } from "@material-ui/core";
import { Select } from "components";
import { styled } from "@material-ui/core/styles";
import { ReactComponent as arrowIcon } from "assets/icons/icon-arrow.svg";
import { first, last } from "lodash";
import { useTranslation } from "react-i18next";
import { useFocusStyles } from "hooks/focusBorder";

const Span = styled("span")(({ theme }) => ({
  fontSize: "12px",
  color: theme.palette.grey["300"],
  lineHeight: "14px",
  padding: "0 14px",
  position: "relative",
  top: "-1px",
  cursor: "pointer",
  "&.selected": {
    color: theme.palette.grey["800"],
  },
}));

const MobileButton = withStyles((theme) => ({
  root: {
    borderRadius: "0px",
    borderWidth: "1px",
    borderColor: "#0091DA",
    color: theme.palette.primary.main,
    "&:disabled": { color: theme.palette.grey["800"] },
  },
  label: {
    fontSize: "11px",
    fontWeight: "bold",
  },
}))(Button);

export const Paginator = ({ pages, currentPage, onChange, isMobile }: any): JSX.Element => {
  const pageLimit = 10;
  const { t } = useTranslation();
  const getPaginationGroup = () => {
    let start = Math.floor((currentPage - 1) / pageLimit) * pageLimit;
    let end = start + pageLimit;
    if (end > pages.length) {
      end = pages.length;
    }
    var pageArray = [];
    for (var i = start; i < end; i++) {
      pageArray.push(pages[i]);
    }
    return pageArray;
  };
  const focusClass = useFocusStyles();
  return (
    <Box display="flex" justifyContent="center" alignItems="center">
      <IconButton
        aria-label={t('aria_label_go_to_previous')}
        color="primary"
        onClick={() => onChange(currentPage - 1)}
        disabled={currentPage === first(pages)}
        tabIndex='0'
        className={focusClass.focusItem}
        aria-current={'page'}
        aria-disabled={currentPage === first(pages)}
      >
        {isMobile ? (
          <MobileButton
            variant={currentPage !== first(pages) ? "outlined" : undefined}
            disabled={currentPage === first(pages)}
            tabIndex='0'
          >
            {t('paginator_prev')}
          </MobileButton>
        ) : (
          <SvgIcon
            component={arrowIcon}
            style={{ transform: "rotate(180deg) translate(25%, 30%)" }}
          />
        )}
      </IconButton>
      {isMobile ? (
        <Box
          display={{ xs: "flex", sm: "flex", md: "flex" }}
          flexDirection="row"
          alignItems="center"
          justifyContent="flex-start"
          marginLeft={{ xs: "10px", sm: "0px" }}
        >
          <Box marginRight={{ xs: "10px", sm: "10px" }}>
            <Typography style={{ fontSize: "12px" }}>Page</Typography>
          </Box>
          <Select
            title={`${currentPage}`}
            options={pages.map((page: any) => {
              return { title: page, id: page };
            })}
            value={currentPage}
            onChange={onChange || { title: currentPage, id: currentPage }}
            pagenation={true}
          />
        </Box>
      ) : (
        getPaginationGroup().map((page: number) => (
          <Span
            key={page}
            className={currentPage === page ? "selected" : ""}
            onClick={() => onChange(page)}
            role="link"
            aria-current={currentPage === page?"page":false}
            tabIndex={0}
          >
            {page}
          </Span>
        ))
      )}
      <IconButton
        aria-label={t('aria_label_go_to_next')}
        color="primary"
        onClick={() => onChange(currentPage + 1)}
        disabled={currentPage === last(pages)}
        tabIndex='0'
        className={focusClass.focusItem}
        aria-current="page"
        aria-disabled={currentPage === last(pages)}
      >
        {isMobile ? (
          <MobileButton
            variant={currentPage !== last(pages) ? "outlined" : undefined}
            disabled={currentPage === last(pages)}
          >
            {t('paginator_next')}
          </MobileButton>
        ) : (
          <SvgIcon component={arrowIcon} style={{ transform: "translate(25%, 30%)" }} />
        )}
      </IconButton>
    </Box>
  );
};
