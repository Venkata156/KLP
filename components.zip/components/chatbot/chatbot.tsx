import { DirectLine } from "botframework-directlinejs";
import { useEffect, useState } from "react";
import ReactWebChat from "botframework-webchat";
import { Box, useMediaQuery } from "@material-ui/core";
import { Theme, withStyles, useTheme } from "@material-ui/core/styles";
import { GET_DIRECT_LINE_TOKEN } from "utils/queries";
import chatbotIcon from "assets/icons/icon-chatbot.svg";
import { CloseIcon } from "components";
import { useLazyQuery } from "@apollo/client";
import { DirectLineToken } from "utils/graphql/DirectLineToken";
import { useSelector } from "react-redux";
import { RootState } from "store";
import { useTranslation } from "react-i18next";
import { useFocusStyles } from "hooks/focusBorder";

const MainHolder = withStyles(() => ({
  root: ({ isMobile }: { isMobile?: boolean }) => ({
    position: "fixed",
    zIndex: 999,
    right: isMobile ? "0px" : "7px",
    bottom: isMobile ? "0px" : "10px",
    width: isMobile ? "100%" : "420px",
    height: isMobile ? "100vh" : "80vh",
    background: "white",
    boxShadow: "0px 0px 7px #00000055",
  }),
}))(Box);

const Container = withStyles((theme: Theme) => ({
  root: {
    height: "66vh",
    "& ul > li:first-child p, ul > li:first-child .ac-container > .ac-container": {
      background: theme.palette.common.white,
      fontSize: "1.05rem !important",
      lineHeight: "1.15rem",
      backgroundImage: "none !important",
      paddingBottom: "0 !important",
      paddingTop: "0 !important",
    },
    "& ul > li:first-child .ac-container > .ac-container img": {
      display: "none",
    },
    "& ul > li:nth-child(2), ul > li:nth-child(4), div.ac-adaptiveCard": {
      "& .webchat__bubble .webchat__bubble__content": {
        background: theme.palette.common.white,
        borderRadius: "0",
        borderColor: "#C9C9C9",
        borderWidth: "0",
        borderTopWidth: "1px",
        marginTop: "12px",
        border: "none"
      },
      "& .ac-textBlock p": {
        color: theme.palette.primary.main,
        fontSize: "1rem",
        paddingBottom: "10px",
      },
      "& button": {
        color: `${theme.palette.grey["800"]} !important`,
        borderColor: theme.palette.grey["A100"],
        textTransform: "uppercase",
        padding: "0.85rem 0",
        cursor: "pointer",
      },
    },
  },
}))(Box);

export const Chatbot = (): JSX.Element => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [directLine, setDirectLineToken] = useState<DirectLine>(new DirectLine({ token: "" }));
  const [isLoaded, setIsLoaded] = useState<boolean>(true);
  const { t } = useTranslation();
  const [loadDirectlineToken, { data }] = useLazyQuery<DirectLineToken>(
    GET_DIRECT_LINE_TOKEN
  );
  const [chatBot, setChatBot] = useState(false);
  const mobilePageButtonEnabled = useSelector((state: RootState) => state.core.pageButtonEnabled);
  const styleOptions = {
    bubbleBackground: "#f5f5f5",
    bubbleBorderColor: "#ececec",
    bubbleTextColor: theme.palette.grey["800"],
    bubbleBorderRadius: 7,
    bubbleFromUserBackground: theme.palette.primary.main,
    bubbleFromUserTopBorderColor: theme.palette.common.white,
    bubbleFromUserBorderRadius: 7,
    bubbleFromUserTextColor: theme.palette.common.white,
    connectivityTextSize: "2%",
    bubbleNubOffset: 0,
    bubbleNubSize: undefined,
    hideUploadButton: true
  };

  useEffect(() => {
    if (data) {
      directLineTokenControl();

    }
  }, [data]);

  const directLineTokenControl = () => {
    setDirectLineToken(
      new DirectLine({ token: data?.directLineToken?.token ? data?.directLineToken?.token : "" })
    );
    setIsLoaded(true)
    setChatBot(!chatBot)
  };

  const handleClose = () => {
    setChatBot(!chatBot);
    directLineTokenControl();
  };
  const focusClass = useFocusStyles();
  if (!isLoaded) {
    return <div>{t('loading')} ... </div>;
  } else {
    return (
      <Box>
        {chatBot ? (
          <MainHolder isMobile={isMobile}>
            <CloseIcon
              fill={theme.palette.common.black}
              onClick={() => handleClose()}
              style={{ float: "right", padding: "15px 8px 0", cursor: "pointer" }}
              className={focusClass.focusItem}
              tabIndex={0}
            />
            <Box display="flex" justifyContent="center" width="100%" component="div">
              <img src={chatbotIcon} alt='Chatbot' height="50px" style={{ paddingBottom: "26px" }} />
            </Box>
            <Box>
              <Container component="h3">
                <ReactWebChat styleOptions={styleOptions} directLine={directLine} />
              </Container>
            </Box>
          </MainHolder>
        ) : (
          <Box
            key={mobilePageButtonEnabled.toString()}
            position="fixed"
            bottom={
              mobilePageButtonEnabled ? { xs: "52px", sm: "30px" } : { xs: "50px", sm: "10px" }
            }
            right={isMobile ? "10px" : "20px"}
            width="42px"
            height="42px"
            zIndex="999"
          >
            <img
              src={chatbotIcon}
              alt='Chatbot'
              onClick={() => { loadDirectlineToken(); setIsLoaded(false); }}
              style={{ cursor: "pointer" }}
            />
          </Box>
        )}
      </Box>
    );
  }
};
