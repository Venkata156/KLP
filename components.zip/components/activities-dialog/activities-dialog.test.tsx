import { ActivitiesDialog } from './activities-dialog';
import { render, screen, waitFor } from 'test/index';
import { availableActivities } from '../../test/mocks/GetActivities';
import { activityUrl } from '../../test/mocks/GetActivityUrl';
describe('Acitivites Dialog Component', () => {
    it('should render without any errors', async () => {
        const onCloseCallback = jest.fn();
        render(<ActivitiesDialog
            onClose={onCloseCallback}
            activities={availableActivities}
            open={true}
            courseID="courseID"
            source="" />);

        await waitFor(async () => {
            const link = screen.getByRole('link', { name: /ActivityName1/i });
            expect(link).toHaveAttribute('href', activityUrl);
        });
    });
});