import { Button, Typography, DialogTitle } from "@material-ui/core";
import { GET_ACTIVITY_URL } from "utils/queries";
import { useQuery } from "@apollo/client";
import { useTheme } from "@material-ui/core/styles";
import MuiDialogActions from "@material-ui/core/DialogActions";
import MuiDialogContent from "@material-ui/core/DialogContent";
import { Dialog } from "components";
import * as ActivityTypes from "utils/graphql/Activities";
import { ActivityURL } from "utils/graphql/ActivityURL";
import { CSSProperties, useState } from "react";
import opensesameIcon from "assets/icons/icon-logo-opensesame.svg";
import linkedinIcon from "assets/icons/icon-logo-linkedIn.svg";
import { LTIForm } from "components";
import { ContentSource } from "utils/graphql/Global";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";
import { useFocusStyles } from "hooks/focusBorder";

const LaunchActivity = ({
  activity,
  courseID,
  source,
}: {
  activity: ActivityTypes.Activities_activities;
  courseID: string;
  source: string;
}): JSX.Element => {
  const [isSubmit, setIsSubmit] = useState(false);
  const { loading, error, data } = useQuery<ActivityURL>(GET_ACTIVITY_URL, {
    variables: {
      activityId: String(activity.id),
      activityType: activity.type,
      courseId: courseID,
    },
    fetchPolicy: "no-cache",
  });
  const style: CSSProperties = {
    paddingTop: "16px",
    paddingBottom: "16px",
    borderRadius: "0px",
    width: "100%",
    marginTop: "20px",
    fontSize: "11px",
    color: "#0091DA",
    borderColor: "#0091DA",
    fontWeight: "bold",
  };

  return source === "OPEN_SESAME" ? (
    <>
      <Button variant="outlined" onClick={() => setIsSubmit(true)} style={style}>
        {activity.name}
      </Button>
      <LTIForm type={source} isSubmit={isSubmit} courseId={courseID} activityId={String(activity.id)}></LTIForm>
    </>
  ) : (
    <Button
      href={data?.activityUrl ?? ""}
      target="_blank"
      disabled={loading || Boolean(error) || !data?.activityUrl}
      style={style}
      variant="outlined"
    >
      {activity.name}
    </Button>
  );
};

type ActivitiesDialogProps = {
  onClose: () => void;
  activities: ActivityTypes.Activities_activities[];
  open: boolean;
  courseID: string;
  source: string;
};
export const ActivitiesDialog = (props: ActivitiesDialogProps): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const logoStyle = { width: "65%", marginTop: "33px", marginBottom: "33px" };
  const focusClass = useFocusStyles();

  return (
    <Dialog onClose={props.onClose} open={props.open} fullScreen role="dialog" aria-modal="true" id="activitiesdialog">
      <DialogTitle>{t('activities')}</DialogTitle>
      <MuiDialogContent>
        <Typography
          style={{
            fontSize: "14px",
            font: "Arial",
            lineHeight: "21px",
            alignItems: "left",
            color: "#333333",
          }}
        >
          {t('activity_redirect_dialog')}
        </Typography>
        {props.source === ContentSource.OPEN_SESAME && (
          <img style={logoStyle} alt="Opensesame Icon" src={opensesameIcon} />
        )}
        {props.source === ContentSource.LINKED_IN && <img style={logoStyle} alt="Linkedin Icon" src={linkedinIcon} />}
        {props.activities.map((activitiy) => (
          <LaunchActivity
            key={activitiy.id}
            activity={activitiy}
            courseID={props.courseID}
            source={props.source}
          />
        ))}
        <Typography
          style={{
            fontSize: "12px",
            font: "Arial",
            lineHeight: "18px",
            alignItems: "left",
            color: "#333333",
            marginTop: "25px",
          }}
        >
          <b>{t('note')}</b> {t('progress_update_dialog')}
        </Typography>
      </MuiDialogContent>
      <MuiDialogActions>
        <Button
          variant="outlined"
          onClick={props.onClose}
          style={{
            borderRadius: "0px",
            margin: "10px",
            borderColor: theme.palette.grey["A100"],
            font: "Arial",
            fontWeight: "bold",
            borderWidth: "1px",
            fontSize: "12px",
            paddingTop: "15px",
            paddingBottom: "15px",
            color: portalSettingsManager.buttonColors?.normal?.active?.text || "#333333",
            width: "100%",
          }}
          className={focusClass.secondaryHover}
        >
          {t('cancel_and_close')}
        </Button>
      </MuiDialogActions>
    </Dialog>
  );
};
