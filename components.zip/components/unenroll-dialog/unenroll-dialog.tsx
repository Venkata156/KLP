import { useLazyQuery, useMutation } from "@apollo/client";
import {
  Box,
  Checkbox,
  FormControlLabel as MuiFormControlLabel,
  Typography,
} from "@material-ui/core";
import { Theme, withStyles, styled, useTheme } from "@material-ui/core/styles";
import { useMediaQuery } from "@material-ui/core";
import { Dialog, DialogActions, DialogContent, RenderHTML, Action } from "components";
import { useEffect, useState } from "react";
import { CourseUnenrollment } from "utils/graphql/CourseUnenrollment";
import { COMPLETE_UNENROLLMENT, GET_COURSE_UNENROLLMENT_DATA } from "utils/queries";
import { useAppDispatch } from "store";
import { emailRegex } from "utils/helpers";
import { useTranslation } from "react-i18next";

import { useFocusStyles } from "hooks/focusBorder";

const FormControlLabel = withStyles((theme: Theme) => ({
  label: {
    fontSize: 12,
    color: theme.palette.grey["800"],
  },
}))(MuiFormControlLabel);
const NonEditableField = withStyles((theme: Theme) => ({
  root: {
    "& label": {
      display: "block",
      fontSize: "11px",
      color: theme.palette.grey["500"],
    },
    "& span": {
      fontSize: "14px",
      color: theme.palette.grey["800"],
      fontWeight: 700,
    },
    "& button": {
      border: `1px solid ${theme.palette.primary.main}`,
      color: theme.palette.primary.main,
      position: "relative",
      left: "15px",
      top: "-7px",
    },
    "& p": {
      fontSize: "11px",
      color: theme.palette.grey["500"],
    },
  },
}))(Box);
const CtlWrapper = withStyles((theme: Theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    border: `1px solid ${theme.palette.grey["A100"]}`,
    width: (props: any) => (props.isMobile ? "200px" : "275px"),
    minHeight: "40px",
    marginTop: "5px",
    padding: "0 5px",
    overflow: "visible",
    "&:focus-within": {
      border: '2px solid #000'
    },
    "& input": {
      border: "none",
      width: "100%",
      "&:focus": {
        outline: "none",
      },
    },
    "& select": {
      border: "none",
      width: "100%",
      "&:focus": {
        outline: "none",

      },
    },
  },
}))(Box);

const Label = styled("label")(({ theme }) => ({
  display: "block",
  fontSize: "12px",
  color: theme.palette.grey["500"],
  marginTop: "29px",
  marginBottom: "10px",
}));

export const UnenrollDialog = ({
  course,
  open,
  handleClose,
  handleEnroll,
  learnerEmail,
  canEditLineManagerEmail,
}: any): JSX.Element => {
  const theme = useTheme();
  const { t } = useTranslation();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [loadData, { data }] = useLazyQuery<CourseUnenrollment>(
    GET_COURSE_UNENROLLMENT_DATA
  );
  const [completeUnenrollment] = useMutation(COMPLETE_UNENROLLMENT);

  const dispatch = useAppDispatch();
  const focusClass = useFocusStyles()
  const [allReasons, setAllReasons] = useState<string[]>([]);
  const [reason, setReason] = useState("");
  const [managerEmail, setManagerEmail] = useState("");
  const [agreeTerms, setAgreeTerms] = useState(false);

  const processUnenrollment = () => {
    const data = {
      courseId: String(course.id),
      lineManagerEmail: managerEmail,
      cancellationReason: reason,
    };
    handleDialogClose();
    dispatch({
      type: "loader/showandhide",
      payload: { show: true, message: t('unenrolling') },
    });
    completeUnenrollment({ variables: { courseUnenroll: data } })
      .then(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('unenrolling') },
        });
        handleEnroll(),
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('course_unenrolled_alert_title'),
            message: t('course_unenrolled_alert_message'),
          },
        });
      })
      .catch(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('unenrolling') },
        });
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('course_unenrolled_alert_title'),
            message: t('course_unenroll_error_alert_message'),
          },
        });
      });
  };

  useEffect(() => {
    if (!!loadData && !!course && open) {
      loadData({ variables: { courseId: String(course.id) } });
    }
  }, [course, open, loadData]);

  useEffect(() => {
    setAllReasons(
      (data?.unenrollmentData?.cancellationReasons || []).flatMap((reason) =>
        reason ? [reason] : []
      )
    );
    setManagerEmail(data?.unenrollmentData?.lineManagerEmail || "");
  }, [data]);
  const handleDialogClose = () => {
    setReason("");
    setAgreeTerms(false);
    handleClose();
  };
  return (
    <Dialog
      id="unenrolldialog"
      isMobile={isMobile}
      onClose={handleDialogClose}
      role="dialog" aria-labelledby="unenroll_dialog_label" aria-modal="true"
      fullWidth={isMobile}
      open={open}
      minHeight={isMobile ? "90vh" : 500}
      minWidth={isMobile ? undefined : 600}
      maxHeight={isMobile ? undefined : 600}
      style={{padding:"0px"}}
      showCloseIcon
    >
      <DialogContent isMobile={isMobile}>
        <Typography style={{ fontSize: "16px", color: theme.palette.grey["800"] }} component="h2" id="unenroll_dialog_label">
          {t('unenroll_from_course')}
        </Typography>
        <Typography
          style={{ fontSize: "12px", fontWeight: 700, color: theme.palette.primary.main }}
          component="h3"
        >
          {course.name}
        </Typography>
        <Box style={{ fontSize: "12px", color: theme.palette.grey["800"], lineHeight: "16px", overflowY:"auto", maxHeight: "135px" }}>
          <RenderHTML content={data?.unenrollmentData?.cancellationPolicy ?? ""} />
        </Box>
        <Box
          display="flex"
          flexDirection={"column"}
          justifyContent="space-between"
          flexWrap={isMobile ? "wrap" : undefined}
          width={isMobile ? "250px" : "600"}

        >
          <div>
            <Label tabIndex={0}>{t('reason_for_cancellation')}</Label>
            <CtlWrapper isMobile={isMobile}
            >
              <select
                multiple={false}
                value={reason || ""}
                onChange={(event) => setReason(event.target.value)}
                aria-label={t('choose_option_cancellation')}
                aria-required="true"
              >
                <option value="" disabled>{t('choose')}</option>
                {allReasons.map((item, idx) => (
                  <option key={idx} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </CtlWrapper>
          </div>
          <div>
            {
              function () {
                if (canEditLineManagerEmail) {
                  return (
                    <>
                      {/* <Label htmlFor={t('managers_email')}>Manager&apos;s Email</Label> */}
                      <Label htmlFor={t('managers_email')}>{t('managers_email')}</Label>
                      <CtlWrapper isMobile={isMobile}>
                        <input
                          value={managerEmail}
                          aria-label={t('enter_managers_email')}
                          aria-required="true"
                          onChange={(event) => setManagerEmail(event.target.value)}
                        />
                      </CtlWrapper>
                    </>
                  )
                }
                return (
                  <NonEditableField>
                    {/* <Label>Manager&apos;s Email</Label> */}
                    <Label>{t('managers_email')}</Label>
                    <div style={{ width: 200 }}>{managerEmail}</div>
                  </NonEditableField>
                )
              }.call(1)
            }
          </div>
        </Box>
        <FormControlLabel
          control={
            <Checkbox
              checked={agreeTerms}
              color="primary"
              inputProps={{ "aria-label":t('agree_terms'), "aria-required": true }}
              onChange={(event) => setAgreeTerms(event.target.checked)}
            />
          }
          tabIndex={0}
          aria-required="true"
          label={t('aria_label_unenroll_confirmation')}
        />
      </DialogContent>
      <DialogActions>
        <Action type="dialog-alt" onClick={handleDialogClose} className={focusClass.focusItem}>
          {t('cancel_and_close')}
        </Action>
        <Action
          type="dialog-primary"
          onClick={processUnenrollment}
          disabled={
            !agreeTerms ||
            !reason ||
            (canEditLineManagerEmail && (!managerEmail ||
              !new RegExp(emailRegex).test(managerEmail))) ||
            (learnerEmail &&
              learnerEmail.toLowerCase().trim() === managerEmail.toLowerCase().trim())
          }
          style={{ height: "32px", width: "190px" }}
        >
          {t('confirm_unenrollment')}
        </Action>
      </DialogActions>
    </Dialog>
  );
};
