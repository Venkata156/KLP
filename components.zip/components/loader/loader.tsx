import { Backdrop, Box, CircularProgress } from '@material-ui/core';
import { Theme, makeStyles, useTheme } from "@material-ui/core/styles";
import { useTranslation } from "react-i18next";
import portalSettingsManager from 'utils/portalSettingsManager';

const useStyles = makeStyles((theme: Theme) => ({
  root: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'column',
    width: '100% !important',
    zIndex: theme.zIndex.modal + 1,
    color: 'white',
    '& > div': {
      padding: '6px',
    }
  },
  circular: {
    background: "white",
    width: "12px",
    height: " 12px",
    borderRadius: "50%",
    boxShadow: "1px 1px 1px grey",
    color: portalSettingsManager.application?.common?.themeColor 
  }
}));

export const Loader = ({
  isDisplay = false,
  message,
  type = "page"
}: {
  isDisplay?: boolean;
  message?: string;
  type?: string;
}): JSX.Element => {
  const theme = useTheme();
  const classes = useStyles();
  const { t } = useTranslation();

  if (type === "component" && isDisplay) {
    return (
      <Backdrop className={classes.root} open={isDisplay}>  
        <CircularProgress style={{'color': `${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`}} className={classes.circular} size={30} thickness={6} />
        <Box style={{ color: theme.palette.common.black }}>{message}</Box>
      </Backdrop>
    )
  } else if (type === "page" && isDisplay) {
    return (
      <Backdrop className={classes.root} open={isDisplay}>
        <CircularProgress style={{'color': `${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`}} className={classes.circular} size={30} thickness={6} />
        <div>{t('please_wait', "")}</div>
      </Backdrop>
    )
  } else {
    return (<></>)
  }
};