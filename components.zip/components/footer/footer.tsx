import { Box, Typography, useMediaQuery } from "@material-ui/core";
import { styled, useTheme } from "@material-ui/core/styles";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";
import { useAppDispatch } from "store";
import portalSettingsManager from "utils/portalSettingsManager";
import { openContactUs } from "utils/helpers";
import { openUrlUtil } from "hooks/open-url";

const LI = styled("li")(({ theme }) => ({
  borderBottom: `1px solid ${theme.palette.grey["800"]}`,
  display: "inline-block",
  marginRight: "40px",
  marginBottom: "10px",
  "& a": {
    fontSize: "12px",
    fontWeight: 400,
    color: theme.palette.grey["800"],
    textDecoration: "none",
  },
  "& a:hover": {
    cursor: "pointer",
  },
}));

interface FooterLink {
  name: string; callback: () => void
}

export const Footer = (): JSX.Element => {
  const dispatch = useAppDispatch();
  const theme = useTheme();
  const { t } = useTranslation();
  const focusClass = useFocusStyles()
  const isMobile = useMediaQuery(theme.breakpoints.down("xs"));
  const footerLinks = () => {
    const footerArr: FooterLink[] = [];
    portalSettingsManager.footer.links.forEach(X => {
      footerArr.push({ name: t(X.type), callback: () => X.type.toLowerCase()!='contact_us'? OpenFooterLinks(X.url):openContactUs() });
    });
    return footerArr;
  }
  const {openUrl}= openUrlUtil();
  const OpenFooterLinks  = (footerUrl: string)=>{
    openUrl(footerUrl);
  }
    
  return (
    <Box >
      {portalSettingsManager?.footer?.logo?.url && (<Box textAlign="center" margin={{ xs: "20px 0", sm: "35px 0 0 0" }}>
        <img src={portalSettingsManager?.footer?.logo?.url || ""}
          style={{
            width: `${portalSettingsManager?.footer?.logo?.widthInPixel || `50`}px`,
            height: `${portalSettingsManager?.footer?.logo?.heightInPixel || `20`}px`
          }}
          alt='Logo' />
      </Box>)}
      <Box
        display="flex"
        maxWidth="1200px"
        height="140px"
        flexDirection={{ xs: "column", sm: "column" }}
        padding={{ xs: "0", sm: "0 20px" }}
        textAlign="center"
      >
        <Box margin={{ xs: "20px 0 0 0", sm: "35px 0px" }}>
          <div>
            <Typography
              style={{
                fontSize: "12px",
                fontWeight: 700,
                color: theme.palette.grey["800"],
                margin: 0,
              }}
              className={focusClass.focusItem}
              aria-label={t('aria_label_copyright_statement')}
            >
              &copy; {t('footer_copyright_statement')}
            </Typography>
            <ul style={{ listStyle: "none", padding: 0, marginBottom: "95px", textAlign:"center" }}>
              {footerLinks().map((item) => {
                return (
                  <>{item.name && <LI key={item.name}  onKeyPress={item.callback}>
                    <a tabIndex={0} onClick={item.callback} target="blank" >
                      <span>{item.name}</span>
                    </a>
                  </LI>}
                  </>
                );
              })}
            </ul>
          </div>
        </Box>
      </Box>
    </Box>
  );
};
