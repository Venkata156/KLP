import React from "react";
import { Typography, Box } from "@material-ui/core";
import { withStyles, makeStyles } from "@material-ui/core/styles";
import { Dialog, DialogActions, DialogContent, Action } from "components";
import { useTranslation } from "react-i18next";

const useStyles = makeStyles(() => ({
  root: {
    "& .MuiPaper-root": {
      borderRadius: "0px",
    },
  },
}));

const Label = withStyles(() => ({
  root: {
    display: "block",
    fontSize: "12px",
    color: "#999999",
    marginTop: "29px",
    marginBottom: "10px",
  },
}))(Box);

export const RemindDialog = ({ open, data, handleSendReminder, sendReminder, remindData, learnerName }: any): JSX.Element => {
  const { t } = useTranslation();
  const classes = useStyles();
  const lastSent = new Date(data?.lastReminderDateTime);
  const date = [('0' + lastSent.getDate()).slice(-2), ('0' + (lastSent.getMonth() + 1)).slice(-2), lastSent.getFullYear()].join('/');
  return (
    <Dialog
      onClose={() => sendReminder()}
      aria-labelledby={t('aria_label_counselee_remind_dialog')}
      open={open}
      minHeight= {300}
      style={{ minWidth: 400, maxWidth: 500 }}
      className={classes.root}
      showCloseIcon
      role="dialog" aria-modal="true"
      id="reminddialog"     
    >
      <DialogContent style={{ padding: "8px 35px" }}>
        <Typography
          style={{ fontSize: "16px", color: "#333333", fontWeight: 400, paddingBottom: "5px" }}
        >
          {t('remind')} {learnerName}
        </Typography>
        <Typography
          style={{
            fontSize: "12px",
            color: "#333333",
            lineHeight: "18px",
            fontWeight: 400,
          }}
        >
          {t('remind_email_dialog')}
        </Typography>
        <Box style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <Label>{t('item_name')}</Label>
        </Box>

        <Box style={{ fontWeight: 700, color: "#000" }}>{remindData.name}</Box>

        {data?.lastReminderDateTime && <Typography
          style={{
            fontSize: "10px",
            color: "#0091DA",
            marginTop: "20px",
            lineHeight: "18px",
            fontWeight: 400,
          }}
        >
          {t('last_reminder_message')} {date}
        </Typography>}
      </DialogContent>

      <DialogActions style={{ padding: "18px 35px 29px 35px" }}>
        <Action type="dialog-alt" onClick={sendReminder}>
          {t('cancel_and_close')}
        </Action>
        <Action type="dialog-primary" disabled={false} onClick={()=>{handleSendReminder();sendReminder()}}>
          {t('send_reminder')}
        </Action>
      </DialogActions>
    </Dialog>
  );
};
