import * as React from "react";
import { Tooltip as KendoTooltip, TooltipProps } from "@progress/kendo-react-tooltip";

interface CustomToolProps extends TooltipProps {
  maxWidth?: number;
  title: string;
  textEllipse?: boolean;
  id?: string;
  maxLines?: number;
  wrapperCss?: React.CSSProperties;
  zIndex?: number;
  anchorElement?:string;
}
const addMaxlines = (Text: string, width: number, fontSize: number, MaxLine: number) => {
  let output = "";
  const charSize = Math.trunc(width / fontSize);
  for (let i = 0; i < MaxLine; i++) {
    const splint = Text.slice(i * charSize, (i + 1) * charSize);
    output = output + splint;
  }
  return output + "...";
};

export const Tooltip = React.forwardRef(
  (props: CustomToolProps, forwardRef: React.ForwardedRef<KendoTooltip> | null | undefined) => {
    return (
      <KendoTooltip
        {...props}
        ref={forwardRef}
        parentTitle={true}
        anchorElement={props.anchorElement || "target"}
        position={props.position || "bottom"}
        style={{ zIndex: props.zIndex || "auto" }}
      >
        <div
          style={props.wrapperCss}
          title={
            props.maxLines
              ? addMaxlines(props.title, props.maxWidth ?? 100, 2, props.maxLines)
              : props.title
          }
        >
          {props.children}
        </div>
      </KendoTooltip>
    );
  }
);
Tooltip.displayName = "Tooltip";

