import { Box, Button } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import { SCAN_UPLOADED_FILE, GET_SAS } from "utils/queries";
import { Loader } from "components";
import { uploadClient } from "utils/fileuploadclient";
import React, { useState } from "react";
import { useMutation, useQuery } from "@apollo/client";
import * as SasTypes from "utils/graphql/SAS";
import { useAppDispatch } from "store";
import { UploadUI } from "@progress/kendo-react-upload";
import { LocalizationProvider, loadMessages } from "@progress/kendo-react-intl";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";

const LaunchUpload = withStyles(() => ({
  root: {
    padding: "6px 0px !important",
    "&:hover": {
      backgroundColor: "transparent",
      cursor: "pointer",
    },
    "& .k-upload, .k-upload-button ": {
      fontSize: "10px",
      fontWeight: 800,
      color: portalSettingsManager.buttonColors.normal.active.text || "#333333",
      border: `1px solid ${portalSettingsManager.buttonColors.normal.active.border || "#333333"}`,
      borderRadius: 0,
      padding: "5px 15px",
      backgroundColor: portalSettingsManager.buttonColors.normal.active.back || "transparent",
      "&:hover": {
        cursor: "pointer",
      },
    },
    "& .k-dropzone-hint, .k-upload-status-total": {
      display: "none",
    },
    "& .k-dropzone": {
      padding: "0px",
      display: "flex",
      justifyContent: "flex-end",
    },
    "& .k-widget": {
      padding: "0px",
      border: "0px",
    },
    "& .k-upload-files": {
      display: "none",
      //border: "0px",
    },
    "& .k-file.k-state-focused": {
      boxShadow: "none",
    },
    "& .k-upload-action, .k-upload-status": {
      display: "none !important",
    },
  },
}))(Button);

const bgMessages = {
  upload: {
    select: "Upload File",
  },
};
loadMessages(bgMessages, "bg-BG");

export const UploadFile = ({ activityId, courseId, onUploadSuccess }: any): JSX.Element => {
  const dispatch = useAppDispatch();
  const [showLoader, setShowLoader] = useState<boolean>(false);
  const { t } = useTranslation();
  const [scanUploadedFile] = useMutation(SCAN_UPLOADED_FILE);
  const {
    data: sasData
  } = useQuery<SasTypes.SAS>(GET_SAS, {
    variables: {
      parameters: { programmeId: courseId, activityId: activityId },
    },
  });
  
  const fileSizeExceeded = () => {
    dispatch({
      type: "alert/show",
      payload: {
        type: "error",
        title: t('fileupload_exeeds_max_alert_title'),
        message:
          t('fileupload_exeeds_max_alert_message'),
      },
    });
    hideToast();  
  };

  const incorrectFileExtension = () => {
    dispatch({
      type: "alert/show",
      payload: {
        type: "error",
        title: t('fileupload_incorrect_extension_alert_title'),
        message:
          t('fileupload_incorrect_extension_alert_message'),
      },
    });
    hideToast();
  };

  const uploadSuccess = () => {
    setShowLoader(false);
    if (sasData !== undefined) {
      scanUploadedFile({
        variables: { fileRelativePath: sasData.sas?.fileRelativePath },
      })
        .then(() => {
          {
            dispatch({
              type: "alert/show",
              payload: {
                type: "success",
                title: t('fileupload_success_alert_title'),
                message: t('fileupload_success_alert_message'),
              },
            });
            if (onUploadSuccess) {
              onUploadSuccess();
            }
            hideToast();
          }
        })
        .catch(() => {
          {
            dispatch({
              type: "alert/show",
              payload: {
                type: "error",
                title: t('fileupload_failed_alert_title'),
                message: t('fileupload_failed_alert_message'),
              },
            });
            hideToast();
          }
        });
    } else {
      dispatch({
        type: "alert/show",
        payload: {
          type: "error",
          title: t('fileupload_failed_alert_title'),
          message: t('fileupload_failed_alert_message'),
        },
      });
      hideToast();
    }
  };

  const uploadFailure = () => {
    setShowLoader(false);
    dispatch({
      type: "alert/show",
      payload: {
        type: "error",
        title: t('fileupload_failed_alert_title'),
        message: t('fileupload_error_message'),
      },
    });
    hideToast();
  };

  const hideToast = () => {
    setTimeout(function () {
      dispatch({ type: "alert/hide" });
    }, 5000);
  };

  const onAdd = (e: any) => {
    const file = e[0];
    if (file.size > Number(process.env.REACT_APP_MAXIMUM_FILE_SIZE)) {
      fileSizeExceeded();
      return;
    }
    const fileExtension = file.name.replace(/.*\./, "").toLowerCase();
    if (["txt", "docx", "pdf", "doc"]?.indexOf(fileExtension) < 0) {
      incorrectFileExtension();
      return;
    }
    if (sasData !== undefined) {
      setShowLoader(true);
      uploadClient.upload(sasData.sas, file, uploadSuccess, uploadFailure);
    }
  };

  return (
    <>
      <LaunchUpload aria-required= "true" aria-label="Upload File" title={t('fileupload_msg')} >
        <Box>
          <LocalizationProvider language={"bg-BG"}>
            <UploadUI onAdd={onAdd}  
            />
          </LocalizationProvider>
        </Box>
        <Loader isDisplay={showLoader} message={t('fileupload_loader')}></Loader>
      </LaunchUpload>
    </>
  );
};
