import React from "react";
import { Activities_activities_availableSessions } from "utils/graphql/Activities";
import {
  Box,
  DialogTitle,
  Dialog,
  DialogContent,
  DialogActions,
  Typography,
  Button,
} from "@material-ui/core";
import { Divider } from "@material-ui/core";
import { useTheme, withStyles } from "@material-ui/core/styles";
import { CarouselIndicators } from "components/carousel-indicators/carousel-indicators";
import { useTranslation } from "react-i18next";

// returns datetime in: dd MMM yyyy h|hh:mm am|pm
// Example: 04 Mar 2021 4:30 pm
const workshopDateTime = (date: Date) => {
  if(date.toString() === "Invalid Date") return "N/A";
  const [, month, day, year, time] = date.toString().split(" ");
  const [strHours, minutes] = time.split(":");
  const hours = parseInt(strHours);
  return `${day} ${month} ${year} ${((hours + 11) % 12) + 1}:${minutes} ${
    hours > 11 ? "pm" : "am"
  }`;
};

const ActionButton = withStyles(() => ({
  root: (props: { close?: boolean }) => ({
    borderRadius: "0px",
    color: props.close ? "#949494" : undefined,
  }),
  label: {
    fontWeight: "bold",
  },
}))(Button);

type ActionsProps = {
  current: number;
  numSlides: number;
  setPage: (index: number) => void;
  onClose: () => void;
};
const Actions: React.FC<ActionsProps> = ({ current, setPage, numSlides, onClose }) => {
  const { t } = useTranslation();
  return (
    <Box display="flex" flexDirection="column" margin="auto">
      <Box margin="auto" marginBottom="15px">
        <CarouselIndicators current={current} numSlides={numSlides} />
      </Box>
      <Box
        display="flex"
        flexDirection="row"
        justifyContent="space-around"
        width="240px"
        marginBottom="12px"
      >
        <ActionButton
          disabled={current <= 0}
          variant="outlined"
          onClick={() => setPage(current - 1)}
        >
          {t('prev_placeholder')}
        </ActionButton>
        <ActionButton onClick={onClose} close>
          {t('close').toUpperCase()}         
        </ActionButton>
        <ActionButton
          disabled={current + 1 >= numSlides}
          variant="outlined"
          onClick={() => setPage(current + 1)}
        >
          {t('next_placeholder')}          
        </ActionButton>
      </Box>
    </Box>
  );
};

type InfoProps = { title: React.ReactNode };
const Info: React.FC<InfoProps> = ({ title, children }) => {
  const theme = useTheme();
  return (
    <Box display="flex" flexDirection="column">
      <Typography
        style={{ marginTop: "19px", color: "#949494", fontSize: "12px", lineHeight: "14px" }}
      >
        {title}
      </Typography>
      <Typography
        style={{
          marginTop: "11px",
          color: theme.palette.grey["800"],
          fontSize: "12px",
          fontWeight: "bold",
          lineHeight: "14px",
        }}
      >
        {children}
      </Typography>
    </Box>
  );
};

type SessionDialogInfoProps = {
  current: number;
  show: boolean;
  setSession: (sessionIndex: number) => unknown;
  setShow: (show: boolean) => unknown;
  sessions: (Activities_activities_availableSessions | null)[] | null;
  name: string;
};
export const SessionDialogInfo: React.FC<SessionDialogInfoProps> = ({
  show,
  current,
  setSession,
  sessions,
  setShow,
  name
}) => {
  const currentSession = sessions?.[current];
  const { t } = useTranslation();
  const theme = useTheme();
  return (
    <Dialog
      open={show}
      role="dialog"  aria-labelledby="expire_dialog_label" aria-modal="true"
      fullScreen
      style={{ margin: "20px", marginTop: "30px", maxHeight: "600px" }}
    >
      <DialogTitle>
        <Box id ="expire_dialog_label" style={{ fontSize: "14px", fontWeight: "bold" }}>{t('workshop_info')}</Box>
        <Box marginTop="10px">
          <Typography
            style={{
              display: "inline",
              fontSize: "12px",
              fontWeight: "bold",
              color: theme.palette.primary.main,
            }}
          >
            {t('workshop')} {name}:
          </Typography>
          <Typography
            style={{ display: "inline", fontSize: "12px", color: theme.palette.primary.main }}
          >
            {" " + (current + 1)} / {sessions?.length}
          </Typography>
        </Box>
      </DialogTitle>
      <Divider />
      <DialogContent>
        <Info title={t('start')}>
          {workshopDateTime(new Date(currentSession?.startDateTimeDisplay ?? ""))}
        </Info>
        <Info title={t('end')}>
          {workshopDateTime(new Date(currentSession?.endDateTimeDisplay ?? ""))}
        </Info>
        <Info title={t('location')}>{currentSession?.location}</Info>
        <Info title={t('open_seats')}>{currentSession?.noOfSeatsAvailable}</Info>
      </DialogContent>
      <DialogActions>
        <Actions
          current={current}
          numSlides={sessions?.length ?? 0}
          onClose={() => setShow(false)}
          setPage={setSession}
        />
      </DialogActions>
    </Dialog>
  );
};
