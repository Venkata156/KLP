import { SvgIcon } from "@material-ui/core";
import React from "react";
import { Tooltip } from "components";
import { ReactComponent as CertificationAltIcon } from "assets/icons/cert_icon-certificate_icon_alt_big.svg";
import { ReactComponent as IconHome } from "assets/icons/icon-home.svg";
import { useTranslation } from "react-i18next";
import { TooltipPosition } from "@progress/kendo-react-tooltip";

type IconProps = React.ComponentProps<typeof SvgIcon>;
type IconWithContentType = IconProps & { contentType?: string, title?: string, position?: TooltipPosition, zIndex?: number };

export const BellIcon = (props: IconProps & { textColor?: string, backgroundColor?: string, borderColor?: string }): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <g id="Page-1" stroke={props?.textColor} strokeWidth="1" fill={props?.backgroundColor} fillRule="evenodd">
        <g id="menu:-main" transform="translate(-20.000000, -155.000000)">
          <g id="icon.-bell-dark" transform="translate(20.000000, 155.000000)">
            <g id="icon.-bell-copy-3" transform="translate(6.000000, 14.000000)" fill={props?.textColor}>
              <path
                d="M2,0 C2,0.55228475 1.55228475,1 1,1 C0.44771525,1 0,0.55228475 0,0 L0,0 Z"
                id="Combined-Shape"
              ></path>
            </g>
            <path
              d="M7,1.5 C8.28195286,1.5 9.56862314,1.95540163 10.4753215,2.99162834 C11.2592554,3.88755274 11.75,5.20671978 11.75,7 L11.75,7 L11.75,9.57142857 C11.75,10.0336906 12.0771433,10.5140586 12.5343619,11.0571598 C12.869859,11.4556758 13.278711,11.9082845 13.4350117,12.5 L13.4350117,12.5 L0.562562568,12.5 C0.719114534,11.8850537 1.13969727,11.4206865 1.48089623,11.0173811 C1.93315587,10.4827992 2.25,10.0145552 2.25,9.57142857 L2.25,9.57142857 L2.25,7 C2.25,5.20671978 2.74074465,3.88755274 3.5246785,2.99162834 C4.43137686,1.95540163 5.71804714,1.5 7,1.5 Z"
              id="Path-4"
              stroke={props?.textColor}
            ></path>
            <g
              id="icon.-bell-copy-3"
              transform="translate(7.500000, 1.000000) rotate(-180.000000) translate(-7.500000, -1.000000) translate(6.000000, 0.000000)"
              fill={props?.backgroundColor}
            >
              <path
                d="M3,-9.82547377e-14 L3,1 C3,1.55228475 2.55228475,2 2,2 C1.44771525,2 1,1.55228475 1,1 C1,0.798021168 0.897022873,0.157222571 1,-1.02917674e-13 L1,-1.02917674e-13 L3,-9.82547377e-14 Z"
                id="Combined-Shape"
              ></path>
            </g>
          </g>
        </g>
      </g>
    </SvgIcon>
  );
};

export const HomeIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      component={IconHome}
      {...props}
    />
  );
};

export const CloseIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g id="Desktop-HD" transform="translate(-186.000000, -203.000000)" fill={props.fill}>
          <g id="Rectangle" transform="translate(186.000000, 203.000000)">
            <rect
              transform="translate(7.495689, 7.181981) rotate(-45.000000) translate(-7.495689, -7.181981) "
              x="7.03415055"
              y="-2.31801948"
              width="1"
              height="19"
            />
            <polygon
              transform="translate(7.495689, 7.181981) rotate(-135.000000) translate(-7.495689, -7.181981) "
              points="7.03415055 -2.31801948 7.95722748 -2.31801948 7.95722748 16.6819805 7.03415055 16.6819805"
            />
          </g>
        </g>
      </g>
    </SvgIcon>
  );
};

export const UserIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <g id="Page-1" stroke={props.stroke} strokeWidth="1" fill={props.fill} fillRule="evenodd">
        <g id="Desktop-HD" transform="translate(-110.000000, -282.000000)" stroke={props.stroke}>
          <g id="Group" transform="translate(111.000000, 283.000000)">
            <circle id="Oval" cx="10" cy="7" r="7"></circle>
            <path
              d="M20,24 C20,18.4771525 15.5228475,14 10,14 C4.4771525,14 0,18.4771525 0,24"
              id="Path"
            ></path>
          </g>
        </g>
      </g>
    </SvgIcon>
  );
};

export const LogoutIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon fontSize="inherit" style={{ width: "66px", height: "76px" }} {...props} viewBox="0 0 66 76">
      <title>icon log out</title>
      <g id="ONE-OFFS" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g id="logoout" transform="translate(-767.000000, -282.000000)" strokeWidth="2">
          <g id="Group" transform="translate(768.000000, 283.000000)">
            <polyline id="Path" stroke="#949494" points="32 74 0 74 0 0 32 0"></polyline>
            <path d="M31,74 L0,74 L0,0 L31,0" id="Path" stroke="#949494" strokeDasharray="5" transform="translate(15.500000, 37.000000) scale(-1, 1) translate(-15.500000, -37.000000) "></path>
            <g id="icon.button-arrow" transform="translate(36.500000, 36.500000) rotate(-270.000000) translate(-36.500000, -36.500000) translate(18.000000, 10.000000)" stroke={props.stroke}>
              <polyline id="Rectangle-14" transform="translate(18.500000, 10.000000) rotate(-90.000000) translate(-18.500000, -10.000000) " points="8.5 -8.5 28.5 10 8.5 28.5"></polyline>
              <line x1="19" y1="1" x2="19" y2="53" id="Line-2" strokeLinecap="square"></line>
            </g>
          </g>
        </g>
      </g>
    </SvgIcon>
  );
};

export const ArrowIcon = (props: IconWithContentType): JSX.Element => {
  const { t } = useTranslation();
  return (
    <Tooltip
      title={props?.contentType ? props?.contentType : ""}
      wrapperCss={{ display: "flex" }}
      position={props.position}
      zIndex={props.zIndex}
    >
      <SvgIcon
        fontSize="inherit"
        style={{ width: `${props.width}`, height: `${props.height}` }}
        {...props}
      >
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="Desktop-HD" transform="translate(-384.000000, -199.000000)" stroke={props.stroke}>
            <g id="Group" transform="translate(385.000000, 198.000000)">
              <g
                id="icon.button-arrow"
                transform="translate(5.500000, 6.500000) rotate(-270.000000) translate(-5.500000, -6.500000) "
              >
                <polyline
                  id="Rectangle-14"
                  transform="translate(5.500000, 2.642857) rotate(-90.000000) translate(-5.500000, -2.642857) "
                  points="3 -2 8 2.64285714 3 7.28571429"
                />
                <line x1="5.5" y1="0.5" x2="5.5" y2="12.5" id="Line-2" strokeLinecap="square" />
              </g>
            </g>
          </g>
        </g>
      </SvgIcon>
    </Tooltip>
  );
};

export const LandingArrowIcon = (props: IconWithContentType): JSX.Element => {
  const { t } = useTranslation();
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
        <g id="Desktop-HD" transform="translate(-384.000000, -199.000000)" stroke={props.stroke}>
          <g id="Group" transform="translate(385.000000, 198.000000)">
            <g
              id="icon.button-arrow"
              transform="translate(5.500000, 6.500000) rotate(-270.000000) translate(-5.500000, -6.500000) "
            >
              <polyline
                id="Rectangle-14"
                transform="translate(5.500000, 2.642857) rotate(-90.000000) translate(-5.500000, -2.642857) "
                points="3 -2 8 2.64285714 3 7.28571429"
              />
              <line x1="5.5" y1="0.5" x2="5.5" y2="12.5" id="Line-2" strokeLinecap="square" />
            </g>
          </g>
        </g>
      </g>
    </SvgIcon>
  );
};
export const TimeIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 15 15" xmlns="http://www.w3.org/2000/svg">
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="Desktop-HD" transform="translate(-220.000000, -294.000000)" stroke={props.stroke}>
            <g id="Group" transform="translate(220.000000, 294.000000)">
              <circle id="Oval" cx="7.5" cy="7.5" r="7" />
              <polyline id="Path-2" points="7.5 3.24378689 7.5 7.87375247 11.5 10.2437869" />
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const EmailIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 22 14" xmlns="http://www.w3.org/2000/svg">
        <title>button email</title>
        <g id="Symbols" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g
            id="learning-record-row"
            transform="translate(-651.000000, -18.000000)"
            stroke={props.stroke}
          >
            <g id="Group" transform="translate(651.000000, 18.000000)">
              <rect id="Rectangle" x="0.5" y="0.5" width="21" height="13"></rect>
              <polyline id="Path-2" points="1 1 11 7 21 1"></polyline>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const CourseDetailsTimeIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g
            id="klp:-course-3"
            transform="translate(-1336.000000, -181.000000)"
            stroke={props.stroke || `#767676`}
          >
            <g id="clock-other" transform="translate(1336.000000, 181.000000)">
              <circle id="Oval" fill="#FFFFFF" cx="16" cy="16" r="15.5"></circle>
              <polyline id="Path-2" points="16 4.94291336 16 16 25.3632386 21.6600153"></polyline>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const CourseIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 43 41" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="Desktop-HD" transform="translate(-200.000000, -629.000000)" stroke={props.stroke}>
            <g id="Group-6" transform="translate(201.000000, 630.000000)">
              <polyline id="Path" points="36.2166667 8 41 8 41 39 0 39 0 8 4.78333333 8" />
              <polyline
                id="Path"
                points="31.3088192 4.2571899 36 3 36 34.8461538 20.5 39 5 34.8461538 5 3 9.75156933 4.27337342"
              />
              <polygon
                id="Rectangle"
                points="10 0 20.5 6.78571429 31 0 31 31.2142857 20.5 38 10 31.2142857"
              />
              <line x1="20.5" y1="7" x2="20.5" y2="39" id="Path-3" />
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const SaveToListIcon = (props: IconWithContentType): JSX.Element => {
  const { t } = useTranslation();
  return (
    <Tooltip
      title={
        props?.contentType
          ? t("add_content_type_to_playlist", { contentType: t(props?.contentType) })
          : ""
      }
      wrapperCss={{ display: "flex" }}
    >
      <SvgIcon
        fontSize="inherit"
        style={{ width: `${props.width}`, height: `${props.height}` }}
        {...props}
      >
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="Desktop-HD" transform="translate(-100.000000, -649.000000)" fill={props.fill}>
            <g id="Group-3" transform="translate(100.000000, 649.000000)">
              <rect id="Rectangle" x="0" y="0" width="14" height="1" />
              <rect id="Rectangle-Copy" x="0" y="5" width="14" height="1" />
              <rect id="Rectangle-Copy-2" x="0" y="10" width="6" height="1" />
              <rect id="Rectangle-Copy-2" x="9" y="10" width="5" height="1" />
              <rect id="Rectangle" x="11" y="8" width="1" height="5" />
            </g>
          </g>
        </g>
      </SvgIcon>
    </Tooltip>
  );
};

export const ShareIcon = (props: IconProps & { itemName: string }): JSX.Element => {
  const { t } = useTranslation();
  return (
    <Tooltip
      title={props?.itemName && `${t("share")} ${props?.itemName}`}
      wrapperCss={{ display: "flex" }}
    >
      <SvgIcon
        fontSize="inherit"
        style={{ width: `${props.width}`, height: `${props.height}` }}
        {...props}
      >
        <g id="Page-1" stroke={props.stroke} strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="Desktop-HD" transform="translate(-146.000000, -650.000000)">
            <g id="Group-2" transform="translate(146.000000, 650.000000)">
              <rect id="Rectangle" fill="#000000" x="0" y="0" width="14" height="1" />
              <g id="Group" transform="translate(2.000000, 3.000000)" stroke={props.stroke}>
                <polyline
                  id="Rectangle-14"
                  transform="translate(5.500000, 2.642857) rotate(-90.000000) translate(-5.500000, -2.642857) "
                  points="3 -2 8 2.64285714 3 7.28571429"
                />
                <line x1="5.5" y1="0.5" x2="5.5" y2="9.5" id="Line-2" strokeLinecap="square" />
              </g>
            </g>
          </g>
        </g>
      </SvgIcon>
    </Tooltip>
  );
};

export const ChannelIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="Desktop-HD" transform="translate(-331.000000, -629.000000)" stroke={props.stroke}>
            <g id="Group-7" transform="translate(331.851852, 630.000000)">
              <circle id="Oval" cx="20.3148148" cy="20.1666667" r="5" />
              <line x1="20.1481481" y1="0" x2="20.1481481" y2="11.8518519" id="Path-7" />
              <polyline
                id="Path-9"
                points="16.1481481 3.7037037 20.1481481 0 24.1481481 3.7037037"
              />
              <line
                x1="20.1481481"
                y1="28.1481481"
                x2="20.1481481"
                y2="40"
                id="Path-7"
                transform="translate(20.148148, 34.074074) rotate(-180.000000) translate(-20.148148, -34.074074) "
              />
              <polyline
                id="Path-9"
                transform="translate(20.148148, 38.148148) rotate(-180.000000) translate(-20.148148, -38.148148) "
                points="16.1481481 40 20.1481481 36.2962963 24.1481481 40"
              />
              <line
                x1="30.1000214"
                y1="4.12220086"
                x2="30.1000214"
                y2="15.9740527"
                id="Path-7"
                transform="translate(30.100021, 10.048127) rotate(-315.000000) translate(-30.100021, -10.048127) "
              />
              <polyline
                id="Path-9"
                transform="translate(32.980827, 7.167321) rotate(-315.000000) translate(-32.980827, -7.167321) "
                points="29.2771231 9.01917323 32.9808268 5.31546953 36.6845305 9.01917323"
              />
              <line
                x1="10.1962749"
                y1="24.0259473"
                x2="10.1962749"
                y2="35.8777991"
                id="Path-7"
                transform="translate(10.196275, 29.951873) rotate(-495.000000) translate(-10.196275, -29.951873) "
              />
              <polyline
                id="Path-9"
                transform="translate(7.315470, 32.832679) rotate(-495.000000) translate(-7.315470, -32.832679) "
                points="3.61176582 34.6845305 7.31546953 30.9808268 11.0191732 34.6845305"
              />
              <line
                x1="34.2222222"
                y1="14.0740741"
                x2="34.2222222"
                y2="25.9259259"
                id="Path-7"
                transform="translate(34.222222, 20.000000) rotate(-270.000000) translate(-34.222222, -20.000000) "
              />
              <polyline
                id="Path-9"
                transform="translate(38.296296, 20.000000) rotate(-270.000000) translate(-38.296296, -20.000000) "
                points="34.2962963 21.8518519 38.2962963 18.1481481 42.2962963 21.8518519"
              />
              <line
                x1="6.07407407"
                y1="14.0740741"
                x2="6.07407407"
                y2="25.9259259"
                id="Path-7"
                transform="translate(6.074074, 20.000000) rotate(-450.000000) translate(-6.074074, -20.000000) "
              />
              <polyline
                id="Path-9"
                transform="translate(2.000000, 20.000000) rotate(-450.000000) translate(-2.000000, -20.000000) "
                points="-2 21.8518519 2 18.1481481 6 21.8518519"
              />
              <line
                x1="30.1000214"
                y1="24.0259473"
                x2="30.1000214"
                y2="35.8777991"
                id="Path-7"
                transform="translate(30.100021, 29.951873) rotate(-225.000000) translate(-30.100021, -29.951873) "
              />
              <polyline
                id="Path-9"
                transform="translate(32.980827, 32.832679) rotate(-225.000000) translate(-32.980827, -32.832679) "
                points="29.2771231 34.6845305 32.9808268 30.9808268 36.6845305 34.6845305"
              />
              <line
                x1="10.1962749"
                y1="4.12220086"
                x2="10.1962749"
                y2="15.9740527"
                id="Path-7"
                transform="translate(10.196275, 10.048127) rotate(-405.000000) translate(-10.196275, -10.048127) "
              />
              <polyline
                id="Path-9"
                transform="translate(7.315470, 7.167321) rotate(-405.000000) translate(-7.315470, -7.167321) "
                points="3.61176582 9.01917323 7.31546953 5.31546953 11.0191732 9.01917323"
              />
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const PlayListIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 24 21" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="Desktop-HD" transform="translate(-484.000000, -648.000000)" stroke={props.stroke}>
            <g id="Group-16" transform="translate(484.000000, 648.000000)">
              <circle id="Oval" cx="2.5" cy="2.5" r="2" />
              <circle id="Oval-Copy-7" cx="2.5" cy="10.5" r="2" />
              <circle id="Oval-Copy-7" cx="2.5" cy="18.5" r="2" />
              <rect id="Rectangle" x="9.5" y="1.5" width="14" height="2" />
              <rect id="Rectangle" x="9.5" y="9.5" width="14" height="2" />
              <rect id="Rectangle" x="9.5" y="17.5" width="14" height="2" />
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const ParentPathwayIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" >
        <g id="Future" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
          <g id="leap:-landing:-v4" transform="translate(-65.000000, -820.000000)" stroke={props.stroke}>
            <g id="icon-collection" transform="translate(65.000000, 820.000000)">
              <circle id="Oval" cx="12" cy="12" r="11.5"/>
              <circle id="Oval-Copy-3" cx="6.5" cy="10.5" r="2"/>
              <circle id="Oval-Copy-7" cx="12" cy="6" r="2.5"/>
              <circle id="Oval-Copy-4" cx="17.5" cy="11.5" r="3"/>
              <circle id="Oval-Copy-6" cx="11" cy="17" r="3.5"/>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const PathwayIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 51 43" xmlns="http://www.w3.org/2000/svg">
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="Desktop-HD" transform="translate(-397.000000, -627.000000)" stroke={props.stroke}>
            <g id="Group-15" transform="translate(397.000000, 627.000000)">
              <path
                d="M9,41.9390582 C19.6533776,42.3047091 26.7009967,41.0249307 30.1428571,38.099723 C35.3056478,33.7119114 23.7262458,29.3240997 28.0285714,24.9362881 C30.8967885,22.0110803 36.8872647,20.365651 46,20"
                id="Path-10"
                strokeDasharray="3"
              />
              <path
                d="M44,0.5 C45.7981441,0.5 47.4271289,1.18861388 48.6058751,2.30532085 C49.7745715,3.41250685 50.5,4.94134384 50.5,6.63157895 C50.5,9.96775013 48.729627,11.8818822 44.5317931,16.6403502 C44.3586551,16.8366113 44.181407,17.0375315 43.9999478,17.2433251 C43.8185566,17.0374903 43.6413271,16.8365912 43.4682069,16.6403502 C39.270373,11.8818822 37.5,9.96775013 37.5,6.63157895 C37.5,4.94134384 38.2254285,3.41250685 39.3941249,2.30532085 C40.5728711,1.18861388 42.2018559,0.5 44,0.5 Z"
                id="Oval"
              />
              <path
                d="M9.5,12.5 C11.9848112,12.5 14.2341951,13.5158585 15.8625011,15.1576961 C17.4922986,16.8010376 18.5,19.0713889 18.5,21.5789474 C18.5,26.442723 16.105228,29.2459734 10.3456253,36.1947717 C10.0713682,36.5256551 9.78951076,36.8657083 9.49990753,37.2153844 C9.21039025,36.8655888 8.92858365,36.525597 8.65437472,36.1947717 C2.89477203,29.2459734 0.5,26.442723 0.5,21.5789474 C0.5,19.0713889 1.50770143,16.8010376 3.13749891,15.1576961 C4.76580493,13.5158585 7.01518881,12.5 9.5,12.5 Z"
                id="Oval-Copy-5"
              />
              <circle id="Oval" cx="44" cy="7" r="2.5" />
              <circle id="Oval-Copy-6" cx="9.5" cy="21.5" r="4" />
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const CertificationIcon = (props: IconWithContentType): JSX.Element => {
  const { t } = useTranslation();
  return (
    <SvgIcon title={t('certified')}
      aria-hidden="false"
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      {(props?.contentType == "course" || props?.contentType == "pathway") && (
        <svg viewBox="0 0 32 42" version="1.1" xmlns="http://www.w3.org/2000/svg">
          <title>3FF7A892-F6FC-41D5-88EF-D666ACB91210</title>
          <g id="Page-1" stroke="none">
            <g id="course-1-details" transform="translate(-271.000000, -210.000000)" stroke="black">
              <g id="cert-icon" transform="translate(271.854545, 211.000000)">
                <g id="Group" fill="white">
                  <polygon
                    id="Rectangle"
                    points="7.15775493 18 18.7636364 20.1266285 12.5440632 36 7.6740585 32.55568 0.938181818 33.8733715"
                  ></polygon>
                  <polygon
                    id="Rectangle-Copy"
                    transform="translate(19.232727, 27.000000) scale(-1, 1) translate(-19.232727, -27.000000) "
                    points="16.5395731 18 28.1454545 20.1266285 21.9258814 36 17.0558767 32.55568 10.32 33.8733715"
                  ></polygon>
                  <polygon
                    id="Star"
                    points="14.0727273 26.3212597 11.8712677 28.2460975 10.366595 25.7285182 7.68384279 26.872198 7.02324478 24.0083154 4.12180639 24.2588858 4.36994702 21.3290368 1.53383546 20.6619703 2.666425 17.9529487 0.173258625 16.4335424 2.07943131 14.2105263 0.173258625 11.9875102 2.666425 10.4681039 1.53383546 7.75908237 4.36994702 7.09201584 4.12180639 4.16216679 7.02324478 4.4127372 7.68384279 1.54885466 10.366595 2.69253442 11.8712677 0.17495516 14.0727273 2.09979294 16.2741868 0.17495516 17.7788595 2.69253442 20.4616118 1.54885466 21.1222098 4.4127372 24.0236482 4.16216679 23.7755075 7.09201584 26.6116191 7.75908237 25.4790295 10.4681039 27.9721959 11.9875102 26.0660232 14.2105263 27.9721959 16.4335424 25.4790295 17.9529487 26.6116191 20.6619703 23.7755075 21.3290368 24.0236482 24.2588858 21.1222098 24.0083154 20.4616118 26.872198 17.7788595 25.7285182 16.2741868 28.2460975"
                  ></polygon>
                </g>
              </g>
            </g>
          </g>
        </svg>
      )}
      {props?.contentType != "course" && props?.contentType != "pathway" && (
        <svg width="22px" height="27px" viewBox="0 0 22 27" version="1.1" xmlns="http://www.w3.org/2000/svg">
          <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
            <g id="gfr-au:-landing" transform="translate(-435.000000, -281.000000)">
              <g id="cert-icon" transform="translate(436.000000, 282.000000)">
                <g id="Group" fill="#FFFFFF">
                  <polygon id="Rectangle" stroke="#474747" points="4.86482025 12.195122 12.804878 13.6359272 8.5498139 24.3902439 5.21804462 22.0566938 0.609756098 22.9494387"></polygon>
                  <polygon id="Rectangle-Copy" stroke="#474747" transform="translate(13.125802, 18.292683) scale(-1, 1) translate(-13.125802, -18.292683) " points="11.2833055 12.195122 19.2233633 13.6359272 14.9682991 24.3902439 11.6365299 22.0566938 7.02824134 22.9494387"></polygon>
                  <polygon id="Star" stroke="#333333" points="9.75609756 18.0706029 8.22990766 19.3920814 7.18677412 17.663662 5.32692195 18.4488441 4.86895397 16.4826736 2.85749482 16.6547003 3.02952147 14.6432412 1.06335098 14.1852732 1.84853312 12.325421 0.12011375 11.2822875 1.44159226 9.75609756 0.12011375 8.22990766 1.84853312 7.18677412 1.06335098 5.32692195 3.02952147 4.86895397 2.85749482 2.85749482 4.86895397 3.02952147 5.32692195 1.06335098 7.18677412 1.84853312 8.22990766 0.12011375 9.75609756 1.44159226 11.2822875 0.12011375 12.325421 1.84853312 14.1852732 1.06335098 14.6432412 3.02952147 16.6547003 2.85749482 16.4826736 4.86895397 18.4488441 5.32692195 17.663662 7.18677412 19.3920814 8.22990766 18.0706029 9.75609756 19.3920814 11.2822875 17.663662 12.325421 18.4488441 14.1852732 16.4826736 14.6432412 16.6547003 16.6547003 14.6432412 16.4826736 14.1852732 18.4488441 12.325421 17.663662 11.2822875 19.3920814"></polygon>
                </g>
                <circle id="Oval" stroke="#474747" cx="9.75609756" cy="9.75609756" r="4.37804878"></circle>
              </g>
            </g>
          </g>
        </svg>
      )}
    </SvgIcon>
  );
};

export const CertificationIconAlt = (props: IconProps): JSX.Element => {
  const { t } = useTranslation();
  return (
    <SvgIcon
      title={t('certified')}
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      viewBox="0 0 30 38"
      component={CertificationAltIcon}
      {...props}
    />
  );
};

export const CalendarIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 13 13" xmlns="http://www.w3.org/2000/svg">
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g
            id="pop:-admin:-course-session:-wizard-21a"
            transform="translate(-959.000000, -324.000000)"
          >
            <g id="Group-3" transform="translate(690.000000, 125.000000)">
              <g id="Group" transform="translate(172.000000, 159.500000)">
                <g transform="translate(97.000000, 39.500000)">
                  <rect
                    id="Rectangle"
                    stroke={props.fill || `#0091DA`}
                    x="0.5"
                    y="2.5"
                    width="12"
                    height="10"
                  ></rect>
                  <rect id="Rectangle" fill={props.fill || `#0091DA`} x="2" y="0" width="1" height="4"></rect>
                  <rect id="Rectangle-Copy" fill={props.fill || `#0091DA`} x="10" y="0" width="1" height="4"></rect>
                  <rect id="Rectangle" fill={props.fill || `#0091DA`} x="0" y="5" width="13" height="1"></rect>
                  <rect id="Rectangle" fill={props.fill || `#0091DA`} x="9" y="9" width="2" height="2"></rect>
                </g>
              </g>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const CheckIcon = (props: IconProps): JSX.Element => {
  const { t } = useTranslation();
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 26 16" xmlns="http://www.w3.org/2000/svg">
        <title>{t("check_enrollment")}</title>
        <g
          id="Symbols"
          stroke="none"
          strokeWidth="1"
          fill="none"
          fillRule="evenodd"
          strokeLinecap="round"
        >
          <g
            id="pathway-course-listing-for-pop"
            transform="translate(-405.000000, -18.000000)"
            stroke="#C6007E"
          >
            <g id="check-enrollment" transform="translate(406.000000, 18.000000)">
              <polyline id="Path-5" points="0 7.58226838 8.27372346 16 24 0"></polyline>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const FilledCheckboxIcon = (props: IconProps): JSX.Element => {
  const { t } = useTranslation();
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
        <title>{t("checkbox_checked")}</title>
        <g id="Page-1" stroke="none" fill="none">
          <g
            id="pop:-add-pathway:-course-1:-w2"
            transform="translate(-720.000000, -617.000000)"
            fill="#0091DA"
          >
            <g id="Rectangle" transform="translate(720.000000, 617.000000)">
              <rect x="0" y="0" width="14" height="14" rx="2"></rect>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};
export const CustomCheckBoxIcon = (props: IconProps): JSX.Element => {
  const { t } = useTranslation();
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 14 14" xmlns="http://www.w3.org/2000/svg">
        <title>{t("checkbox_checked")}</title>
        <g id="Page-1" stroke="none" fill="none">
          <g
            id="pop:-add-pathway:-course-1:-w2"
            transform="translate(-720.000000, -617.000000)"
            stroke="#979797"
          >
            <g id="Rectangle" transform="translate(720.000000, 617.000000)">
              <rect x="0.5" y="0.5" width="13" height="13" rx="2"></rect>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const CheckmarkCircleIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}` || `100px`, height: `${props.height}` || `100px` }}
      {...props}
    >
      <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg">
        <title>6D43D75F-CE2A-4DB0-8DD7-A9DB2C936B9A</title>
        <g id="Future" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="admin:-activity-complete-confirm:-finish" transform="translate(-750.000000, -182.000000)" stroke={props.stroke || "#43B02A"}>
            <g id="Group-2" transform="translate(750.000000, 182.000000)">
              <circle id="Oval" cx="50" cy="50" r="49.5"></circle>
              <g id="check-fat" transform="translate(24.500000, 33.000000)" strokeLinecap="round" strokeWidth="2">
                <polyline id="Path-5" points="0 16.1123203 17.5816624 34 51 0"></polyline>
              </g>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const RequiredLearningIconLanding = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg
        viewBox="0 0 21 33"
      >
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="Desktop-HD" transform="translate(-459.000000, -196.000000)" stroke={props.htmlColor}>
            <polygon
              id="Path"
              points="477.538462 197 465.846154 197 460 215.909091 467.307692 215.909091 462.923077 229 479 210.090909 470.230769 210.090909"
            ></polygon>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const CourseCompletionIconLanding = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg
        viewBox="0 0 43 41"
      >
        <g id="Page-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="Desktop-HD" transform="translate(-200.000000, -629.000000)" stroke={props.htmlColor}>
            <g id="Group-6" transform="translate(201.000000, 630.000000)">
              <polyline id="Path" points="36.2166667 8 41 8 41 39 0 39 0 8 4.78333333 8"></polyline>
              <polyline
                id="Path"
                points="31.3088192 4.2571899 36 3 36 34.8461538 20.5 39 5 34.8461538 5 3 9.75156933 4.27337342"
              ></polyline>
              <polygon
                id="Rectangle"
                points="10 0 20.5 6.78571429 31 0 31 31.2142857 20.5 38 10 31.2142857"
              ></polygon>
              <line x1="20.5" y1="7" x2="20.5" y2="39" id="Path-3"></line>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const CourseRequiredIconLanding = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      fontSize="inherit"
      style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg viewBox="0 0 32 42">
        <g id="Page-1" stroke="white" strokeWidth="1" fill="none" fillRule="evenodd">
          <g
            id="Desktop-HD"
            transform="translate(-273.000000, -629.000000)"
            stroke={props.htmlColor}
          >
            <g id="Group" transform="translate(274.000000, 630.000000)">
              <polygon
                id="Rectangle"
                fill="none"
                points="6.28047469 19 18 21.4810666 11.7195253 40 6.80183386 35.9816267 4.99600361e-16 37.5189334"
              ></polygon>
              <polygon
                id="Rectangle-Copy"
                fill="none"
                transform="translate(21.000000, 29.500000) scale(-1, 1) translate(-21.000000, -29.500000) "
                points="18.2804747 19 30 21.4810666 23.7195253 40 18.8018339 35.9816267 12 37.5189334"
              ></polygon>
              <polygon
                id="Star"
                fill="none"
                points="15 27.7835519 12.653483 29.8153251 11.0496652 27.1578803 8.1901425 28.3650979 7.48601672 25.3421107 4.39339828 25.6066017 4.65788927 22.5139833 1.63490214 21.8098575 2.84211967 18.9503348 0.184674891 17.346517 2.2164481 15 0.184674891 12.653483 2.84211967 11.0496652 1.63490214 8.1901425 4.65788927 7.48601672 4.39339828 4.39339828 7.48601672 4.65788927 8.1901425 1.63490214 11.0496652 2.84211967 12.653483 0.184674891 15 2.2164481 17.346517 0.184674891 18.9503348 2.84211967 21.8098575 1.63490214 22.5139833 4.65788927 25.6066017 4.39339828 25.3421107 7.48601672 28.3650979 8.1901425 27.1578803 11.0496652 29.8153251 12.653483 27.7835519 15 29.8153251 17.346517 27.1578803 18.9503348 28.3650979 21.8098575 25.3421107 22.5139833 25.6066017 25.6066017 22.5139833 25.3421107 21.8098575 28.3650979 18.9503348 27.1578803 17.346517 29.8153251"
              ></polygon>
              <circle id="Oval" cx="15" cy="15" r="7.5"></circle>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};

export const AvailableSkillIcon = (props: IconProps): JSX.Element => {
  return (
    <SvgIcon
      viewBox="0 0 62 62"
      // style={{ width: `${props.width}`, height: `${props.height}` }}
      {...props}
    >
      <svg xmlns="http://www.w3.org/2000/svg" width="62px" height="62px" viewBox="0 0 62 62" version="1.1">
        <title>85799B84-BE3E-492F-A01B-2F22A16D4629</title>
        <defs>
          <linearGradient x1="92.0707967%" y1="30.3265104%" x2="11.1805078%" y2="71.50965%" id="linearGradient-1">
            <stop stopColor="#E5A72C" offset="0%" />
            <stop stopColor="#A158A1" offset="100%" />
          </linearGradient>
          <path d="M12.7109199,0 C12.710191,0 12.7094622,0.000428126992 12.7090249,0 L12.7090249,0 C12.4029063,0.00770628586 12.0967876,0.0154125717 11.7908148,0.0229761486 L11.7908148,0.0229761486 C11.4858623,0.0362480853 11.1809099,0.0496627311 10.8759574,0.0629346678 L10.8759574,0.0629346678 C10.8003024,0.0655034298 10.722315,0.0723534616 10.6457854,0.0783472395 L10.6457854,0.0783472395 C10.5761069,0.0870524884 10.50672,0.0954723192 10.4371874,0.104034859 L10.4371874,0.104034859 L10.180485,0.136144383 C10.0097875,0.160547622 9.84040183,0.193656109 9.67043311,0.222340618 L9.67043311,0.222340618 C8.99303632,0.353918313 8.32890468,0.550999439 7.69115754,0.80987356 L7.69115754,0.80987356 C6.41508019,1.32719368 5.24701899,2.09354099 4.27166674,3.04826418 L4.27166674,3.04826418 C3.2963145,4.00327279 2.51367122,5.14665728 1.98525216,6.39621726 L1.98525216,6.39621726 C1.45493809,7.64463557 1.18336714,8.99794499 1.1830756,10.346545 L1.1830756,10.346545 C1.1830756,10.347544 1.1830756,10.3485429 1.18292983,10.3496846 L1.18292983,10.3496846 L1.18292983,28.6325624 C0.789348738,29.0869478 0.39576765,29.5410479 0.00204079083,29.995576 L0.00204079083,29.995576 L0,29.9980021 L0.00233233237,29.9980021 L2.51731549,29.9980021 L2.6977797,29.9994292 C2.70710903,30 2.71658413,30 2.726205,30 L2.726205,30 L2.73363931,30 C2.75550493,30 2.77824517,29.9992865 2.80127695,29.9980021 L2.80127695,29.9980021 L9.47874454,29.9980021 L9.4819515,29.9980021 C11.1411144,29.9988583 12.799257,29.6085492 14.2762065,28.8686031 L14.2762065,28.8686031 C15.0149727,28.4992722 15.7088416,28.0441732 16.3390087,27.5158645 L16.3390087,27.5158645 C16.4925053,27.379292 16.6458562,27.2428622 16.7993528,27.1062897 L16.7993528,27.1062897 C16.9443947,26.9611546 17.0892908,26.8158769 17.2343328,26.6708845 L17.2343328,26.6708845 C17.3703369,26.517615 17.5060495,26.3644883 17.6421994,26.2115042 L17.6421994,26.2115042 C17.7623145,26.0588056 17.8824296,25.9063924 18.0026905,25.7539792 L18.0026905,25.7539792 C18.0032736,25.7532657 18.0040024,25.7524094 18.0044398,25.7518386 L18.0044398,25.7518386 C19.4319729,24.0580255 20.8590688,22.3646405 22.2864562,20.6708274 L22.2864562,20.6708274 C25.814692,20.6404304 29.3426363,20.6098907 32.8707263,20.5794937 L32.8707263,20.5794937 C32.8606681,20.6566992 32.8504642,20.7339048 32.8405518,20.8109677 L32.8405518,20.8109677 C32.8202896,20.9473975 32.7918643,21.0825429 32.768541,21.2184018 L32.768541,21.2184018 C32.6590672,21.7591262 32.495075,22.288862 32.2794801,22.797905 L32.2794801,22.797905 C31.8485817,23.8162764 31.2093768,24.7508777 30.4120107,25.5314959 L30.4120107,25.5314959 C29.6142072,26.3122568 28.659846,26.937893 27.61948,27.3594554 L27.61948,27.3594554 C26.5794055,27.7824449 25.4550755,27.9995053 24.3254978,28.0000761 L24.3254978,28.0000761 L24.3227282,28.0000761 L19.190285,28.0000761 L19.190285,28.4995576 L19.190285,28.9990391 L19.190285,29.4985206 L19.190285,29.9980021 L24.3227282,29.9980021 L24.3257893,29.9980021 C25.7171714,29.9978594 27.1132181,29.729281 28.4012486,29.2051109 L28.4012486,29.2051109 C29.6901538,28.6826532 30.8697309,27.9085996 31.8548498,26.9444577 L31.8548498,26.9444577 C32.8399687,25.9800303 33.6306294,24.825229 34.1644419,23.5633961 L34.1644419,23.5633961 C34.4316398,22.9329077 34.6348442,22.2761609 34.770411,21.6065703 L34.770411,21.6065703 C34.8001483,21.4384591 34.8345502,21.2710615 34.8596227,21.1023794 L34.8596227,21.1023794 C34.8705556,21.017753 34.8816341,20.9329839 34.8925669,20.8485001 L34.8925669,20.8485001 C34.901459,20.7805706 34.9100594,20.7129266 34.9188057,20.6451398 L34.9188057,20.6451398 C34.9253654,20.569504 34.9323624,20.4921558 34.9348405,20.4173762 L34.9348405,20.4173762 C34.9486887,20.115404 34.9625369,19.8137172 34.9765309,19.5118877 L34.9765309,19.5118877 C34.9842568,19.2089165 34.9921284,18.906088 35,18.6031168 L35,18.6031168 C34.9995627,18.601547 35.0005831,18.5988355 34.9992711,18.5981219 L34.9992711,18.5981219 C34.6074393,18.5901302 34.2236249,18.5748604 33.8250876,18.5731479 L33.8250876,18.5731479 C33.4609522,18.5761448 33.0968168,18.5794271 32.7326814,18.5825667 L32.7326814,18.5825667 L31.5201601,18.5929844 L29.0954091,18.6139626 C27.4788112,18.6279481 25.8623591,18.6419336 24.2457612,18.6557764 L24.2457612,18.6557764 C24.158153,18.6566326 24.070399,18.6573462 23.9827907,18.6580597 L23.9827907,18.6580597 C26.5853821,15.569837 29.1884108,12.4811862 31.7910022,9.39282079 L31.7910022,9.39282079 L31.7920226,9.39182182 L31.7876495,9.39182182 L22.5478232,9.39182182 L22.5446163,9.39182182 C21.0033819,9.39125099 19.4627306,9.72747338 18.0675585,10.3693785 L18.0675585,10.3693785 C16.6722407,11.0091429 15.4221105,11.9558744 14.4390324,13.1145287 L14.4390324,13.1145287 C14.4384493,13.1150996 14.4378662,13.1159558 14.4371374,13.1166694 L14.4371374,13.1166694 C13.8744622,13.7754141 13.311787,14.4344442 12.7491118,15.093189 L12.7491118,15.093189 L12.7491118,10.3842202 L12.7491118,5.70407862 L12.7491118,3.36407919 L12.7491118,2.19400812 L12.7491118,1.13425111 C12.7434268,0.75007849 12.7249139,0.379320515 12.713398,0.00142708997 L12.713398,0.00142708997 C12.7135438,0 12.7131065,0 12.7123776,0 L12.7123776,0 C12.7119403,0 12.7113572,0 12.7109199,0 L12.7109199,0 Z M3.30188679,10.2110667 C3.30216975,10.210069 3.30216975,10.2092139 3.30216975,10.2083589 L3.30216975,10.2083589 C3.30273566,9.11739647 3.51523453,8.03170718 3.92948001,7.0272522 L3.92948001,7.0272522 C4.34231071,6.0226547 4.95504881,5.10085918 5.71959203,4.33041599 L5.71959203,4.33041599 C6.48427673,3.56040034 7.39935178,2.94316218 8.39662512,2.52715706 L8.39662512,2.52715706 C8.89504958,2.31894073 9.41398824,2.16046258 9.94339623,2.05471548 L9.94339623,2.05471548 C10.0763849,2.03234042 10.2086661,2.00469225 10.3422207,1.98531003 L10.3422207,1.98531003 C10.4169207,1.97561893 10.4913377,1.96607033 10.5660377,1.95652174 L10.5660377,1.95652174 L10.5660377,17.3347446 C9.66680814,18.4181537 8.76772003,19.5014202 7.86849044,20.5848292 L7.86849044,20.5848292 C6.815758,21.8532244 5.76302556,23.1217621 4.71029312,24.3900148 L4.71029312,24.3900148 L3.30188679,26.0869565 L3.30188679,10.2110667 Z M15.7617194,14.2169754 C15.7624391,14.2162325 15.7630149,14.215341 15.7634467,14.2147467 L15.7634467,14.2147467 C16.5499196,13.2375259 17.5425105,12.4460321 18.6548573,11.9078697 L18.6548573,11.9078697 C19.7661964,11.3688159 20.9922536,11.0866596 22.2200379,11.0869565 L22.2200379,11.0869565 L22.2226288,11.0869565 L27.0754717,11.0869565 C25.053154,13.6175975 23.0309801,16.1479411 21.0085185,18.6784332 L21.0085185,18.6784332 C18.7796508,18.6987889 16.5507832,18.7191446 14.3217716,18.7395002 L14.3217716,18.7395002 L14.3188929,18.7395002 C13.724864,18.7447006 13.1315549,18.8030931 12.5471698,18.9130435 L12.5471698,18.9130435 L12.5471698,18.1857369 C13.6187823,16.8627668 14.6901069,15.540094 15.7617194,14.2169754 L15.7617194,14.2169754 Z M14.6842791,20.9124439 C14.6850175,20.9124439 14.6860513,20.9124439 14.687085,20.9124439 L14.687085,20.9124439 C16.3953113,20.898151 18.1032422,20.8838581 19.8113208,20.8695652 L19.8113208,20.8695652 C18.7196627,22.1249578 17.6283001,23.3803503 16.5367897,24.635883 L16.5367897,24.635883 C16.5360513,24.6365836 16.5356082,24.6372842 16.5347222,24.6378447 L16.5347222,24.6378447 C16.4251429,24.7734871 16.3152682,24.9089893 16.2052458,25.0444916 L16.2052458,25.0444916 C16.094042,25.1659812 15.9829859,25.2874708 15.8716344,25.4088202 L15.8716344,25.4088202 C15.7531943,25.5237239 15.6349018,25.6386276 15.5164616,25.7536714 L15.5164616,25.7536714 C15.3910804,25.8617088 15.2656992,25.9697463 15.1403181,26.0779239 L15.1403181,26.0779239 C14.6256497,26.4960611 14.0585547,26.8564662 13.4549824,27.1491903 L13.4549824,27.1491903 C12.2476901,27.735199 10.8938983,28.0441777 9.53774354,28.0434783 L9.53774354,28.0434783 L9.53478992,28.0434783 L8.58490566,28.0434783 C9.05896171,27.7026896 9.50215242,27.3243483 9.90901361,26.9144786 L9.90901361,26.9144786 C10.8351212,25.9823577 11.5742647,24.8860086 12.0777093,23.6964755 L12.0777093,23.6964755 C12.4253504,22.876736 12.6589817,22.0122961 12.7712193,21.1335634 L12.7712193,21.1335634 C13.3975344,20.9924561 14.0403899,20.9176286 14.6842791,20.9124439 L14.6842791,20.9124439 Z M8.17605541,24.0685556 C8.17650519,24.0678443 8.17740475,24.067133 8.17800446,24.0664218 L8.17800446,24.0664218 C8.84997615,23.3033868 9.66078002,22.6625456 10.5660377,22.173913 L10.5660377,22.173913 C10.4726334,22.5131819 10.3565901,22.8471875 10.2183576,23.1730848 L10.2183576,23.1730848 C9.80590911,24.1485007 9.19720651,25.051084 8.43692796,25.8162527 L8.43692796,25.8162527 C7.67724912,26.5817059 6.76599433,27.2090333 5.76583298,27.6421879 L5.76583298,27.6421879 C5.51590509,27.7511522 5.2604299,27.8466027 5.00075677,27.9308154 L5.00075677,27.9308154 C4.87436852,27.9672317 4.75052903,28.0124675 4.62264151,28.0434783 L4.62264151,28.0434783 C5.80721276,26.7185514 6.99163409,25.3934824 8.17605541,24.0685556 L8.17605541,24.0685556 Z" id="path-2" />
          <linearGradient x1="92.0707967%" y1="30.3265104%" x2="11.1805078%" y2="71.50965%" id="linearGradient-3">
            <stop stopColor="#D8D8D8" offset="0%" />
            <stop stopColor="#D8D8D8" offset="100%" />
          </linearGradient>
        </defs>
        <g id="Future" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
          <g id="leap:-profile:-skills-alt-2" transform="translate(-289.000000, -795.000000)">
            <g id="skill-card" transform="translate(240.000000, 775.000000)">
              <g id="Group" transform="translate(50.000000, 21.000000)">
                <circle id="Oval-Copy" stroke="#F5F5F5" strokeWidth="2" cx="30" cy="30" r="30" />
                <g id="Group-3" transform="translate(13.000000, 15.000000)">
                  <mask id="mask-4" fill="white">
                    <use xlinkHref="#path-2" />
                  </mask>
                  <use id="Clip-2" fill="url(#linearGradient-3)" xlinkHref="#path-2" />
                </g>
              </g>
            </g>
          </g>
        </g>
      </svg>
    </SvgIcon>
  );
};
