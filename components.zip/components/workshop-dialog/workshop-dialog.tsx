import {
  Box,
  Typography,
  withStyles,
  useTheme,
  DialogContent as MuiDialogContent,
  DialogActions as MuiDialogActions,
} from "@material-ui/core";
import { Select, Action, Dialog } from "components";
import { useMediaQuery } from "@material-ui/core";
import { useEffect , useLayoutEffect} from "react";
import { useTranslation } from "react-i18next";

const DialogContent = withStyles(() => ({
  root: {
    overflow: "hidden",
    padding: "0px 25px",
  },
}))(MuiDialogContent);

const TypographyLbl = withStyles(() => ({
  root: {
    fontSize: "11px",
    color: useTheme().palette.grey["500"],
    margin: "18px 0px 5px 0px",
  },
}))(Typography);

const SelectBox = withStyles(() => ({
  root: {
    display: "flex",
    "& .MuiButtonBase-root": {
      width: 212,
      padding: "5px 11px",
      height: "40px",
    },
    "& .MuiButton-label": {
      justifyContent: "space-between",
      fontSize: "12px",
    },
  },
}))(Box);

const DialogActions = withStyles(() => ({
  root: {
    display: "flex",
    padding: "20px 25px 30px 25px",
  },
}))(MuiDialogActions);
export const WorkshopDialog = ({
  open,
  handleClose,
  data,
  handleLocationSelection,
  handleDateSelection,
  selectedWorkshopDate,
  selectedWorkshopLocation,
  handleExpressInterest
}: any): JSX.Element => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const isSmallScreen = useMediaQuery(theme.breakpoints.down("xs"));
  const { t } = useTranslation();

  useLayoutEffect(() => {
    setTimeout(() => {
      document
        .querySelector("#workshop-dialog-location button")
        ?.setAttribute("aria-label", t('workshop_dialog_location_button'));
      document
        .querySelector("#workshop-dialog-calendar button")
        ?.setAttribute("aria-label", t('workshop_dialog_calendar_button'));
    }, 1000);
  });


  return (
    <Dialog
      id="workshopdialog"
      onClose={handleClose}
      role="dialog"  aria-labelledby="workshop_dialog_label" aria-modal="true"
      open={open}
      maxHeight={450}
      showCloseIcon
    >
      <DialogContent>
        <Typography style={{ fontSize: "16px", color: theme.palette.grey["800"] }} component="h2" id="workshop_dialog_label">
          {t('express_interest')}
        </Typography>
        <Typography
          style={{
            fontSize: "12px",
            color: theme.palette.grey["800"],
            lineHeight: "18px",
            marginTop: "15px",
          }}
          component="h3"
        >
          {t('express_interest_dialog',{and_location :data?.customerExpressInterests?.locations?.length ? t('and_location') : "" })}
        </Typography>
        <Box style={{ display: !isMobile?"flex":"", justifyContent: "left",maxHeight:"100px",overflow:"auto" }}>
          <Box style={{ paddingRight: "10px" }}>
            <TypographyLbl>
              {t('month')}
            </TypographyLbl>
            <SelectBox id="workshop-dialog-calendar">
              <Select
                title={t('month_year')}
                options={
                  data &&
                  data.customerExpressInterests.dates.map((item: any) => {
                    return { title: item.displayText, id: item.interestedDate };
                  })
                }
                onChange={handleDateSelection}
                value={selectedWorkshopDate}
              />
            </SelectBox>
          </Box>
          {
          data?.customerExpressInterests?.locations?.length > 0 && <Box style={{ paddingLeft: !isMobile?"10px":"0px" }}>
            <TypographyLbl>
              {t('location')}
            </TypographyLbl>
            {(
              <SelectBox id="workshop-dialog-location">
                <Select
                  title={t('location')}
                  options={
                    data &&
                    data.customerExpressInterests.locations.map((item: any) => {
                      return { title: item, id: item };
                    })
                  }
                  onChange={handleLocationSelection}
                  value={selectedWorkshopLocation}
                />
              </SelectBox>
            )}
          </Box>
        }
        </Box>
      </DialogContent>
      <DialogActions style={{justifyContent : isSmallScreen? "center" : undefined}}>
        <Action
          type="dialog-primary"
          onClick={handleExpressInterest}
          disabled={
            !selectedWorkshopDate ||
            (data?.customerExpressInterests?.locations?.length && !selectedWorkshopLocation)
          }
          style={{ height: "32px", width: "216px" }}
        >
          {t('express_interest_close_dialog')}
        </Action>
      </DialogActions>
    </Dialog>
  );
};
