import {
  IconButton,
  Dialog as MuiDialog,
  DialogTitle as MuiDialogTitle,
  DialogActions as MuiDialogActions,
  DialogContent as MuiDialogContent,
  DialogProps as MuiDialogProps,
  DialogContentProps,
  DialogActionsProps as MuiDialogActionProps,
  useMediaQuery,
} from "@material-ui/core";
import { Theme, withStyles } from "@material-ui/core/styles";
import CloseIcon from "@material-ui/icons/Close";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";

const StyledDialog = withStyles((theme: Theme) => ({
  root: {
    minHeight: (props: DialogProps) => (props.minHeight ? props.minHeight : props.isLargeHeight ? '652px' : "90vh"),
    maxHeight: (props: DialogProps) =>
      props.isMobile ? "100%" : props.maxHeight ? props.maxHeight : "90vh",
    maxWidth: (props: DialogProps) => (props.max_Width ? props.max_Width : 720),
    minWidth: (props: DialogProps) => (props.minWidth ? props.minWidth : 200),
    padding: (props: DialogProps) => (props.isMobile ? "0" : theme.spacing(3)),
    margin: "auto",
    [theme.breakpoints.up("xs")]: {
      "& .MuiDialog-paperWidthXs": {
        maxWidth: "335px",
      },
    },
    [theme.breakpoints.up("sm")]: {
      "& .MuiDialog-paperWidthSm": {
        maxWidth: "660px",
        borderRadius: "0",
      },
    },
  },
  paper: {
    minHeight: (props: DialogProps) => (props.minHeight ? props.minHeight : ""),
    width: (props: DialogProps) => (props.minWidth ? props.minWidth : ""),
  },
}))(MuiDialog);

export const DialogTitle = withStyles(() => ({
  root: {
    display: "flex",
    justifyContent: "flex-end",
    padding: 0,
  },
}))(MuiDialogTitle);

export const DialogContent = withStyles(() => ({
  root: {
    overflow: (props: DialogContentProps & { isMobile?: boolean }) =>
      props.isMobile ? undefined : "hidden",
  },
}))(MuiDialogContent);

type DialogActionsProps = MuiDialogActionProps & { isMobile?: boolean; alignContent?: string };
export const DialogActions = withStyles(() => ({
  root: {
    display: "flex",
    justifyContent: (props: DialogActionsProps) =>
      props.alignContent ? props.alignContent : "flex-end",
    padding: (props: DialogActionsProps) =>
      props.isMobile ? "0px 0px 0px 0px" : "20px 25px 30px 25px",
  },
}))(MuiDialogActions);

export const keyDownHandler = (dialogtitle:string,e):void => {
  // only execute if tab is pressed
  if (e.key !== 'Tab') return

  const modalRef = document.getElementById(dialogtitle);

  // here we query all focusable elements, customize as your own need
  const focusableModalElements = modalRef.querySelectorAll(
    'a[href], button:not([disabled]), textarea, input, select'
  )

  const firstElement = focusableModalElements[0];
  const lastElement = focusableModalElements[focusableModalElements.length - 1];

  // if going forward by pressing tab and lastElement is active shift focus to first focusable element 
  if (!e.shiftKey && document.activeElement === lastElement) {
    (firstElement as HTMLElement)?.focus();
    return e.preventDefault();
  }

  // if going backward by pressing tab and firstElement is active shift focus to last focusable element 
  if (e.shiftKey && document.activeElement === firstElement) {
    (lastElement as HTMLElement)?.focus();
    e.preventDefault();
  }
}

type DialogProps = MuiDialogProps & {
  isMobile?: boolean;
  max_Width?: number | string;
  minWidth?: number | string;
  maxHeight?: number | string;
  minHeight?: number | string;
  disableCloseIcon?: boolean;
  isLargeHeight?: boolean;
  role?:string;
  id:string;
};
export const Dialog = ({
  children,
  onClose,
  showCloseIcon,
  id,
  ...props
}: DialogProps & {
  onClose: React.MouseEventHandler<HTMLButtonElement> | undefined;
  showCloseIcon?: boolean;
}): JSX.Element => {
  const isLargeHeight = useMediaQuery('(min-height:700px)')
  const focusClass = useFocusStyles();
  const { t } = useTranslation();
  return (
    <StyledDialog 
      id={id}
      onKeyDown={(e)=>{keyDownHandler(id,e);}}
     {...props} disableBackdropClick={true} disableEnforceFocus={true} isLargeHeight={isLargeHeight} >
      {showCloseIcon && (
        <>
          {props.disableCloseIcon ? (
            ""
          ) : (<div style={{ width: "100%", display: "flex", justifyContent: "flex-end" }}>
            <IconButton aria-label={t('close').toLowerCase()+' '+props.title} className={focusClass.focusItem}
              onClick={onClose} >
              <CloseIcon />
            </IconButton>
          </div>
          )
          }
          <DialogTitle />
        </>
      )}
      {children}
    </StyledDialog >
  );
};
