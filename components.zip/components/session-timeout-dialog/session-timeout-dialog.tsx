import { Box, useMediaQuery, ButtonProps, DialogActionsProps } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import MuiButton from "@material-ui/core/Button";
import MuiDialogActions from "@material-ui/core/DialogActions";
import MuiDialogContent from "@material-ui/core/DialogContent";
import { Theme, withStyles } from "@material-ui/core/styles";
import { Dialog } from "components";
import { useInterval } from "utils/custom-hooks";
import { useEffect, useState } from "react";
import SessionManager from "utils/sessionManager";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";

type MobileProps = { mobile?: boolean };

const DialogContent = withStyles((theme: Theme) => ({
  root: {
    overflow: "hidden",
    "& svg": {
      width: "40px",
      color: "#FFD157",
      transform: "scale(1.5)",
    },
    "& h2": {
      fontWeight: "normal",
      marginTop: "5px",
    },
    "& p:first-child": {
      marginBottom: "35px",
    },
    "& p:nth-child(3), p:nth-child(4)": {
      margin: "40px 0",
      display: "inline",
      marginRight: "20px",
      "& span": {
        color: theme.palette.primary.main,
        fontSize: "55px",
      },
      "& span:nth-child(2)": {
        fontSize: 20,
        color: "#9d9d9d",
      },
    },
    "& p:nth-child(5)": {
      fontWeight: "bold",
    },
    "& p:nth-child(3) .toString": {
      color: "red",
    },
  },
}))(MuiDialogContent);

type ActionProps = DialogActionsProps & MobileProps;
const DialogActions = withStyles(() => ({
  root: (props: ActionProps) => ({
    display: "flex",
    padding: props.mobile ? "auto" : "0px 25px 30px 25px",
    margin: props.mobile ? "auto" : undefined,
    marginBottom: props.mobile ? "20px" : undefined,
    height: "42px",
  }),
}))(MuiDialogActions);

type CustomeButtonProps = ButtonProps & MobileProps;
const Button = withStyles((theme: Theme) => ({
  root: {
    borderRadius: 0,
    color: portalSettingsManager.buttonColors?.themed?.active?.text || theme.palette.primary.main,
    border: `1px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
    padding: "10px 25px",
    marginLeft: (props: CustomeButtonProps) => (props.mobile ? "0px" : "20px"),
  },
  label: {
    fontSize: 11,
    fontWeight: 700,
  },
  outlined: {
    border: `1px solid ${theme.palette.primary.main}`,
  },
  disabled: {
    color: theme.palette.grey["500"],
  },
}))(MuiButton);

const CloseButton = withStyles((theme: Theme) => ({
  root: {
    borderRadius: 0,
    color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["500"],
    padding: "10px 25px",
  },
  label: {
    fontSize: 11,
    fontWeight: 700,
  },
}))(MuiButton);

export const SessionTimeoutDialog = ({
  open,
  handleClose,
  reset,
}: {
  open: boolean;
  handleClose: () => void;
  reset: () => void;
}): JSX.Element => {
  const [time, setTime] = useState({ minutes: 5, seconds: 0 });
  const [timedout, setTimedout] = useState<boolean>(false);
  const { t } = useTranslation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const focusClass = useFocusStyles();

  const tick = () => {
    // const isExpired = SessionManager.isExpired;
    // const timeLeft = SessionManager.timeLeft;
    // console.log(timeLeft, isExpired);
    if(SessionManager.isExpired) {
      setTimedout(true);
    } else {
      setTime(SessionManager.timeLeft);
    }
  };

  useInterval(tick, open && !timedout ? 1000 : null);

  useEffect(() => {
    if (open) {
      setTimedout(false);
    }
  }, [open]);

  return (
    <Dialog
      id = "sessiondialog"
      onClose={handleClose}
      role="dialog"  aria-labelledby="session_dialog_label" aria-modal="true"
      open={open}
      fullScreen={isMobile}
      maxHeight={450}
      minHeight={450}
      showCloseIcon
      disableCloseIcon
    >
      <DialogContent>
        <Box>
          {!timedout ? (
            <div>
              <h2 id="session_dialog_label">{t('session_expire_message')}</h2>
              <p id="session_dialog_label">
              {t('session_expire_logout_message')}
              </p>
              <p>
                <span>{`${time.minutes.toString().padStart(2, "0")}`}</span>
                <span>{t('mins')}</span>
              </p>
              <p>
                <span>{`${time.seconds.toString().padStart(2, "0")}`}</span>
                <span>{t('secs')}</span>
              </p>
              <p>{t('remain_loggedin')}</p>
            </div>
          ) : (
            <div>
              <p>{t('session_timed_out')}</p>
            </div>
          )}
        </Box>
      </DialogContent>
      <DialogActions mobile={isMobile}>
        {!timedout ? (
          <div
            style={{
              display: isMobile ? "flex" : undefined,
              flexDirection: isMobile ? "column-reverse" : undefined,
              alignItems: isMobile ? "center" : undefined,
            }}
          >
            <CloseButton className={`${focusClass.secondaryHover}`} onClick={handleClose}>{t('log_me_out')}</CloseButton>
            <Button
              onClick={reset}
              mobile={isMobile}
              style={{ width: "245px" }}
              className={`${focusClass.primaryHover}`}
            >
              {t('keep_me_logged_in')}
            </Button>
          </div>
        ) : (
          <Button className={`${focusClass.primaryHover}`} style={{ width: "90px" }} onClick={handleClose}>CLOSE</Button>
        )}
      </DialogActions>
    </Dialog>
  );
};
