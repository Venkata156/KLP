import { useEffect, useState } from "react";
import { Box } from "@material-ui/core";
import { Theme, withStyles } from "@material-ui/core/styles";
import portalSettingsManager from "utils/portalSettingsManager";

const Container = withStyles((theme: Theme) => ({
  root: {
    minHeight: "50px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey['300']}`,
    color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey['800'],
    backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back,
    marginBottom: "10px",
    cursor: "pointer",
    userSelect: "none",
    "&:hover":{
      border: `1px solid ${portalSettingsManager.buttonColors?.normal?.hover?.border || theme.palette.grey['300']}`,
      color: portalSettingsManager.buttonColors?.normal?.hover?.text || theme.palette.grey['800'],
      backgroundColor: portalSettingsManager.buttonColors?.normal?.hover?.back,
    },
    "&.on": {
      border: `2px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
      color: portalSettingsManager.buttonColors?.themed?.active?.text || theme.palette.primary.main,
      backgroundColor: portalSettingsManager.buttonColors?.themed?.active?.back || "#FFFFFF"
    },
  },
}))(Box);

export const Toggle = ({ title, code, isOn, onChange, ...restProps }: any): JSX.Element => {
  const [on, setOn] = useState<boolean>(false);

  useEffect(() => {
    setOn(isOn);
  }, [isOn]);

  return (
    <Container className={on ? "on" : ""} aria-pressed={on} onClick={() => onChange(code)} {...restProps} tabIndex={0}>
      <span style={{ textAlign: "center", fontSize: "14px" }}>{title}</span>
    </Container>
  );
};
