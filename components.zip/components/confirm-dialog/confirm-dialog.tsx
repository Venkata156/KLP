import {
  Typography,  
  DialogProps,  
  Button as MuiButton,
} from "@material-ui/core";
import { Dialog, DialogActions, DialogContent } from "components";
import { Theme, withStyles, useTheme, makeStyles } from "@material-ui/core/styles";
import { useFocusStyles } from "hooks/focusBorder";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";


const Button = withStyles((theme: Theme) => ({
  root: {
    flex: 1,
    borderRadius: 0,
    color: portalSettingsManager.buttonColors?.themed?.active?.text || theme.palette.primary.main,
  },
  label: {
    fontSize: 11,
    fontWeight: 700,
  },
  outlined: {
    border: `1px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
  },
  disabled: {
    color: theme.palette.grey["500"],
  },
}))(MuiButton);
const useStyles = makeStyles({
  dialog: {
    position: 'absolute',
    right: 10,
    top: 100
  }
});
type ConfirmDialogProps = DialogProps & {
  open: boolean;
  title: string;
  handleConfirmed: () => void;
  handleClose: (val: false) => void;
  message: string;
  isNotificationDrawer?: boolean;
};
export const ConfirmDialog = ({
  open,
  title,
  handleConfirmed,
  handleClose,
  message,
  isNotificationDrawer,
  ...props
}: ConfirmDialogProps): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const classes = useStyles();
  const focusClass = useFocusStyles();
  return (
    <Dialog
      id="confirmdialog"     
      classes={{
        paper: isNotificationDrawer ? classes.dialog : ""
      }}
      onClose={(() => handleClose(false)) as any}
      role="dialog"  aria-labelledby="confirm_dialog" aria-modal="true"
      open={open}
      {...{
        disableBackdropClick: true,
        disableEscapeKeyDown: true,
        ...props,
      }}>
      <DialogContent>
        <Typography component={'h2'} style={{ fontSize: "16px", color: theme.palette.grey["800"], fontWeight: 600 }}>
          {title}
        </Typography>
        <Typography
          style={{
            fontSize: "12px",
            color: theme.palette.grey["800"],
            lineHeight: "16px",
            marginTop: "10px",
          }}
        >
          <span id="confirm_dialog" aria-hidden='true'>{message}</span>
        </Typography>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={() => {
            handleClose(false);
            handleConfirmed();
          }}
          variant="outlined"
          style={{ width: "160px", height: "32px", backgroundColor: portalSettingsManager.buttonColors?.themed?.active?.back }}
          className={`${focusClass.primaryHover}`}
          aria-label = {t('yes')}         
        > 
          {t('yes')}
        </Button>
        <Button onClick={() => handleClose(false)} style={{ color: theme.palette.grey["500"] }} aria-label = {t('no')}>
        {t('no')} 
        </Button>
      </DialogActions>
    </Dialog>
  );
};
