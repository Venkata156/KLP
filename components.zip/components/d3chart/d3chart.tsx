import { Box, Typography, SvgIcon } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import * as d3 from "d3";
import { useEffect, useRef, useState } from "react";
import { Tooltip } from "components";
import { ReactComponent as arrowIcon } from "assets/icons/icon-arrow-blue.svg";
import { useTranslation } from "react-i18next";

const typeToDisplayText = (type: string): string => {
  if (type === "inProgress") {
    return 'In Progress';
  }
  return type;
};

const getXForSum = (sum: number, width: number) => {
  if (sum > 999) {
    return 20;
  }
  if (sum > 99) {
    return 35;
  }
  return sum > 9 ? width / 3 : 63;
};

export const D3Chart = ({ metricsData, metricsIcon, metricsTitle }: any): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const d3Ref = useRef(null);
  const svgTooltipRef= useRef<any>(null);
  const [tooltipTitle, setTooltipTitle]= useState('');
  const [open, setOpen]= useState(false);
  const metricSum = metricsData.reduce((s: any, { value }: { value: any }) => s + value, 0);
  const ariaLabeltext = `${metricsTitle} ${metricSum} ${t('total_courses')} ${metricsData.map((d:{value:string, type:string}) => `${d.value}  ${typeToDisplayText(d.type)}`).join(", ")}`;

  const onMouseOverFunc = (e:SVGPathElement , index:number)=>{
    if(index === 0){
      setTooltipTitle(t('enrolled'));
    } else  if(index === 1){
      setTooltipTitle(t('inprogress'));
    } else  if(index === 2){
      setTooltipTitle(t('completed'));
    }
    if(!open){
      setOpen(true);
    }
    svgTooltipRef?.current?.handleMouseOver(e);
  }

  const onMouseOutFunc = (e: SVGPathElement, openVar:boolean)=>{
    tooltipTitle !== '' && setTooltipTitle('');
    open !== openVar && setOpen(openVar);
    svgTooltipRef?.current?.handleMouseOut(e);
  }


  useEffect(() => {
    const svg = d3.select(d3Ref.current);
    const width = parseInt(svg.attr("width"));
    const height = parseInt(svg.attr("height"));
    svg.selectAll("svg > *").remove();

    const margin = 10;
    const arcWidth = 5;
    const radius = Math.min(width / 2 - margin, height / 2 - margin) - arcWidth / 2;
    const center = { x: width / 2, y: height / 2 };
    let anglePos = 0;
    const angleOffset = 0.025;
    const sum = metricsData.reduce((s: any, { value }: { value: any }) => s + value, 0);

    if (metricsData.length > 0) {
      const json = {
        nodes: [
          {
            x: 72,
            r: radius,
          },
        ],
      };

      if (sum === 0) {
        const elem = svg.selectAll("g").data(json.nodes);

        const elemEnter = elem
          .enter()
          .append("g")
          .attr("transform", function () {
            return "translate(75,75)";
          });

       elemEnter
          .append("circle")
          .attr("r", function (d) {
            return d.r;
          })
          .attr("stroke", theme.palette.grey['300'])
          .attr("fill", theme.palette.common.white)
          .style("stroke-width", arcWidth);
      }

      metricsData.forEach(
        (
          { value, text, color }: { value: any; text: any; color: any },
          index: any
        ) => {
          const angle = (Math.PI * 2 * value) / sum;
          const start = {
            x: center.x + radius * Math.sin(anglePos + angleOffset),
            y: center.y + radius * -Math.cos(anglePos + angleOffset),
          };

          const arcCenter = {
            x: center.x + radius * Math.sin(anglePos + angle / 2),
            y: center.y + radius * -Math.cos(anglePos + angle / 2),
          };

          anglePos += angle;
          const end = {
            x: center.x + radius * Math.sin(anglePos - angleOffset),
            y: center.y + radius * -Math.cos(anglePos - angleOffset),
          };
          const flags = value / sum >= 0.5 ? "1 1 1" : "0 0 1";
          const pathId = `my-pie-chart-path-${index+metricsTitle}`;
          if (text > 0) {
            svg
              .append("path")
              .attr("id", pathId)
              .attr("d", `M ${start.x},${start.y} A ${radius},${radius} ${flags} ${end.x},${end.y}`)
              .style("stroke", color)
              .style("fill", "none")
              .style("stroke-width", arcWidth)
              .on("mouseover", (e)=>{
                onMouseOverFunc(e, index);
              })
              .on("mouseout", (e)=>{
                onMouseOutFunc(e, false);
              });

            svg
              .append("circle")
              .attr("cx", arcCenter.x)
              .attr("cy", arcCenter.y)
              .attr("r", 10)
              .attr("fill", color)
              .attr('aria-hidden', true)
              .attr('aria-label', ariaLabeltext)
              .on("mouseover",(e)=>{
                onMouseOverFunc(e, index);
              })
              .on("mouseout",(e)=>{
                onMouseOutFunc(e,true);
              });

            svg
              .append("text")
              .text(text)
              .attr("x", arcCenter.x)
              .attr("y", arcCenter.y)
              .attr("text-anchor", "middle")
              .attr("alignment-baseline", "middle")
              .style("fill","white")
              .style("font-size", "12px")
              .attr('aria-hidden', true)
              .attr('aria-label', ariaLabeltext)
              .on("mouseover",(e)=>{
                onMouseOverFunc(e, index);
              })
              .on("mouseout",(e)=>{
                onMouseOutFunc(e,true);
              });
          }

          svg
            .append("text")
            .attr("x", getXForSum(sum, width))
            .attr("y", 90)
            .attr("font-size", "45px")
            .text(sum)
            .attr('aria-hidden', true)
            .attr('aria-label', ariaLabeltext)
            .on("mouseover",(e)=>{
              onMouseOutFunc(e,false);
            });
          svg.append("text").attr("x", 63).attr("y", 115).attr("font-weight", "normal").attr("font-family", "Arial").attr("font-size", "12px").style('fill','#818589').text("Total")
          .attr('aria-hidden', true)
          .attr('aria-label', ariaLabeltext)
          .on("mouseover",(e)=>{
            onMouseOutFunc(e,false);
          });
        }
      );
    }
  }, [d3Ref, metricsData, metricsIcon]);
  return (
    <Box maxWidth="140px">
      <Box maxWidth="140px" textAlign="center" aria-label= {ariaLabeltext}>
        <Typography
          display="inline"
          style={{
            maxWidth: "124px",
            fontSize: "14px",
            fontFamily: "Arial",
            color: "#333333",
            fontWeight: 700,
          }}
        >
          {metricsTitle}
        </Typography>
        <SvgIcon
          component={arrowIcon}
          style={{
            position: "absolute",
            marginTop: "5px",
            marginLeft: "6px",
            color: theme.palette.primary.main,
          }}
        />
      </Box>
 
      <Box display="inline-flex" position="relative" aria-label= {ariaLabeltext}>
        <Box
          width="100%"
          height="100%"
          top="0"
          bottom="0"
          left="0"
          right="0"
          style={{ position: "absolute", zIndex: 0, opacity: 0.15 }}
        >
          <Box
            width="60px"
            height="60px"
            m="0 auto"
            style={{
              background: `url(${metricsIcon}) no-repeat center`,
              backgroundSize: "contain",
              marginTop: "45px",
            }}
          />
        </Box>
        <Tooltip zIndex={10} anchorElement="pointer" title={tooltipTitle} ref={svgTooltipRef} openDelay={0} open={open} aria-label= {ariaLabeltext}>
          <svg
            aria-label= {ariaLabeltext}
            width="150"
            ref={d3Ref}
            height="150"
            className="test"
            style={{ zIndex: 10, position: "relative", cursor: "pointer" }}
            onMouseOut={() => {
              setOpen(false);
            }}
          />
        </Tooltip>
      </Box>
    </Box>
  );
};
