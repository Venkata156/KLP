import {
  Badge as MuiBadge,
  Box,
  Button,
  IconButton,
  Menu as MuiMenu,
  Typography,
  useMediaQuery,
  useTheme,
  Theme,
} from "@material-ui/core";
import { withStyles, makeStyles } from "@material-ui/core/styles";
import CloseIcon from "@material-ui/icons/Close";
import { useRef, useState } from "react";
import { useFocusStyles } from "../../hooks/focusBorder";
import { useTranslation } from "react-i18next";
import { BellIcon } from "components/common-icons/common-icons";
import portalSettingsManager from "utils/portalSettingsManager";


const Badge = withStyles(() => ({
  badge: {
    fontSize: "10px",
    fontWeight: 700,
    maxWidth: "22px",
    minWidth: "12px",
    height: "18px",
    backgroundColor: portalSettingsManager.header.colors.notificationCountBadge.back,
    color: portalSettingsManager.header.colors.notificationCountBadge.text,
    borderColor:portalSettingsManager.header.colors.notificationCountBadge.border
  },
}))(MuiBadge);

const Menu = withStyles((theme: Theme) => ({
  [theme.breakpoints.down("sm")]: {
    list: {
      position: "unset",
      padding: "20px 0",
    },
    paper: {
      height: "100%",
      maxHeight: "calc(100% - 30px)",
    },
  },
}))(MuiMenu);

type NotificationClick = (survey: "survey") => void;

const NotificationItem = ({ onClick }: { onClick: NotificationClick }): JSX.Element => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const { t } = useTranslation();

  return (
    <Box display="flex" alignItems="flex-start" m="20px 0">
      <Typography
        style={{
          width: "10px",
          height: "10px",
          backgroundColor: theme.palette.primary.main,
          borderRadius: "50%",
          marginTop: "5px",
        }}
      />
      <Box m={{ xs: "0 10px", sm: "0 20px" }} style={{ flex: 1 }}>
        <Box
          display="flex"
          alignItems={{ xs: "start", sm: "center" }}
          justifyContent="space-between"
          flexDirection={{ xs: "column", sm: "row" }}
        >
          <Typography
            style={{ fontSize: "12px", fontWeight: 700, color: theme.palette.grey["800"] }}
          >
            {t("notification_new_survey")}
          </Typography>
          <Typography style={{ fontSize: "12px", color: theme.palette.grey["500"] }}></Typography>
        </Box>
        <Typography
          style={{
            fontSize: "12px",
            color: theme.palette.grey["800"],
            lineHeight: "16px",
            margin: "10px 0",
          }}
        >
          {t("new_survey_dialogue")}
        </Typography>
        <Button
          variant="outlined"
          style={{
            fontSize: "11px",
            fontWeight: 700,
            color: theme.palette.primary.main,
            border: `1px solid ${theme.palette.primary.main}`,
            borderRadius: 0,
            height: isMobile ? "42px" : "auto",
          }}
          onClick={() => {
            onClick("survey");
          }}
          fullWidth={isMobile}
        >
          {t("take_survey")}
        </Button>
      </Box>
    </Box>
  );
};

export const Notification = ({
  onClick,
  visible,
  setVisibility,
  notificationCount,
  isMobile,
}: {
  onClick: NotificationClick;
  visible: boolean;
  setVisibility: (visible: boolean) => void;
  isMobile?: boolean;
  notificationCount?: number;
}): JSX.Element => {
  const theme = useTheme();
  const anchorRef = useRef<HTMLButtonElement | null>(null);
  const focusClass = useFocusStyles();
  const { t } = useTranslation();
  const handleClick = () => {
    setVisibility(true);
  };

  const handleClose = () => {
    setVisibility(false);
  };

  const hasNoNotification = !notificationCount || notificationCount === 0;

  const useStyles = makeStyles({
    rippleVisible: {
      visibility:"hidden"
    }
  });

  const classes = useStyles();

  return (
    <Box style={{ marginRight: "20px", marginTop: "-16px" }}>
      <IconButton
        ref={anchorRef}
        aria-controls="notification-menu"
        aria-haspopup="true"
        onClick={handleClick}
        className={hasNoNotification ? "" : focusClass.focusItem}
        aria-label={t("notification_bell_icon")}
        TouchRippleProps={{classes}}
        style={{border: "2px solid transparent"}}
      >
        <Badge badgeContent={notificationCount} invisible={hasNoNotification}>
          <BellIcon
            style={{
              position: "absolute",
              right: "-10px",
              width: "30px",
              height: "30px",
            }}
            backgroundColor={portalSettingsManager.header?.colors?.bellIcon?.back || "none"}
            textColor={portalSettingsManager.header?.colors?.bellIcon?.text || "none"}
          />
        </Badge>
      </IconButton>
      <Menu
        id="notification-menu"
        anchorEl={anchorRef.current}
        open={visible && Boolean(anchorRef.current)}
        onClose={() => setVisibility(false)}
        keepMounted
      >
        <Box
          width={{ xs: "auto", sm: "450px" }}
          height={{ xs: "100%", sm: "auto" }}
          p={{ xs: "0", sm: "0 30px" }}
        >
          <Box display={{ xs: "none", sm: "flex" }} justifyContent="flex-end" m="0 -25px">
            <IconButton
              aria-label={t("aria_label_notification_close")}
              onClick={handleClose}
              style={{ padding: "6px" }}
            >
              <CloseIcon />
            </IconButton>
          </Box>
          <Box
            display="flex"
            justifyContent="space-between"
            alignItems="flex-end"
            borderBottom={`1px solid ${theme.palette.grey["300"]}`}
            paddingBottom="9px"
            padding={{ xs: "0 20px 20px 20px", sm: "0 0 9px 0" }}
          >

          </Box>
          <Box padding={{ xs: "0 20px", sm: "0" }}>
            <NotificationItem
              onClick={(type) => {
                handleClose();
                onClick(type);
              }}
            />
          </Box>
          <Box
            display={{ xs: "block", sm: "none" }}
            position="absolute"
            width="calc(100% - 40px)"
            padding="0 20px"
            bottom="20px"
            right="0"
          >
            <Button
              style={{ fontSize: "11px", fontWeight: "bold", height: "42px", borderRadius: 0 }}
              variant="outlined"
              onClick={handleClose}
              fullWidth
            >
              {t("close")}
            </Button>
          </Box>
        </Box>
      </Menu>
    </Box>
  );
};
