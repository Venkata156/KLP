import {
  Box,
  Button,
  Divider,
  IconButton,
  Typography,
  useMediaQuery,
  makeStyles,
  useTheme,
} from "@material-ui/core";
import contentBg from "assets/images/course.png";
import linkedInIcon from "assets/icons/icon-logo-linkedIn.svg";
import linkedmobileIcon from "assets/icons/icon-bug-linkedIn.svg";
import opensesamemobileIcon from "assets/icons/icon-bug-opensesame.svg";
import opensesameIcon from "assets/icons/icon-logo-opensesame.svg";
import {
  ArrowIcon,
  ChannelIcon,
  CourseIcon,
  PathwayIcon,
  ParentPathwayIcon,
  PlayListIcon,
  TimeIcon,
  CertificationIcon,
  SaveToListIcon,
  ShareIcon,
  Rating,
  Tooltip
} from "components";
import { useFocusStyles } from "hooks/focusBorder";
import React, { useEffect, CSSProperties } from "react";
import { Link } from "react-router-dom";
import * as CategoryTypes from "utils/graphql/Category";
import { ActivityType, ContentSource, ContentType } from "utils/graphql/Global";
import sanitizeHtml from "sanitize-html";
import { dueDateFormat, formatTime } from "utils/helpers";
import { colors } from "components/theme/colors";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";
import { t } from "i18next";

const useStyles = makeStyles({
  viewLess: {
    display: "-webkit-box",
    "-webkit-line-clamp": 3,
    "-webkit-box-orient": "vertical",
    overflow: "hidden",
  },
});

export const NewIcon = ({ style = {} }: { style: CSSProperties }): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  return (
    <Typography
      display="inline"
      style={{
        position: "absolute",
        padding: "3px 3px 3px 0px",
        fontSize: "10px",
        fontWeight: 500,
        textAlign: "center",
        color: theme.palette.common.white,
        letterSpacing: "1px",
        backgroundColor: colors.green["500"],
        textTransform: "uppercase",
        width: "40px",
        height: "12px",
        zIndex: 100,
        ...style,
      }}
    >
      {t('new')}
    </Typography>
  );
};

NewIcon.defaultProps = { style: {} };
export const ContentIcon = ({
  contentType,
  item,
  studyModes,
}: {
  contentType: string;
  item: CategoryTypes.Category_contentListByCategory_contents;
  studyModes: (ActivityType | null)[];
}): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  let toolTipText = t(contentType.toLowerCase());
  if (
    item &&
    contentType &&
    contentType.toUpperCase() == "COURSE" &&
    item.studyModes &&
    item.studyModes.length > 0
  ) {
    if (item.studyModes.length > 1) {
      toolTipText = t('hybrid');
    } else {
      if (studyModes.length == 1) {
        toolTipText = t(studyModes[0].toLowerCase());
      }
    }
  }

  return (
    <Tooltip
      title={
        contentType.toUpperCase() === "COURSE" ? `${t('course')}-` + toolTipText : toolTipText
      }
    >
      <Box
        display="flex"
        alignItems="center"
        p="10px"
        style={{ position: "relative", top: "10px", backgroundColor: theme.palette.common.white }}
      >
        {(() => {
          const iconProps = { width: "26px", height: "26px", stroke: theme.palette.grey["A100"] };
          switch (contentType.toLowerCase()) {
            case ContentType.PLAYLIST.toLowerCase():
              return <PlayListIcon {...iconProps} />;
            case ContentType.CHANNEL.toLowerCase():
              return <ChannelIcon {...iconProps} />;
            case ContentType.PATHWAY.toLowerCase():
              return <PathwayIcon {...iconProps} />;
            case ContentType.PARENT_PATHWAY.toLowerCase():
              return <ParentPathwayIcon {...iconProps} />
            default:
              return <CourseIcon {...iconProps} />;
          }
        })()}
        <Typography
          display="inline"
          style={{
            marginLeft: "10px",
            fontSize: "10px",
            fontWeight: 700,
            color: "#767676",
            letterSpacing: "2px",
            textTransform: "uppercase",
          }}
        >
          {contentType.toUpperCase() == "COURSE" ? toolTipText : toolTipText}
        </Typography>
      </Box>
    </Tooltip>
  );
};

export const Certification = ({
  display,
  contentType,
}: {
  display: string;
  contentType: string;
}): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const title = `${t('certified')} ${t(contentType.toLowerCase())}`;
  return display ? (
    <Tooltip title={title}>
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        top="10px"
        left="10px"
        borderRadius="50%"
        style={{ backgroundColor: theme.palette.common.white, cursor: "pointer" }}
      >
        <CertificationIcon width="22px" height="24px" stroke={theme.palette.grey["800"]} />
      </Box>
    </Tooltip>
  ) : (
    <Tooltip title={title}>
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        width="28px"
        height="28px"
        top="18px"
        right="12px"
        position="absolute"
        borderRadius="50%"
        style={{ backgroundColor: theme.palette.common.white, cursor: "pointer" }}
      >
        <CertificationIcon width="18px" height="18px" stroke={theme.palette.grey["800"]} />
      </Box>
    </Tooltip>
  );
};

export const ContentBanner = ({
  item,
  showProgress,
  children,
  contentType,
  isAutoEnrolled
}: {
  item: { isEnrolled: boolean; statusCode: string | null; percentageComplete: any };
  showProgress?: boolean;
  children?: string;
  contentType?: string;
  isAutoEnrolled?:boolean;
}): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  return (
    <>
      {item.isEnrolled && item.statusCode === "InProgress" && (
        <div style={{ width: "100%" }}>
          <Typography
            style={{
              background: `${portalSettingsManager.statusColors?.inprogress?.back || '#005EB8'}`,
              textAlign: "center",
              fontSize: "10px",
              fontWeight: 700,
              color: portalSettingsManager.statusColors?.inprogress?.text || theme.palette.common.white,
              letterSpacing: "2px",
              padding: "5px 8px",
              textTransform: "uppercase",
              width: "100%",
              boxSizing: "border-box",
            }}
          >
            {children ?? t('inprogress')}
          </Typography>
          {showProgress && (item.percentageComplete || item.percentageComplete === 0) && (
            <progress
              max="100"
              value={item.percentageComplete}
              data-label={t('inprogress').toUpperCase()}
              style={{ appearance: "unset", display: "block", height: "5px", width: "100%" }}
            />
          )}
        </div>
      )}
      {item.isEnrolled && item.statusCode === "Enrolled" && (
        <Typography
          style={{
            background: `${portalSettingsManager.statusColors?.enrolled?.back || '#C6007E'}`,
            textAlign: "center",
            fontSize: "10px",
            fontWeight: 700,
            color: portalSettingsManager.statusColors?.enrolled?.text || theme.palette.common.white,
            letterSpacing: "2px",
            padding: "5px 8px",
            textTransform: "uppercase",
            width: "100%",
            boxSizing: "border-box",
          }}
        >
          {t(contentType === "channel" ? (isAutoEnrolled ? 'auto_subscribed' : 'subscribed') : 'enrolled')}
        </Typography>
      )}
      {item.isEnrolled && item.statusCode === "Completed" && (
        <Typography
          style={{
            background: `${portalSettingsManager.statusColors?.completed?.back || '#16837D'}`,
            textAlign: "center",
            fontSize: "10px",
            fontWeight: 700,
            color: portalSettingsManager.statusColors?.completed?.text || theme.palette.common.white,
            letterSpacing: "2px",
            padding: "5px 8px",
            textTransform: "uppercase",
            width: "100%",
            boxSizing: "border-box",
          }}
        >
          {t('completed')}
        </Typography>
      )}
    </>
  );
};
export const RequiredByDate = ({
  dueDate
}: {
  dueDate: string | null
}): JSX.Element => {
  const theme = useTheme();
  return (
    <>
      {(dueDate && dueDate !== null) && (
        <div style={{ width: "100%" }}>
          <Typography
            style={{
              background: "#f68d2e",
              textAlign: "center",
              fontSize: "10px",
              fontWeight: 700,
              color: theme.palette.common.white,
              letterSpacing: "2px",
              padding: "5px 8px",
              textTransform: "uppercase",
              width: "100%",
              boxSizing: "border-box",
            }}
          >
            {t("required_by")}: {dueDateFormat(dueDate)}
          </Typography>
        </div>
      )}
      
    </>
  );
};

type ContentTileType = {
  item: CategoryTypes.Category_contentListByCategory_contents;
  selectTile: (item: CategoryTypes.Category_contentListByCategory_contents) => void;
  handleClick?: React.MouseEventHandler<HTMLAnchorElement>;
  display?: string;
  setIsOpenPlaylist: (open: boolean) => void;
  setOpenShareContent: (open: boolean) => void;
  setOpenActivity: (open: boolean) => void;
};
export const ContentTile = ({
  item,
  selectTile,
  handleClick,
  display = "",
  setIsOpenPlaylist,
  setOpenShareContent,
  setOpenActivity,
}: ContentTileType): JSX.Element => {
  const { t } = useTranslation();
  const classes = useStyles();
  const theme = useTheme();
  const focusClass = useFocusStyles()
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const isSmallScreen = useMediaQuery(theme.breakpoints.down("xs"));
  const contentType = item.contentType ?? "";
  const studyModes = item.studyModes ?? [];
  const summary = item.summary ?? "";

  const summaryRef = React.useRef(null);
  const [showEllipsis, setShowEllipsis] = React.useState(false);
  const maxHeight = 60;
  const showTitleTooltip = (item?.name || "").length > 30;

  useEffect(() => {
    if (summaryRef.current !== null) {
      const checkSizeandSetEllipsis = (): any => {
        const { clientHeight, scrollHeight } = summaryRef.current || { clientHeight: 0, scrollHeight: 0 };
        setShowEllipsis(scrollHeight > maxHeight);
      };
      checkSizeandSetEllipsis();
      window.addEventListener("resize", checkSizeandSetEllipsis);
      return window.removeEventListener("resize", checkSizeandSetEllipsis);
    }
  }, [setShowEllipsis, summary, summaryRef]);

  const footer = (
    <Box
      display={{ xs: "flex", sm: "flex" }}
      alignItems="center"
      justifyContent="space-between"
      height="34px"
    >
      {item.hasActivities && (
        <Button
          onClick={(e) => {
            e.preventDefault();
            selectTile(item);
            setOpenActivity(true);
          }}
          style={{
            fontSize: "12px",
            textTransform: "none",
            position: "relative",
            left: "-7px",
            color: `${theme.palette.primary.main}`
          }}
          className={focusClass.focusItem}
          aria-label={t('aria_label_click_to_view_activities') + item.name}
        >
          {t('view_activities')}
        </Button>
      )}
      <Divider style={{ flex: 1, opacity: 0 }} />
      {portalSettingsManager.application?.features?.allowShareContent && contentType.toLowerCase() !== "playlist" && (
        <IconButton
          aria-label={t('aria_label_click_to_share') + item.name}
          style={{

            padding: "4px",
            marginLeft: "10px",
          }}
          className={`${focusClass.greyBorder} ${focusClass.focusItem}`}
          onClick={(e) => {
            e.preventDefault();
            selectTile(item);
            setOpenShareContent(true);
          }}
        >
          <ShareIcon
            stroke="#000000"
            style={{ transform: "translate(20%, 25%)" }}
            itemName={item.name ?? ""}
          />
        </IconButton>
      )}

      {portalSettingsManager.application?.features?.allowCreatePlaylist && contentType.toLowerCase() === "course" && (
        <Box
          display={{ xs: "block", sm: "block" }}
          onClick={(e) => {
            e.preventDefault();
            selectTile(item);
            setIsOpenPlaylist(true);
          }}
        >
          <IconButton
            aria-label={t('aria_label_click_to_add_course_to_playlist', { course: item.name })}
            style={{
              padding: "4px",
              marginLeft: "10px",
            }}
            className={`${focusClass.greyBorder} ${focusClass.focusItem}`}
          >
            <SaveToListIcon
              fill={"#000000"}
              style={{ transform: "translate(20%, 25%)" }}
              contentType={contentType.toLowerCase()}
            />
          </IconButton>
        </Box>
      )}
      <IconButton
        aria-label={t('aria_label_go_to_course_details', { course: item.name })}
        style={{
          padding: "4px",
          marginLeft: "10px",
          border: `1px solid ${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`
        }}
        className={`${focusClass.borderItem} ${focusClass.focusItem}`}
        role="link"
      >
        <ArrowIcon
          stroke={`${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`}
          style={{ transform: "translate(20%, 25%)" }}
          contentType={`${t("arrowicon_tooltip_title")} ${t(contentType.toLowerCase())}`}  
        />
      </IconButton>
    </Box>
  );
  const courseIcons = {
    [ContentSource.OPEN_SESAME]: !isMobile ? opensesameIcon : opensesamemobileIcon,
    [ContentSource.LINKED_IN]: !isMobile ? linkedInIcon : linkedmobileIcon,
    [ContentSource.KLP]: "",
    [ContentSource.NONE]: "",
  };
  return (
    <>
      {!display && (
        <Link to={`/${item.contentType}/${item.id}`} onClick={handleClick} role="presentation"> 
          <Box
            display="flex"
            flexDirection="column"
            width={{ xs: "280px", sm: "360px" }}
            minWidth={{ xs: "280px", sm: "360px" }}
            height={{ xs: "300px", sm: "360px" }}
            style={{
              boxShadow: "0 4px 14px 0 rgba(0,0,0,0.10)",
              backgroundColor: portalSettingsManager?.tile?.colors?.active?.back || theme.palette.common.white,
            }}
          >
            <Box
              style={{
                backgroundImage: `url(${item.imageUrl || contentBg})`,
                backgroundPosition: "center center",
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                minHeight: "140px",
                height: "140px",
                position: "relative",
              }}
            >
              <Box display="flex">{item.isNew && <NewIcon />}</Box>
              <Box display="flex">
                <ContentIcon contentType={contentType} studyModes={studyModes} item={item} />
              </Box>
              {item.hasCertificate && !isMobile && (
                <Certification display={display} contentType={contentType} />
              )}
                <Box
                display="flex"
                justifyContent="center"
                width="100%"
                style={{ position: "absolute", bottom: item.isEnrolled ?25:0 }}
              >
                <RequiredByDate dueDate={item.dueDate} />
              </Box>
              <Box
                display="flex"
                justifyContent="center"
                width="100%"
                style={{ position: "absolute", bottom: 0 }}
              >
                <ContentBanner contentType={item.contentType?.toLowerCase()} item={item} isAutoEnrolled={item.isAutoEnrolled}/>
              </Box>
            </Box>
            <Box flex="1">
              {item.isEnrolled && item.statusCode === "InProgress" && (item.percentageComplete || item.percentageComplete === 0) && (
                <progress
                  max="100"
                  value={item.percentageComplete}
                  data-label={t('inprogress').toUpperCase()}
                  style={{ appearance: "unset", display: "block", height: "5px", width: "100%" }}
                />
              )}
              <div
                style={{
                  margin:
                    item.isEnrolled && item.statusCode === "InProgress"
                      ? "15px 20px 20px 20px"
                      : "20px",
                }}
              >
                {
                  <Box display="flex" alignItems="center">
                    {item.durationDisplay && (
                      <div style={{ flex: 1, display: "flex" }}>
                        <TimeIcon width="15px" height="15px" stroke={theme.palette.grey["800"]} />
                        <span
                          style={{
                            fontSize: "12px",
                            color: theme.palette.grey["800"],
                            marginLeft: "5px",
                            marginTop: "1px",
                          }}
                        >
                          {formatTime(item.durationDisplay)}
                        </span>
                      </div>
                    )}
                    {contentType.toLowerCase() === "course" && (
                      <div
                        style={{
                          backgroundImage: `url(${courseIcons[item.source] || ""})`,
                          backgroundPosition: "center right",
                          backgroundRepeat: "no-repeat",
                          height: "20px",
                          flex: 2,
                        }}
                      ></div>
                    )}
                    {item.hasCertificate && isMobile && (
                      <CertificationIcon width="25px" height="25px" stroke={theme.palette.grey["800"]} />
                    )}
                  </Box>
                }
                <span style={{ display: "flex" }}>
                  <Box
                    fontSize={{ xs: "16px", sm: `${portalSettingsManager.fonts?.tile?.titleFont?.size || "18px"}` }}
                    style={{
                      fontWeight: 700,
                      color: portalSettingsManager.fonts?.tile?.titleFont?.color || theme.palette.grey["800"],
                      fontFamily: portalSettingsManager.fonts?.tile?.titleFont?.name || "inherit",
                      margin: "8px 0",
                      overflow: "hidden",
                      whiteSpace: "nowrap",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {item.name}
                  </Box>
                  {showTitleTooltip && (
                    <Tooltip title={item.name || ""} tooltipStyle={{ maxWidth: "250px" }}>
                      <span
                        style={{
                          display: "inline-block",
                          marginTop: "5px",
                          marginLeft: "-25px",
                          minWidth: "30px",
                          minHeight: "10px",
                          cursor: "pointer",
                          color: "transparent",
                          alignSelf: "flex-end",
                          backgroundColor: "transparent",
                        }}
                      >
                        {"..."}
                      </span>
                    </Tooltip>
                  )}
                </span>
                <Box
                  display={{ xs: "none", sm: "block" }}
                  style={{
                    fontSize: portalSettingsManager.fonts?.tile?.summaryFont?.size || "13px",
                    color: portalSettingsManager.fonts?.tile?.summaryFont?.color || theme.palette.grey["500"],
                    fontFamily: portalSettingsManager.fonts?.tile?.titleFont?.name || "inherit",
                    lineHeight: "19px",
                    height: "55px",
                    maxHeight: "55px",
                    position: "relative",
                    overflow: "hidden",
                  }}
                >
                  <div
                    ref={summaryRef}
                    className={classes.viewLess}
                    style={{ whiteSpace: "break-spaces" }}
                    dangerouslySetInnerHTML={{
                      __html: sanitizeHtml(summary, {
                        allowedTags: false,
                        allowedAttributes: false,
                      }),
                    }}
                  />
                  {/* // QUESTION: Do we need this? */}
                  {showEllipsis && (
                    <Tooltip title={summary} tooltipStyle={{ maxWidth: "250px" }}>
                      <div
                        style={{
                          position: "absolute",
                          bottom: "-2px",
                          right: 0,
                          width: "150px",
                          cursor: "pointer",
                          height: "20px",
                        }}
                      >
                        {/* {"...   "} */}
                      </div>
                    </Tooltip>
                  )}
                </Box>
              </div>
            </Box>
            <Box m="0 20px 20px 20px">{footer}</Box>
          </Box>
        </Link>
      )}

      {display && (
        <Link to={`/${item.contentType}/${item.id}`} onClick={handleClick} role="presentation">
          <Box
            display="flex"
            width="100%"
            paddingBottom={{ xs: "20px", sm: "40px" }}
            margin={{ xs: "20px 0", sm: "40px 0" }}
            borderBottom={`1px solid ${theme.palette.grey["300"]}`}
            style={{ cursor: "pointer" }}
          >
            {item.isNew && <NewIcon />}
            <Box
              width={{ xs: "120px", sm: "200px" }}
              minWidth={{ xs: "120px", sm: "200px" }}
              height={{ xs: "110px", sm: "170px" }}
              position="relative"
              style={{
                backgroundImage: `url(${item.imageUrl || contentBg})`,
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                display: "flex",
                justifyContent: "flex-end",
                flexDirection: "column",
              }}
            >
              <RequiredByDate
              dueDate={item.dueDate}
              />
              <ContentBanner
                item={item}
                contentType={item.contentType?.toLowerCase()}
                showProgress
                isAutoEnrolled={item.isAutoEnrolled}
              />
            </Box>
            <Box
              flex="1"
              display="flex"
              flexDirection="column"
              marginLeft={{ xs: "10px", sm: "20px" }}
              maxWidth="calc(100% - 220px)"
              height={{ xs: "110px", sm: "170px" }}
            >
              <Box display="flex" m="0px 0 0 -10px" alignItems="start">
                <Box marginTop="-20px"><ContentIcon contentType={contentType} studyModes={studyModes} item={item} /></Box>
                {contentType.toLowerCase() === "course" && courseIcons[item.source] && (
                  <div 
                    role="img"
                    aria-label={item.source === 'LINKED_IN' ? 'LinkedIn' : item.source === 'OPEN_SESAME' ? 'OpenSesame' : ''}
                    style={{
                      backgroundImage: `url(${courseIcons[item.source] || ""})`,
                      backgroundPosition: "center right",
                      backgroundRepeat: "no-repeat",
                      height: "20px",
                      flex: "3",
                    }}
                  ></div>
                )}
                {item.hasCertificate && (
                  <div style={{display: isSmallScreen ? "none" : "block", marginLeft: "auto", width: "25px", height: "30px" }}>
                    <Certification display={display} contentType={contentType} />
                  </div>
                )}
              </Box>
              <span style={{ display: "flex", width:"80%" }}>
                <Box
                  fontSize={{ xs: "14px", sm: `${portalSettingsManager.fonts?.wideTile?.titleFont?.size || "16px"}` }}
                  marginBottom={{ xs: "16px", sm: "5px" }}
                  whiteSpace={{ xs: "wrap", sm: "nowrap" }}
                  style={{
                    marginTop: "10px",
                    fontWeight: 700,
                    color: portalSettingsManager.fonts?.wideTile?.titleFont?.color || theme.palette.grey["800"],
                    fontFamily: portalSettingsManager.fonts?.wideTile?.titleFont?.name || "inherit",
                  
                    overflow: "hidden",
                    whiteSpace: "nowrap",
                    textOverflow: "ellipsis"
                  }}
                >
                  {item.name}
                </Box>
                {showTitleTooltip && (
                  <Tooltip title={item.name || ""} tooltipStyle={{ maxWidth: "250px" }}>
                    <span
                      style={{
                        display: "inline-block",
                        marginTop: "5px",
                        marginLeft: "-25px",
                        minWidth: "30px",
                        minHeight: "10px",
                        cursor: "pointer",
                        color: "transparent",
                        alignSelf: "flex-end",
                        backgroundColor: "transparent",
                      }}
                    >
                      {"..."}
                    </span>
                  </Tooltip>
                )}
              </span>
              <Box
                display={{ xs: "none", sm: "block" }}
                flex="1"
                marginTop="0"
                style={{
                  fontSize: portalSettingsManager.fonts?.wideTile?.summaryFont?.size || "13px",
                  color: portalSettingsManager.fonts?.wideTile?.summaryFont?.color || theme.palette.grey["500"],
                  fontFamily: portalSettingsManager.fonts?.wideTile?.summaryFont?.name || "inherit",
                  lineHeight: "19px",
                  height: "55px",
                  maxHeight: "55px",
                  overflow: "hidden",
                  position: "relative",
                }}
              >
                <div
                  ref={summaryRef}
                  className={classes.viewLess}
                  style={{ whiteSpace: "break-spaces" }}
                  dangerouslySetInnerHTML={{
                    __html: sanitizeHtml(summary, { allowedTags: false, allowedAttributes: false }),
                  }}
                />
                {showEllipsis && (
                  <Tooltip title={summary} tooltipStyle={{ maxWidth: "250px" }}>
                    <div
                      style={{
                        position: "absolute",
                        bottom: "-2px",
                        right: 0,
                        cursor: "pointer",
                        width: "150px",
                        height: "20px"
                      }}
                    >
                      {/* {"...   "} */}
                    </div>
                  </Tooltip>
                )}
              </Box>
              <Box display="flex" alignItems="flex-end" flex="1">
                <Box flex="1">
                  <Box
                    display="flex"
                    alignItems="center"
                    justifyContent={{ xs: "space-between", sm: "start" }}
                    marginBottom={{ xs: 0, sm: "0px" }}
                    height={35}
                  >
                    {item.durationDisplay ? (
                      <Box display="flex">
                        <TimeIcon width="15px" height="15px" stroke={theme.palette.grey["800"]} />
                        <Typography
                          style={{
                            fontSize: "12px",
                            color: theme.palette.grey["800"],
                            margin: "0 20px 0 5px",
                          }}
                        >
                          {formatTime(item.durationDisplay)}
                        </Typography>
                      </Box>
                    ) : (
                      <Typography
                        style={{
                          fontSize: "12px",
                          color: theme.palette.grey["800"],
                          margin: "0 20px 0 5px",
                        }}
                      >
                        &nbsp;
                      </Typography>
                    )}
                    {item.hasCertificate && (
                      <Box display={{ xs: "block", sm: "none" }}>
                        <CertificationIcon width="25px" height="25px" stroke={theme.palette.grey["800"]} />
                      </Box>
                    )}
                    {contentType.toLowerCase() === "playlist" ? (
                      ""
                    ) : (
                      <Box display={{ xs: "none", sm: "block" }} className={focusClass.focusItem}>
                        <Rating
                          score={item.rating || 0}
                          numberOfReviews={item.numberOfPeopleWhoRated || 0}
                          display={display}
                        />
                      </Box>
                    )}
                  </Box>
                  <Box display={{ xs: "none", sm: "block" }}>
                    {item?.tags?.map((tag, idx) => (
                      <Typography
                        display="inline"
                        key={idx}
                        style={{
                          fontSize: "11px",
                          color: theme.palette.grey["800"],
                          marginRight: "7px",
                          padding: `${!isMobile ? "2px 20px" : "2px 0px"}`,
                          background: "#f5f5f5",
                        }}
                      >
                        {tag}
                      </Typography>
                    ))}
                  </Box>
                </Box>
                {(!isMobile || !isSmallScreen) && footer}
              </Box>
            </Box>
          </Box>
        </Link>
      )}
    </>
  );
};
