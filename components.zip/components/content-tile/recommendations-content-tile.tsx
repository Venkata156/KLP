import {
  Box,
  Button,
  Divider,
  IconButton,
  Typography,
  useMediaQuery,
  makeStyles,
  useTheme,
} from "@material-ui/core";
import contentBg from "assets/images/course.png";
import linkedInIcon from "assets/icons/icon-logo-linkedIn.svg";
import linkedmobileIcon from "assets/icons/icon-bug-linkedIn.svg";
import opensesamemobileIcon from "assets/icons/icon-bug-opensesame.svg";
import opensesameIcon from "assets/icons/icon-logo-opensesame.svg";
import {
  TimeIcon,
  CertificationIcon,
  SaveToListIcon,
  ShareIcon,
  Rating,
  Tooltip,
} from "components";
import { useFocusStyles } from "hooks/focusBorder";
import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import * as CategoryTypes from "utils/graphql/Category";
import { ContentSource } from "utils/graphql/Global";
import sanitizeHtml from "sanitize-html";
import { formatTime } from "utils/helpers";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";
import { ContentIcon, Certification, ContentBanner, RequiredByDate, NewIcon } from "./content-tile";
import { useState } from "react";

const useStyles = makeStyles({
  viewLess: {
    display: "-webkit-box",
    "-webkit-line-clamp": 4,
    "-webkit-box-orient": "vertical",
    overflow: "hidden",
  },
  viewTitle: {
    display: "-webkit-box",
    "-webkit-line-clamp": 3,
    "-webkit-box-orient": "vertical",
    overflow: "hidden",
  },
});

type RecommendationsTileType = {
  item: CategoryTypes.Category_contentListByCategory_contents;
  selectTile: (item: CategoryTypes.Category_contentListByCategory_contents) => void;
  handleClick?: React.MouseEventHandler<HTMLAnchorElement>;
  display?: string;
  setIsOpenPlaylist: (open: boolean) => void;
  setOpenShareContent: (open: boolean) => void;
  setOpenActivity: (open: boolean) => void;
  index?: number;
  tileType?: string;
  tabIndex?: number | undefined;
};
export const RecommendationsContentTile = ({
  item,
  selectTile,
  handleClick,
  display = "",
  setIsOpenPlaylist,
  setOpenShareContent,
  setOpenActivity,
  tabIndex
}: RecommendationsTileType): JSX.Element => {
  const { t } = useTranslation();
  const classes = useStyles();
  const theme = useTheme();
  const focusClass = useFocusStyles();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const isSmallScreen = useMediaQuery(theme.breakpoints.down("xs"));
  const contentType = item.contentType ?? "";
  const studyModes = item.studyModes ?? [];
  const summary = item.summary ?? "";
  const [showTitleTooltip, setShowTitleTooltip] = useState(false);

  const summaryRef = React.useRef(null);
  const titleRef = React.useRef(null);
  const [showEllipsis, setShowEllipsis] = React.useState(false);
  const maxHeight = 60;
  //const showTitleTooltip = (item?.name || "").length > 30;

  useEffect(() => {
    if (summaryRef.current !== null) {
      const checkSizeandSetEllipsis = (): any => {
        const { clientHeight, scrollHeight } = summaryRef.current || {
          clientHeight: 0,
          scrollHeight: 0,
        };
        setShowEllipsis(scrollHeight > maxHeight);
      };
      checkSizeandSetEllipsis();
      window.addEventListener("resize", checkSizeandSetEllipsis);
      return window.removeEventListener("resize", checkSizeandSetEllipsis);
    }
  }, [setShowEllipsis, summary, summaryRef]);

  useEffect(() => {
    if (titleRef.current !== null) {
      const windowResizeCallback = (): any => {
        const { clientWidth, scrollWidth, clientHeight, scrollHeight} = titleRef.current || {
          clientWidth: 0,
          scrollWidth: 0,
        };
        setShowTitleTooltip(scrollHeight > clientHeight);
      };
      windowResizeCallback();
      window.addEventListener("resize", windowResizeCallback);
      return () => {
        window.removeEventListener("resize", windowResizeCallback);
      };
    }
  }, [item.name, titleRef]);

  const footer = (
    <Box
      display={{ xs: "flex", sm: "flex" }}
      alignItems="center"
      justifyContent="space-between"
      height="34px"      
    >
      {item.hasActivities && (
        <Button
          onClick={(e) => {
            e.preventDefault();
            selectTile(item);
            setOpenActivity(true);
          }}
          style={{
            fontSize: "12px",
            textTransform: "none",
            position: "relative",
            left: "12px",
            color: `${theme.palette.primary.main}`,
          }}
          className={focusClass.focusItem}
          aria-label={t("aria_label_click_to_view_activities") +' '+ item.name}
          role="button"
        >
          {t("view_activities")}
        </Button>
      )}
      {contentType.toLowerCase() === 'pathway' && <span
          style={{
            fontSize: "12px",
            textTransform: "none",
            position: "relative",
            left: "12px",
          }}
          className={focusClass.focusItem}
          aria-label={t("aria_label_click_Courses") +' '+ item.name}
        >
          {item.numberOfChildContents || 0} {t("Courses")}
        </span>}
      <Box display={"flex"} width="90px" marginLeft="auto">
        {portalSettingsManager.application?.features?.allowCreatePlaylist &&
          contentType.toLowerCase() === "course" && (
            <Box
              display={{ xs: "block", sm: "block" }}
              onClick={(e) => {
                e.preventDefault();
                selectTile(item);
                setIsOpenPlaylist(true);
              }}
            >
              <IconButton
                aria-label={t("aria_label_click_to_add_course_to_playlist", { course: item.name })}
                style={{
                  padding: "4px",
                  marginLeft: "10px",
                }}
                className={`${focusClass.greyBorder} ${focusClass.focusItem}`}
                role="button"
              >
                <SaveToListIcon
                  fill={"#000000"}
                  style={{ transform: "translate(20%, 25%)" }}
                  contentType={contentType.toLowerCase()}
                />
              </IconButton>
            </Box>
          )}
          {portalSettingsManager.application?.features?.allowShareContent &&
          contentType.toLowerCase() !== "playlist" && (
            <IconButton
              aria-label={t("aria_label_click_to_share") + item.name}
              style={{
                padding: "4px",
                marginLeft: "10px",
              }}
              className={`${focusClass.greyBorder} ${focusClass.focusItem}`}
              onClick={(e) => {
                e.preventDefault();
                selectTile(item);
                setOpenShareContent(true);
              }}
              tabIndex={tabIndex}
              role="button"
            >
              <ShareIcon
                stroke="#000000"
                style={{ transform: "translate(20%, 25%)" }}
                itemName={item.name ?? ""}
              />
            </IconButton>
          )}
      </Box>
    </Box>
  );
  const courseIcons = {
    [ContentSource.OPEN_SESAME]: !isMobile ? opensesameIcon : opensesamemobileIcon,
    [ContentSource.LINKED_IN]: !isMobile ? linkedInIcon : linkedmobileIcon,
    [ContentSource.KLP]: "",
    [ContentSource.NONE]: "",
  };

  function getImageContent() {
    return (
      <Box>
        <Box
          style={{
            backgroundImage: `url(${item.imageUrl || contentBg})`,
            backgroundPosition: "center center",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
            minHeight:  `${isSmallScreen?"210px":"230px"}`,
            height: `${isSmallScreen?"210px":"230px"}`  ,
            width: `${isSmallScreen?"calc(100% - 0px)":"300px"}` ,
            minWidth: "300px",
            position: "relative",
          }}
        >
          <Box display="flex">{item.isNew && <NewIcon />}</Box>
          <Box display="flex">
            <ContentIcon contentType={contentType} studyModes={studyModes} item={item} />
          </Box>
          <Box
            justifyContent="center"
            width="100%"
            style={{ position: "absolute", bottom: 16}}
          >
            <RequiredByDate dueDate={item.dueDate} />
            {contentType.toLowerCase() === "course" && courseIcons[item.source] && (
              <Box style={{display:"flex", justifyContent:"center", marginTop:"16px", backgroundColor:"white", padding:"5px 10px 5px 10px"}} width = {item.source === "LINKED_IN" ? 70 : 100 }>
                <div
                  style={{
                    backgroundImage: `url(${courseIcons[item.source] || ""})`,
                    backgroundPosition: "center right",
                    backgroundRepeat: "no-repeat",
                    height: "20px",
                    width: item.source === "LINKED_IN" ? 70 : 100,
                    backgroundColor:"white",
                  }}
                ></div>
              </Box>
            )}
          </Box>
          <Box
            display="flex"
            justifyContent="center"
            width="100%"
            style={{ position: "absolute", bottom: 0 }}
          >
            <ContentBanner contentType={item.contentType?.toLowerCase()} item={item} />
          </Box>
        </Box>
        {item.isEnrolled && item.statusCode === "InProgress" && (item.percentageComplete || item.percentageComplete === 0) && (
          <progress
            value={item.percentageComplete}
            data-label={t("inprogress").toUpperCase()}
            style={{ appearance: "unset", display: "block", height: "5px", width: "100%" }}
          />
        )}
      </Box>
    );
  }

  function getIcons() {
    return (
      <Box display="flex" alignItems="center" height={30}>
        {item.durationDisplay && (
          <div style={{ display: "flex" }}>
            <TimeIcon width="15px" height="15px" stroke={theme.palette.grey["800"]} />
            <span
              style={{
                fontSize: "12px",
                color: theme.palette.grey["800"],
                marginLeft: "5px",
                marginTop: "1px",
              }}
            >
              {formatTime(item.durationDisplay)}
            </span>
          </div>
        )}
        {item.hasCertificate && !isMobile && (
          <Box style={{ marginLeft: "6px" }}>
            <CertificationIcon width="22px" height="24px" stroke={theme.palette.grey["800"]} />
          </Box>
        )}
      </Box>
    );
  }

  function getTextContent() {
    return (
      <Box flex="1" style={{ display: "flex", flexDirection: "column", height: "100%" }} marginTop={isSmallScreen&&"15px"}>
        <Box style={{ marginLeft: "20px", marginBottom: `${isSmallScreen?"15px":"2px"}` }}>{getIcons()}</Box>
        <div
          style={{
            margin:
              item.isEnrolled && item.statusCode === "InProgress"
                ? "15px 20px 20px 20px"
                : "0 20px 20px 20px",
          }}
        >
          <span style={{ display: "flex" }}>
            <div
             
              style={{
                fontWeight: 700,
                color:
                  portalSettingsManager.fonts?.tile?.titleFont?.color || theme.palette.grey["800"],
                fontFamily: portalSettingsManager.fonts?.tile?.titleFont?.name || "inherit",
                marginBottom: "5px",
                overflow: "hidden",
                whiteSpace: "break-spaces",
                textOverflow: "ellipsis",
                fontSize:
                  isSmallScreen? "16px":`${portalSettingsManager.fonts?.tile?.titleFont?.size || "18px"}`,              
              }}
              className={classes.viewTitle}
              ref={titleRef}
            >
              {item.name}
            </div>
            {showTitleTooltip && (
              <Tooltip title={item.name || ""} tooltipStyle={{ maxWidth: "250px" }}>
                <span
                  style={{
                    display: "inline-block",
                    marginTop: "5px",
                    marginLeft: "-50px",
                    minWidth: "50px",
                    minHeight: isMobile?"":"60px",
                    cursor: "pointer",
                    color: "transparent",
                    alignSelf: "flex-end",
                    backgroundColor: "transparent",
                  }}
                >
                  {"..."}
                </span>
              </Tooltip>
            )}
          </span>
          <Box
            display={{ xs: "block", sm: "block" }}
            style={{
              fontSize: portalSettingsManager.fonts?.tile?.summaryFont?.size || "13px",
              color:
                portalSettingsManager.fonts?.tile?.summaryFont?.color || theme.palette.grey["500"],
              fontFamily: portalSettingsManager.fonts?.tile?.titleFont?.name || "inherit",
              lineHeight: "19px",
              position: "relative",
              overflow: "hidden",
            }}
          >
            <div
              ref={summaryRef}
              className={classes.viewLess}
              style={{ whiteSpace: "break-spaces" }}
              dangerouslySetInnerHTML={{
                __html: sanitizeHtml(summary, {
                  allowedTags: false,
                  allowedAttributes: false,
                }),
              }}
            />
            {/* // QUESTION: Do we need this? */}
            {showEllipsis && (
              <Tooltip title={summary} tooltipStyle={{ maxWidth: "250px" }}>
                <div
                  style={{
                    position: "absolute",
                    bottom: "-2px",
                    right: 0,
                    width: "150px",
                    cursor: "pointer",
                    height: "20px",
                  }}
                >
                  {/* {"...   "} */}
                </div>
              </Tooltip>
            )}
          </Box>
        </div>
        <Box style={{ marginTop: "auto" }}> {footer}</Box>
      </Box>
    );
  }

  return (
    <>
      {!display && (
        <Link to={`/${item.contentType}/${item.id}`} onClick={handleClick} tabIndex={tabIndex} role="presentation">
          <Box
            display="flex"
            width={isSmallScreen?"350px" :{ xs: "350px", sm: "580px" }}
            minWidth={{ xs: "280px", sm: "580px" }}
//minHeight={{xs:"300px",sm:"350px"}}
            margin={isSmallScreen&&"0 20px 15px 0"}
            style={{
              //boxShadow: "0 4px 14px 0 rgba(0,0,0,0.10)",
              backgroundColor:
                portalSettingsManager?.tile?.colors?.active?.back || theme.palette.common.white,
            }}
            flexDirection={isSmallScreen&&"column"}
          >
            {getImageContent()}
            <Box style={{ display: "flex", flexDirection: "column", overflow: "hidden", flex:"1 1 0", minHeight:"215px" }}>{getTextContent()}</Box>
          </Box>
        </Link>
      )}

      {display && (
        <Link to={`/${item.contentType}/${item.id}`} onClick={handleClick} role="presentation">
          <Box
            display="flex"
            width="100%"
            paddingBottom={{ xs: "20px", sm: "40px" }}
            margin={{ xs: "20px 0", sm: "40px 0" }}
            borderBottom={`1px solid ${theme.palette.grey["300"]}`}
            style={{ cursor: "pointer" }}
          >
            {!item.isNew && <NewIcon />}
            <Box
              width={{ xs: "120px", sm: "200px" }}
              minWidth={{ xs: "120px", sm: "200px" }}
              height={{ xs: "110px", sm: "170px" }}
              position="relative"
              style={{
                backgroundImage: `url(${item.imageUrl || contentBg})`,
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                display: "flex",
                justifyContent: "flex-end",
                flexDirection: "column",
              }}
            >
              <RequiredByDate dueDate={item.dueDate} />
              <ContentBanner
                item={item}
                contentType={item.contentType?.toLowerCase()}
                showProgress
              />
            </Box>
            <Box
              flex="1"
              display="flex"
              flexDirection="column"
              marginLeft={{ xs: "10px", sm: "20px" }}
            >
              <Box display="flex" m="-20px 0 0 -10px" alignItems="baseline">
                <ContentIcon contentType={contentType} studyModes={studyModes} item={item} />
                {contentType.toLowerCase() === "course" && (
                  <div
                    style={{
                      backgroundImage: `url(${courseIcons[item.source] || ""})`,
                      backgroundPosition: "center right",
                      backgroundRepeat: "no-repeat",
                      height: "20px",
                      flex: "3",
                    }}
                  ></div>
                )}
                {item.hasCertificate && !isMobile && (
                  <div style={{ marginLeft: "auto", width: "25px", height: "30px" }}>
                    <Certification display={display} contentType={contentType} />
                  </div>
                )}
              </Box>
              <Box
                fontSize={{
                  xs: "14px",
                  sm: `${portalSettingsManager.fonts?.wideTile?.titleFont?.size || "16px"}`,
                }}
                marginBottom={{ xs: "16px", sm: "5px" }}
                whiteSpace={{ xs: "wrap", sm: "nowrap" }}
                style={{
                  marginTop: "10px",
                  fontWeight: 700,
                  color:
                    portalSettingsManager.fonts?.wideTile?.titleFont?.color ||
                    theme.palette.grey["800"],
                  fontFamily: portalSettingsManager.fonts?.wideTile?.titleFont?.name || "inherit",
                }}
              >
                {item.name}
              </Box>
              <Box
                display={{ xs: "none", sm: "block" }}
                flex="1"
                marginTop="0"
                style={{
                  fontSize: portalSettingsManager.fonts?.wideTile?.summaryFont?.size || "13px",
                  color:
                    portalSettingsManager.fonts?.wideTile?.summaryFont?.color ||
                    theme.palette.grey["500"],
                  fontFamily: portalSettingsManager.fonts?.wideTile?.summaryFont?.name || "inherit",
                  lineHeight: "19px",
                  height: "55px",
                  maxHeight: "55px",
                  overflow: "hidden",
                  position: "relative",
                }}
              >
                <div
                  ref={summaryRef}
                  className={classes.viewLess}
                  style={{ whiteSpace: "break-spaces" }}
                  dangerouslySetInnerHTML={{
                    __html: sanitizeHtml(summary, { allowedTags: false, allowedAttributes: false }),
                  }}
                />
                {showEllipsis && (
                  <Tooltip title={summary} tooltipStyle={{ maxWidth: "250px" }}>
                    <div
                      style={{
                        position: "absolute",
                        bottom: "-2px",
                        right: 0,
                        cursor: "pointer",
                        width: "150px",
                        height: "20px",
                      }}
                    >
                      {/* {"...   "} */}
                    </div>
                  </Tooltip>
                )}
              </Box>
              <Box display="flex" alignItems="flex-end" flex="1">
                <Box flex="1">
                  <Box
                    display="flex"
                    alignItems="center"
                    justifyContent={{ xs: "space-between", sm: "start" }}
                    marginBottom={{ xs: 0, sm: "0px" }}
                  >
                    {item.durationDisplay ? (
                      <Box display="flex">
                        <TimeIcon width="15px" height="15px" stroke={theme.palette.grey["800"]} />
                        <Typography
                          style={{
                            fontSize: "12px",
                            color: theme.palette.grey["800"],
                            margin: "0 20px 0 5px",
                          }}
                        >
                          {formatTime(item.durationDisplay)}
                        </Typography>
                      </Box>
                    ) : (
                      <Typography
                        style={{
                          fontSize: "12px",
                          color: theme.palette.grey["800"],
                          margin: "0 20px 0 5px",
                        }}
                      >
                        &nbsp;
                      </Typography>
                    )}
                    {item.hasCertificate && (
                      <Box display={{ xs: "block", sm: "none" }}>
                        <CertificationIcon
                          width="25px"
                          height="25px"
                          stroke={theme.palette.grey["800"]}
                        />
                      </Box>
                    )}
                    {contentType.toLowerCase() === "playlist" ? (
                      ""
                    ) : (
                      <Box
                        display={{ xs: "none", sm: "block" }}
                        className={focusClass.focusItem}
                        role="button"
                      >
                        <Rating
                          score={item.rating || 0}
                          numberOfReviews={item.numberOfPeopleWhoRated || 0}
                          display={display}
                        />
                      </Box>
                    )}
                  </Box>
                  <Box display={{ xs: "none", sm: "block" }}>
                    {item?.tags?.map((tag, idx) => (
                      <Typography
                        display="inline"
                        key={idx}
                        style={{
                          fontSize: "11px",
                          color: theme.palette.grey["800"],
                          marginRight: "7px",
                          padding: `${!isMobile ? "2px 20px" : "2px 0px"}`,
                          background: "#f5f5f5",
                        }}
                      >
                        {tag}
                      </Typography>
                    ))}
                  </Box>
                </Box>
                {(!isMobile || !isSmallScreen) && footer}
              </Box>
            </Box>
          </Box>
        </Link>
      )}
    </>
  );
};
