import { Box, Button, Divider, IconButton, Typography, useMediaQuery, makeStyles, useTheme } from "@material-ui/core";
import contentBg from "assets/images/course.png";
import linkedInIcon from "assets/icons/icon-logo-linkedIn.svg";
import linkedmobileIcon from "assets/icons/icon-bug-linkedIn.svg";
import opensesamemobileIcon from "assets/icons/icon-bug-opensesame.svg";
import opensesameIcon from "assets/icons/icon-logo-opensesame.svg";
import { TimeIcon, PathwayIcon, CertificationIcon, SaveToListIcon, ShareIcon, Tooltip } from "components";
import { useFocusStyles } from "hooks/focusBorder";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import * as CategoryTypes from "utils/graphql/Category";
import { ContentSource } from "utils/graphql/Global";
import sanitizeHtml from "sanitize-html";
import { formatTime } from "utils/helpers";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";
import { ContentIcon, ContentBanner, RequiredByDate, NewIcon } from "./content-tile";
import {
  TILE_TYPES
} from "utils/constants";

const useStyles = makeStyles({
  view: {
    display: "-webkit-box",
    "-webkit-line-clamp": 2,
    "-webkit-box-orient": "vertical",
    overflow: "hidden",
  },
  viewMore: {
    "-webkit-line-clamp": 4,
  },
});

const getStyleVariables = (tileType: string | undefined, isTileView: boolean, isSmallScreen) => {
  if (!isTileView) {
    return {
      mainContainer: {
        width: { xs: "350px", sm: "350px" },
        height: { xs: "100%", sm: "250px" },
        contentHeight: { xs: undefined, sm: undefined },
        margin:`${isSmallScreen?"0px 0 0 -15px":"0"}`
      },
      imageContainer: {
        height: `${isSmallScreen?"210px" :"140px"}` ,
        width: undefined,
      },
    }
  } else {
    return {
      mainContainer: {
        flexDirection: "column",
        width: { xs: "280px", sm: "350px" },
        height: { xs: undefined, sm: "250px" },
        contentHeight: { xs: undefined, sm: undefined },
        margin:`${isSmallScreen?"0px 0 0 -10px":"0"}`
      },
      imageContainer: {
        height:"140px",
        width: undefined,
      },
    };
  }
};

type ExpandableContentTileType = {
  item: CategoryTypes.Category_contentListByCategory_contents;
  selectTile: (item: CategoryTypes.Category_contentListByCategory_contents) => void;
  handleClick?: React.MouseEventHandler<HTMLAnchorElement>;
  handleIsActiveChanged?: (index: number) => void;
  display?: string;
  setIsOpenPlaylist: (open: boolean) => void;
  setOpenShareContent: (open: boolean) => void;
  setOpenActivity: (open: boolean) => void;
  index?: number;
  tileType?: string;
  isTileView: boolean | undefined;
  tabIndex?: number | undefined;
};
export const ExpandableContentTile = ({
  item,
  handleClick,
  display = "",
  tileType,
  index,
  handleIsActiveChanged,
  isTileView,
  selectTile,
  setOpenActivity,
  setOpenShareContent,
  setIsOpenPlaylist,
  tabIndex
}: ExpandableContentTileType): JSX.Element => {
  const { t } = useTranslation();
  const classes = useStyles();
  const theme = useTheme();
  const focusClass = useFocusStyles();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const isSmallScreen = useMediaQuery(theme.breakpoints.down("xs"));
  const contentType = item.contentType ?? "";
  const studyModes = item.studyModes ?? [];
  const summary = item.summary ?? "";

  const summaryRef = React.useRef(null);
  const titleRef = React.useRef(null);
  const [showFullContent, setShowFullContent] = useState(false);
  const [showEllipsis, setShowEllipsis] = useState(false);
  const [showTitleTooltip, setShowTitleTooltip] = useState(false);
  const maxHeight = 60;
  // const showTitleTooltip = (item?.name || "").length > 30;

  const styleVariables = getStyleVariables(tileType, isTileView,isSmallScreen);

  useEffect(() => {
    if (summaryRef.current !== null) {
      const checkSizeandSetEllipsis = (): any => {
        const { clientHeight, scrollHeight } = summaryRef.current || {
          clientHeight: 0,
          scrollHeight: 0,
        };
        setShowEllipsis(scrollHeight > maxHeight);
      };
      checkSizeandSetEllipsis();
      window.addEventListener("resize", checkSizeandSetEllipsis);
      return () => {
        window.removeEventListener("resize", checkSizeandSetEllipsis);
      };
    }
  }, [setShowEllipsis, summary, summaryRef, showFullContent]);

  useEffect(() => {
    if (titleRef.current !== null) {
      const windowResizeCallback = (): any => {
        const { clientWidth, scrollWidth} = titleRef.current || {
          clientWidth: 0,
          scrollWidth: 0,
        };
        setShowTitleTooltip(scrollWidth > clientWidth);
      };
      windowResizeCallback();
      window.addEventListener("resize", windowResizeCallback);
      return () => {
        window.removeEventListener("resize", windowResizeCallback);
      };
    }
  }, [item.name, titleRef]);

  const courseIcons = {
    [ContentSource.OPEN_SESAME]: !isMobile ? opensesameIcon : opensesamemobileIcon,
    [ContentSource.LINKED_IN]: !isMobile ? linkedInIcon : linkedmobileIcon,
    [ContentSource.KLP]: "",
    [ContentSource.NONE]: "",
  };

  const getTimeIcon = () => {
    return (
      <Box display="flex" alignItems="center">
        {item.numberOfChildContents && item.numberOfChildContents > 0 && (
          <div style={{ display: "flex", margin: "-5px 10px 0 0",  }}>
          <PathwayIcon width="25px" height="27px" stroke={theme.palette.grey["800"]} />
          <span
              style={{
                fontSize: "12px",
                color: theme.palette.grey["800"],
                marginLeft: "5px",
                marginTop: "6px",
              }}
            >
              {item.numberOfChildContents || 0} {item.numberOfChildContents === 1 ? t('Pathway') : t('Pathways')}
            </span>
          </div>
        )}
        {item.durationDisplay && (
          <div style={{ display: "flex", marginRight: "10px" }}>
            <TimeIcon width="15px" height="15px" stroke={theme.palette.grey["800"]} />
            <span
              style={{
                fontSize: "12px",
                color: theme.palette.grey["800"],
                marginLeft: "5px",
                marginTop: "1px",
              }}
            >
              {formatTime(item.durationDisplay)}
            </span>
          </div>
        )}

        {item.hasCertificate&& (
          <CertificationIcon width="22px" height="24px" stroke={theme.palette.grey["800"]} />
        )}
      </Box>
    );
  };

  const handleHoverChange = (isHover: boolean) => {
    setShowFullContent(isHover);
    if (handleIsActiveChanged) {
      if (isHover && index != null) {
        handleIsActiveChanged(index);
      } else {
        handleIsActiveChanged(-1);
      }
    }
  };

  const footer = (
    <Box
      display={{ xs: "flex", sm: "flex" }}
      alignItems="center"
      justifyContent="space-between"
      height="34px"
      style={{ display: "flex" }}
    >
      {item.hasActivities && (
        <Button
          onClick={(e) => {
            e.preventDefault();
            selectTile(item);
            setOpenActivity(true);
          }}
          style={{
            fontSize: "12px",
            textTransform: "none",
            position: "relative",
            left: "-7px",
            color: `${theme.palette.primary.main}`
          }}
          className={focusClass.focusItem}
          aria-label={t('aria_label_click_to_view_activities') + item.name}
        >
          {t('view_activities')}
        </Button>
      )}
      <Divider style={{ flex: 1, opacity: 0 }} />
      {portalSettingsManager.application?.features?.allowShareContent && contentType.toLowerCase() !== "playlist" && (
        <IconButton
          aria-label={t('aria_label_click_to_share') + item.name}
          style={{

            padding: "4px",
            marginLeft: "10px",
          }}
          className={`${focusClass.greyBorder} ${focusClass.focusItem}`}
          onClick={(e) => {
            e.preventDefault();
            selectTile(item);
            setOpenShareContent(true);
          }}
        >
          <ShareIcon
            stroke="#000000"
            style={{ transform: "translate(20%, 25%)" }}
            itemName={item.name ?? ""}
          />
        </IconButton>
      )}

      {portalSettingsManager.application?.features?.allowCreatePlaylist && contentType.toLowerCase() === "course" && (
        <Box
          display={{ xs: "block", sm: "block" }}
          onClick={(e) => {
            e.preventDefault();
            selectTile(item);
            setIsOpenPlaylist(true);
          }}
        >
          <IconButton
            aria-label={t('aria_label_click_to_add_course_to_playlist', { course: item.name })}
            style={{
              padding: "4px",
              marginLeft: "10px",
            }}
            className={`${focusClass.greyBorder} ${focusClass.focusItem}`}
          >
            <SaveToListIcon
              fill={"#000000"}
              style={{ transform: "translate(20%, 25%)" }}
              contentType={contentType.toLowerCase()}
            />
          </IconButton>
        </Box>
      )}

    </Box>
  );

  const className = showFullContent ? `${classes.view} ${classes.viewMore}` : classes.view;

  return (
    <>
      <Box height={styleVariables.mainContainer.height}  onMouseEnter={() => handleHoverChange(true)}  onMouseLeave={() => handleHoverChange(false)}>
        {!display && (
          <Link to={`/${item.contentType}/${item.id}`} tabIndex={tabIndex} >
            <Box
              display="flex"
              flexDirection="column"
              width={styleVariables.mainContainer.width}
              margin={styleVariables.mainContainer.margin}
              minWidth={styleVariables.mainContainer.width}
              height={styleVariables.mainContainer.contentHeight}
              minHeight={styleVariables.mainContainer.contentHeight}
              padding="15px"
              style={{
                boxShadow: showFullContent ? "0 4px 14px 0 rgba(0,0,0,0.10)" : undefined,
                backgroundColor:
                  portalSettingsManager?.tile?.colors?.active?.back || theme.palette.common.white,
              }}
            >
              <Box
                style={{
                  backgroundImage: `url(${item.imageUrl || contentBg})`,
                  backgroundPosition: "center center",
                  backgroundRepeat: "no-repeat",
                  backgroundSize: "cover",
                  minHeight: styleVariables.imageContainer.height,
                  height: styleVariables.imageContainer.height,
                  width: styleVariables.imageContainer.width,
                  minWidth: styleVariables.imageContainer.width,
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <Box display="flex">{item.isNew && <NewIcon />}</Box>
                  <Box display="flex">
                    <ContentIcon contentType={contentType} studyModes={studyModes} item={item} />
                  </Box>
                  <Box display="flex" flexDirection="column" marginTop="auto">
                    {item.dueDate && (
                      <Box display="flex" justifyContent="center" width="100%" marginTop="auto">
                        <RequiredByDate dueDate={item.dueDate} />
                      </Box>
                    )}
                    {item.isEnrolled && item.statusCode === "InProgress" && (item.percentageComplete || item.percentageComplete === 0) && (
                      <progress
                        max="100"
                        value={item.percentageComplete}
                        data-label={t("inprogress").toUpperCase()}
                        style={{ appearance: "unset", display: "block", height: "5px", width: "100%" }}
                      />
                    )}
                    <Box display="flex" justifyContent="center" width="100%">
                      <ContentBanner contentType={item.contentType?.toLowerCase()} item={item} isAutoEnrolled={item.isAutoEnrolled} />
                    </Box>
                  </Box>
                </Box>

              <Box style={{ display: "flex", flexDirection: "column" }}>
                <Box flex="1">
                    <Box display={"flex"} alignItems={"center"} >
                      <div
                        style={{
                          fontWeight: 700,
                          color:
                            portalSettingsManager.fonts?.tile?.titleFont?.color ||
                            theme.palette.grey["800"],
                          fontFamily: portalSettingsManager.fonts?.tile?.titleFont?.name || "inherit",
                          margin: "8px 0",
                          overflow: "hidden",
                          whiteSpace: "nowrap",
                          textOverflow: "ellipsis",
                          width: contentType.toLowerCase() === "course" && courseIcons[item.source] ? "70%" : "100%",
                          fontSize: isSmallScreen ? "16px" : `${portalSettingsManager.fonts?.tile?.titleFont?.size || "18px"}`,
                        }}
                        ref={titleRef}
                      >
                        {item.name}
                      </div>
                     {showTitleTooltip && <Tooltip
                        title={item.name}
                        tooltipStyle={{ maxWidth: "250px", minHeight: "20px", minWidth: "20px" }}                        
                      >
                        <div
                          style={{
                            marginLeft: "-30px",
                            right: 0,
                            cursor: "pointer",
                            minWidth: "50px",
                            minHeight: "20px",
                            backgroundColor: "transparent",
                          }}
                        ></div>
                      </Tooltip>}
                      {contentType.toLowerCase() === "course" && courseIcons[item.source] && (
                        <Box
                          style={{
                            backgroundColor: "white",
                            width: "30%",
                            paddingLeft: "30px",
                            marginLeft:"auto"
                          }}
                        >
                          <div
                            style={{
                              backgroundImage: `url(${courseIcons[item.source] || ""})`,
                              backgroundPosition: "center right",
                              backgroundRepeat: "no-repeat",
                              height: "20px",
                            }}
                          ></div>
                        </Box>
                      )}
                    </Box>
                    <Box
                      display={{ xs: "block", sm: "block" }}
                      style={{
                        fontSize: portalSettingsManager.fonts?.tile?.summaryFont?.size || "13px",
                        color:
                          portalSettingsManager.fonts?.tile?.summaryFont?.color ||
                          theme.palette.grey["500"],
                        fontFamily:
                          portalSettingsManager.fonts?.tile?.titleFont?.name || "inherit",
                        lineHeight: "19px",
                        //height: "55px",
                        //maxHeight: "55px",
                        position: "relative",
                        overflow: "hidden",
                      }}
                    >
                      <div
                        ref={summaryRef}
                        className={className}
                        style={{ whiteSpace: "break-spaces" }}
                        dangerouslySetInnerHTML={{
                          __html: sanitizeHtml(summary, {
                            allowedTags: false,
                            allowedAttributes: false,
                          }),
                        }}
                      />
                      {showEllipsis && (
                        <Tooltip title={summary} tooltipStyle={{ maxWidth: "250px" }}>
                          <div
                            style={{
                              position: "absolute",
                              bottom: "-2px",
                              right: 0,
                              cursor: "pointer",
                              width: "150px",
                              height: "20px",
                            }}
                          >
                            {/* {"...   "} */}
                          </div>
                        </Tooltip>
                      )}
                    </Box>
                    <Box display="flex" alignItems="center" marginTop="20px">
                      <Box>{getTimeIcon()}</Box>
                      {showFullContent && <Box style={{ marginLeft: "auto" }}>{footer}</Box>}
                    </Box>
                </Box>
              </Box>
            </Box>
          </Link>
        )}
      </Box>
    </>
  );
};
