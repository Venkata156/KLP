import { ArrowIcon, HomeIcon, BellIcon, Notification, Search, Tooltip, UserIcon } from "components";
import {
  Badge,
  BadgeProps,
  Box,
  Button,
  ButtonProps,
  Drawer,
  IconButton,
  Menu,
  MenuItem,
  Typography,
  useMediaQuery,
} from "@material-ui/core";
import profileAvatar from "assets/icons/icon.profile.png";
import reporting from "assets/icons/icon-reporting.svg";
import incident from "assets/icons/icon-incident.svg";
import contact from "assets/icons/icon-contact.svg";

import logoutIcon from "assets/icons/icon_log_out_sml.svg";
import { Link, useHistory, useLocation } from "react-router-dom";
import { MouseEvent, useState, CSSProperties } from "react";
import { useTheme, withStyles, makeStyles } from "@material-ui/core/styles";
import { HEADER_CLICK_TYPES, PERMISSIONS } from "utils/constants";
import MenuIcon from "@material-ui/icons/Menu";
import { MobileDrawer } from "components/mobile-drawer/mobile-drawer";
import MoreVertIcon from "@material-ui/icons/MoreVert";
import SearchIcon from "@material-ui/icons/Search";
import { UserContext_userContext } from "utils/graphql/UserContext";
import { useFocusStyles } from "hooks/focusBorder";
import { tenantSettings } from "utils/authentication/tenantSettings";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";

type ActionProps = ButtonProps & { mobile?: boolean };
const Action = withStyles(() => ({
  root: {
    display: "flex",
    alignItems: "center",
    justifyContent: "left",
    textTransform: "none",
    textAlign: "left",
    paddingLeft: (props: ActionProps) => (props.mobile ? "0px" : "8px"),
    paddingRight: (props: ActionProps) => (props.mobile ? "0px" : "8px"),
    "& div": {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
    },
    "& svg": {
      marginRight: "10px",
    },
  },
}))(Button);
Action.displayName = "Action";

const useStyle = makeStyles(() => ({
  root: {
    fontSize: "12px",
    lineHeight: "30px",
  },
}));

type MobileBadgeProps = BadgeProps & { menu?: boolean };
const MobileBadge = withStyles(() => ({
  dot: {
    right: (props: MobileBadgeProps) => (props.menu ? 3 : -17),
    top: (props: MobileBadgeProps) => (props.menu ? 3 : -8),
    height: "10px",
    width: "10px",
    border: "2px solid white",
    borderRadius: "50%",
  },
}))(Badge);
MobileBadge.displayName = "MobileBadge";

const MobileSearch = ({
  showSearch,
  setShowSearch,
  handleNavigate,
}: {
  showSearch: boolean;
  setShowSearch: (val: boolean) => void;
  handleNavigate: () => void;
}) => {
  const { t } = useTranslation();
  const theme = useTheme();
  const focusClass = useFocusStyles();
  return (
    <Drawer open={showSearch} anchor="top">
      <Box
        style={{
          height: "100vh",
          display: "flex",
          padding: "20px",
          flexDirection: "column",
          justifyContent: "space-between",
        }}
      >
        <Search
          onSubmit={() => {
            setShowSearch(false);
            handleNavigate();
          }}
          mobile
        />
        <Button
          variant="outlined"
          onClick={() => setShowSearch(false)}
          style={{
            borderRadius: "0px",
            borderColor: theme.palette.grey["A100"],
            font: "Arial",
            fontWeight: "bold",
            borderWidth: "1px",
            fontSize: "12px",
            paddingTop: "15px",
            paddingBottom: "15px",
            color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"]
          }}
          className={focusClass.secondaryHover}
        >
          {t('cancel_and_close')}
        </Button>
      </Box>
    </Drawer>
  );
};

type HeaderProps = {
  userContext?: UserContext_userContext | null;
  showSearch: boolean | undefined;
  onClick: (val: string) => void;
  isSurveyCompleted: boolean;
  setOpenNotification: (val: boolean) => void;
  newNotificationCount?: number;
  notificationCount?: number;
  isClearNotification: boolean
};
export const Header = ({
  userContext,
  showSearch,
  onClick,
  isSurveyCompleted,
  setOpenNotification,
  newNotificationCount,
  notificationCount,
  isClearNotification
}: HeaderProps): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const classes = useStyle();
  const history = useHistory();
  const location = useLocation();

  const { userDisplayName } = userContext || {};
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const [mobileProfileDrawerOpen, setMobileProfileDrawerOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const isMobile = useMediaQuery(theme.breakpoints.down("xs"));
  const [showMobileSearch, setShowMobileSearch] = useState(false);
  const focusClass = useFocusStyles();
  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const isReportMenuAvailable = userContext?.permissions && userContext.permissions.length > 0 && userContext.permissions.includes(PERMISSIONS.CAN_VIEW_REPORT);

  const isServiceNowMenuAvailable = tenantSettings?.customConfig?.serviceNowUrl && userContext?.permissions && userContext.permissions.length > 0 && userContext.permissions.includes(PERMISSIONS.CAN_VIEW_REPORT); // permission will change.

  const isAttendanceMenuAvailable = userContext?.permissions && userContext.permissions.length > 0 && userContext.permissions.includes(PERMISSIONS.CAN_MANAGE_ATTENDANCE);

  const handleClose = () => {
    setAnchorEl(null);
  };
  const contactUS = () => {
    setAnchorEl(null);
    onClick(HEADER_CLICK_TYPES.CONTACTUS);
  };
  const handleLogout = () => {
    setAnchorEl(null);
    onClick(HEADER_CLICK_TYPES.LOGOUT);
  };
  const navigateHome = () => {
    if (location.pathname !== "/") {
      history.push("/");
    }
    setMobileProfileDrawerOpen(false);
  };
  const navigateAttendance = () => {
    setAnchorEl(null);
    if (location.pathname !== "/attendance-confirmation") {
      history.push("/attendance-confirmation");
    }
    setMobileProfileDrawerOpen(false);
  };

  const toggleNotifications = (isVisible: boolean) => {
    // setNotificationsOpen(isVisible);
    setOpenNotification(true)
    setMobileProfileDrawerOpen(false);
  };

  const handleNavigateToProfile = () => {
    setAnchorEl(null);
    if (location.pathname !== "/profile") {
      history.push("/profile");
    }
    setMobileProfileDrawerOpen(false);
  };

  const handleNavigate = () => {
    if (location.pathname !== "/catalog") {
      history.push("/catalog");
    }
  };

  const skipToMainContent = () => {
    if (location.pathname !== '/') return;
    const container: (HTMLElement | null) = document.querySelector('.mainContent')
    if (container) {
      container.tabIndex = -1;
      container.focus()
    }
  }
  return (
    <Box
      display="flex"
      alignItems="center"
      justifyContent={!isMobile && "space-between"}
      height={{ xs: "50px", sm: "70px" }}
      width="100%"
      bgcolor={portalSettingsManager.header?.colors?.base?.back || "#FFFFFF"}
    >
      <MobileSearch
        showSearch={showMobileSearch}
        setShowSearch={setShowMobileSearch}
        handleNavigate={handleNavigate}
      />
      <Box
        display={{ xs: "flex", sm: "none" }}
        alignItems="center"
        justifyContent="center"
        position={!isMobile && "absolute"}
        left="10px"
      >
        <IconButton onClick={() => setMobileProfileDrawerOpen(true)}>
          {userContext && !userContext.showSurvey && !isSurveyCompleted ? (
            <MobileBadge variant="standard" color="default" menu>
              <MenuIcon fontSize="small" />
            </MobileBadge>
          ) : (
            <MobileBadge variant="dot" color="secondary" menu>
              <MenuIcon fontSize="small" style={{ color: "white" }} />
            </MobileBadge>
          )}
        </IconButton>
      </Box>
      <MobileDrawer
        isOpen={mobileProfileDrawerOpen}
        onVisibilityChange={setMobileProfileDrawerOpen}
      >
        <Box>
          <Box m="15px 0" style={{ fontSize: "14px", fontWeight: "bold" }}>
            {t('menu')}
          </Box>
          <Action onClick={navigateHome} fullWidth mobile={isMobile}>
            <Box position="relative" marginRight="35px">
              <HomeIcon
                style={{
                  position: "absolute",
                  top: "-12px",
                  left: "3px",
                  width: "30px",
                  height: "30px",
                }}
              />
            </Box>
            {t('home')}
          </Action>
          {userContext && (
            <>
              {((notificationCount && notificationCount > 0) ||
                (newNotificationCount && newNotificationCount > 0) ||
                (userContext.showSurvey && !isSurveyCompleted) || !isClearNotification) && (
                  <Action onClick={() => toggleNotifications(true)} fullWidth mobile={isMobile}>
                    <Box position="relatvie" marginRight="35px">
                      <MobileBadge color="secondary" variant="dot">
                        <BellIcon
                          style={{
                            position: "absolute",
                            top: "-12px",
                            left: "3px",
                            width: "30px",
                            height: "30px",
                          }}
                          textColor={portalSettingsManager.header?.colors?.bellIcon?.text || "none"}
                          backgroundColor={portalSettingsManager.header?.colors?.bellIcon?.back || "none"}
                          borderColor={portalSettingsManager.header?.colors?.bellIcon?.border || "none"}
                        />
                      </MobileBadge>
                    </Box>
                    {`${t('notifications')} (${newNotificationCount})`}
                  </Action>
                )}
            </>
          )}
          <Action onClick={handleNavigateToProfile} fullWidth mobile={isMobile}>
            <div style={{ width: "100%" }}>
              <Box style={{ fontSize: "14px" }}>
                <Box position="relative" marginRight="35px">
                  <img
                    style={{
                      position: "absolute",
                      top: "-10px",
                      left: "5px",
                    }}
                    alt='Profile Avatar'
                    src={profileAvatar}
                  />
                </Box>
                {t('profile')}
              </Box>
              <ArrowIcon
                width="18px"
                height="18px"
                stroke={theme.palette.primary.main}
                viewBox="0 0 14 11"
                contentType={`${t("arrowicon_tooltip_title")} ${t('profile')}`}
              />
            </div>
          </Action>
          <Box
            style={{
              marginTop: "20px",
              marginBottom: "20px",
              maxWidth: "325px",
              borderTop: "1px Solid #d8d8d8",
            }}
          ></Box>
          {isReportMenuAvailable &&
            <Action
              onClick={() => {
                setAnchorEl(null);
                onClick(HEADER_CLICK_TYPES.REPORT);
              }}
              fullWidth
              mobile={isMobile}
            >
              <div style={{ width: "100%" }}>
                <Box style={{ fontSize: "14px" }}>
                  <Box position="relative" marginRight="35px">
                    <img
                      style={{
                        position: "absolute",
                        top: "-10px",
                        left: "5px",
                      }}
                      alt='Reporting'
                      src={reporting}
                    />
                  </Box>
                  {t('reporting')}
                </Box>
                <ArrowIcon
                  width="18px"
                  height="18px"
                  stroke={theme.palette.primary.main}
                  viewBox="0 0 14 11"
                  contentType={`${t("arrowicon_tooltip_title")} ${t('view_reporting')}`}
                />
              </div>
            </Action>}
          {isServiceNowMenuAvailable && <Action
            onClick={() => {
              setAnchorEl(null);
              onClick(HEADER_CLICK_TYPES.SERVICENOW);
            }}
            fullWidth
            mobile={isMobile}
          >
            <div style={{ width: "100%" }}>
              <Box style={{ fontSize: "14px" }}>
                <Box position="relative" marginRight="35px">
                  <img
                    style={{
                      position: "absolute",
                      top: "-10px",
                      left: "5px",
                    }}
                    alt='Incident Management'
                    src={incident}
                  />
                </Box>
                {t('incident_management')}
              </Box>
              <ArrowIcon
                width="18px"
                height="18px"
                stroke={theme.palette.primary.main}
                viewBox="0 0 14 11"
                contentType={`${t("arrowicon_tooltip_title")} ${t('incident_management')}`}
              />
            </div>
          </Action>}
          <Action onClick={contactUS} fullWidth mobile={isMobile}>
            <Box style={{ fontSize: "14px" }}>
              <Box position="relatvie" marginRight="35px">
                <img
                  style={{
                    position: "absolute",
                    left: "5px",
                    width: "20px",
                  }}
                  src={contact}
                  alt='Contact Us'
                />
              </Box>
              {t('contact_us')}
            </Box>
          </Action>
          <Action onClick={handleLogout} fullWidth mobile={isMobile}>
            <Box style={{ fontSize: "14px" }}>
              <Box position="relatvie" marginRight="35px">
                <img
                  style={{
                    position: "absolute",
                    left: "5px",
                    width: "20px",
                  }}
                  src={logoutIcon}
                  alt='Logout icon'
                />
              </Box>
              {t('log_out')}
            </Box>
          </Action>
        </Box>
      </MobileDrawer>
      <Link
        to="/"
        style={
          isMobile
            ? {
              textDecoration: "none",
              display: "flex",
              justifyContent: "center",
              alignContent: "center",
              flex: "1 1 auto",
            }
            : { textDecoration: "none" }
        }
        aria-label={t("aria_label_welcome_header")}
        onClick={skipToMainContent}
      >
        <Box
          display="flex"
          alignItems="center"
          justifyContent={{ xs: "center", sm: "start" }}
          width="100%"
          marginLeft={{ sm: "15px" }}
          maxWidth={260}
        >
          {portalSettingsManager &&
            portalSettingsManager?.header &&
            portalSettingsManager?.header?.logo &&
            portalSettingsManager?.header?.logo?.url && (
              <Box margin={{ xs: "0 17px 0 0", sm: "0 38px 0 31px" }} height="20px" display='flex' alignItems="center">
                <img
                  src={portalSettingsManager?.header?.logo?.url || ""}
                  style={{
                    width: `${portalSettingsManager?.header?.logo?.widthInPixel || `50`}px`,
                    height: `${portalSettingsManager?.header?.logo?.heightInPixel || `20`}px`,
                  }}
                  alt='Application logo'
                />
              </Box>
            )}
          {portalSettingsManager?.application?.common?.applicationName && (
            <Typography
              style={{
                fontSize: "3.8vh",
                letterSpacing: "3.4px",
                color:
                  portalSettingsManager.header?.colors?.base?.text || theme.palette.grey["800"],
                fontWeight: "bold",
              }}
            >
              {portalSettingsManager.application?.common?.applicationName}
            </Typography>
          )}
        </Box>
      </Link>

      {isMobile ? (
        <Box style={{ display: "unset" }}>
          <IconButton onClick={() => setShowMobileSearch(true)} className={focusClass.focusItem}>
            <SearchIcon style={{ color: "white" }} />
          </IconButton>
        </Box>
      ) : (
        <Box
          display={{ xs: "none", sm: "flex" }}
          justifyContent="center"
          style={{ width: "800px", height: "40px" }}
        >
          {showSearch && <Search onSubmit={handleNavigate} height="40px" />}
        </Box>
      )}

      <Box alignItems="center" display={{ xs: "none", sm: "flex" }}>
        {userContext && (
          <>
            {((notificationCount && notificationCount > 0) ||
              (newNotificationCount && newNotificationCount > 0) ||
              (userContext.showSurvey && !isSurveyCompleted)) &&
              !isClearNotification && (
                <Tooltip zIndex={1000} title={t("notification_center")} className="header-tooltip">
                  <Notification
                    onClick={onClick}
                    visible={notificationsOpen}
                    setVisibility={toggleNotifications}
                    notificationCount={newNotificationCount}
                    isMobile
                  />
                </Tooltip>
              )}
            <Box>
              <Link to="/profile" style={{ cursor: "pointer" }} title={t("profile")} aria-label={t("click_profile")}>
                <Tooltip zIndex={1000} title={t("profile")} className="header-tooltip">
                  <UserIconWrapper />
                </Tooltip>
              </Link>
            </Box>
            <Box>
              <IconButton
                aria-controls="main-menu"
                aria-label={t("three_dot")}
                aria-haspopup="true"
                style={{
                  paddingRight: Boolean(anchorEl) ? "30px" : "",
                  color: portalSettingsManager.header?.colors?.base?.text || "none",
                  border: "2px solid transparent"
                }}
                onClick={handleClick}
                tabIndex={0}
                className={focusClass.focusItem}
              >
                <MoreVertIcon />
              </IconButton>
              <Menu
                id="main-menu"
                anchorEl={anchorEl}
                keepMounted
                open={Boolean(anchorEl)}
                onClose={handleClose}
                className={classes.root}
              >
                {isReportMenuAvailable && (
                  <MenuItem
                    onClick={() => {
                      setAnchorEl(null);
                      onClick(HEADER_CLICK_TYPES.REPORT);
                    }}
                    style={{ height: "30px", fontSize: "12px" } as CSSProperties}
                    onMouseEnter={(e) =>
                      ((e.target as HTMLElement).style.backgroundColor = "#f1f1f1")
                    }
                    onMouseLeave={(e) =>
                      ((e.target as HTMLElement).style.backgroundColor = "white")
                    }
                    className={`${classes.root}  ${focusClass.focusItem}`}
                    tabIndex={0}
                  >
                    {t('view_reporting')}
                  </MenuItem>
                )}
                {isServiceNowMenuAvailable && (
                  <MenuItem
                    onClick={() => {
                      setAnchorEl(null);
                      onClick(HEADER_CLICK_TYPES.SERVICENOW);
                    }}
                    style={{ height: "30px", fontSize: "12px" } as CSSProperties}
                    onMouseEnter={(e) =>
                      ((e.target as HTMLElement).style.backgroundColor = "#f1f1f1")
                    }
                    onMouseLeave={(e) =>
                      ((e.target as HTMLElement).style.backgroundColor = "white")
                    }
                    className={`${classes.root}  ${focusClass.focusItem}`}
                    tabIndex={0}
                  >
                    {t('incident_management')}
                  </MenuItem>
                )}
                {isAttendanceMenuAvailable && (

                  <MenuItem
                    onClick={navigateAttendance}
                    style={{ height: "30px", fontSize: "12px" } as CSSProperties}
                    onMouseEnter={(e) => ((e.target as HTMLElement).style.backgroundColor = "#f1f1f1")}
                    onMouseLeave={(e) => ((e.target as HTMLElement).style.backgroundColor = "white")}
                    className={`${classes.root}  ${focusClass.focusItem}`}
                    tabIndex={0}
                  >
                    {t('manage_attendance_completion_menu')}
                  </MenuItem>
                )}
                <MenuItem
                  onClick={contactUS}
                  className={`${classes.root}  ${focusClass.focusItem}`}
                  style={{ height: "30px", fontSize: "12px" } as CSSProperties}
                  onMouseEnter={(e) => ((e.target as HTMLElement).style.backgroundColor = "#f1f1f1")}
                  onMouseLeave={(e) => ((e.target as HTMLElement).style.backgroundColor = "white")}
                  tabIndex={0}
                >
                  {t('contact_us')}
                </MenuItem>
                <MenuItem
                  onClick={handleLogout}
                  className={`${classes.root}  ${focusClass.focusItem}`}
                  style={{ height: "30px", fontSize: "12px" } as CSSProperties}
                  onMouseEnter={(e) => ((e.target as HTMLElement).style.backgroundColor = "#f1f1f1")}
                  onMouseLeave={(e) => ((e.target as HTMLElement).style.backgroundColor = "white")}
                  tabIndex={0}
                >
                  {t('log_out')}
                </MenuItem>
              </Menu>
            </Box>
          </>
        )}
      </Box>
    </Box>
  );
};

const UserIconWrapper = () => {
  return (
    <UserIcon
      stroke={portalSettingsManager.header?.colors?.profileIcon?.text}
      fill={portalSettingsManager.header?.colors?.profileIcon?.back}
    />
  );
};
