import { useLazyQuery } from "@apollo/client";
import {
  Box,
  Button,
  ButtonProps,
  IconButton,
  IconButtonProps,
  Table,
  TableBody,
  TableCell as MuiTableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  useMediaQuery,
} from "@material-ui/core";
import { Theme, withStyles, useTheme, styled } from "@material-ui/core/styles";
import { KeyboardArrowDown, KeyboardArrowUp } from "@material-ui/icons";
import React, { useEffect, useState } from "react";
import { Activities_activities } from "utils/graphql/Activities";
import * as ActivityUrlTypes from "utils/graphql/ActivityURL";
import * as AssignmentTemplateTypes from "utils/graphql/AssignmentTemplate";
import { RenderHTML, SessionDialogInfo, UploadFile } from "components";
import { GET_ACTIVITY_URL, GET_ASSIGNMENT_TEMPLATE } from "utils/queries";
import { InfoOutlined } from "@material-ui/icons";
import { LaunchConfirmDialog } from "./launch-confirm-dialog";
import { useAppDispatch, UPDATE_COURSE_IN_PROGRESS_FLAG } from "store";
import { KLP_COURSE_WINDOW_NAME } from "utils/constants";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";
import { openUrlUtil } from "hooks/open-url";
import { ActivityType } from "utils/graphql/Global";

const Toggle = withStyles((theme: Theme) => ({
  root: (props: IconButtonProps) =>
    props.className == "expanded"
      ? {
        borderRadius: "50%",
        "& svg": {
          transform: "rotate(180deg)",
        },
      }
      : {
        color: theme.palette.grey["800"],
        "& svg": {
          transform: "none",
        },
      },
}))(IconButton);
Toggle.displayName = "Toggle";

const Launch = withStyles((theme: Theme) => ({
  root: (props: ButtonProps) =>
    props.className == "expanded"
      ? {
        color: theme.palette.primary.main,
        border: `1px solid ${theme.palette.primary.main}`,
        "&:focus": {
          border: '2px solid #000'
        }
      }
      : {
        "&:focus": {
          border: '2px solid #000'
        }
      },
}))(Button);
Launch.displayName = "Launch";

const SessionData = withStyles((theme: Theme) => ({
  root: ({ isMobile }: { isMobile?: boolean }) => ({
    "& > div": {
      flex: isMobile ? "1 0 49%" : "1 0 16.66%",
      marginTop: "15px",
      fontSize: isMobile ? "12px" : undefined,
      fontWeight: isMobile ? "bold" : undefined,
      "& > span": {
        fontSize: "12px",
        fontWeight: 400,
        color: theme.palette.grey["500"],
        marginBottom: isMobile ? "5px" : undefined,
        display: isMobile ? "inline-block" : undefined,
      },
    },
  }),
}))(Box);
SessionData.displayName = "SessionData";

const TableCell = withStyles((theme: Theme) => ({
  root: {
    fontSize: "12px",
    color: theme.palette.grey["800"],
  },
}))(MuiTableCell);
TableCell.displayName = "TableCell";

const DescriptionTag = styled("div")({
  wordBreak: "break-word",
  "& *": {
    maxWidth: "100% !important",
  },
});

interface ActivityProps {
  activity: Activities_activities;
  courseID: string;
  source: string;
  showHeader: boolean;
  isFirstActivity: boolean | null;
  showAction: boolean;
  showSession: boolean;
  handleEnroll: () => void;
  handleActivityRefresh: () => void;
  handleOpenWorkshop: (activityId: string) => void;
}

export const Activity = ({
  activity,
  courseID,
  showHeader,
  isFirstActivity,
  source,
  showAction,
  showSession,
  handleEnroll,
  handleActivityRefresh,
  handleOpenWorkshop,
}: ActivityProps): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const dispatch = useAppDispatch();
  const focusClass = useFocusStyles();
  // state used for controlling the dialog window showing more info about available sessions in mobile
  const [showSessionInfo, setShowSessionInfo] = useState(false);
  const [currentSession, setCurrentSession] = useState(0);
  const showMoreInfo = (sessionIndex: number) => {
    setShowSessionInfo(true);
    setCurrentSession(sessionIndex);
  };

  const [expanded, setExpanded] = useState(true);
  const [launchDialog, setLaunchDialog] = useState(false);


  const [updateActivityStatus] = useLazyQuery<ActivityUrlTypes.ActivityURL>(GET_ACTIVITY_URL);

  const [
    downloadTemplate,
    templateResponse,
  ] = useLazyQuery<AssignmentTemplateTypes.AssignmentTemplate>(GET_ASSIGNMENT_TEMPLATE, {
    fetchPolicy: "no-cache",
  });


  function toggle() {
    setExpanded(!expanded);
  }

  const { openUrl } = openUrlUtil();
  const launchCourseWindow = (courseUrl: string) => {
    const { isSuccess, windowEvent } = openUrl(courseUrl, KLP_COURSE_WINDOW_NAME);
    updateActivityStatus({
      variables: {
        activityId: String(activity.id),
        activityType: activity.type,
        courseId: courseID,
      },
    });    
    dispatch({ type: UPDATE_COURSE_IN_PROGRESS_FLAG, payload: true });
    const closeWindow = setInterval(function () {
      if (windowEvent?.closed) {
        dispatch({ type: UPDATE_COURSE_IN_PROGRESS_FLAG, payload: false });
        clearInterval(closeWindow);
        if (showSession) {
          handleEnroll();
        } else {
          handleActivityRefresh();
        }
      }
    }, 500);  
    
    if (!isFirstActivity && expanded) {
      setExpanded(false);
    }
  }

  const handleActivityButton = () => {
    if (source === "OPEN_SESAME" || source === "LINKED_IN") {
      setLaunchDialog(true);
      return false;
    }
    launchCourseWindow(activity.url);
  };

  useEffect(() => {
    if (templateResponse?.data && templateResponse?.data?.assignmentTemplateUri) {
      const { isSuccess } = openUrl(templateResponse?.data?.assignmentTemplateUri);
      if (!isSuccess) {
        return;
      }
      handleActivityRefresh();
    }
  }, [templateResponse]);

  const launchActivityURL = (activity: any) => {
    launchCourseWindow(activity.url)
    if (!isFirstActivity && expanded) {
      setExpanded(false);
    }
  }

  return (
    <Box role='table'>
      {isMobile && (
        <SessionDialogInfo
          sessions={activity.availableSessions}
          show={showSessionInfo}
          current={currentSession}
          setSession={setCurrentSession}
          setShow={setShowSessionInfo}
          name={activity.name ?? ""}
        />
      )}
      {showHeader && (
        <Box
          display="flex"
          p="0 10px 7px 60px"
          borderBottom={`1px solid ${theme.palette.grey["300"]}`}
          style={{ fontSize: "11px", color: theme.palette.grey["800"] }}
          role='row'
        >
          <Box role="columnheader" flex="1" marginLeft={"-15px"}>
            <span>{t('name').toTitleCase()}</span>
          </Box>
          <Box role="columnheader" minWidth={{ xs: "0", sm: "120px" }}>
            <span>{t('status')}</span>
          </Box>
          <Box role="columnheader" display={{ xs: "none", sm: "block" }} minWidth="115px">
            <span>{t('type')}</span>
          </Box>
          {showAction && (
            <Box role="columnheader" textAlign="left" display={{ xs: "none", sm: "flex" }} minWidth="180px">
              <span>{t('action')}</span>
            </Box>
          )}
        </Box>
      )}
      {activity?.type !== ActivityType.DIVIDER && (
        <Box
          paddingLeft={isMobile ? "4px" : "44px"}
          paddingRight="10px"
          borderBottom={`1px solid ${theme.palette.grey["300"]}`}
          className={`${expanded ? "expanded" : ""}`}
        >
          <Box
            role="row"
            display="flex"
            paddingLeft={isMobile ? "44px" : "0px"}
            alignItems="center"
            minHeight="30px"
            m="10px 0"
            style={{
              fontSize: "12px",
              color: portalSettingsManager.application?.common?.themeColor  || `${theme.palette.grey["800"]}`,
            }}
          >
            <Box role="cell" flex="1" position="relative" style={{ fontWeight: 700 }}>
              <Toggle
                aria-label={t('aria_label_click_to_toggle')+' '+activity.name}
                aria-expanded={expanded}
                size="small"
                onClick={toggle}
                style={{
                  position: "absolute",
                  top: "-3px",
                  left: "-44px",
                  backgroundColor: expanded ? portalSettingsManager.buttonColors.themed.active.back : portalSettingsManager.buttonColors?.normal?.active?.back,
                  border: expanded ? portalSettingsManager.buttonColors.themed.active.border : portalSettingsManager.buttonColors?.normal?.active?.border,
                  height: "24px",
                  width: "24px",
                }}
                className={`${expanded ? "expanded" : ""} ${focusClass.focusItem}`}
              >
                {expanded ? <KeyboardArrowDown style={{color: portalSettingsManager.buttonColors.themed.active.text || theme.palette.grey["800"]}}/> : <KeyboardArrowUp style={{color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"]}}/>}

              </Toggle>
              <span>{activity.name}</span>
            </Box>
            <Box role='cell' justifyContent="start" minWidth={{ xs: "0", sm: "120px" }} >
              <span>{t(activity.statusCode?.toLowerCase())}</span>
            </Box>
            <Box role='cell' justifyContent="start" minWidth={{ xs: "0", sm: "115px" }}>
              <Box display={{ xs: "none", sm: "block" }}>
                <span tabIndex={0} aria-label={t(activity.type.toLowerCase()) || ''}>{t(activity.type.toLowerCase())}</span>
              </Box>
            </Box>
            {showAction && (
              <Box
                textAlign="left"
                minWidth="180px"
                display={{ xs: "block", sm: "flex" }}
                role='cell'
              >
                {(activity.type !== ActivityType.ASSIGNMENT && activity?.statusCode !== "Processing" && activity?.statusCode !== "PaymentAwaited" && activity?.hasLaunchUrl) && (
                  <Launch
                    onClick={handleActivityButton}
                    style={{
                      fontSize: "10px",
                      fontWeight: 800,
                      color: expanded ? portalSettingsManager.buttonColors.themed.active.text : (portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"]),
                      border: `1px solid ${expanded ? portalSettingsManager.buttonColors.themed.active.border : (portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"])}`,
                      backgroundColor: expanded ? portalSettingsManager.buttonColors.themed.active.back : portalSettingsManager.buttonColors?.normal?.active?.back,
                      borderRadius: 0,
                      padding: "5px 15px",
                    }}
                    className={`${expanded ? "expanded" : ""} ${focusClass.focusItem} ${focusClass.border800} ${focusClass.secondaryHover}`}
                    aria-describedby={activity?.statusCode?.toLowerCase() === "enrolled" ? t('click_to_launch_course') : t('click_to_relaunch_course')}
                    aria-label={activity?.statusCode?.toLowerCase() === "enrolled" ? t('click_to_launch_course') : t('click_to_relaunch_course')}
                    role="link"
                  >
                    {activity?.statusCode?.toLowerCase() === "enrolled" ? t('launch') : t('re_launch')}
                  </Launch>
                )}
                {activity.type === ActivityType.ASSIGNMENT && (
                  <div>
                    {((!activity?.hasContent && activity?.statusCode !== "Processing" && activity?.statusCode !== "PaymentAwaited" ) ||
                      (activity?.hasContent &&
                        activity?.statusCode !== "Processing" && activity?.statusCode !== "PaymentAwaited" &&
                        activity?.statusCode !== "Enrolled")) && (
                        <div>
                          <UploadFile
                            onUploadSuccess={handleActivityRefresh}
                            activityId={activity.id}
                            courseId={courseID}
                          />
                          <br></br>
                          <Box role='cell' style={{ fontSize: "13px", color: "#333333", lineHeight: "21px" }} fontWeight={700}>
                            <RenderHTML content={`(doc, docx, pdf, txt) `} />
                          </Box>
                          <br></br>
                        </div>
                      )}
                    {activity?.statusCode === "Completed" && (
                      <Launch
                        onClick={handleActivityButton}
                        style={{
                          fontSize: "10px",
                          fontWeight: 800,
                          color:portalSettingsManager.buttonColors.normal.active.text || theme.palette.grey["800"],
                          border: `1px solid ${portalSettingsManager.buttonColors.normal.active.border || theme.palette.grey["800"]}`,
                          backgroundColor: portalSettingsManager.buttonColors.normal.active.back || "transparent",
                          borderRadius: 0,
                          padding: "5px 15px",
                        }}
                        className={`${expanded ? "expanded" : ""}`}
                        title={t('download_msg')}
                        aria-label={t('download_stored_file')}
                      >
                        {t('download_stored_file')}
                      </Launch>
                    )}
                  </div>
                )}
              </Box>
            )}
          </Box>
          {expanded && (
            <>
              <Box
                style={{
                  marginTop: isMobile ? "25px" : "0px",
                  paddingTop: "5px",
                  //borderTop: `1px solid ${theme.palette.grey["300"]}`,
                }}
                role='row'
              >
                <Typography role='cell' style={{ fontSize: "13px", color: "#333333", fontWeight: 700 }}>
                  {t('details').toTitleCase()}
                </Typography>
                <Box
                  m="10px 0 30px 0"
                  style={{ fontSize: "13px", color: theme.palette.grey["800"], lineHeight: "21px" }}
                
                  role='cell'
                >
                  <DescriptionTag>
                    <RenderHTML content={activity.description ? activity.description : ""} />
                  </DescriptionTag>
                </Box>
              </Box>
              {showSession && (
                <>
                  {activity.bookedSession && (
                    <Box role='row'>
                      {activity.hasSessionInfo && (
                        <>
                          <Typography
                            style={{
                              fontSize: "14px",
                              fontWeight: 700,
                              color: theme.palette.grey["800"],
                            }}
                            tabIndex={0}
                            role='columnheader'
                          >
                            {t('session_details')}
                          </Typography>
                          <SessionData role='row' isMobile={isMobile} display="flex" flexWrap="wrap">
                            <div role='cell'>
                              <span tabIndex={0}>{t('session_id')}</span>
                              <div tabIndex={0}>{activity.bookedSession.externalSessionId}</div>
                            </div>
                            {isMobile && <div />}
                            <div role='cell'>
                              <span tabIndex={0}>{t('start')}</span>
                              <div tabIndex={0}>{activity.bookedSession.startDateTimeDisplay}</div>
                            </div>
                            <div role='cell'>
                              <span tabIndex={0}>{t('end')}</span>
                              <div tabIndex={0}>{activity.bookedSession.endDateTimeDisplay}</div>
                            </div>
                            <div role='cell'>
                              <span tabIndex={0}>{t('duration')}</span>
                              <div tabIndex={0}>{activity.bookedSession.duration}</div>
                            </div>
                            <div role='cell'>
                              <span>{t('location')}</span>
                              <div>{activity.bookedSession.location}</div>
                            </div>
                            {!isMobile && <div />}
                            <div role='cell'>
                              <span>{t('venue_name')}</span>
                              <div>{activity.bookedSession.address?.name}</div>
                            </div>
                            <div role='cell'>
                              <span>{t('venue_address_1')}</span>
                              <div>{activity.bookedSession.address?.streetAddress1}</div>
                            </div>
                            <div role='cell'>
                              <span>{t('venue_address_2')}</span>
                              <div>{activity.bookedSession.address?.streetAddress2}</div>
                            </div>
                            <div role='cell'>
                              <span>{t('venue_city')}</span>
                              <div>{activity.bookedSession.address?.city}</div>
                            </div>
                            {activity.bookedSession.address?.state && (
                              <div role='cell'>
                                <span>{t('venue_state')}</span>
                                <div>{activity.bookedSession.address?.state}</div>
                              </div>
                            )}
                            {activity.bookedSession.address?.country && (
                              <div role='cell'>
                                <span>{t('venue_country')}</span>
                                <div>{activity.bookedSession.address?.country}</div>
                              </div>
                            )}
                            <div role='cell'>
                              <span>{t('venue_postal_code')}</span>
                              <div>{activity.bookedSession.address?.postalCode}</div>
                            </div>
                            <div />
                          </SessionData>
                        </>
                      )}
                    </Box>
                  )}
                  {activity.availableSessions && activity.availableSessions.length > 0 && (
                    <Box>
                      <Box>
                        {activity.hasSessionInfo && (
                          <>
                            <Box
                              display="flex"
                              justifyContent="space-between"
                              alignItems="center"
                              m="15px 0"
                              role='row'
                            >
                              <Typography
                                style={{
                                  fontSize: "14px",
                                  fontWeight: 700,
                                  color: theme.palette.grey["800"],
                                }}
                                role='columnheader'
                              >
                                {t('available_sessions')}
                              </Typography>
                              <div role='columnheader'>
                                <Button
                                  // disabled
                                  style={{
                                    fontSize: "10px",
                                    fontWeight: 700,
                                    color: theme.palette.primary.main,
                                    border: `1px solid ${theme.palette.primary.main}`,
                                    borderRadius: 0,
                                    height: "32px",
                                    width: "120px",
                                  }}
                                  onClick={() => handleOpenWorkshop(activity.id as string)}
                                  className={`${focusClass.primaryHover}`}
                                >
                                  {t('suggest_a_date').toUpperCase()}
                                </Button>
                              </div>
                            </Box>
                            <Box>
                              <TableContainer>
                                <Table aria-label={t('aria_label_simple_table')}>
                                  <TableHead>
                                    <TableRow>
                                      {isMobile ? (
                                        <>
                                          <TableCell align="left" style={{ fontWeight: 700 }}>
                                            {t('start_enddate_time')}
                                          </TableCell>
                                          <TableCell></TableCell>
                                        </>
                                      ) : (
                                        <>
                                          <TableCell tabIndex={0} align="left" style={{ fontWeight: 700 }} scope="col">
                                            {t('start_date_time')}
                                          </TableCell>
                                          <TableCell tabIndex={0} align="left" style={{ fontWeight: 700 }} scope="col">
                                            {t('end_date_time')}
                                          </TableCell>
                                          <TableCell tabIndex={0} align="left" style={{ fontWeight: 700 }} scope="col">
                                            {t('location')}
                                          </TableCell>
                                          <TableCell tabIndex={0} align="center" style={{ fontWeight: 700 }} scope="col">
                                            {t('open_seats')}
                                          </TableCell>
                                        </>
                                      )}
                                    </TableRow>
                                  </TableHead>
                                  <TableBody>
                                    {isMobile
                                      ? activity.availableSessions.map((row, index) => {
                                        return (
                                          <React.Fragment key={"mobile_" + index}>
                                            <TableRow>
                                              <TableCell align="left" tabIndex={0} >
                                                <Box>{row?.startDateTimeDisplay}</Box>
                                                <Box>{row?.endDateTimeDisplay}</Box>
                                              </TableCell>
                                              <TableCell tabIndex={0} >
                                                <IconButton
                                                  color="primary"
                                                  onClick={() => showMoreInfo(index)}
                                                >
                                                  <InfoOutlined />
                                                </IconButton>
                                              </TableCell>
                                            </TableRow>
                                          </React.Fragment>
                                        );
                                      })
                                      : activity.availableSessions.map((row, index) => {
                                        return (
                                          <React.Fragment key={index}>
                                            {row && (
                                              <TableRow key={index}>
                                                <TableCell align="left" tabIndex={0} >
                                                  {row.startDateTimeDisplay}
                                                </TableCell>
                                                <TableCell align="left" tabIndex={0} >
                                                  {row.endDateTimeDisplay}
                                                </TableCell>
                                                <TableCell align="left" tabIndex={0} >{row.location}</TableCell>
                                                <TableCell align="center" tabIndex={0} >
                                                  {row.noOfSeatsAvailable}
                                                </TableCell>
                                              </TableRow>
                                            )}
                                          </React.Fragment>
                                        );
                                      })}
                                  </TableBody>
                                </Table>
                              </TableContainer>
                            </Box>
                          </>
                        )}
                      </Box>
                    </Box>
                  )}
                </>
              )}
              {(activity?.type === ActivityType.ASSIGNMENT &&
                activity?.hasContent &&
                activity?.statusCode !== "Processing" && activity?.statusCode !== "PaymentAwaited" &&
                showAction) && (
                  <div
                    style={{
                      color: theme.palette.primary.main,
                      cursor: "pointer",
                      margin: "15px 0px",
                      fontSize: "14px",
                    }}
                    onClick={() =>
                      downloadTemplate({
                        variables: {
                          activityId: String(activity.id),
                          programmeId: courseID,
                        },
                      })
                    }
                  >
                    {t('download_template')}
                  </div>
                )}
            </>
          )}
        </Box>
      )}
      {activity?.type === ActivityType.DIVIDER && (
        <>
        <Box role="cell" flex="1" position="relative" style={{ fontWeight: 700, fontSize: "14px", margin: "10px" }}>
          <span tabIndex={0}>{activity.name}</span>
        </Box>
        <Box
        m="10px 0 10px 10px"
        style={{ fontSize: "13px", color: theme.palette.grey["500"], lineHeight: "21px" }}
      
        role='cell'
      >
        <DescriptionTag>
          <RenderHTML content={activity.description ? activity.description : ""} />
        </DescriptionTag>
      </Box>
      </>
      )}
      {launchDialog && (
        <LaunchConfirmDialog
          open={launchDialog}
          type={source}
          courseId={courseID}
          handleActivityRefresh={handleActivityRefresh}
          loadActivityURL={() => launchActivityURL(activity)}
          activityId={String(activity.id)}
          handleClose={() => setLaunchDialog(false)}
        />
      )}
    </Box>
  );
};
