import {
  Typography,
  Dialog,
  DialogProps,
  DialogContent,
  Button as MuiButton,
} from "@material-ui/core";
import { Theme, withStyles, useTheme } from "@material-ui/core/styles";
import { DialogActions, LTIForm } from "components";
import linkedInIcon from "assets/icons/icon-logo-linkedIn.svg";
import opensesameIcon from "assets/icons/icon-logo-opensesame.svg";
import { ContentSource } from "utils/graphql/Global";
import { useEffect, useState } from "react";
import { useAppDispatch, UPDATE_COURSE_IN_PROGRESS_FLAG } from "store";
import { useTranslation } from "react-i18next";
import { useFocusStyles } from "hooks/focusBorder";
import portalSettingsManager from "utils/portalSettingsManager";

const Button = withStyles((theme: Theme) => ({
  root: {
    flex: 1,
    borderRadius: 0,
    width: "100%",
    color: theme.palette.primary.main,
  },
  label: {
    fontSize: 11,
    fontWeight: 700,
  },
  outlined: {
    border: `1px solid ${theme.palette.primary.main}`,
  },
  disabled: {
    color: theme.palette.grey["500"],
  },
}))(MuiButton);

type ConfirmDialogProps = DialogProps & {
  open: boolean;
  handleClose: () => void;
  loadActivityURL: () => void;
  handleActivityRefresh: () => void;
  type: string;
  courseId: string;
  activityId: string;
};
export const LaunchConfirmDialog = ({
  open,
  handleClose,
  type,
  loadActivityURL,
  courseId,
  handleActivityRefresh,
  activityId,
  ...props
}: ConfirmDialogProps): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const [isSubmit, setIsSubmit] = useState(false);
  const [initiateForm, setInitiateForm] = useState(false);
  const [dataLoading, setDataLoading] = useState(false);
  const launchLinkedInWithLTI = portalSettingsManager?.application?.features?.launchLinkedInWithLTI;

  const dispatch = useAppDispatch();
  useEffect(() => {
    if (type === ContentSource.OPEN_SESAME) {
      dispatch({
        type: "loader/showandhide",
        payload: { show: dataLoading, message: t('loading') },
      });
    }
  }, [dataLoading, dispatch, t]);
  const launchCourse = (type: string) => {
    if (type === ContentSource.LINKED_IN) {
      if (!launchLinkedInWithLTI) {
        loadActivityURL();
        handleClose();
      } else {
        setIsSubmit(true);
      }
    } else if (type === ContentSource.OPEN_SESAME) {
      setIsSubmit(true)
    }
  };
  const onSubmited = (): void => {
    handleClose();
  }
  const continueCourse = (type: string) => {
    if (type === ContentSource.OPEN_SESAME  || (type === ContentSource.LINKED_IN && launchLinkedInWithLTI)) {
      setInitiateForm(true);
      setDataLoading(true);
    } else {
      launchCourse(type)
    }
  }
  const focusClass = useFocusStyles();
  const srcUrlTitle =
  type=== "OPEN_SESAME"
  ? "OpenSesame"
  : type === "LINKED_IN"
    ? "LinkedIn"
    : ""; 

  return (
    <Dialog
      id="Confirmation_dialog"
      onClose={() => handleClose()}
      tabIndex={0}
      open={open}
      {...{
        disableBackdropClick: true,
        disableEscapeKeyDown: true,
        ...props,
      }}
      role="dialog" aria-labelledby="launch_dialog_label" aria-modal="true"
    >
      <DialogContent>
        <header
        role="heading"
         aria-label={srcUrlTitle || ''}
         aria-level={2}
          style={{
            backgroundImage: `url(${type === "OPEN_SESAME" ? opensesameIcon : type === "LINKED_IN" ? linkedInIcon : ""
              })`,
            backgroundPosition: "center center",
            backgroundRepeat: "no-repeat",
            height: "40px",
            margin: "20px",
          }}
        ></header>

        <Typography style={{ fontSize: "14px", color: theme.palette.grey["800"], fontWeight: 600 }} id="launch_dialog_label">
          {t('external_course_redirect_dialog_1')}
        </Typography>
        <Typography
          style={{
            fontSize: "14px",
            marginTop: "10px",
            color: theme.palette.grey["800"],
            fontWeight: 600,
          }}
        >
          {t('external_course_redirect_dialog_2')}
        </Typography>
        <Typography
          style={{
            fontSize: "14px",
            color: theme.palette.grey["800"],
            fontWeight: 600,
            lineHeight: "16px",
            marginTop: "10px",
          }}
        >
          {t('progress_update_note')}
        </Typography>
      </DialogContent>
      <DialogActions>
        <Button
          className={focusClass.focusItem}
          tabIndex={0} onClick={handleClose} style={{ color: theme.palette.grey["500"], width: "100%" }}>
          {t('no_cancel_close')}
        </Button>
        <Button
          color="primary"
          // disabled={dataLoading}
          variant="outlined"
          onClick={() => { continueCourse(type) }}
          tabIndex={0}
          className={focusClass.focusItem}

        >
          {t('yes_continue')}
        </Button>
      </DialogActions>
      {(type === ContentSource.OPEN_SESAME || type === ContentSource.LINKED_IN) &&  initiateForm  ? <LTIForm
        handleActivityRefresh={handleActivityRefresh}
        dataLoaded={() => { setDataLoading(false); launchCourse(type) }}
        isSubmit={isSubmit}
        onSubmitted={onSubmited}
        courseId={courseId}
        activityId={activityId}
        type={type}
      ></LTIForm> : ""}
    </Dialog>
  );
};
