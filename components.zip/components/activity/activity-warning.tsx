import {
    Box,
    Typography
} from "@material-ui/core";
import { withStyles } from '@material-ui/core/styles';
import * as CanLaunchCourseByPathWays from "utils/graphql/CanLaunchCourseBySequencialPathway";
import { Trans, useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { colors } from "components/theme/colors";

const WarningMessage = withStyles(() => ({
    root: {
        color: colors.orange["500"],
        fontSize: '12px',
        fontWeight: 'bold',
        marginBottom: '1rem',
    }
}))(Typography);
interface ActivityWarningProps {
  data?: CanLaunchCourseByPathWays.CanLaunchCourseBySequencialPathway;
  onClick?: () => void;
}

export function ActivityWarning({ data, onClick }: ActivityWarningProps): JSX.Element {
    const localeKey = getWarningMessageKey(data);
    const { t } = useTranslation();

const handleClick = () => {
  if (onClick) {
    onClick();
  }
};

    return (
        localeKey ? <Box>
            <WarningMessage>
                <Trans i18nKey={localeKey} t={t}>
                    <span>
                        {data?.canLaunchCourseBySequencialPathway?.blockingPathways?.map(pathway => (
                            <Link onClick={handleClick} key={pathway?.id} to={`/PATHWAY/${pathway?.id}`} style={{ margin: '0 2px', textDecoration: 'underline' }}>
                                {pathway?.name}
                            </Link>
                        ))}
                    </span>
                </Trans>
            </WarningMessage>
        </Box> : <></>
    )
}

export const getWarningMessageKey = (data?: CanLaunchCourseByPathWays.CanLaunchCourseBySequencialPathway): string => {
    const blockingPathwayNames: string[] = [];
    if (data?.canLaunchCourseBySequencialPathway?.blockingPathways?.length) {
        data?.canLaunchCourseBySequencialPathway?.blockingPathways.forEach(pathway => {
            if (pathway && pathway.name) {
                blockingPathwayNames.push(pathway.name)
            }
        });
    }
    if (Boolean(data?.canLaunchCourseBySequencialPathway?.canLaunch) || (!Boolean(data?.canLaunchCourseBySequencialPathway?.canLaunch) && blockingPathwayNames.length === 0)) {
        return "";
    }
    return blockingPathwayNames?.length === 1 ? "activity_warning_previous_course" : "activity_warning_previous_course_multiple";
}
