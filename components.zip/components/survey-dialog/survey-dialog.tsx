import { useMutation, useQuery } from "@apollo/client";
import { Box, useMediaQuery, Button } from "@material-ui/core";
import MuiDialogActions from "@material-ui/core/DialogActions";
import MuiDialogContent from "@material-ui/core/DialogContent";
import MuiDialogTitle from "@material-ui/core/DialogTitle";
import FormControl from "@material-ui/core/FormControl";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormLabel from "@material-ui/core/FormLabel";
import Radio, { RadioProps } from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import { makeStyles, Theme, withStyles, useTheme } from "@material-ui/core/styles";
import { useAppDispatch } from "store";
import clsx from "clsx";
import { RenderHTML, Dialog, Action } from "components";
import { useEffect, useState } from "react";
import { KeyValuePairOfGuidAndGuidInput, SaveSurveyInput } from "utils/graphql/Global";
import * as SurveyTypes from "utils/graphql/SurveyData";
import { SAVE_SURVEY, SURVEY_DATA } from "utils/queries";
import { Loader } from "components/loader/loader";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";

const DialogTitle = withStyles(() => ({
  root: {
    justifyContent: "flex-end",
    padding: 0,
  },
  svg: {
    float: "right",
  },
}))(MuiDialogTitle);

const DialogActions = withStyles(() => ({
  root: {
    display: "flex",
    padding: "30px",
  },
}))(MuiDialogActions);

const DialogContent = withStyles((theme: Theme) => ({
  root: {
    minHeight: 350,
    "&::-webkit-scrollbar": {
      width: "0.4em",
    },
    "&::-webkit-scrollbar-track": {
      boxShadow: "inset 0 0 6px rgba(0,0,0,0.00)",
      webkitBoxShadow: "inset 0 0 6px rgba(0,0,0,0.00)",
    },
    "&::-webkit-scrollbar-thumb": {
      backgroundColor: theme.palette.grey["300"],
      borderRadius: "2.5px",
    },
    margin: "0px 30px",
    padding: "unset",
    borderBottom: `1px solid ${theme.palette.grey["300"]}`,
    borderTop: `1px solid ${theme.palette.grey["300"]}`,
    overflowY: 'initial',
  },
}))(MuiDialogContent);
const useStyles = makeStyles((theme: Theme) => ({
  root: {
    marginLeft: "1px",
    "&:hover": {
      backgroundColor: "transparent",
    },
  },
  icon: {
    borderRadius: "50%",
    width: 14,
    height: 14,
    border: `1px solid ${theme.palette.grey["A100"]}`,
    backgroundColor: theme.palette.common.white,
  },
  checkedIcon: {
    backgroundColor: theme.palette.primary.main,
  },
  attendRadio: {
        border:"2px solid #000 !important"
  }
}));

const StyledRadio = (props: RadioProps): JSX.Element => {
  const classes = useStyles();

  return (
    <Radio
      focusVisibleClassName={classes.attendRadio}
      className={classes.root}
      tabIndex={0}
      // disableRipple
      color="default"
      checkedIcon={<span className={clsx(classes.icon, classes.checkedIcon)} />}
      icon={<span className={classes.icon} />}
      {...props}
    />
  );
};

const RadioField = withStyles((theme: Theme) => ({
  root: {
    marginTop: "27px",
    minWidth: "500px",
    " & fieldset": {
      fontFamily: "Arial",
      fontSize: "14px",
      color: theme.palette.grey["800"],
      letterSpacing: 0,
      fontWeight: 400,
      marginBottom: "13px",
      " & div": {
        float: "right",
      },
    },
    " & div": {
      "& label": {
        paddingLeft: "5px",
        margin: 0,
      },
    },
  },
}))(Box);

const SurveyTitle = withStyles((theme: Theme) => ({
  root: {
    padding: "0px 45px 0px 30px",
    "  div:nth-child(1)": {
      fontSize: "16px",
      color: theme.palette.grey["800"],
      letterSpacing: 0,
      fontWeight: 400,
      fontFamily: "Arial"
    },
    "  div:nth-child(2)": {
      fontSize: "12px",
      // color: "#767676",
      color: theme.palette.grey["A700"],
      letterSpacing: 0,
      lineHeight: "16px",
      fontWeight: 400,
      fontFamily: "Arial"
    },
  },
}))(Box);

export const SurveyDialog = ({
  open,
  handleClose,
  onSubmit,
  handleSkipSurvey,
}: {
  open: boolean;
  handleClose: () => void;
  onSubmit: () => void;
  handleSkipSurvey?: () => void;
}): JSX.Element => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [surveyData, setSurveyData] = useState<SurveyTypes.SurveyData | null>(null);
  const [surveyId, setSurveyId] = useState<SaveSurveyInput>();
  const [surveyResponse, setSurveyResponse] = useState<KeyValuePairOfGuidAndGuidInput[]>([]);
  const {
    loading: isSurveyLoading,
    data,
  } = useQuery<SurveyTypes.SurveyData>(SURVEY_DATA, {
    notifyOnNetworkStatusChange: true,
  });
  const { t } = useTranslation();
  const dispatch = useAppDispatch();

  const [saveSurvey] = useMutation(SAVE_SURVEY);

  const handleCancel = () => {
    handleDialogClose();
    handleSkipSurvey?.();
  };
  const submitSurvey = () => {
    const surveyObj: SaveSurveyInput = {
      surveyId: surveyId,
      questionIdOptionId: surveyResponse,
    };
    handleClose();
    saveSurvey({ variables: { surveyAnswer: surveyObj } })
      .then(() => {
        onSubmit();
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('survey_submit_title'),
            message: t('survey_submit_success_alert_message'),
          },
        });
      })
      .catch(() => {
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('surveysubmit_title'),
            message: t('survey_submit_error_alert_message'),
          },
        });
      });
  };
  const handleChange = (
    event: React.ChangeEvent<HTMLInputElement>,
    questionId: unknown,
    index: number
  ) => {
    const newArr = [...surveyResponse];
    newArr[index] = { value: event.target.value, key: questionId };
    setSurveyResponse(newArr);
  };
  useEffect(() => {
    if (data) {
      setSurveyId(data.survey?.surveyId);
      setSurveyData(data);
    }
  }, [data]);

  const handleDialogClose = () => {
    setSurveyResponse([]);
    handleClose();
  };

  const validateSelection = () => {
    return surveyResponse.length === 0 || JSON.stringify(surveyResponse).includes("null") || surveyResponse.length !== surveyData?.survey?.questions?.length
  }
  const focusClass = useFocusStyles();
  const DialogButton = withStyles((theme: Theme) => ({
    root: {
      borderRadius: 0,
      fontSize: "11px",
      fontWeight: 700,
      lineHeight: "12px",
      height: "42px",
      width: "143px",
      border: `1px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
      color: portalSettingsManager.buttonColors?.themed?.active?.text || theme.palette.primary.main,
      backgroundColor: portalSettingsManager.buttonColors?.themed?.active?.back,
      '&.Mui-disabled': {
        border: `1px solid ${theme.palette.primary.main}`,
      },

    },
    label: {
      fontSize: 11,
      fontWeight: 700,
    },
  }))(Button)
  return (
    <Dialog
      id="surdialog"      
      onClose={handleDialogClose}
      role="dialog" aria-modal="true"  
      aria-labelledby="dialog1_label" 
      open={open}      
      disableBackdropClick={true}
      minWidth={!isMobile ? 724 : undefined}
      maxHeight={742}
      minHeight={!isMobile ? 660 : undefined}
      fullScreen={isMobile}
      showCloseIcon      
    >
      <DialogTitle style={{ minWidth: isMobile ? "79vw" : "660px" }} aria-required="true">
        <SurveyTitle>
          <span id="dialog1_label" role="heading" style={{ fontSize: "16px",
            color: theme.palette.grey["800"],
            letterSpacing: 0,
            fontWeight: 400,
            fontFamily: "Arial"}} aria-level={2}><h2><RenderHTML content={surveyData?.survey?.title || ""} /></h2></span>
          <span role="heading" aria-level={3} style={{ fontSize: "14px", color: theme.palette.grey["500"],
      letterSpacing: 0,
      lineHeight: "16px",
      fontWeight: 400,
      fontFamily: "Arial"}}> <h3><RenderHTML content={surveyData?.survey?.htmlText || ""} /></h3></span>
        </SurveyTitle>
        <Box style={{ padding: "0px 0px 0px 30px" }}>
          <Box
            style={{
              // borderBottom: `1px solid ${theme.palette.grey['300']}`,
              fontSize: "12px",
              color: theme.palette.primary.main,
              letterSpacing: 0,
              fontWeight: 700
            }}
          >
            {surveyData && (
              <h3 style={{ fontSize: "14px" }} role="heading" aria-level={4}>
                {surveyData?.survey?.questions?.length} {t('questions')}
              </h3>
            )}
          </Box>
        </Box>
      </DialogTitle>

      <DialogContent style={{ display: "flex", flexDirection: "column", overflowX: isMobile ? "hidden" : "auto" }}>
        <Box>
          <Loader isDisplay={isSurveyLoading} type="component" message={t('survey_loading')} />
          {surveyData?.survey?.questions?.map((item, index) => {
            return (
              <RadioField key={index}>
                <FormControl component="fieldset" aria-disabled="false">
                  <FormLabel component="legend" key={index} style={{ paddingBottom: "13px", maxWidth: isMobile? "70vw": "500px" }} aria-label={`${item?.htmlText ?? ""} ${t('aria_label_madatory_field')}`} aria-required={true}>
                    {
                      <legend
                        // htmlFor="namedInput"
                        style={{
                          fontSize: "14px",
                          color: theme.palette.grey["800"],
                          paddingLeft: "15px",
                          textIndent: "-15px",
                          lineHeight: "21px"                          
                        }}                       
                      >
                        <RenderHTML content={item?.htmlText ?? ""} />
                      </legend>
                    }
                  </FormLabel>
                  <RadioGroup
                    // aria-label="radio"
                    name={`${t('question').toLowerCase()} ${index + 1}`}
                    onChange={(e) => handleChange(e, item?.questionId, index)}
                  >
                    {item?.options?.map((option, optionIndex) => {
                      return (
                        <FormControlLabel
                          key={optionIndex}
                          value={option?.optionId}
                          aria-required="true"
                          aria-label={` ${option?.htmlText ?? ""}`}
                          control={<StyledRadio />}
                          label={
                            <div
                              style={{
                                fontSize: "14px",
                                color: theme.palette.grey["800"],
                                lineHeight: "21px",
                              }}
                            >
                              <RenderHTML content={option?.htmlText ?? ""} />
                            </div>
                          }
                        />
                      );
                    })}
                  </RadioGroup>
                </FormControl>
              </RadioField>
            );
          })}
        </Box>
      </DialogContent>
      <DialogActions>
        <Action type="dialog-alt-contrast" onClick={handleCancel}>
          {t('cancel_and_close')}
        </Action>
        <DialogButton
          variant="outlined"
          className={focusClass.focusItem}
          onClick={submitSurvey}
          disabled={validateSelection()}
        >
          {t('surveysubmit_button')}
        </DialogButton>
      </DialogActions>
    </Dialog >
  );
};
