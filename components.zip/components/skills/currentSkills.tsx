import { Box, Typography, makeStyles, Theme } from "@material-ui/core";
import { useTranslation } from "react-i18next";
import { LearnerSkillAssessments_learnerSkillAssessments } from "utils/graphql/LearnerSkillAssessments";
import { Level } from "./level";

const useStyles = makeStyles((theme: Theme) => ({
    themedLabel: {
        "color": "#005EB8",
        "fontSize": "12px"
    },
    container: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        height: "160px",
        width: "160px",
        border: `1px solid ${theme.palette.grey["300"]}`,
        marginTop: `${theme.spacing()}px`
    }
}));

interface CurrentSkillProps {
    skill: LearnerSkillAssessments_learnerSkillAssessments
}

export const CurrentSkills = ({ skill }: CurrentSkillProps) => {
    const { t } = useTranslation();
    const classes = useStyles();
    return (
        <>
            <Box className={classes.container}>
                <Level skill={skill} />
                <Typography style={{ fontWeight:700, fontSize: "14px", textAlign: "center" }}>
                    {skill.skillName}
                </Typography>
                <Typography className={classes.themedLabel}>
                    {t('retake', "Retake")}
                </Typography>
            </Box>
        </>
    );
};