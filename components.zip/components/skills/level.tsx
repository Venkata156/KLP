/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import React from "react";
import { makeStyles, createStyles } from "@material-ui/core/styles";
import CircularProgress, {
    CircularProgressProps
} from "@material-ui/core/CircularProgress";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import { LearnerSkillAssessments_learnerSkillAssessments } from "utils/graphql/LearnerSkillAssessments";

// Inspired by the former Facebook spinners.
const useStyles = makeStyles(() =>
    createStyles({
        root: {
            position: "relative"
        },
        remaining: {
            color: "gray"
        },
        completed: {
            color: "#1a90ff",
            position: "absolute",
            left: 0
        },
        circle: {
            strokeLinecap: "round"
        },
        themedLabel: {
            color: "#005EB8",
            fontSize: "12px",
            lineHeight: "14px"
        },
        skillLevel: {
            color: "#005EB8",
            fontSize: "20px",
            fontWeight: "bold",
            lineHeight: "23px"
        }
    })
);

interface LevelProps extends CircularProgressProps {
    skill: LearnerSkillAssessments_learnerSkillAssessments
}

export const Level = ({ skill }: LevelProps) => {
    const classes = useStyles();
    return (
        <div className={classes.root}>
            <div>
                <CircularProgress
                    variant="determinate"
                    className={classes.remaining}
                    size={60}
                    thickness={2}
                    value={100}
                />
                <CircularProgress
                    variant="determinate"
                    disableShrink
                    className={classes.completed}
                    classes={{
                        circle: classes.circle
                    }}
                    size={60}
                    thickness={2}
                    value={skill.skillRating ? skill.skillRating * 20 : 0}
                />
                <Box
                    top={0}
                    left={0}
                    bottom={0}
                    right={0}
                    position="absolute"
                    display="flex"
                    flexDirection="column"
                    alignItems="center"
                    justifyContent="center"
                >
                    <Typography variant="body1" component="div" color="textSecondary" className={classes.themedLabel}>
                        Level
                    </Typography>
                    <Typography variant="body1" component="div" color="textSecondary" className={classes.skillLevel}>
                        {skill.skillRating || "N/A"}
                    </Typography>
                </Box>
            </div>
        </div>
    );
}
