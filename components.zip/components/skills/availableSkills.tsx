import { Box, Typography, makeStyles, Theme } from "@material-ui/core";
import { useTranslation } from "react-i18next";
import {
    AvailableSkillIcon
} from "components";
import { LearnerSkillAssessments_learnerSkillAssessments } from "utils/graphql/LearnerSkillAssessments";

const useStyles = makeStyles((theme: Theme) => ({
    themedLabel: {
        "color": "#005EB8",
        "fontSize": "12px"
    },
    container: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        height: "160px",
        width: "160px",
        border: `1px solid ${theme.palette.grey["300"]}`,
        marginTop: `${theme.spacing()}px`
    }
}));
interface AvailableSkillProps {
    skill: LearnerSkillAssessments_learnerSkillAssessments
}

export const AvailableSkills = ({ skill }: AvailableSkillProps) => {
    const { t } = useTranslation();
    const classes = useStyles();
    return (
        <>
            <Box className={classes.container}>
                <AvailableSkillIcon style={{ fontSize: "60px" }} />
                <Typography style={{ fontWeight:700, fontSize: "14px", textAlign: "center" }}>
                    {skill?.skillName}
                </Typography>
                <Typography className={classes.themedLabel}>
                    {t('take_assessment', "Take Assessment")}
                </Typography>
            </Box>
        </>
    );
};