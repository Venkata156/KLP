import React from "react";
import { Box } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";

type CarouselIndicatorsProps = {
  current: number;
  numSlides: number;
  indicatorWidth?: string;
  indicatorHeight?: string;
  indicatorGap?: string;
};
export const CarouselIndicators: React.FC<CarouselIndicatorsProps> = ({
  current,
  numSlides,
  indicatorGap="2px",
  indicatorHeight="5px",
  indicatorWidth="10px"
}) => {
  const theme = useTheme();
  return (
    <Box>
      {Array(numSlides)
        .fill(null)
        .map((_, idx) => (
          <Box
            display="inline-block"
            key={idx}
            marginRight={indicatorGap}
            width={indicatorWidth}
            height={indicatorHeight}
            bgcolor={theme.palette.grey[idx === current ? "800" : "300"]}
          />
        ))}
    </Box>
  );
};
