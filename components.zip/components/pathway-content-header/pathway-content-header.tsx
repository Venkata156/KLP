import { useLazyQuery, useMutation } from "@apollo/client";
import { Box, Typography, Button, IconButton, useMediaQuery, DialogContent } from "@material-ui/core";
import completionIcon from "assets/icons/icon-course.svg";
import pathwayIcon from "assets/icons/icon-pathway.svg";
import certificationIcon from "assets/icons/icon-certification.svg";
import sanitizeHtml from "sanitize-html";
import {
  Select,
  CertificationIcon,
  ShareIcon,
  ConfirmDialog,
  Rating,
  MobileBottomContainer as MBC,
  ContentBanner,
  NewIcon,
  RenderHTML,
  Dialog,
} from "components";
import { useAppDispatch } from "store";
import { useEffect, useRef, useState } from "react";
import LinearProgress from "@material-ui/core/LinearProgress";
import { Close } from "@material-ui/icons";
import CreateIcon from "@material-ui/icons/Create";
import { PathwayType } from "utils/types";
import * as CanChangeCompletedType from "utils/graphql/CanChangeCompletedStatusToEnroll";
import {
  SORT_ALPHABETICAL_ASCENDING,
  SORT_ALPHABETICAL_DESCENDING,
  SORT_DURATION_ASCENDING,
  SORT_DURATION_DESCENDING,
  SORT_PRICE_ASCENDING,
  SORT_PRICE_DESCENDING,
} from "utils/constants";
import {
  COMPLETE_CHANNEL_ENROLLMENT,
  COMPLETE_CHANNEL_UNENROLLMENT,
  COMPLETE_PATHWAY_UNENROLLMENT,
  DELETE_PLAYLIST,
  CAN_CHANGE_COMPLETE_TO_ENROLL,
} from "utils/queries";
import { createStyles, withStyles, Theme, useTheme, styled, makeStyles } from "@material-ui/core/styles";
import { SortType } from "utils/types";
import { useHistory, useLocation } from "react-router-dom";
import { ChannelIcon, PathwayIcon, PlayListIcon } from "components/common-icons/common-icons";
import { mobileDateString } from "utils/helpers";
import { useFocusStyles } from "hooks/focusBorder";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";

const useStyles = makeStyles({
  viewLess: {
    display: "-webkit-box",
    "-webkit-line-clamp": 2,
    "-webkit-box-orient": "vertical",
    overflow: "hidden",
  },
});

const BorderLinearProgress = withStyles((theme: Theme) =>
  createStyles({
    root: {
      height: 5,
    },
    colorPrimary: {
      backgroundColor: "#DBF3FF",
    },
    bar: {
      borderRadius: 5,
      backgroundColor: theme.palette.primary.main,
    },
  })
)(LinearProgress);

const MatrixBox = withStyles((theme: Theme) => ({
  root: (props: { bg: string; mobile?: boolean }) => ({
    position: "relative",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "column",
    textAlign: "center",
    margin: props.mobile ? "" : "0 25px",
    marginRight: props.mobile ? "5px" : undefined,
    width: props.mobile ? "18px" : undefined,
    height: props.mobile ? "17px" : undefined,
    "&:before": {
      position: "absolute",
      width: "100%",
      height: "40px",
      top: props.mobile ? -10 : 0,
      left: 0,
      bottom: 0,
      right: 0,
      content: `""`,
      backgroundImage: `url(${props.bg})`,
      backgroundPosition: "center center",
      backgroundRepeat: "no-repeat",
      opacity: 0.2,
    },
    [theme.breakpoints.down("xs")]: {
      display: props.mobile ? "flex" : "none",
    },
  }),
}))(Box);
MatrixBox.displayName = "MatrixBox";

const Matrix = ({
  bg,
  label,
  count,
  mobile = false,
  completedCount = 0,
  pageType
}: {
  bg: string;
  label?: string;
  count: number;
  mobile?: boolean;
  completedCount?: number;
  pageType: string;
}): JSX.Element => {
  const theme = useTheme();

  return (
    <MatrixBox bg={bg} mobile={mobile}>
      <Typography
        style={{
          fontSize: mobile ? "15px" : "26px",
          fontWeight: "bold",
          color: theme.palette.grey["800"],
          lineHeight: "31px",
          margin: mobile ? "2px 0px 0px 0px" : "5px 0 9px 0",
        }}
      >
        {pageType === 'parentpathway' || pageType === 'pathway' ? `${completedCount}/${count}` : count}
      </Typography>
      {label && (
        <Typography
          style={{ fontSize: "11px", color: theme.palette.grey["800"], lineHeight: "16px" }}
        >
          {label}
        </Typography>
      )}
    </MatrixBox>
  );
};

export const PathwayContentHeader = ({
  id,
  title,
  type,
  updatedOnDisplay,
  tags,
  editPlaylist,
  contentMetrics,
  hasCertificate,
  isEnrolled,
  percentageComplete,
  selectSort,
  rating,
  numberOfPeopleWhoRated = 0,
  handleSharContentHeader,
  openRating,
  handleRefetch,
  handleAddToLearning,
  isNew,
  description,
  isAutoEnrolled
}: {
  type: PathwayType;
  isEnrolled?: boolean;
  handleRefetch?: () => void;
  editPlaylist?: () => void;
  [x: string]: any;
}): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("xs"));
  const [isInMyLearning, setIsInMyLearning] = useState<boolean | null>();
  const [showConfirmDialog, setConfirmDialog] = useState<any>(false);
  const [showDialog, setShowDialog] = useState<any>(false);
  const [confirmDialogTitle, setConfirmDialogTitle] = useState<string>("");
  const [confirmDialogMessage, setConfirmDialogMessage] = useState<string>("");
  const history = useHistory();

  const [completePathwayUnEnrollment] = useMutation(COMPLETE_PATHWAY_UNENROLLMENT);
  const [deletePlaylist] = useMutation(DELETE_PLAYLIST);
  const [completeChannelEnrollment] = useMutation(COMPLETE_CHANNEL_ENROLLMENT);
  const [completeChannelUnEnrollment] = useMutation(COMPLETE_CHANNEL_UNENROLLMENT);

  const [sort, setSort] = useState<SortType>();
  const dispatch = useAppDispatch();
  const handleSort = (id: any) => {
    setSort(id);
    selectSort(id);
  };

  const [showMore, setShowMore] = useState(false);
  const descriptionRef = useRef();

  useEffect(() => {
    const elementRef = descriptionRef.current as HTMLElement;
    if (elementRef && elementRef.clientHeight < elementRef.scrollHeight) {
      setShowMore(true);
    } else {
      setShowMore(false);
    }
  }, [descriptionRef.current]);

  const DescriptionTag = styled("div")({
    wordBreak: "break-word",
    "& *": {
      maxWidth: "100% !important",
    },
  });
  const [canChangeCompletedStatus, { data }] =
    useLazyQuery<CanChangeCompletedType.CanChangeCompletedStatusToEnroll>(
      CAN_CHANGE_COMPLETE_TO_ENROLL,
      {
        variables: { pathwayId: id },
      }
    );

  const handleAddtoMyLearning = () => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: true },
    });
    canChangeCompletedStatus();
  };

  const classes= useStyles();

  useEffect(() => {
    if (data) {
      dispatch({
        type: "loader/showandhide",
        payload: { show: false },
      });
      if (data.canChangeCompletedStatusToEnroll) {
        setConfirmDialogTitle(t('confirmdialogtitle'));
        setConfirmDialogMessage(t('pathway_dialog'));
        setConfirmDialog(true);
      } else {
        handleAddToLearning();
      }
    }
  }, [data]);

  const Icon = withStyles((theme: Theme) => ({
    root: {
      // backgroundColor: theme.palette.primary.main,
      color: theme.palette.common.white,
      borderRadius: "50%",
      width: 14,
      height: 14,
      cursor: "pointer",
      position: "absolute",
      padding: "2px",
      "& path": { fill: portalSettingsManager.application?.common?.themeColor || '#0091da' },
    },
  }))(CreateIcon);

  const handleConfirmDialogClick = () => {
    if (type === PathwayType.pathway) {
      handleAddToLearning();
    } else if (type === PathwayType.playlist) {
      handleRemovePlaylist();
    }
  };
  const handleRemovePlaylist = () => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: true, message: t('delete_playlist_msg') },
    });

    deletePlaylist({ variables: { playlistId: id } })
      .then(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('delete_playlist_msg') },
        });
        history.push("/");
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('playlist'),
            message: t('playlist_deletion_progress'),
          },
        });
      })
      .catch(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('remove_from_mylearning') },
        });
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('playlist'),
            message: t('playlist_deletion_error'),
          },
        });
      });
  };

  const handlePathwayUnEnrollment = () => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: true, message: t('remove_from_mylearning') },
    });

    completePathwayUnEnrollment({ variables: { pathwayId: id } })
      .then(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('remove_from_mylearning') },
        });
        setIsInMyLearning(false);
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: pageType === "pathway" ? t('pathway') : t('parent_pathway'),
            message: pageType === "pathway" ? t('pathway_removal_dialog') : t('parent_pathway_removal_dialog')
          },
        });
        handleRefetch?.();
      })
      .catch(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('remove_from_mylearning') },
        });
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('pathway'),
            message: t('pathway_unenrollment_error'),
          },
        });
      });
  };

  const handleChannelUnEnrollment = () => {
    dispatch({ type: "loader/showandhide", payload: { show: true, message: t('unsubscribing ') } });
    completeChannelUnEnrollment({ variables: { channelId: id } })
      .then(() => {
        dispatch({ type: "loader/showandhide", payload: { show: false, message: t('unsubscribing ') } });
        setIsInMyLearning(false);
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('channel'),
            message: t('channel_unsubscribed_successfully'),
          },
        });
        handleRefetch?.();
      })
      .catch(() => {
        dispatch({ type: "loader/showandhide", payload: { show: false, message: t('unsubscribing ') } });
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('channel'),
            message: t('channel_unenrollment_error'),
          },
        });
      });
  };

  const handleChannelEnrollment = () => {
    dispatch({ type: "loader/showandhide", payload: { show: true, message: t('subscribing ') } });
    completeChannelEnrollment({ variables: { channelId: id } })
      .then(() => {
        dispatch({ type: "loader/showandhide", payload: { show: false, message: t('subscribing ') } });
        setIsInMyLearning(true);
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('channel'),
            message: t('channel_subscribed_successfully'),
          },
        });
        handleRefetch?.();
      })
      .catch(() => {
        dispatch({ type: "loader/showandhide", payload: { show: false, message: t('subscribing ') } });
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('channel'),
            message: t('channel_subscribed_error'),
          },
        });
      });
  };

  useEffect(() => {
    setIsInMyLearning(isEnrolled);
  }, [isEnrolled]);

  const handleDeletePlaylist = () => {
    setConfirmDialogTitle(t('playlist_delete'));
    setConfirmDialogMessage(t('confirm_playlist_deletion'));
    setConfirmDialog(true);
  };

  const sanitize: string = sanitizeHtml(description, { allowedTags: [], allowedAttributes: {}, });
  const des: string = sanitize?.slice(0, 500);
  const focusClass = useFocusStyles()

  const showNewIcon = isNew && type !== "playlist"
  const location = useLocation()
  const pageType = location.pathname.toLowerCase().startsWith("/pathway/")
    ? PathwayType.pathway
    : location.pathname.toLowerCase().startsWith("/channel/")
    ? PathwayType.channel
    : location.pathname.toLowerCase().startsWith("/playList/")
    ? PathwayType.playlist
    : PathwayType.parentpathway;

  return (
    <>
      {showNewIcon && (
        <Box width="5%" style={{ marginBottom: "5px" }}>
          <NewIcon style={{ position: "static", padding: "4px 9px 3px 7px" }} />
        </Box>
      )}
      <Box display="flex" justifyContent="space-between">
        <Box width="50%">
          {isMobile && (
            <>
              {(type === PathwayType.pathway || type === PathwayType.parentpathway ) && isInMyLearning && (
                <>
                  <ContentBanner
                    item={{
                      percentageComplete,
                      isEnrolled: !!isEnrolled,
                      statusCode: "InProgress",
                    }}
                  />
                  <BorderLinearProgress variant="determinate" value={percentageComplete} />
                </>
              )}
              {type === PathwayType.channel && isInMyLearning && (
                <>
                  <ContentBanner
                    item={{
                      percentageComplete,
                      isEnrolled: !!isEnrolled,
                      statusCode: "InProgress",
                    }}
                  >
                    {t('subscribed')}
                  </ContentBanner>
                </>
              )}
              <Box
                display="flex"
                alignItems="center"
                justifyContent="space-between"
                marginTop="15px"
              >
                <Box display="flex" alignItems="center">
                  {(() => {
                    const settings = { width: "19px", height: "17px", stroke: "#000000" };
                    switch (type) {
                      case PathwayType.pathway: {
                        return <PathwayIcon {...settings} />;
                      }
                      case PathwayType.playlist: {
                        return <PlayListIcon {...settings} />;
                      }
                      case PathwayType.channel: {
                        return <ChannelIcon {...settings} />;
                      }
                    }
                  })()}
                  <Typography
                    style={{
                      marginLeft: "10px",
                      fontWeight: "bold",
                      fontSize: "12px",
                      letterSpacing: "2.4px",
                      color: theme.palette.grey["800"],
                      fontFamily: "Arial",
                      lineHeight: "14px",
                    }}
                  >
                    {type.toUpperCase()}
                  </Typography>
                </Box>
                <Box display="flex">
                  {portalSettingsManager.application?.features?.allowShareContent && type !== PathwayType.playlist && (
                    <Box display="flex">
                      <Box
                        style={{
                          display: "inline-block",
                          border: "solid",
                          borderRadius: "50%",
                          borderWidth: "1px",
                          borderColor: theme.palette.grey["A100"],
                          aspectRatio: "1",
                          width: "30px",
                          height: "30px",
                        }}
                      >
                        <IconButton onClick={handleSharContentHeader}>
                          <ShareIcon
                            stroke={theme.palette.grey["A100"]}
                            style={{ transform: "translate(-15%, -15%)" }}
                            itemName={type}
                          />
                        </IconButton>
                      </Box>
                      {type === PathwayType.pathway && hasCertificate && isMobile && (
                        <Box marginLeft="8px" position="relative" width="30px">
                          <CertificationIcon
                            stroke={theme.palette.grey["A100"]}
                            style={{
                              position: "absolute",
                              top: "-3px",
                              width: "30px",
                              height: "40px",
                            }}
                          />
                        </Box>
                      )}
                    </Box>
                  )}
                  {type === PathwayType.playlist && hasCertificate && (
                    <Box marginLeft="13px">
                      <CertificationIcon
                        width="22px"
                        height="30px"
                        stroke={theme.palette.grey["A100"]}
                      />
                    </Box>
                  )}
                </Box>
              </Box>
            </>
          )}
          <Box display="flex">
            <Typography
              style={{
                display: "inline",
                fontSize: isMobile ? "18px" : "26px",
                fontWeight: isMobile ? "bold" : undefined,
                maxWidth: isMobile ? "205px" : undefined,
                color: theme.palette.grey["800"],
                position: "relative",
              }}
              component='h2'
            >
              {title}{" "}</Typography><Typography
                style={{
                  display: "inline",
                  fontSize: isMobile ? "18px" : "26px",
                  fontWeight: isMobile ? "bold" : undefined,
                  maxWidth: isMobile ? "15px" : undefined,
                  color: theme.palette.grey["800"],
                  position: "relative",
                }}
              >
              {type === PathwayType.playlist && !isMobile && <IconButton
                aria-label={`${t('aria_label_click_to_edit')} ${t(title)}`}
                onClick={editPlaylist}
                style={{ borderColor: portalSettingsManager.application?.common?.themeColor, marginLeft: "5px" }}
                tabIndex={0}
                className={`${focusClass.borderItem} ${focusClass.focusItem}`}><Icon onClick={editPlaylist} /></IconButton>}
            </Typography>
            {type === PathwayType.playlist && isMobile && (
              <IconButton onClick={editPlaylist} aria-label={t('edit_playlist')}>
                <Icon />
              </IconButton>
            )}
          </Box>
          {isMobile && (
            <Box display="flex" justifyContent="flex-start">
              <Matrix mobile bg={completionIcon} count={contentMetrics?.numberOfCourses} pageType={pageType}/>
              {type !== PathwayType.playlist && type !== PathwayType.pathway && <Matrix mobile bg={pathwayIcon} count={contentMetrics?.numberOfPathways} pageType={pageType}/>}
            </Box>
          )}
          {description && (
            <div style={{display:"flex", margin: "10px 0 30px 0",}}>
              <div
                className={classes.viewLess}
                style={{ fontSize: "13px", color: theme.palette.grey["800"],lineHeight: "21px"}}
                ref={descriptionRef}
              >
                <RenderHTML content={description ?? ""} />{" "}
              </div>
              {showMore && (
                  <Box
                    style={{minWidth:"100px",alignSelf: "flex-end", textDecoration: "underline", cursor: "pointer", fontSize: "13px", color: theme.palette.grey["800"], lineHeight: "21px" }}
                    onClick={() => setShowDialog(true)}
                    aria-label={t("view_more")}
                    role="button"
                    tabIndex={0}
                  >
                    {t("view_more")}
                  </Box>
              )}
            </div>
          )}

          <Box display="flex" flexDirection="row" alignItems="center">
            {updatedOnDisplay && (
              <Typography
                component="div"
                style={{
                  fontSize: "14px",
                  color: theme.palette.grey["800"],
                  lineHeight: "16px",
                  marginRight: "20px",
                  margin: type === PathwayType.playlist ? "10px 0 20px 0" : "0",
                }}
              >
                {t('updated_on')}{" "}
                {isMobile ? mobileDateString(new Date(updatedOnDisplay)) : updatedOnDisplay}
              </Typography>
            )}
            {/* <Rating score={0} numberOfReviews={23} /> */}
            <Box marginLeft={"10px"}>
              {type !== PathwayType.playlist && (
                <Rating
                  score={rating || 0}
                  numberOfReviews={numberOfPeopleWhoRated}
                  onSubmit={openRating}
                  display={true}
                />
              )}
            </Box>
          </Box>
          <Box display="flex" flexWrap="wrap" role="list">
            {(tags || []).map((item: any, index: number) =>
              item ? (
                <span
                  key={index}
                  aria-label={item}
                  role="listitem"
                  style={{
                    fontSize: "11px",
                    color: theme.palette.grey["800"],
                    marginRight: "7px",
                    marginBottom: "7px",
                    padding: "3px 15px",
                    background: "#f5f5f5",
                  }}
                >
                  {item}
                </span>
              ) : (
                <></>
              )
            )}
          </Box>
        </Box>

        <Box display="flex" alignItems="center" alignSelf="flex-start" marginTop={showNewIcon ? "-25px" : "5px" }>
        {pageType !== 'parentpathway' && <Matrix bg={completionIcon} label="Courses" count={contentMetrics?.numberOfCourses} completedCount={contentMetrics?.numberOfCoursesCompleted} pageType={pageType}/>}
          {type !== PathwayType.playlist && type !== PathwayType.pathway && pageType !== 'parentpathway' && (
            <Matrix bg={pathwayIcon} label="Pathways" count={contentMetrics?.numberOfPathways} pageType={pageType}/>
          )}
          {type === PathwayType.pathway && pageType === 'pathway' && hasCertificate && !isMobile && (
            <Box marginTop="-5px">
              <CertificationIcon width="54px" height="64px" stroke={theme.palette.grey["A100"]} />
            </Box>
          )}
          {type === PathwayType.playlist && hasCertificate && !isMobile && (
            <Box marginTop="-5px">
              <CertificationIcon width="54px" height="64px" stroke={theme.palette.grey["A100"]} />
            </Box>
          )}
          {pageType === 'parentpathway' && hasCertificate && !isMobile && (
            <>
              <Matrix pageType={pageType} bg={certificationIcon} label="Certifications" count={contentMetrics?.numberOfCertifications} completedCount={contentMetrics?.numberOfCertificationsCompleted} />
              <Matrix pageType={pageType} bg={pathwayIcon} label="Pathways" count={contentMetrics?.numberOfPathways} completedCount={contentMetrics?.numberOfPathwaysCompleted} />
              <Matrix pageType={pageType} bg={completionIcon} label="Courses" count={contentMetrics?.numberOfCourses} completedCount={contentMetrics?.numberOfCoursesCompleted} />
            </>
          )}
        </Box>
      </Box>
      {showDialog && (<Box display="flex"
        justifyContent="space-between"
        borderBottom="1px solid  #D8D8D8;"
        paddingBottom="20px">
        <Dialog
          id="pathwaycontentdialog"
          onClose={() => setShowDialog(false)}
          aria-labelledby="adding-playlist-dialog"
          open={true}
          minWidth={0}
          showCloseIcon
          minHeight={150}
        ><DialogContent style={{ padding: "8px 35px", minWidth: isMobile ? 0 : 360 }}>
            <Typography
              style={{
                fontSize: "12px",
                color: theme.palette.grey["800"],
                lineHeight: "16px",
                marginTop: "10px",
              }}
            >
              <RenderHTML content={description ?? ""} />
            </Typography>
          </DialogContent>
        </Dialog>
      </Box>)}
      <Box
        display="flex"
        justifyContent="space-between"
        borderBottom="1px solid  #D8D8D8;"
        paddingBottom="20px"
      >
        <Box>
          {type === PathwayType.playlist && isMobile && (
            <MBC bgcolor={theme.palette.grey["800"]}>
              <MBC.Button onClick={() => handleDeletePlaylist()}>
                {t('remove_from_mylearning')}
              </MBC.Button>
            </MBC>
          )}
          {type === PathwayType.playlist && (
            <Button
              style={{
                borderRadius: 0,
                color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
                backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back, 
                padding: "10px 30px",
                fontSize: "12px",
                fontWeight: 700,
                margin: "15px 10px 0px 0px",
                borderColor: portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]
              }}
              // title={t('delete_playlist_button_title')}
              onClick={() => handleDeletePlaylist()}
              startIcon={<Close fontSize="large" />}
              tabIndex={0}
              className={`${focusClass.greyBorder} ${focusClass.focusItem} ${focusClass.secondaryHover}`}
            >
              {t('delete_this_playlist')}
            </Button>
          )}
          {isInMyLearning && type === PathwayType.pathway && isMobile && (
            <MBC bgcolor={theme.palette.grey["800"]}>
              <MBC.Button onClick={handlePathwayUnEnrollment}>{t('remove_from_mylearning')}</MBC.Button>
            </MBC>
          )}
          {isInMyLearning && type === PathwayType.pathway && !isMobile && (
            <Button
              style={{
                border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]}`,
                borderRadius: 0,
                color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
                backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back,
                padding: "10px 20px",
                fontSize: "12px",
                fontWeight: 700,
                margin: "15px 10px 0px 0px",
              }}
              onClick={handlePathwayUnEnrollment}
              className={`${focusClass.secondaryHover} ${focusClass.focusItem}`}
            >
              {t('remove_from_mylearning')}
            </Button>
          )}
          {isInMyLearning === false && type === PathwayType.pathway && isMobile && (
            <MBC>
              <MBC.Button onClick={handleAddToLearning}>{t('add_to_mylearning')}</MBC.Button>
            </MBC>
          )}
          {isInMyLearning === false && type === PathwayType.pathway && !isMobile && (
            <Button
              style={{
                border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]}`,
                borderRadius: 0,
                color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
                backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back,
                padding: "10px 30px",
                fontSize: "12px",
                fontWeight: 700,
                margin: "15px 10px 0px 0px",
              }}
              className={`${focusClass.secondaryHover} ${focusClass.focusItem}`}
              onClick={handleAddtoMyLearning}
            >
              {t('add_to_mylearning').toUpperCase()}
            </Button>
          )}
          {isInMyLearning && type === PathwayType.channel && isMobile && !isAutoEnrolled &&(
            <MBC bgcolor={theme.palette.grey["800"]}>
              <MBC.Button onClick={handleChannelUnEnrollment}>{t('unsubscribe')}</MBC.Button>
            </MBC>
          )}
          {isInMyLearning && type === PathwayType.channel && !isMobile && !isAutoEnrolled &&(
            <Button
              style={{
                border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]}`,
                borderRadius: 0,
                color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
                backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back || "black",
                padding: "10px 30px",
                fontSize: "12px",
                fontWeight: 700,
                margin: "15px 10px 0px 0px",
              }}
              className={`${focusClass.secondaryHover} ${focusClass.focusItem}`}
              onClick={handleChannelUnEnrollment}
            >
              {t('unsubscribe')} 
            </Button>
          )}
          {isInMyLearning === false && type === PathwayType.channel && isMobile && (
            <MBC>
              <MBC.Button onClick={handleChannelEnrollment}>{t('subscribe')}</MBC.Button>
            </MBC>
          )}
          {isInMyLearning === false && type === PathwayType.channel && !isMobile && (
            <Button
              style={{
                border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]}`,
                borderRadius: 0,
                color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
                backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back || "black",
                padding: "10px 30px",
                fontSize: "12px",
                fontWeight: 700,
                margin: "15px 10px 0px 0px",
              }}
              className={`${focusClass.secondaryHover} ${focusClass.focusItem}`}
              onClick={handleChannelEnrollment}
            >
              {t('subscribe')}
            </Button>
          )}
          {portalSettingsManager.application?.features?.allowShareContent && type !== PathwayType.playlist && !isMobile && (
            <>
              <Button
                style={{
                  border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]}`,
                  borderRadius: 0,
                  color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
                  backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back,
                  padding: "10px 30px",
                  fontSize: "12px",
                  fontWeight: 700,
                  margin: "15px 10px 0px 0px",
                }}
                className={`${focusClass.secondaryHover} ${focusClass.focusItem}`}
                onClick={handleSharContentHeader}
                startIcon={
                  <ShareIcon
                    stroke={portalSettingsManager.buttonColors?.normal?.active?.text || "#000000"}
                    style={{ transform: "translate(20%, 25%)" }}
                    itemName={type}
                  />
                }
              >
                {t('share')}
              </Button>
            </>
          )}
        </Box>
        {(type === PathwayType.pathway || type === PathwayType.parentpathway) && isInMyLearning && !isMobile && (
          <Box style={{ minWidth: "300px", marginTop: "9px" }}>
            <Box
              style={{
                display: "flex",
                justifyContent: "space-between",
                color: theme.palette.grey["800"],
                fontSize: "12px",
                margin: "15px 0px",
              }}
            >
              <Box>{pageType === 'parentpathway' ? t('parent_pathway_progress') : t('pathway_progress')}</Box>
              <Box>{percentageComplete}%</Box>
            </Box>
            <BorderLinearProgress variant="determinate" value={percentageComplete} />
          </Box>
        )}
        {type === PathwayType.channel && (
          <Box display="flex" justifyContent="center" alignItems="flex-end" >
            <Select
              title={t('sort_by')}
              aria-label={t('aria_label_sort_by')}
              options={[
                { title: t('sort_by_name_asc'), id: SORT_ALPHABETICAL_ASCENDING },
                { title: t('sort_by_name_desc'), id: SORT_ALPHABETICAL_DESCENDING },
                { title: t('sort_by_duration_asc'), id: SORT_DURATION_ASCENDING },
                { title: t('sort_by_duration_desc'), id: SORT_DURATION_DESCENDING },
                { title: t('sort_by_price_asc'), id: SORT_PRICE_ASCENDING },
                { title: t('sort_by_price_desc'), id: SORT_PRICE_DESCENDING },
              ]}
              value={sort}
              onChange={handleSort}
            />
          </Box>

        )}
        {type === PathwayType.playlist && (
          <Box display="flex" justifyContent="center" alignItems="flex-end">
            <Select
              title={t('sort_by')}
              aria-label={t('aria_label_sort_by')}
              options={[
                { title: t('sort_by_name_asc'), id: SORT_ALPHABETICAL_ASCENDING },
                { title: t('sort_by_name_desc'), id: SORT_ALPHABETICAL_DESCENDING },
                { title: t('sort_by_duration_asc'), id: SORT_DURATION_ASCENDING },
                { title: t('sort_by_duration_desc'), id: SORT_DURATION_DESCENDING },
                { title: t('sort_by_price_asc'), id: SORT_PRICE_ASCENDING },
                { title: t('sort_by_price_desc'), id: SORT_PRICE_DESCENDING },
              ]}
              value={sort}
              onChange={handleSort}
            />
          </Box>
        )}
      </Box>
      {
        showConfirmDialog && (
          <ConfirmDialog
            open={showConfirmDialog}
            title={confirmDialogTitle}
            message={confirmDialogMessage}
            handleConfirmed={handleConfirmDialogClick}
            handleClose={() => setConfirmDialog(false)}
          />
        )
      }
    </>
  );
};
