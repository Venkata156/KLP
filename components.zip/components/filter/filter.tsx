import {
  Box,
  Button,
  Checkbox as MuiCheckbox,
  FormControl,
  FormGroup,
  FormLabel,
  FormControlLabel as MuiFormControlLabel,
  Radio,
  RadioGroup,
  Slider as MuiSlider,
  useMediaQuery,
  Typography,
} from "@material-ui/core";
import { Theme, withStyles, styled, useTheme, makeStyles } from "@material-ui/core/styles";
import { Switch, ArrowIcon, Accordion, FilledCheckboxIcon, CustomCheckBoxIcon } from "components";
import { useState, useEffect, useRef } from "react";
import { DatePicker, MultiViewCalendar } from "@progress/kendo-react-dateinputs";
import { IntlProvider, LocalizationProvider } from "@progress/kendo-react-intl";
import { ToggleButton } from '@progress/kendo-react-dateinputs';
import { useTranslation } from "react-i18next";
export interface FilterProps {
  type:
  | "switch"
  | "radio"
  | "checkbox"
  | "range"
  | "rating"
  | "sessionDate"
  | "rangeSlider"
  | "slider";
  title?: string;
  options?: any;
  handleFilters?: any;
  handleSliderChange?: any;
  switchValue?: any;
  filterName: string;
  radioValue?: string;
  checkboxValue?: any;
  sliderValue?: any[];
  sliderMinValue?: number;
  sliderMaxValue?: number;
  sliderStep?: number;
  handleClear?: any;
  switchFilter?: any;
  showClear?: any;
  clearDateRange?: any;
}

type RenderFunction = (a: any) => void;
export interface ShowMoreProps {
  render: RenderFunction;
  list: any[];
  size: number;
}

const Checkbox = withStyles((theme) => ({
  root: {},
  checked: {
    color: `${theme.palette.primary.main} !important`,
  },
}))(MuiCheckbox);

const Slider = withStyles((theme: Theme) => ({
  root: {
    color: theme.palette.grey["300"],
    width: "calc(100% - 15px)",
    marginLeft: 7,
  },
  thumb: {
    color: theme.palette.grey["800"],
  },
  active: {
    color: theme.palette.primary.main,
  },
  focusVisible:{
    "&:after":{
      border:"2px solid #000"
    }
  }
}))(MuiSlider);

const Value = styled("span")(({ theme }) => ({
  fontSize: 11,
  fontWeight: 700,
  color: theme.palette.grey["500"],
  border: `1px solid ${theme.palette.grey["A100"]}`,
  width: 54,
  textAlign: "center",
}));

const useStyles = makeStyles({
  root: {
    "& .k-datepicker": {
      border: "1px solid rgba(0,0,0,0.54)",
      height: "24px",
      borderRadius: "2px",
    },
    "& .k-picker-wrap": {
      border: "0px solid black",
    },
    "& .k-input": {
      padding: "0px",
      height: "100%",
      fontSize: "10px",
      lineHeight: "100%",
      marginLeft: "1px",
      fontWeight: "bold",
    },
    "& .k-icon": {
      fontSize: "12px",
      color: "black",
    },
    "& .k-dateinput-wrap.k-state-focused": {
      border:"2px solid #000 !important"
      },
  },
  calendarPopup: {
    zIndex: 3000,
  },
});

const FormControlLabel = withStyles((theme: Theme) => ({
  root: {
    marginLeft: (props: any) => props.isMobile && "0px",
  },
  label: {
    fontSize: (props: any) => (props.isMobile ? "14px" : "11px"),
    color: theme.palette.grey["800"],
    minWidth: "100px",
    width: (props: any) => (props.isMobile ? "100%" : undefined),
  },
}))(MuiFormControlLabel);

const focusUseStyles = makeStyles({
  focusBorder: {
  border:"2px solid #000 !important"
  },
  });

export const ShowMore = ({ list, render }: ShowMoreProps): JSX.Element => {
  return (
    <Box>
      {list.map(render)}
    </Box>
  );
};


export const ToggleCalendarButton = (props: any) => {
  return <ToggleButton {...props} title={null} />;
};
export const Filter = ({
  type,
  title,
  options,
  handleFilters,
  handleSliderChange,
  switchValue,
  filterName,
  sliderValue,
  sliderStep,
  sliderMaxValue,
  sliderMinValue,
  handleClear,
  switchFilter,
  showClear,
  clearDateRange,
}: FilterProps): JSX.Element => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const DateSyles = useStyles();
  const classes = focusUseStyles();
  const [startDate, setStartDate] = useState<Date | null>(null);
  const [endDate, setEndDate] = useState<Date | null>(null);
  const { t } = useTranslation();

  const picker = useRef(null);

  useEffect(() => {
    if (clearDateRange) {
      setStartDate(null)
      setEndDate(null)
    }
  }, [clearDateRange]);

  const onhandleFocus= () => {
    document.querySelector("#startdate")?.setAttribute("aria-label", startDate?.toDateString());
    document.querySelector("#enddate")?.setAttribute("aria-label", endDate?.toDateString());
  };

  const handleClearClick = (type: any, filterName: any) => {
    if (type === "sessionDate") {
      setStartDate(null);
      setEndDate(null);
      handleClear(type, filterName);
    } else {
      handleClear(type, filterName);
    }
  };
  return (
    <Box
      width={isMobile ? "90%" : "150px"}
      borderBottom={!isMobile && `1px solid ${theme.palette.grey["300"]}`}
      p={isMobile ? "0px" : "12px 0"}
      m={isMobile ? "5px 0" : "12px 0"}
    >
      <FormControl component="fieldset" style={{ width: "100%" }}>
        {title && (
          <>
            <FormLabel
              component="legend"
              style={{
                display: isMobile ? "none" : "block",
                fontSize: "12px",
                fontWeight: 700,
                color: theme.palette.grey["800"],
                marginBottom: "12px",
              }}
            >
              {title}
            </FormLabel>
            {showClear && (
              <Button
                style={{
                  fontSize: "11px",
                  color: theme.palette.primary.main,
                  padding: 0,
                  textTransform: "none",
                  justifyContent: "left",
                }}
                onClick={() => handleClearClick(type, filterName)}
              >
                {t('clear')}
              </Button>
            )}
          </>
        )}
        {type === "switch" && (
          <FormControlLabel
            control={
              <Switch
                checked={switchValue}
                onChange={(e) => handleFilters(type, filterName, e)}
                name="switch"
                focusVisibleClassName={classes.focusBorder}
              />
            }
            isMobile={isMobile}
            labelPlacement={isMobile ? "start" : "end"}
            label={options.label}
          />
        )}
        {type === "checkbox" && !isMobile && (
          <FormGroup>
            {options && (
              <ShowMore
                list={options}
                size={3}
                render={(item: any) => {
                  return (
                    <FormControlLabel
                      control={
                        <Checkbox
                          icon={<CustomCheckBoxIcon width={"15px"} height={"15px"} />}
                          checkedIcon={<FilledCheckboxIcon width={"15px"} height={"15px"} />}
                          onChange={(e) => handleFilters(type, filterName, e)}
                          name={item.value}
                          color="primary"
                          size="small"
                          key={item.value}
                          focusVisibleClassName={classes.focusBorder}
                          checked={switchFilter[filterName].some(
                            (x: { code: string }) => x.code === item.value
                          )}
                        />
                      }
                      // value={true}
                      label={item.label}
                    />
                  );
                }}
              />
            )}
          </FormGroup>
        )}
        {type === "checkbox" && isMobile && (
          <Accordion
            mobile
            title={title}
            expanded={false}
            positionArrow="right"
            style={{
              fontSize: "14px",
              fontWeight: 300,
            }}
          >
            <Box>
              {options.map(({ value, label }: { value: string; label: string }, idx: number) => {
                return (
                  <Box key={idx}>
                    <FormControlLabel
                      key={idx}
                      control={
                        <Checkbox
                          onChange={(e) => handleFilters(type, filterName, e)}
                          name={value}
                          color="primary"
                          size="medium"
                          checked={switchFilter[filterName].some(
                            (x: { code: string }) => x.code === value
                          )}
                        />
                      }
                      label={<Typography style={{ fontSize: "12px" }}>{label}</Typography>}
                    />
                  </Box>
                );
              })}
            </Box>
          </Accordion>
        )}
        {type === "radio" && (
          <RadioGroup aria-label="" name="" onChange={(e) => handleFilters(type, filterName, e)}>
            {options &&
              options.map((item: any, index: number) => {
                return (
                  <FormControlLabel
                    key={index}
                    value={item.label}
                    control={<Radio color="primary" size="small" />}
                    label={item.label}
                  />
                );
              })}
          </RadioGroup>
        )}
        {type === "sessionDate" && (
          <Box
            className={DateSyles.root}
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            marginTop="10px"
            fontSize="10px"
          >
            <LocalizationProvider language={"en-US"}>
              <IntlProvider locale={"en"}>
                <DatePicker
                  id="startdate"
                  ref={picker}
                  value={startDate}
                  format="dd MMM yy"
                  title={t('date_picker_startdate_title')}
                  calendar={(props: any) => (
                    <MultiViewCalendar views={1} ref={props._ref} value={props.value} onChange={props.onChange} />
                  )}
                  formatPlaceholder="formatPattern"
                  toggleButton={ToggleCalendarButton}
                  placeholder="dd MMM yy"
                  popupSettings={{ popupClass: DateSyles.calendarPopup, appendTo: document.body }}
                  onChange={(e) => {
                    handleFilters(type, "sessionStartDate", e), setStartDate(e.value);
                  }}
                  onFocus={onhandleFocus}
                />

                <ArrowIcon
                  width="26px"
                  height="26px"
                  stroke="#000000"
                  style={{ position: "relative", top: "4px", left: "3px" }}
                />
                <DatePicker
                  id="enddate"
                  formatPlaceholder="formatPattern"
                  ref={picker}
                  value={endDate}
                  format="dd MMM yy"
                  placeholder="dd MMM yy"
                  title={t('date_picker_enddate_title')}
                  calendar={(props: any) => (
                    <MultiViewCalendar views={1} ref={props._ref}
                      value={props.value} onChange={props.onChange} />
                  )}
                  toggleButton={ToggleCalendarButton}
                  popupSettings={{ popupClass: DateSyles.calendarPopup, appendTo: document.body }}
                  onChange={(e) => {
                    handleFilters(type, "sessionEndDate", e), setEndDate(e.value);
                  }}       
                  onFocus={onhandleFocus}         
                />
              </IntlProvider>
            </LocalizationProvider>
          </Box>
        )}
        {type === "rangeSlider" && (
          <>
            <Slider
              value={sliderValue}
              onChange={(event, newValue) => handleSliderChange(type, filterName, event, newValue)}
              onChangeCommitted={(e) => handleFilters(type, filterName, e)}
              max={sliderMaxValue}
              valueLabelDisplay="auto"
              aria-labelledby="range-slider"
            />
            {sliderValue && (
              <Box display="flex" justifyContent="space-between">
                <Value>{sliderValue[0]}</Value>
                <Value>{sliderValue[1]}</Value>
              </Box>
            )}
          </>
        )}
        {type === "slider" && (
          <Slider
            onChangeCommitted={(e) => handleFilters(type, filterName, e)}
            min={sliderMinValue}
            max={sliderMaxValue}
            aria-labelledby="discrete-slider-custom"
            step={sliderStep}
            valueLabelDisplay="auto"
          />
        )}
      </FormControl>
    </Box>
  );
};
