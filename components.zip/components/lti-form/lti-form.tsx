import React from "react";
import * as LTILaunchParameters from "utils/graphql/LTILaunchParameters";
import { GET_LTI_LAUNCH_PARAMS } from "utils/queries";
import { useQuery } from "@apollo/client";
import { useSelector } from "react-redux";
import { KLP_COURSE_WINDOW_NAME } from "utils/constants";
import { useAppDispatch, UPDATE_COURSE_IN_PROGRESS_FLAG, RootState } from "store";
import { useTranslation } from "react-i18next";
import { openUrlUtil } from "hooks/open-url";
import { LTIContentSource } from "utils/graphql/Global";

export const LTIForm = (props: { activityId: string; dataLoaded?: (isLoading: boolean) => void; isSubmit?: boolean; courseId: string; onSubmitted?: () => void; handleActivityRefresh?: () => void; children?: React.ReactNode, type:  string }): JSX.Element => {
  const { t } = useTranslation();
  const userContext = useSelector((state: RootState) => state.core.userContext.userContext);
  const dispatch = useAppDispatch();
  const { loading, error, data } = useQuery<LTILaunchParameters.LTILaunchParameters>(
    GET_LTI_LAUNCH_PARAMS,
    {
      variables: { courseId: props.courseId, activityId: props.activityId, source: props.type},
      onCompleted: () => { props.dataLoaded?.(false) }
    }
  );  
  const formEl = React.useRef<HTMLFormElement>(null);
  const result = data?.ltiLaunchParameters;
  const { openUrl } = openUrlUtil();
  useSelector(() => {
    if (props.isSubmit) {
      formEl.current?.submit();
      props.onSubmitted?.();
      const { isSuccess, windowEvent } = openUrl("", KLP_COURSE_WINDOW_NAME);
      if (isSuccess) {
        dispatch({ type: UPDATE_COURSE_IN_PROGRESS_FLAG, payload: true });
        const closeWindow = setInterval(
          (props) => {
            if (windowEvent?.closed) {
              dispatch({ type: UPDATE_COURSE_IN_PROGRESS_FLAG, payload: false });
              clearInterval(closeWindow);
              props.handleActivityRefresh();
            }
          }, 500, props);
      }
    }
  });
  return (
    <form
      ref={formEl}
      action={result?.contentUrl ?? ""}
      method="post"
      target={KLP_COURSE_WINDOW_NAME}
      style={{ flex: 1 }}
    >
      <fieldset
        style={{ borderWidth: "0px", padding: "0px", margin: "0px" }}
        disabled={!!error || loading}
      >
        <input type="hidden" name="lti_message_type" value={result?.ltiMessageType ?? ""} />
        <input type="hidden" name="lti_version" value={result?.ltiVersion ?? ""} />
        <input type="hidden" name="user_id" value={result?.learnerId ?? ""} />
        <input type="hidden" name="oauth_consumer_key" value={result?.consumerKey ?? ""} />
        <input type="hidden" name="oauth_nonce" value={result?.nonce ?? ""} />
        <input type="hidden" name="oauth_signature" value={result?.signature ?? ""} />
        <input type="hidden" name="oauth_signature_method" value={result?.signatureMethod ?? ""} />
        <input type="hidden" name="oauth_timestamp" value={result?.timestamp ?? ""} />
        <input type="hidden" name="oauth_version" value={result?.version ?? ""} />
        {props.type === LTIContentSource.LINKED_IN && (
          <>
            <input type="hidden" name="lis_person_name_given" value={userContext?.firstName} />
            <input type="hidden" name="lis_person_name_family" value={userContext?.lastName} />
            <input type="hidden" name="lis_person_contact_email_primary" value={userContext?.learnerEmail} />
            <input type="hidden" name="lis_person_name_full" value={userContext?.userDisplayName} />
          </>
        )}
      </fieldset>
    </form>
  );
};
