import { Box, Typography, useMediaQuery } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import courseIcon from "assets/icons/icon-course.svg";
import userIcon from "assets/icons/icon-user.svg";
import PathwayIcon from "assets/icons/icon-pathway.svg";
import ParentPathwayIcon from "assets/icons/icon-parentpathway.svg";
import ChannelIcon from "assets/icons/icon-channel.svg";
import PlaylistIcon from "assets/icons/icon-playlist-sml.svg";
import { BreadCrumb } from "components/breadcrumb/breadcrumb";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { RootState } from "store";
import { usePageTitle } from "hooks";
import { useTranslation } from "react-i18next";
import { SUB_HEADER_CONTENT_TYPE } from "utils/constants";

export const SubHeader = ({ contentType, studyModes, breadCrumbData, handleBreadCrumbClick }: any): JSX.Element => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const subHeaderTitle = useSelector((state: RootState) => state.core.subHeaderTitle);
  const { t } = useTranslation();

  const [title, setTitle] = useState<string | null>(subHeaderTitle);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [subTitle, setSubTitle] = useState<string | null>(null);
  const [titleIcon, setTitleIcon] = useState<string | null>(null);
  useEffect(() => {
    if (contentType == "Course") {
      setTitle(t('course').toUpperCase());
      if (studyModes) {
        if (studyModes.length > 1) {
          setTitle(t('hybrid_course'));
        } else {
          if (studyModes.length == 1) {
            setTitle(t(studyModes[0].toLowerCase()).toUpperCase() + " " + t('course').toUpperCase());            
          }
        }
      }
    }
  }, [studyModes]);
  useEffect(() => {
    switch (contentType) {
      case "Course":
        // setTitle("COURSE");
        setSubTitle(t('my_learning'));
        setTitleIcon(courseIcon);
        break;
      case "Search":
        setTitle(t('search_results_title'));
        setSubTitle("");
        break;
      case "Profile":
        setTitle(t('profile').toUpperCase());
        setSubTitle(t('profile'));
        setTitleIcon(userIcon);
        break;
      case "Pathway":
        setTitle(t('pathway').toUpperCase());
        setSubTitle("");
        setTitleIcon(PathwayIcon);
        break;
      case "parentpathway":
        setTitle(t('parent_pathway').toUpperCase());
        setSubTitle("");
        setTitleIcon(ParentPathwayIcon);
        break;
      case "Channel":
        setTitle(t('channel').toUpperCase());
        setSubTitle("");
        setTitleIcon(ChannelIcon);
        break;
      case "MyLearning":
        setTitle(t('my_learning').toUpperCase());
        setSubTitle("");
        break;
      case "Popular":
        setTitle(t('popular_items'));
        setSubTitle("");
        break;
      case "Recommendations":
        setTitle(t('learningsection_recommendations_title'));
        setSubTitle("");
        break;
      case "Playlist":
        setTitle(t('playlist'));
        setSubTitle("");
        setTitleIcon(PlaylistIcon);
        break;
      case "All":
        if (subHeaderTitle) {
          setTitle(t('my_learning').toUpperCase());
          setSubTitle("");
          setTitleIcon("")
        } else {
          setTitle(t('search_results_title'));
          setSubTitle("");
          setTitleIcon("")
        }
        break;
      case "Attendance":
        setTitle(t('SESSION ATTENDANCE CONFIRMATION'));
        setSubTitle("");
        break;
      case SUB_HEADER_CONTENT_TYPE.ATTENDANCE_CONFIRMATION:
        setTitle(t('subheader_attendace_activity_confirmation'));
        setSubTitle("");
        break;
      case SUB_HEADER_CONTENT_TYPE.ACTIVITY_COMPLETION:
        setTitle(t('subheader_activity_completion'));
        setSubTitle("");
        break;
      default:
        setTitle(contentType);
        setSubTitle("");
        break;
    }
  }, [contentType, subHeaderTitle, t]);
  usePageTitle(title);
  return (
    <>
      <Box
        display={{ xs: "none", sm: "flex" }}
        alignItems="center"
        height="50px"
        borderBottom="1px solid #c9c9c9"
        marginBottom="60px"
        aria-label={`${title}`}
      >
        <Box>
          <BreadCrumb
            breadCrumbData={breadCrumbData}
            handleBreadCrumbClick={handleBreadCrumbClick}
          />
        </Box>
        <Box
          height="30px"
          style={{
            textAlign: "center",
            position: "absolute",
            width:`${isMobile? "50%": "50%"}`,
            left: `${isMobile? "60%": "50%"}`,
            transform: "translate(-50%, 0px)",
            marginLeft: `${!isMobile ? 0 : '10%'}`,
            marginTop: `${!isMobile ? 0 : '3%'}`
          }}
        >
          <Typography
            style={{
              fontSize: isMobile? "8px" : "16px",
              color: theme.palette.grey["800"],
              lineHeight: "30px",
              letterSpacing: "2.4px",
              fontFamily: "Arial",
              right: "150px",
              fontWeight: "bold"
            }}
            component='h1'
            aria-label={`${title}`}
          >
            {title}
          </Typography>
          <div
            style={{
              backgroundImage: `url(${titleIcon})`,
              backgroundPosition: "center center",
              backgroundRepeat: "no-repeat",
              opacity: title === "Playlist" ? 0.1 : 0.2,
              position: "relative",
              bottom: "30px",
              height: "inherit",
              // right: "150px"
            }}
          ></div>
        </Box>
      </Box>
    </>
  );
};
