import { Box, Menu, MenuItem } from "@material-ui/core";
import MuiButton from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";
import { ArrowDropDown } from "@material-ui/icons";
import { MouseEvent, useState, useEffect } from "react";
import { useTheme, useMediaQuery } from "@material-ui/core";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";

const DesktopButton = withStyles((theme) => ({
  root: {
    border: `1px solid ${theme.palette.grey['A100']}`,
    borderRadius: 0,
    color: theme.palette.grey['800'],
    padding: "5px 10px",
    fontSize: "12px",
    textTransform: "none",
  },
  // label:{
  //   justifyContent:"space-between"
  // }
}))(MuiButton);

const MobileButton = withStyles((theme) => ({
  root: {
    border: `1px solid ${theme.palette.grey['A100']}`,
    borderRadius: 0,
    color: theme.palette.grey['800'],
    padding: "5px 5px 5px 10px",
    fontSize: "12px",
    lineHeight: "14px",
    textTransform: "none",
  },
  endIcon: {
    marginLeft: "2px"
  }
}))(MuiButton);

const Button = (props: any) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const style = { ...props.style, width: props.width };
  return isMobile ? <MobileButton {...props} style={style} /> : <DesktopButton {...props} style={style} />
}

export interface option {
  title: string;
  id: any;
}

export const Select = ({
  title,
  options,
  onChange,
  toggle,
  pagenation,
  width,
  value,
  arialabel,
}: any): JSX.Element => {
  const [label, setLabel] = useState<string | null>(title);
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const focusClass = useFocusStyles()
  useEffect(() => {
    if (pagenation) {
      setLabel(title);
    }
    setLabel(title);
  }, [title]);

  useEffect(() => {
    if (options && options.length > 0 && !toggle) {
      const label = options.find((option: any) => option.id === value);
      if (label) {
        setLabel(label.title);
      } else {
        setLabel(title);
      }
    }
  }, [value, options, title, toggle])

  const handleOpen = (event: MouseEvent<HTMLButtonElement>) => {
    if (!toggle) {
      setAnchorEl(event.currentTarget);
    } else if (options.length === 1) {
      onChange(options[0].id);
    } else if (options.length > 1) {
      const nextOption = options.find((option: any) => option.title !== label);
      if (nextOption) {
        setLabel(nextOption.title);
        onChange(nextOption.id);
        handlefocus(nextOption.title);
      }
    }
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const { t } = useTranslation();

  const handlefocus = (btntitle: string) => {
    if (btntitle == t('show_filters_button')) {
      document.querySelector("#btnfilter")?.setAttribute("aria-expanded", 'false');
    }
    else if (btntitle == t('hide_filters_button')) {
      document.querySelector("#btnfilter")?.setAttribute("aria-expanded", 'true');
    }

  };
  return (
    <Box>
      <Button
        id="btnfilter"
        aria-controls={`${title}-menu`}
        aria-haspopup="true"
        onClick={handleOpen}
        endIcon={<ArrowDropDown />}
        width={width}
        className={focusClass.focusItem}
        onFocus={()=>handlefocus(label)}
        aria-label={arialabel}
        title={label}
      //aria-expanded= {title == t('show_filters_button')?false : true}
      >
        {label}
      </Button>
      {options && options.length > 0 && <Menu
        id={`${title}-menu`}
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
        aria-expanded={true}
      >
        {options.map((item: any, idx: number) => {
          return (
            <MenuItem
              key={idx}
              onClick={() => {
                if (onChange) {
                  onChange(item.id);
                }
                setLabel(item.title);
                handleClose();
              }}
              style={{ fontSize: "12px" }}
              className={focusClass.focusItem}
            >
              {item.title}
            </MenuItem>
          );
        })}
      </Menu>}
    </Box>
  );
};
