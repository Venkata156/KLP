import { Box, Typography } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import KeyboardBackspace from "@material-ui/icons/KeyboardBackspace";

export const Ranking = ({ title, value, isUp }: any): JSX.Element => {
  const theme = useTheme();

  return (
    <Box>
      <div>
        <Typography style={{ fontSize: "11px", fontWeight: 400, color: theme.palette.grey['500'] }}>{title}</Typography>
      </div>
      <div>
        <Typography display="inline" style={{ fontSize: "40px", fontWeight: 700, color: theme.palette.grey['800'] }}>{value}</Typography>
        {isUp && <KeyboardBackspace style={{ transform: "rotate(90deg)", color: "#43B02A" }} />}
        {!isUp && <KeyboardBackspace style={{ transform: "rotate(-90deg)", color: "#D0021B" }} />}
      </div>
    </Box>
  );
};
