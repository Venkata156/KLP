import { render, screen, userEvent } from 'test/index';
import { Accordion } from './accordion';

describe('Accordion Component', () => {
    describe('when redered with default props', () => {
        const defaultProps = {
            title: 'Accordion Title',
        }
        it('renders correctly without any errors', () => {
            const { container } = render(<Accordion title={defaultProps.title} />);
            expect(container).not.toBeNull();
        });
        it('title displayed properly in the right casing', () => {
            render(<Accordion title={defaultProps.title} />);
            const accordionTitle = screen.getByText(defaultProps.title);
            expect(accordionTitle).toBeInTheDocument();
        });
        it('show the default arrow icon on left side', () => {
            render(<Accordion title={defaultProps.title} />);
            const accordionTitle = screen.getByText(defaultProps.title);
            const accordionHeaderNode = accordionTitle.parentElement;
            expect(accordionHeaderNode).not.toBeNull();
            expect(accordionHeaderNode && accordionHeaderNode.lastChild).toEqual(accordionTitle);
        });
        it('should be expanded default', () => {
            const { container } = render(<Accordion title={defaultProps.title} />);
            const firstChild = container.firstChild as HTMLElement;
            expect(firstChild.classList?.contains('expanded')).toBe(true);
        });
    });

    describe('when user clicks on icon', () => {
        const defaultProps = {
            title: 'Accordion Title',
        }
        it('children should be toggled', () => {
            // const { container, debug } = render(<Accordion title={defaultProps.title} />);
            const { container } = render(<Accordion title={defaultProps.title} />);
            const firstChild = container.firstChild as HTMLElement;
            expect(firstChild.classList?.contains('expanded')).toBe(true);
            // debug(container);
            const arrowButton = screen.getByLabelText('arrow-icon');
            userEvent.click(arrowButton);
            expect(firstChild.classList?.contains('expanded')).toBe(false);
        });
    });

    describe('when arrow position is set to right', () => {
        const defaultProps = {
            title: 'Accordion Title',
            positionArrow: 'right' as const,
        }
        it('arrow icon should be displayed right side', () => {
            render(<Accordion title={defaultProps.title} positionArrow={defaultProps.positionArrow} />);
            const accordionTitle = screen.getByText(defaultProps.title);
            const accordionHeaderNode = accordionTitle.parentElement;
            expect(accordionHeaderNode?.firstChild).toEqual(accordionTitle);
        });
    });
});