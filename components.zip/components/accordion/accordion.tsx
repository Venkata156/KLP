import { Box, Typography, IconButton } from "@material-ui/core";
import { withStyles, useTheme } from "@material-ui/core/styles";
import { KeyboardArrowDown, KeyboardArrowUp } from "@material-ui/icons";
import React, { useState } from "react";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";
import { useFocusStyles } from "hooks/focusBorder";

const Container = withStyles(() => ({
  root: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
  },
}))(Box);

const Arrow: React.FC<{
  toggle: () => void;
  outlined: boolean;
  direction: "up" | "down";
  position: "left" | "right";
  title: string; 
  focusClass: string;
}> = ({ toggle, outlined, position, direction, title, focusClass }) => {
  const { t } = useTranslation();
  const theme = useTheme();
  return (
    <Box marginRight={position === "right" ? "-5px" : "13px"}>
      <IconButton
        aria-label={`${title || ''} ${t(direction === 'up' ? 'collapse' : 'expand')}`}
        size="small"
        onClick={toggle}
        style={{
          backgroundColor: outlined ? (portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main) : undefined,
          color: outlined ? theme.palette.common.white : theme.palette.grey["800"],
        }}
        className={focusClass}
      >
        {direction === "up" ? <KeyboardArrowUp /> : <KeyboardArrowDown />}
      </IconButton>
    </Box>
  );
};

export const Accordion: React.FC<{
  title: React.ReactNode;
  mobile?: boolean;
  expanded?: boolean;
  positionArrow?: "left" | "right";
  outlined?: boolean;
  style?: React.CSSProperties;
}> = ({
  title,
  mobile,
  children,
  positionArrow = "left",
  expanded = true, // initialize accordion expanded or collapsed
  outlined = false,
  style,
}) => {
    const { t } = useTranslation();
    const theme = useTheme();
    const [_expanded, setExpanded] = useState(expanded);
    const focusClass = useFocusStyles();

    function toggle() {
      setExpanded(!_expanded);
    }

    return (
      <Container className={`${_expanded ? "expanded" : ""}`}>
        <Box
          display="flex"
          width="100%"
          alignItems="center"
          justifyContent={positionArrow === "right" ? "space-between" : undefined}
        >
          {positionArrow === "left" && (
            <Arrow
              direction={_expanded ? "up" : "down"}
              position={positionArrow}
              outlined={outlined}
              toggle={toggle}
              title={t(_expanded ? 'collapse_button' : 'expand_button')}
              focusClass={focusClass.focusItem}
            />
          )}
          <Typography
            style={{
              fontSize: "16px",
              fontWeight: 700,
              color: theme.palette.grey["800"],
              letterSpacing: 0,
              ...style,
            }}
          >
            {title}
          </Typography>
          {positionArrow === "right" && (
            <Arrow
              direction={_expanded ? "up" : "down"}
              position={positionArrow}
              outlined={outlined}
              toggle={toggle}
              title={t(_expanded ? 'collapse_button' : 'expand_button')}
              focusClass={focusClass.focusItem}
            />
          )}
        </Box>
        <Box flex="1" width="100%" marginLeft={mobile ? "0px" : "45px"}>
          {_expanded && <div>{children}</div>}
        </Box>
      </Container>
    );
  };
