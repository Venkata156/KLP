import { useMutation } from "@apollo/client";
import { Typography } from "@material-ui/core";
import { styled, useTheme } from "@material-ui/core/styles";
import { Dialog, DialogActions, DialogContent, Action } from "components";
import { ClipboardEvent, useEffect, useState } from "react";
import { UPDATE_EMAIL_ADDRESS } from "utils/queries";
import { useAppDispatch } from "store";
import { emailRegex } from "utils/helpers";
import { useTranslation , TFunction} from "react-i18next";

const Label = styled("label")(({
  theme
}) => ({
  display: "block",
  fontSize: "12px",
  color: theme.palette.grey['500'],
  marginTop: "29px",
  marginBottom: "10px",
}));

const Current = styled("span")(({
  theme
}) => ({
  fontSize: "14px",
  fontWeight: 700,
  color: theme.palette.grey['800'],
}));

const Email = styled("input")({
  padding: "10px 8px",
  width: "calc(100% - 30px)",
});

const validateEmail = (email: any, t: TFunction<"translation", undefined>) => {
  const reg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  const result = reg.test(email)
  if (result) {
    return null;
  }
  let message = t('enter_valid_email');
  if (email.indexOf("@") < 0) {
    message = t('email_validation',{email_addr: email}) 
  }
  if (email.indexOf("@") === email.length - 1) {
     message = t('email_validaton_incomplete') 
    }
  if (email.indexOf(".") === email.length - 1) {
     message = t('email_kpmg_validation')
  }
  return message;
}

export const EmailDialog = ({ open, profile, handleClose }: any): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const [newEmail, setNewEmail] = useState("");
  const [emailValidationMessage, setEmailValidationMessage] = useState<string | null>(t('new_email_mandatory'));
  const [confirmEmail, setConfirmEmail] = useState("");
  const [confirmEmailMessage, setConfirmEmailMessage] = useState<string>(t('verify_email_mandatory'));
  const [emailIsValid, setEmailIsValid] = useState(true);

  const [updateEmailAddress] = useMutation(UPDATE_EMAIL_ADDRESS);
  const dispatch = useAppDispatch();

  const handleVerifyEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {   
    const newValue = event?.target?.value;
    setConfirmEmail(newValue);    
    setConfirmEmailMessage(t(''));
    if (newEmail !== newValue) {
      setConfirmEmailMessage(t('valid_email'));
    }
  };

  const handleEmailChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = event?.target?.value;
    setNewEmail(newValue);
    const result = validateEmail(newValue, t);
    setEmailValidationMessage(result);
  };

  const onClose = (updated: boolean) => {
    handleClose(updated, "from dialog");
    setNewEmail("");
    setConfirmEmail("");
    setEmailIsValid(true);
  };

  const handleUpdateEmailAddress = () => {
    updateEmailAddress({ variables: { emailId: newEmail } })
      .then(() => {
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('update_progress'),
            message: t('email_update_progress'),
          },
        });
        onClose(true);
      })
      .catch(() => {
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('update_progress'),
            message: t('error_updating_profile'),
          },
        });
      });
  };

  const preventPaste = (event: ClipboardEvent<unknown>) => {
    event.preventDefault();
    return false;
  };

  useEffect(() => {
    if (String(newEmail).toLowerCase() === String(confirmEmail).toLowerCase()) {
      if (
        new RegExp(emailRegex).test(newEmail) === true &&
        new RegExp(emailRegex).test(confirmEmail) === true
      ) {
        setEmailIsValid(false);
      }
    } else {
      setEmailIsValid(true);
    }
  }, [newEmail, confirmEmail]);

  return (
    <Dialog
      id="emaildialog"
      onClose={() => onClose(false)}
      role="dialog"  aria-labelledby="update_email_label" aria-modal="true"
      open={open}
      style={{ maxWidth: 400 }}
      showCloseIcon
    >
      <DialogContent>
        <Typography style={{ fontSize: "16px", color: theme.palette.grey['800'] }} component="h2" id="update_email_label">{t('change_email')}</Typography>
        <Typography style={{ fontSize: "12px", color: theme.palette.grey['800'], lineHeight: "16px" }} component="h3">
        {t('fields_change_email')}
        </Typography>
        <Label>{t('current_email')}</Label>
        <Current>{profile?.email}</Current>
        <Label aria-label={t('new_email')} >{t('new_email')}</Label>
        <Email
          type="email"
          value={newEmail}
          onChange={handleEmailChange}
          title={emailValidationMessage || ''}
          aria-label={t('new_email')} 
          autoComplete="email"
        />
        <Label aria-label={t('verify_new_email')} >{t('verify_new_email')}</Label>
        <Email
          type="email"
          value={confirmEmail}
          onChange={handleVerifyEmailChange}
          onPaste={preventPaste}
          title={confirmEmailMessage}
          aria-required="true"
          aria-label= {t('verify_new_email')} 
          autoComplete="email"
        />
      </DialogContent>
      <DialogActions>
        <Action type="dialog-alt" onClick={() => onClose(false)}>
        {t('cancel_and_close')}
        </Action>
        <Action
          type="dialog-primary"
          onClick={handleUpdateEmailAddress}
          disabled={emailIsValid}
          style={{ height: "32px" }}
        >
          {t('save')}
        </Action>
      </DialogActions>
    </Dialog>
  );
};
