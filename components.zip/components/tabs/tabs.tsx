import React, { useState } from "react";
import { Box, Typography } from "@material-ui/core";
import Muitabs from "@material-ui/core/Tabs";
import MuiTab from "@material-ui/core/Tab";
import { Theme, withStyles } from "@material-ui/core/styles";
import { EditOutlined } from "@material-ui/icons";
import portalSettingsManager from "utils/portalSettingsManager";

import { useTranslation } from "react-i18next";
const Icon = withStyles((theme: Theme) => ({
  root: {
    backgroundColor: theme.palette.common.white,
    color: theme.palette.primary.main,
    border: `1px solid ${theme.palette.primary.main}`,
    borderRadius: "50%",
    width: 13,
    height: 13,
    position: "absolute",
    right: 0,
    top: 15,
    padding: "2px",
    opacity: "0.7"
  },
}))(EditOutlined);

const CircleIcon = withStyles((theme: Theme) => ({
  root: {
    backgroundColor: portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main,
    borderRadius: "50%",
    width: "9px",
    height: "9px",
    position: "absolute",
    right: 6,
    top: 25,
  },
}))(Box);

type TabProps = React.ComponentProps<typeof MuiTab> & { mobile?: boolean };
const Tab = withStyles((theme: Theme) => ({
  root: {
    minWidth: 75,

    paddingLeft: 17,
    paddingRight: 17,
    fontSize: (props: TabProps) => (props.mobile ? "12px" : undefined),
    "&:focus": { border: "2px solid #000000" }
  },
  wrapper: {
    fontWeight: 700,
    color: theme.palette.grey['800'],
    textTransform: "none",
  },
  [theme.breakpoints.down("sm")]: {
    root: {
      flex: 1,
    },
  },
}))(MuiTab);

const MTabs = withStyles((theme: Theme) => ({
  root: {
    borderBottom: `1px solid ${theme.palette.grey['300']}`,
    "& button": {
      [theme.breakpoints.down("xs")]: {
        padding: 0,
        fontSize:13
      },
    }
  },

  wrapper: {
    fontSize: "14px",
    fontWeight: 700,
    color: theme.palette.grey["800"],
  },
  indicator: {
    background: portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main,
    height: "3px"
  },
}))(Muitabs);

interface TabPanelProps {
  index: any;
  value: any;
  style?: any;
  persistInDom?: boolean
}
export const TabPanel: React.FC<TabPanelProps> = (props) => {
  const { children, value, index, persistInDom = false, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
    >
      {value === index || persistInDom ? (
        <Box p={3} {...other}>
          <Typography component="div">{children}</Typography>
        </Box>
      ) : ""}
    </div>
  );
};

type TabsProps<T> = {
  value?: T | 0;
  mobile?: boolean;
  tabs: { label: string; isDirty?: boolean; value?: T }[];
  onChange: (event: React.ChangeEvent<unknown>, value: T | 0) => void;
  height?: number;
};
export const Tabs = <T,>({ value = 0, tabs, onChange, mobile, height }: TabsProps<T>): JSX.Element => {
  //const [active, setActive] = useState<T | 0>(value);
  const { t } = useTranslation();
  const handleChange = (event: React.ChangeEvent<unknown>, value: T | 0) => {
    onChange(event, value);
    //setActive(value);
  };

  return (
    <MTabs value={value} onChange={handleChange} aria-label={t('aria_label_profile_tabs')}>
      {tabs.map((item, index) => {
        return <Tab style={{ maxHeight: height, minHeight: height }} mobile={mobile} key={index} label={item.label} icon={item.isDirty ? <CircleIcon /> : <></>} value={item.value || index} />;
      })}
    </MTabs>
  );
};
