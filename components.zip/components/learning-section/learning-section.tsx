import { useLazyQuery } from "@apollo/client";
import { Box, Button, IconButton, useMediaQuery, useTheme } from "@material-ui/core";
import { Add } from "@material-ui/icons";
import { setCustomCatalogTitle } from "store/core";
import {
  ContentTile,
  Select,
  ArrowIcon,
  ChannelIcon,
  CourseIcon,
  PathwayIcon
} from "components";

import { useEffect, useState, useRef } from "react";
import { Link, useHistory } from "react-router-dom";
import { useAppDispatch } from "store";

import {
  CATEGORY_CODE_ALL,
  CATEGORY_CODE_POPULAR,
  CATEGORY_CODE_RECOMMENDED,
  CATEGORY_CODE_REQUIRED,
  SORT_ALPHABETICAL_ASCENDING,
  SORT_ALPHABETICAL_DESCENDING,
  SORT_DURATION_ASCENDING,
  SORT_DURATION_DESCENDING,
  SORT_PRICE_ASCENDING,
  SORT_PRICE_DESCENDING,
  FILTER_ENROLLED,
  FILTER_IN_PROGRESS,
  CATEGORY_CODE_MYINTEREST,
  SORT_DEFAULT,
} from "utils/constants";
import * as CategoryTypes from "utils/graphql/Category";
import { parseSortType } from "utils/helpers";
import { GET_CATEGORIES } from "utils/queries";
import { SortType } from "utils/types";
import { styled } from "@material-ui/core/styles";
import styles from "./learning-section.module.css";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";

const Figure = styled("figure")({
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
});

const FigureCaption = styled("figcaption")(({ theme }) => ({
  fontSize: "12px",
  color: theme.palette.grey["800"],
  fontWeight: 700,
  textTransform: "uppercase",
  marginTop: "10px",
  letterSpacing: "2.4px"
}));

const DefaultIcons = styled("div")(({ theme }) => ({
  "&:before, &:after": {
    position: "absolute",
    background: theme.palette.grey["300"],
    width: "0.5px",
    height: "20px",
    content: "''",
    bottom: 0,
  },
  "&:after": {
    right: 0,
  },
}));

const LearningSectionDefault = () => {
  const theme = useTheme();

  const dispatch = useAppDispatch();
  const history = useHistory();
  const { t } = useTranslation();
  const handleAddToMyLearning = () => {
    dispatch(setCustomCatalogTitle(true));
    dispatch({
      type: "subheader/title",
      payload: "",
    });
    dispatch({
      type: "search/setSearchFilters",
      payload: {
        sort: SORT_DEFAULT,
        text: "",
        code: CATEGORY_CODE_ALL,
      },
    });
    history.push("/catalog");
  };

  return (
    <Box
      style={{
        display: "flex",
        padding: "40px 51px",
        justifyContent: "space-between",
        boxShadow: "0 4px 14px 0 rgba(0,0,0,0.10)",
      }}
    >
      <Box style={{ maxWidth: "375px", marginRight: "48px" }}>
        <span
          style={{
            display: "block",
            textAlign: "center",
            fontSize: "28px",
            color: theme.palette.primary.main,
          }}
        >
          {t('add_to_mylearning')}
        </span>
        <span
          style={{
            display: "block",
            textAlign: "center",
            fontSize: "14px",
            color: theme.palette.grey["500"],
            lineHeight: "21px",
            paddingTop: "8px",
          }}
        >
          {t('learning_section_description')}
        </span>
      </Box>
      <DefaultIcons
        style={{
          display: "flex",
          borderBottom: `1px solid ${theme.palette.grey["300"]}`,
          position: "relative",
        }}
      >
        <Figure>
          <CourseIcon width="32px" height="32px" stroke={theme.palette.grey["A100"]} />
          <FigureCaption>{t('courses')}</FigureCaption>
        </Figure>
        <Figure>
          <PathwayIcon
            width="32px"
            height="32px"
            stroke={theme.palette.grey["A100"]}
          />
          <FigureCaption>{t('pathways')}</FigureCaption>
        </Figure>
        <Figure>
          <ChannelIcon
            width="32px"
            height="32px"
            stroke={theme.palette.grey["A100"]}
          />
          <FigureCaption>{t('channels')}</FigureCaption>
        </Figure>
        {/* <Figure>
          <PlayListIcon width="32px" height='32px' stroke={theme.palette.grey['A100']} alt="Playlists" />
          <FigureCaption>Playlists</FigureCaption>
        </Figure> */}
      </DefaultIcons>
      <Box
        style={{ display: "flex", flexDirection: "column", justifyContent: "center" }}
        onClick={handleAddToMyLearning}
      >
        <IconButton
          aria-label={t('aria_label_click_to_share')}
          style={{
            border: `1px solid ${theme.palette.primary.main}`,
            padding: "6px",
            margin: "auto",
          }}
        >
          <ArrowIcon
            stroke={theme.palette.primary.main}
            style={{ transform: "translate(20%, 25%)" }}
          />
        </IconButton>
        <span
          style={{
            display: "block",
            fontSize: "12px",
            color: theme.palette.primary.main,
            letterSpacing: "2.4px",
            fontWeight: 700,
            textTransform: "uppercase",
          }}
        >
          {t('catalog')}
        </span>
      </Box>
    </Box>
  );
};

export const LearningSection = ({
  code,
  title,
  subTitle,
  list,
  reload,
  setReload,
  selectTileHandler,
  setIsOpenPlaylist,
  setOpenShareContent,
  setOpenActivity,
  handleTileClick,
}: any): JSX.Element => {
  const dispatch = useAppDispatch();
  const history = useHistory();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const isMD = useMediaQuery(theme.breakpoints.down("md"));
  const scrollTimeout = useRef(0);
  const { t } = useTranslation();
  const [scrollPercent, setScrollPercent] = useState(0);

  const [courses, setCourses] = useState<CategoryTypes.Category_contentListByCategory_contents[]>(
    list || []
  );
  const [sort, setSort] = useState<SortType>(SORT_DEFAULT);
  const [page, setPage] = useState(0);
  const [contentCount, setContentCount] = useState(0);
  const handlePrev = () => {
    if (page > 0) {
      setPage(page - 1);
    }
  };

  const handleNext = () => {
    const isLastPage = page + 1 >= courses.length / 3;
    if (isLastPage) {
      setPage(0);
    } else {
      setPage(page + 1);
    }
  };

  const handleViewAll = () => {
    dispatch({
      type: "search/setSearchFilters",
      payload: {
        sort: SORT_DEFAULT,
        text: "",
      },
    });
    dispatch({ type: "search/setSearchFilters", payload: { code } });
    history.push(`/catalog/${code}`);
    window.scrollTo(0, 0);
  };

  const handleAddToMyLearning = () => {
    dispatch({
      type: "subheader/title",
      payload: "",
    });
    dispatch(setCustomCatalogTitle(true));
    dispatch({
      type: "search/setSearchFilters",
      payload: {
        sort: SORT_DEFAULT,
        text: "",
        code: CATEGORY_CODE_ALL,
      },
    });
    history.push("/catalog");
  };

  const variables = {
    categoryCode: code,
    sort: parseSortType(sort),
    count: Number(process.env.REACT_APP_CATEGORY_COUNT),
  };
  if (code === CATEGORY_CODE_REQUIRED) {
    Object.assign(variables, {
      filters: [
        {
          items: [
            { code: FILTER_ENROLLED },
            { code: FILTER_IN_PROGRESS },
          ],
          type: "MultiSelect",
          code: "Status",
        },
        {
          type: "MultiSelect",
          code: "ContentCategory",
          items: [
            { code: "Programme" },
            { code: "Pathway" }
          ]
        }
      ],
    });
  }

  const [loadCourses, { loading, data, refetch }] = useLazyQuery<CategoryTypes.Category>(
    GET_CATEGORIES,
    {
      // extremely bizarre that this is necessary, but all LearningSections show the same content without this
      fetchPolicy: "no-cache",
      variables,
      notifyOnNetworkStatusChange: true,
    }
  );

  const handleSort = (id: any) => {
    setSort(id ? id : SORT_DEFAULT);
  };

  const focusClass = useFocusStyles()

  useEffect(() => {
    if (!list || !list.length) {
      loadCourses();
    } else {
      setCourses(list);
    }
  }, [list, loadCourses]);

  useEffect(() => {
    if (reload && refetch) {
      refetch({
        categoryCode: CATEGORY_CODE_MYINTEREST,
        sort: parseSortType(sort),
        count: Number(process.env.REACT_APP_CATEGORY_COUNT),
      });
      setReload(false);
    }
  }, [reload, refetch])

  useEffect(() => {
    if (data) {
      // remove null values
      if (data.contentListByCategory && data.contentListByCategory?.contents) {
        setCourses(
          data.contentListByCategory.contents.flatMap((course) => (course ? [course] : []))
        );
        setContentCount(data.contentListByCategory?.contentCount);
      }
      // setCourses(
      //   (data.contentListByCategory?.contents || []).flatMap((course) => (course ? [course] : []))
      // );
    }
  }, [data]);

  useEffect(() => {
    if (refetch) {
      refetch({
        categoryCode: code,
        sort: parseSortType(sort),
        count: Number(process.env.REACT_APP_CATEGORY_COUNT),
      });
    }
  }, [code, refetch, sort]);

  useEffect(() => {
    if (code === CATEGORY_CODE_REQUIRED) {
      dispatch({
        type: "loader/showandhide",
        payload: { show: loading, message: t('course_loading') },
      });
    }
  }, [loading, code]);
  return (
    <Box>
      {(code === CATEGORY_CODE_REQUIRED ||
        (list && list.length) ||
        ((code === CATEGORY_CODE_RECOMMENDED ||
          code === CATEGORY_CODE_MYINTEREST ||
          code === CATEGORY_CODE_POPULAR) &&
          courses &&
          courses.length > 0)) && (
          <Box
            borderBottom={code !== CATEGORY_CODE_POPULAR && `1px solid ${theme.palette.grey["300"]}`}
            paddingBottom="40px"
            marginBottom={code !== CATEGORY_CODE_POPULAR && "40px"}
          >
            <Box marginBottom={{ xs: "10px", sm: "20px" }} style={{ display: "flex" }}>
              <Box style={{ flex: 1 }} textAlign={{ xs: "center", sm: "left" }}>
                <h2
                  style={{
                    fontSize: `${portalSettingsManager.fonts?.learningSection?.titleFont?.size || "18px"}`,
                    fontWeight: "bold",
                    display: "block",
                    fontFamily: portalSettingsManager.fonts?.learningSection?.titleFont?.name || "inherit",
                    color: portalSettingsManager.fonts?.learningSection?.titleFont?.color || theme.palette.grey["800"],
                  }}
                >{`${title} (${title === t('related_items') ? list && list.length : contentCount
                  })`}</h2>
                <Box display={{ xs: "none", sm: "block" }}>
                  <span
                    style={{
                      display: "block",
                      color: portalSettingsManager.fonts?.learningSection?.summaryFont?.color || theme.palette.grey["500"],
                      fontSize: `${portalSettingsManager.fonts?.learningSection?.summaryFont?.size || "14px"}`,
                      fontFamily: portalSettingsManager.fonts?.learningSection?.summaryFont?.name || "inherit",
                      margin: "5px 0",
                    }}
                  >
                    {subTitle}
                  </span>
                </Box>
              </Box>
              {courses && courses.length > 0 && code === CATEGORY_CODE_REQUIRED && (
                <div>
                  <Box display={{ xs: "none", sm: "block" }}>
                    <Link to="/catalog">
                      <Button
                        style={{
                          fontSize: "10px",
                          fontWeight: "bold",
                          lineHeight: "11px",
                          border: `1px solid ${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`,
                          borderRadius: 0,
                          color: portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main,
                          height: "42px",
                          width: "177px",
                        }}
                        onClick={handleAddToMyLearning}
                        startIcon={<Add fontSize="large" />}
                        className={`${focusClass.primaryHover}`}
                      >
                        {t('add_to_mylearning')}
                      </Button>
                    </Link>
                  </Box>
                </div>
              )}
            </Box>
            {courses && courses.length > 0 && (
              <Box>
                <Box style={{ display: "flex" }}>
                  <Box display={{ xs: "none", sm: "block" }}>
                    {(!list || !list.length) && (
                      <Select
                        title={t('sort_by')}
                        aria-label={t('aria_label_Select_from_SortBy_dropdown')}
                        options={[
                          { title: t('sort_by_name_asc'), id: SORT_ALPHABETICAL_ASCENDING },
                          { title: t('sort_by_name_desc'), id: SORT_ALPHABETICAL_DESCENDING },
                          { title: t('sort_by_duration_asc'), id: SORT_DURATION_ASCENDING },
                          { title: t('sort_by_duration_desc'), id: SORT_DURATION_DESCENDING },
                          { title: t('sort_by_price_asc'), id: SORT_PRICE_ASCENDING },
                          { title: t('sort_by_price_desc'), id: SORT_PRICE_DESCENDING },
                        ]}
                        value={sort}
                        onChange={handleSort}
                      />
                    )}
                  </Box>
                  {courses && courses.length > 3 && (
                    <Box
                      display={{ xs: "flex", sm: "flex" }}
                      justifyContent={{ xs: "center", sm: "flex-end" }}
                      style={{ flex: 1, alignItems: "flex-end" }}
                    >
                      {isMobile ? (
                        <Box
                          style={{
                            zIndex: -3,
                            backgroundColor: theme.palette.grey["300"],
                            maxWidth: "300px",
                            overflowX: "hidden",
                            height: "5px",
                            position: "relative",
                          }}
                        >
                          <Box
                            style={{
                              backgroundColor: theme.palette.grey["800"],
                              width: "12px",
                              height: "5px",
                              position: "absolute",
                              transition: "left 0.2s ease",
                              left: `${Math.ceil(scrollPercent * (courses.length * 12))}px`,
                              zIndex: -2,
                            }}
                          ></Box>
                          {courses.map((course, idx) => (
                            <Box
                              key={idx}
                              style={{
                                display: "inline-block",
                                position: "relative",
                                color: "white",
                                backgroundColor: "white",
                                minWidth: "2px",
                                width: "2px",
                                minHeight: "5px",
                                height: "50px",
                                marginLeft: "10px",
                              }}
                            ></Box>
                          ))}
                        </Box>
                      ) : (
                        courses
                          .filter((item: any, idx: number) => idx % 3 === 0)
                          .map((item: any, idx: number) => {
                            return (
                              <Box key={idx} width="20px" marginRight="2px" style={{ cursor: "pointer" }} onClick={() => setPage(idx)}>
                                <Box
                                  style={{
                                    width: "100%",
                                    height: "5px",
                                    backgroundColor: `${idx === page
                                      ? theme.palette.grey["800"]
                                      : theme.palette.grey["300"]
                                      }`,
                                  }}
                                />
                              </Box>
                            );
                          })
                      )}
                    </Box>
                  )}
                </Box>
              </Box>
            )}

            {courses && courses.length === 0 && !loading && <LearningSectionDefault />}
            <Box
              style={{
                display: "flex",
                alignItems: "center",
                width: "100%",
                position: "relative",
              }}
            >
              <div>
                <Box
                  style={{
                    position: "absolute",
                    width: "42px",
                    top: 0,
                    bottom: 0,
                    alignItems: "center",
                    zIndex:999,
                    left:`${isMobile?"0px":isMD?"0px":"-70px"}`,
                  }}
                  display={{ xs: "none", sm: "flex" }}
                >
                  <IconButton
                    tabIndex={0}
                    className={`${focusClass.greyBorder} ${focusClass.focusItem} ${styles.focusOnly}`}
                    style={{
                      border: `1px solid ${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`,
                      padding: "6px",
                      opacity: page <= 0 ? 0 : 1,
                      backgroundColor:portalSettingsManager.buttonColors?.normal?.active?.back || "#ffffff",
                      boxShadow:"rgba(0, 0, 0 ,0.10) 0px 4px 14px 0px"
                    }}
                    aria-label={t('aria_label_click_previous_page')}
                    color="primary"
                    onClick={handlePrev}
                    disabled={page <= 0}
                  >
                    <ArrowIcon
                      stroke={`${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`}
                      style={{ transform: "translate(-25%, -25%) rotate(180deg)" }}
                      contentType={t('arrowicon_tooltip_previouspage')}
                      position={"right"}
                      zIndex={1000}
                    />
                  </IconButton>
                </Box>
              </div>
              <div style={{ overflow: "hidden", width: "100%" }}>
                <Box
                  className={styles.carousel}
                  overflow={{ xs: "auto", sm: "visible" }}
                  style={{ display: "flex", width: "100%", padding: "20px 0", whiteSpace: "nowrap", transition: "transform 0.2s", transform: `translateX(-${page * 100 + (page * 3.75 - (page * 0.75))}%)` }}
                  onScroll={(e) => {
                    const _scrollPercent = e.currentTarget.scrollLeft / e.currentTarget.scrollWidth;
                    clearTimeout(scrollTimeout.current);
                    scrollTimeout.current = window.setTimeout(
                      () => setScrollPercent(_scrollPercent),
                      100
                    );
                  }}
                >
                  {courses &&
                    courses
                      .map((item, idx: number) => {
                        return (
                          <Box
                            key={idx}
                            marginLeft={{
                              xs: idx > 0 && idx < courses.length ? "10px" : 0,
                              sm: idx > 0 && idx < courses.length ? "3.3%" : 0,
                            }}
                          >
                            <ContentTile
                              item={item}
                              handleClick={handleTileClick}
                              selectTile={selectTileHandler}
                              setIsOpenPlaylist={setIsOpenPlaylist}
                              setOpenShareContent={setOpenShareContent}
                              setOpenActivity={setOpenActivity}
                            />
                          </Box>
                        );
                      })}
                </Box>
              </div>
              {courses.length > 3 && (
                <div>
                  <Box
                    style={{
                      position: "absolute",
                      width: "42px",
                      top: 0,
                      right:  `${isMobile?"0px":isMD?"165px":"-70px"}`,
                      bottom: 0,
                      alignItems: "center",
                    }}
                    display={{ xs: "none", sm: "flex" }}
                  >
                    <IconButton
                      tabIndex={0}
                      style={{
                        border: `1px solid ${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`,
                        padding: "6px",
                        opacity: !courses || courses.length === 0 ? 0 : 1,                        
                        backgroundColor:portalSettingsManager.buttonColors?.normal?.active?.back || "#ffffff",
                        boxShadow:"rgba(0, 0, 0 ,0.10) 0px 4px 14px 0px"
                      }}
                      aria-label={t('aria_label_click_next_page')}
                      color="primary"
                      onClick={handleNext}
                      disabled={!courses || courses.length === 0 ? true : false}
                      className={`${focusClass.focusItem} ${styles.focusOnly}`}
                    >
                      <ArrowIcon
                        stroke={`${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`}
                        style={{ transform: "translate(20%, 25%)" }}
                        contentType={t('arrowicon_tooltip_nextpage')}
                      />
                    </IconButton>
                  </Box>
                </div>
              )}
            </Box>
            {(code === CATEGORY_CODE_REQUIRED ||
              code === CATEGORY_CODE_RECOMMENDED ||
              code === CATEGORY_CODE_POPULAR ||
              code === CATEGORY_CODE_MYINTEREST) &&
              courses &&
              courses.length > 0 && (
                <Box style={{ display: "flex", justifyContent: "center" }}>
                  <Box
                    width={{ xs: "100%", sm: "auto" }}
                    margin={{ xs: "10px 0 0 0", sm: "20px 0 0 0" }}
                  >
                    <Button
                      style={{
                        width: "100%",
                        border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]}`,
                        borderRadius: 0,
                        color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
                        backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back,
                        padding: "10px 30px",
                        fontSize: "12px",
                        fontWeight: 700,
                      }}
                      className={`${focusClass.focusItem} ${styles.focusOnly} ${focusClass.secondaryHover}`}
                      onClick={handleViewAll}
                      role="link"
                    >
                      {t('view_all_button_text')}
                    </Button>
                  </Box>
                </Box>
              )}
          </Box>
        )}
    </Box>
  );
};
