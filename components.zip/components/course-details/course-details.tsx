import { Box, Typography, Button, SvgIcon, useMediaQuery, Divider as MuiDivider, DialogContent } from "@material-ui/core";
import { ApolloQueryResult, useLazyQuery } from "@apollo/client";
import { Theme, withStyles, useTheme, styled, makeStyles } from "@material-ui/core/styles";
import { Link } from "react-router-dom";
import { ReactComponent as shareIcon } from "assets/icons/icon-share.svg";
import { ReactComponent as saveToListIcon } from "assets/icons/icon-save to list.svg";
import contentBg from "assets/images/course.png";
import sanitizeHtml from "sanitize-html";
import { RootState } from "store";
import { useSelector } from "react-redux";
import linkedInIcon from "assets/icons/icon-logo-linkedIn.svg";
import opensesameIcon from "assets/icons/icon-logo-opensesame.svg";
import {
  Activity,
  Rating,
  RenderHTML,
  Dialog,
  UnenrollDialog,
  Tabs,
  TabPanel,
  ShareDialog,
  PlayListDialog,
  MobileBottomContainer as MBC,
  CourseDetailsTimeIcon,
  CourseIcon,
  ShareIcon,
  ActivityWarning,
  SaveToListIcon,
  PathwayIcon,
  CertificationIcon
} from "components";
import React, { useEffect, useState } from "react";
import * as ActivityTypes from "utils/graphql/Activities";
import { GET_ACTIVITIES } from "utils/queries";
import * as CourseTypes from "utils/graphql/Course";
import * as CanLaunchCourseByPathWays from "utils/graphql/CanLaunchCourseBySequencialPathway";
import { formatTime, getContentType, mobileDateString, dueDateFormat } from "utils/helpers";
import { ContentBanner } from "components";
import { IconButton } from "@material-ui/core";
import { ActivityType, ContentSource } from "utils/graphql/Global";
import { ActivitiesDialog } from "components/activities-dialog/activities-dialog";
import { colors } from "components/theme/colors";
import { Loader } from "components/loader/loader";
import { useFocusStyles } from "hooks/focusBorder";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";
import { PERMISSIONS } from "utils/constants";

const Status = withStyles((theme: Theme) => ({
  root: {
    padding: "5px 7px",
    fontSize: "10px",
    color: theme.palette.common.white,
    letterSpacing: "2px",
    textAlign: "center",
    fontWeight: 700,
    backgroundColor: theme.palette.primary.main,
    border: `1px solid ${theme.palette.common.white}`,
    textTransform: "uppercase",
    display: "inline",
    "&.new": {
      backgroundColor: colors.orange["400"],
    },
    "&.required": {
      backgroundColor: theme.palette.grey["800"],
    },
    "&.duedate": {
      backgroundColor: "#f68d2e",
    },
    "&.enrolled": {
      backgroundColor: portalSettingsManager.statusColors?.enrolled?.back || "#C6007E",
    },
    "&.inprogress": {
      backgroundColor: portalSettingsManager.statusColors?.inprogress?.back || "#005EB8",
    },
    "&.completed": {
      backgroundColor: portalSettingsManager.statusColors?.completed?.back || "#16837D",
    },
  },
}))(Typography);

const DescriptionTag = styled("div")({
  wordBreak: "break-word",
  "& *": {
    maxWidth: "100% !important",
  },
});

type ActionProps = {
  ["aria-controls"]?:
  | "share-button"
  | "add-to-playlist"
  | "transcript-button"
  | "enroll-button"
  | "unenroll-button";
};
const Action = withStyles((theme: Theme) => ({
  root: {
    border: `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["500"]}`,
    borderColor: (props: ActionProps) =>
      props["aria-controls"] == "enroll-button"
        ? portalSettingsManager.buttonColors?.enroll?.active?.border || theme.palette.primary.main
        : portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["500"],

    borderRadius: 0,
    padding: "10px 20px",
    marginRight: "20px",
    marginBottom:"12px",
    height: "42px",

    backgroundColor: (props: ActionProps) =>
      props["aria-controls"] == "enroll-button"
        ? portalSettingsManager.buttonColors?.enroll?.active?.back || theme.palette.primary.main
        : props["aria-controls"] == "unenroll-button"
          ? portalSettingsManager.buttonColors?.dark?.active?.back || theme.palette.grey["800"]
          : portalSettingsManager.buttonColors?.normal?.active?.back || "#ffffff",
    "& svg": {
      transform: "translate(25%, 25%)",
    },
    "&:hover": {
      backgroundColor: (props: ActionProps) =>
        props["aria-controls"] == "enroll-button"
          ? portalSettingsManager.buttonColors?.enroll?.hover?.back || theme.palette.primary.main
          : props["aria-controls"] == "unenroll-button"
            ? portalSettingsManager.buttonColors?.dark?.hover?.back || theme.palette.grey["800"]
            : portalSettingsManager.buttonColors?.normal?.hover?.back || "rgb(51, 51, 51, 0.4)",
      opacity: "0.75",
    },
  },
  label: {
    fontSize: "11px",
    fontWeight: 700,
    color: (props: ActionProps) =>
      props["aria-controls"] == "share-button" ||
        props["aria-controls"] == "add-to-playlist" ||
        props["aria-controls"] == "transcript-button"
        ? portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"]
        : portalSettingsManager.buttonColors?.enroll?.active?.text || "#ffffff",
  },
}))(Button);

const Divider = withStyles((theme: Theme) => ({
  root: {
    width: '100%',
    color: theme.palette.grey["300"],
    margin: `${theme.spacing(1.5)}px 0`,
  }
}))(MuiDivider);

interface DetailIconProps {
  children: React.ReactNode;
  label?: string;
  showDivider?: boolean;
}

const DetailIcon = ({ children, label, showDivider }: DetailIconProps): JSX.Element => {
  const theme = useTheme();
  return (<>
    <Box display="flex" flexDirection='column' alignItems='center'>
      {children}
      {label && <span
        style={{
          fontSize: "12px",
          fontWeight: "bold",
          color: theme.palette.grey["800"],
          marginTop: "10px",
          marginBottom: "10px",
          letterSpacing: 0,
          lineHeight: '14px',
          maxWidth: '56px',
          textAlign: 'center',
        }}
      >
        {label}
      </span>}
      {showDivider && <Divider variant="fullWidth" orientation="horizontal" />}
    </Box>
  </>)
}
interface CourseDetailsProps {
  course: CourseTypes.Course_courseDetailsById;
  activityData: ActivityTypes.Activities | undefined;
  handleEnroll: () => void;
  handleRating: any;
  handleOpenWorkshop: (id: string) => void;
  handleOpenEnroll: () => void;
  handleSuggestADate: () => void;
  showActivityAction: boolean;
  activitiesRefetch: () => Promise<ApolloQueryResult<ActivityTypes.Activities>>
  courseDetailsRefetch: () => Promise<ApolloQueryResult<CourseTypes.Course>>,
  canLaunchCourseByPathWay?: CanLaunchCourseByPathWays.CanLaunchCourseBySequencialPathway
}

const useStyles = makeStyles((theme: Theme) => ({
  breakBox: {
    [theme.breakpoints.between("xs", "sm")]: {
      flexDirection: "column"
    },
  },
  boxFullWidth: {
    [theme.breakpoints.between("xs", "sm")]: {
      width: "calc(100% - 0px)",
      justifyContent: "center !important",
      alignItems: "flex-start !important",
      marginTop: "15px",
      marginLeft: "0px !important"
    },
  }
}));

export const CourseDetails = ({
  course,
  activityData,
  handleEnroll,
  handleRating,
  handleOpenWorkshop,
  handleOpenEnroll,
  handleSuggestADate,
  showActivityAction,
  activitiesRefetch,
  courseDetailsRefetch,
  canLaunchCourseByPathWay
}: CourseDetailsProps): JSX.Element => {
  const classes = useStyles();
  const theme = useTheme();
  const userContext = useSelector((state: RootState) => state.core.userContext);
  const [openUnenroll, setOpenUnenroll] = useState<boolean>(false);
  const [value, setValue] = React.useState(course.isEnrolled ? 1 : 0);
  const [activities, setActivities] = useState<ActivityTypes.Activities_activities[]>([]);
  const [isOpenPlaylist, setIsOpenPlaylist] = useState<boolean>(false);
  const [openShareContent, setOpenShareContent] = useState<boolean>(false);
  const isMobile = useMediaQuery(theme.breakpoints.down("xs"));
  const isMD = useMediaQuery(theme.breakpoints.down("md"));
  const isPad = useMediaQuery(theme.breakpoints.down("sm"));
  const [openCourses, setOpenCourses] = useState(false);
  const isCourseEnrolled = React.useMemo(() => course?.isEnrolled, [course.isEnrolled]);
  const [loader, setLoader] = useState(false);
  const [showDialog, setShowDialog] = useState<boolean>(false);
  const [fetchActivities] = useLazyQuery<ActivityTypes.Activities>(GET_ACTIVITIES, {
    variables: {
      courseId: String(course.id),
    },
  });
  const sanitize: string = sanitizeHtml(course.summary, { allowedTags: [], allowedAttributes: {}, });
  const sum: string = sanitize?.slice(0, 500);
  const focusClass = useFocusStyles()
  const enrolledPathwayId = canLaunchCourseByPathWay?.canLaunchCourseBySequencialPathway?.enrolledPathwayId;

  const handleActivityRefresh = () => {
    setLoader(true);
    setTimeout(() => {
      try {
        fetchActivities();
        activitiesRefetch();
        courseDetailsRefetch();
        setLoader(false);
      } catch (err) {
        setLoader(false);
        console.log("Error while refreshing", err);
      }
    }, 5000);
    return false;
  };
  const handleChange = (event: React.ChangeEvent<unknown>, newValue: number) => {
    setValue(newValue);
  };
  const { t } = useTranslation();
  useEffect(() => {
    setActivities(
      (activityData?.activities || []).flatMap((activity) => (activity ? [activity] : []))
    );
  }, [activityData]);

  useEffect(() => {
    setValue(course?.isEnrolled ? 1 : value);
  }, [course?.isEnrolled]);

  const srcUrl =
    course.source === ContentSource.OPEN_SESAME
      ? opensesameIcon
      : course.source === ContentSource.LINKED_IN
        ? linkedInIcon
        : "";
  const srcUrlTitle =
    course.source === ContentSource.OPEN_SESAME
      ? "OpenSesame"
      : course.source === ContentSource.LINKED_IN
        ? "LinkedIn"
        : "";

  let showHeader: boolean = true; 
  let prevActivityType: ActivityType = ActivityType.DIVIDER;
  let isFirstActivity: boolean | null = null; 
  return (
    <>
      <Loader isDisplay={loader} message={t('refreshing_content')} />

      <Box>
        {isMobile && (
          <ActivitiesDialog
            activities={activities}
            open={openCourses}
            onClose={() => setOpenCourses(false)}
            courseID={String(course.id)}
            source={course.source}
          />
        )}

        <Box
          display="flex"
          flexDirection={{ xs: "column-reverse", sm: "row" }}
          marginBottom={{ xs: "0px", sm: "40px" }}
          className={classes.breakBox} >
          <Box flex="1" display="flex" flexDirection="column">
            {!isMobile && (
              <Box display="flex" alignItems="center" >
                {srcUrl !== "" ? (
                  <div
                    role="img" aria-label={srcUrlTitle || ''}
                    style={{
                      backgroundImage: `url(${srcUrl})`,
                      backgroundPosition: "center right",
                      backgroundRepeat: "no-repeat",
                      marginRight: "10px",
                      height: "40px",
                      width: "140px",
                    }}
                  ></div>
                ) : (
                  ""
                )}
                {course.isNew && <Status className="new">{t('new')}</Status>}
                {/* {course.isMandatory && <Status className="required">{t('required')}</Status>} */}
                {(course?.dueDate && course?.dueDate !== null) && <Status className="duedate">{t("required_by")}: {dueDateFormat(course?.dueDate)}</Status>}
                {course.statusCode?.toLowerCase() !== "notenrolled" && <Status className={course.statusCode?.toLowerCase()}>{t(course.statusCode?.toLowerCase())}</Status>}
              </Box>
            )}
            {isMobile && (
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box display="flex" alignItems="center">
                  <CourseIcon
                    style={{ marginRight: "10px" }}
                    width="18px"
                    height="17px"
                    stroke={theme.palette.grey["A100"]}
                  />
                  <Typography
                    style={{
                      fontSize: "12px",
                      fontFamily: "Arial",
                      fontWeight: "bold",
                      lineHeight: "14px",
                      color: theme.palette.grey["800"],
                      letterSpacing: "2px",
                    }}
                  >
                    {t('course').toUpperCase()}
                  </Typography>
                </Box>
                {portalSettingsManager.application?.features?.allowShareContent && (
                  <Box display="flex" alignItems="center" paddingLeft="50%">
                    <IconButton
                      aria-label={t('aria_label_click_to_share') + course.name}
                      style={{
                        border: `1px solid ${theme.palette.grey["A100"]}`,
                        padding: "4px",
                        marginLeft: "10px",
                      }}
                      onClick={() => setOpenShareContent(true)}
                    >
                      <ShareIcon
                        stroke="#000000"
                        style={{ transform: "translate(20%, 25%)" }}
                        itemName=""
                      />
                    </IconButton>

                  </Box>
                )}
                {portalSettingsManager.application?.features?.allowCreatePlaylist && (
                  <Box display="flex" alignItems="center">
                    <IconButton
                      aria-label={t('aria_label_click_to_add_course_to_playlist', { course: course.name })}
                      style={{
                        border: `1px solid ${theme.palette.grey["A100"]}`,
                        padding: "4px",
                        marginLeft: "10px",
                      }}
                      onClick={() => setIsOpenPlaylist(true)}
                    >
                      <SaveToListIcon
                        fill={"#000000"}
                        style={{ transform: "translate(20%, 25%)" }}

                      />
                    </IconButton>
                  </Box>
                )}
              </Box>
            )}
            <Box flex="1">
              <Box
                margin={{ xs: "18px 0 27px 0", sm: "0 0 35px 0" }}
                fontSize={{ xs: "18px", sm: "40px" }}
                fontWeight={{ xs: "bold", sm: "400" }}
                color={theme.palette.grey["800"]}
              >
                {course.name}
              </Box>
            </Box>
            {course.summary && course.summary.length <= 500 ? (
              <Box m="10px 0 30px 0" style={{ fontSize: "13px", color: theme.palette.grey["800"], lineHeight: "21px" }}>
                <RenderHTML content={course.summary ?? ""} /> </Box>) : (sum && sum !== 'undefined' ? (
                  <Box m="10px 0 30px 0" style={{ fontSize: "13px", color: theme.palette.grey["800"], lineHeight: "21px" }}>
                    <DescriptionTag>
                      {sum + "... "}
                      <span style={{ textDecoration: "underline", cursor: "pointer" }} onClick={() => setShowDialog(true)} aria-label={t('view_more')} role="button" tabIndex={0}>{t('view_more')}</span>
                    </DescriptionTag>
                  </Box>) : "")}
            {showDialog && (<Box display="flex"
              justifyContent="space-between"
              borderBottom="1px solid  #D8D8D8;"
              paddingBottom="20px">
              <Dialog
                id="coursedetailsdialog"
                onClose={() => setShowDialog(false)}
                aria-labelledby={t('aria_label_adding_playlist_dialog')}
                open={true}
                minWidth={0}
                showCloseIcon
                minHeight={150}
                role="dialog" aria-modal="true"
              ><DialogContent style={{ padding: "8px 35px", minWidth: isMobile ? 0 : 360 }}>
                  <Typography
                    style={{
                      fontSize: "12px",
                      color: theme.palette.grey["800"],
                      lineHeight: "16px",
                      marginTop: "10px",
                    }}
                  >
                    <RenderHTML content={course.summary ?? ""} />
                  </Typography>
                </DialogContent>
              </Dialog>
            </Box>)}
            {isMobile ? (
              <>
                <Box>
                  <Rating
                    score={course.rating || 0}
                    numberOfReviews={course.numberOfPeopleWhoRated || 0}
                    onSubmit={handleRating}
                    mobile
                  />
                </Box>
                <Box marginBottom="20px" display="flex" alignItems="center">
                  <span
                    style={{ fontSize: "12px", color: theme.palette.grey["800"], letterSpacing: 0 }}
                  >
                    {!!course.createdOnDisplay &&
                      `${t('created_on')} ${mobileDateString(new Date(course.createdOnDisplay))}`}
                  </span>
                  {srcUrl !== "" ? (
                    <div
                      style={{
                        backgroundImage: `url(${srcUrl})`,
                        backgroundPosition: "center right",
                        backgroundRepeat: "no-repeat",
                        margin: "0 10px",
                        height: "40px",
                        width: "140px",
                      }}
                    ></div>
                  ) : (
                    ""
                  )}
                  {course.hasCertificate && <CertificationIcon style={{ margin: '0 10px', width: '38px', height: '40px' }}
                    stroke={theme.palette.grey["800"]} />}
                  {enrolledPathwayId && <Link to={`/PATHWAY/${enrolledPathwayId}`}><PathwayIcon width="35px" height="35px" stroke={theme.palette.grey["800"]} /></Link>}
                </Box>
              </>
            ) : (
              <>
                <Box>
                  <span
                    style={{ fontSize: "14px", color: theme.palette.grey["800"], letterSpacing: 0 }}
                  >
                    {!!course.createdOnDisplay && `${t('created_on')} ${course.createdOnDisplay}`}
                  </span>
                </Box>
                <Box>
                  <Rating
                    score={course.rating || 0}
                    numberOfReviews={course.numberOfPeopleWhoRated || 0}
                    onSubmit={handleRating}
                  />
                </Box>
              </>
            )}
            <Box display="flex" flexWrap="wrap" marginBottom={{ xs: "5px", sm: "30px" }} role="list">
              {(course.tags || []).map((tag, index) =>
                tag ? (
                  <span
                    role="listitem"
                    key={index}
                    aria-label={tag}
                    style={{
                      fontSize: "11px",
                      color: theme.palette.grey["800"],
                      marginRight: "7px",
                      marginBottom: "7px",
                      padding: "3px 15px",
                      background: "#f5f5f5",
                    }}
                  >
                    {tag}
                  </span>
                ) : (
                  <></>
                )
              )}
            </Box>
            {isCourseEnrolled && showActivityAction && canLaunchCourseByPathWay.canLaunchCourseBySequencialPathway.canLaunch && (
              <MBC bgcolor={theme.palette.grey["800"]}>
                <MBC.Button className={focusClass.focusItem} style={{ width: "50%" }} onClick={() => setOpenUnenroll(true)}>
                  {t('unenroll').toUpperCase()}
                </MBC.Button>
                <MBC.Button
                  onClick={() => setOpenCourses(true)}
                  className={focusClass.focusItem}
                  style={{ width: "50%", backgroundColor: theme.palette.primary.main }}
                >
                  {t('launch_activity')}
                </MBC.Button>
              </MBC>
            )}
            {userContext?.userContext?.permissions?.includes(PERMISSIONS.CAN_ENROLL_USERS) &&
              course.canEnroll && (
                <MBC>
                  <MBC.Button onClick={() => handleOpenEnroll()} className={focusClass.focusItem}>{t((course.isEnrolled || !course.allowSelfEnrol) ? 'enroll_others' : 'enroll').toUpperCase()}</MBC.Button>
                </MBC>
              )}
            {(!userContext?.userContext?.permissions?.includes(PERMISSIONS.CAN_ENROLL_USERS))
              && !course.isEnrolled && course.canEnroll && course.allowSelfEnrol && (
                <MBC>
                  <MBC.Button onClick={() => handleOpenEnroll()} className={focusClass.focusItem}>{t('enroll').toUpperCase()}</MBC.Button>
                </MBC>
              )}
            <Box display="flex" alignItems="center">
              <Box display={{ xs: "none", sm: "block" }} className={focusClass.focusItem}>
                {(userContext?.userContext?.permissions?.includes(PERMISSIONS.CAN_ENROLL_USERS) &&
                  course.canEnroll) && (
                    <Action
                      aria-controls="enroll-button"
                      onClick={() => handleOpenEnroll()}
                      className={focusClass.focusItem}
                    >
                      {(course.isEnrolled || !course.allowSelfEnrol) ? t('enroll_others') : t('enroll')}
                    </Action>
                  )}
                {course.canExpressInterest &&
                   <Action
                    aria-controls="enroll-button"
                    onClick={handleSuggestADate}
                    className={focusClass.focusItem}
                  >
                    {t('suggest_a_date').toUpperCase()}
                  </Action>
                }
                {(!userContext?.userContext?.permissions?.includes(PERMISSIONS.CAN_ENROLL_USERS))
                  && !course.isEnrolled && course.canEnroll && course.allowSelfEnrol && (
                    <Action
                      aria-controls="enroll-button"
                      onClick={() => handleOpenEnroll()}
                      style={{ width: "88px" }}
                      className={focusClass.focusItem}
                    >
                      {t('enroll')}
                    </Action>
                  )}
                {course.isEnrolled && course.canUnenroll && (
                  <Action
                    aria-controls="unenroll-button"
                    onClick={() => setOpenUnenroll(true)}
                    className={focusClass.focusItem}
                    style={{ width: "108px" }}
                  >
                    {t('unenroll')}
                  </Action>
                )}
                {portalSettingsManager.application?.features?.allowShareContent && (
                  <Action
                    aria-controls="share-button"
                    //aria-haspopup="true"
                    onClick={() => setOpenShareContent(true)}
                    className={focusClass.focusItem}
                    startIcon={<SvgIcon component={shareIcon} />}
                    style={{ width: "103px" }}
                  >
                    {t('share')}
                  </Action>
                )}
                {portalSettingsManager.application?.features?.allowCreatePlaylist && (
                  <Action
                    aria-controls="add-to-playlist"
                    //aria-haspopup="true"
                    onClick={() => setIsOpenPlaylist(true)}
                    className={focusClass.focusItem}
                    startIcon={<SvgIcon component={saveToListIcon} />}
                    style={{ width: "163px", padding: "0px" }}
                  >
                    {t('add_to_playlist')}
                  </Action>
                )}
              </Box>
            </Box>
          </Box>
          <Box
            className={classes.boxFullWidth}
            width={{ xs: "100%", sm: "calc(50% - 85px)" }}
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: isMobile ? "flex-end" : undefined,
              marginLeft: "10px",
            }}
          >
            <Box style={{ display: "flex", justifyContent: isMobile ? "flex-end" : undefined }}>
              <Box>
                <Box
                  height="280px"
                  width={isMobile ? "360px" : isPad ? "450px" : isMD ? "350px" : "450px"}
                  position="relative"
                  style={{
                    backgroundImage: `url(${course?.imageUrl || contentBg})`,
                    backgroundPosition: "center center",
                    backgroundSize: "cover",
                    display: isMobile ? "flex" : undefined,
                    flexDirection: isMobile ? "column" : undefined,
                    justifyContent: "flex-end",
                  }}
                >
                  {isMobile && <ContentBanner item={course} showProgress />}
                </Box>
                {course.isEnrolled && course.statusCode === "InProgress" && (course.percentageComplete || course.percentageComplete === 0) && (
                  <progress
                    max="100"
                    value={course.percentageComplete}
                    data-label={t('inprogress').toUpperCase()}
                    style={{ appearance: "unset", display: "block", height: "5px", width: "100%" }}
                  />
                )}
              </Box>
              {!isMobile && <Box display="flex" flexDirection='column' style={{ marginLeft: '10px' }}>
                {enrolledPathwayId && <Link to={`/PATHWAY/${enrolledPathwayId}`} onClick={() => sessionStorage.setItem("relatedItemClick", "true")}><DetailIcon label="Course in Pathway" showDivider={Boolean(course.durationDisplay || course.hasCertificate)}>
                  <PathwayIcon style={{ width: "35px", height: "35px" }} stroke={theme.palette.grey["800"]} />
                </DetailIcon></Link>}
                {course.durationDisplay && <DetailIcon label={formatTime(course.durationDisplay)} showDivider={Boolean(course.hasCertificate)}>
                  <CourseDetailsTimeIcon style={{ width: "35px", height: "35px" }}
                    stroke={theme.palette.grey["800"]} />
                </DetailIcon>}
                {course.hasCertificate && <DetailIcon>
                  <CertificationIcon
                    width="54px"
                    height="64px"
                    stroke={theme.palette.grey["800"]}
                  />
                </DetailIcon>}
              </Box>}
            </Box>
          </Box>
        </Box>
        <Tabs
          value={value}
          aria-label={t('aria_label_course_details_activities_tabs')}
          tabs={[{ label: t('course_details') }, { label: t('activities') }]}
          onChange={handleChange}
        />
        <TabPanel value={value} index={0} style={{ padding: "24px 0" }}>
          <DescriptionTag style={{ fontSize: "18px", color: "#333333", fontFamily: "Arial" }}>
            <RenderHTML content={course.description ?? ""} />
          </DescriptionTag>
        </TabPanel>
        <TabPanel value={value} index={1} style={{ padding: "24px 0" }}>
          {canLaunchCourseByPathWay && <ActivityWarning data={canLaunchCourseByPathWay} />}
          {!!activities && (
            <>
              {activities.map((activity, index: number) => {
                showHeader = prevActivityType === ActivityType.DIVIDER && activity.type !== ActivityType.DIVIDER; 
                prevActivityType = activity.type;
                isFirstActivity = (activity.type !== ActivityType.DIVIDER && isFirstActivity === null) ? true: isFirstActivity === null? null: false;
              
                return (
                  <Activity
                    key={index}
                    activity={activity}
                    source={course.source}
                    courseID={String(course.id)}
                    showHeader={showHeader}
                    isFirstActivity={isFirstActivity}
                    showAction={isCourseEnrolled && showActivityAction}
                    showSession={true}
                    handleEnroll={handleEnroll}
                    handleActivityRefresh={handleActivityRefresh}
                    handleOpenWorkshop={handleOpenWorkshop}
                  />
                );
              })}
            </>
          )}
        </TabPanel>

        <UnenrollDialog
          course={course}
          handleEnroll={handleEnroll}
          open={openUnenroll}
          handleClose={() => setOpenUnenroll(false)}
          learnerEmail={userContext?.userContext?.learnerEmail}
          canEditLineManagerEmail={userContext?.userContext?.canEditLineManagerEmail}
        />
        {openShareContent && (
          <ShareDialog
            open={openShareContent}
            course={course}
            contentType="course"
            shareLink={window.location.href}
            handleClose={() => setOpenShareContent(false)}
          />
        )}
        {isOpenPlaylist && (
          <PlayListDialog
            title={t('playlist_dialog_title')}
            description={t('playlist_dialog_discription')}
            contentId={course.id}
            contentType={getContentType("course")}
            open={isOpenPlaylist}
            handleConfirm={() => setIsOpenPlaylist(false)}
            handleClose={() => setIsOpenPlaylist(false)}
          />
        )}
      </Box>
    </>
  );
};