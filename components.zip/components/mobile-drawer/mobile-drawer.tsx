import React from "react";
import { Box, Button, Drawer, Hidden } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import { useTranslation } from "react-i18next";

type MobileDrawerProps = {
  closeMessage?: string;
  isOpen: boolean;
  onVisibilityChange: (state: boolean) => void;
};

export const MobileDrawer: React.FC<MobileDrawerProps> = ({
  children,
  closeMessage ="Close Menu",
  isOpen,
  onVisibilityChange,
}) => {
  const theme = useTheme();
  const { t } = useTranslation();

  return (
    <>
      <Hidden smUp>
        <Drawer anchor="right" open={isOpen} onClose={() => onVisibilityChange(false)}>
          <Box width="100vw">
            <Box padding="20px">{children}</Box>
            <Box
              position="absolute"
              bottom="0"
              left="0"
              borderTop={`1px solid ${theme.palette.grey["A100"]}`}
              width="100%"
              height="42px"
            >
              <Button
                style={{ fontSize: "11px", fontWeight: "bold", height: "100%" }}
                fullWidth
                onClick={() => onVisibilityChange(false)}
              >
                {t('close_menu')}
              </Button>
            </Box>
          </Box>
        </Drawer>
      </Hidden>
    </>
  );
};
