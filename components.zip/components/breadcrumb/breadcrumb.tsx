
import Breadcrumbs from '@material-ui/core/Breadcrumbs';
import Tooltip from "@material-ui/core/Tooltip";
import { Link } from 'react-router-dom';
import { Button, SvgIcon, Typography, useMediaQuery, withStyles } from '@material-ui/core';
import { useTheme } from "@material-ui/core/styles";
import { ReactComponent as arrowIcon } from "assets/icons/icon-arrow.svg";
import { useTranslation } from "react-i18next";

const CustomBreadcrumbs = withStyles(() => ({
    root: {
      "& .MuiBreadcrumbs-separator": {
        marginLeft: 2,
        marginRight: 2,
      }
    },
  }))(Breadcrumbs);

export const BreadCrumb = ({ breadCrumbData, handleBreadCrumbClick }: any) => {
    const theme = useTheme();
    const { t } = useTranslation();
    const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
    const handleClick = (e: any, path: string, breadCrumbKey: any) => {
        e.preventDefault();
        handleBreadCrumbClick(path, breadCrumbKey);
    }
    return (
        <div style={isMobile ? { marginTop: "5%", marginLeft : "-8%"} : {}}>
            <CustomBreadcrumbs aria-label={t('aria_label_breadcrumb')} >
                {
                    breadCrumbData && JSON.parse(breadCrumbData).data.map((index: any, key: any) => {
                        return (<span key={index.path} onClick={(e) => handleClick(e, index.path, key)} role="link">
                            {index.title === t('home') ? <Button
                                aria-controls="home-button"                                
                                role='presentation'
                                startIcon={
                                    <SvgIcon
                                        component={arrowIcon}
                                        style={{ transform: "rotate(180deg) translate(25%, 30%)", marginRight: "-8px" }}
                                    />
                                }
                                style={{ fontSize: isMobile ? "8px" : "11px", color: theme.palette.grey['800'], marginRight: "-8px", marginLeft: "25px", textTransform: "none" }}
                            >
                                {index.title}
                            </Button> :
                                <Tooltip title={`${index.title}` + `${index.title === t('search_results_title') && JSON.parse(breadCrumbData).searchString.length > 0 ? " (" + JSON.parse(breadCrumbData).searchString + ")" : ""}`}
                                >
                                    <Button
                                         role='presentation'
                                        style={{ fontSize: "11px", minWidth:"auto", color: theme.palette.grey['800'], textTransform: "none" , paddingLeft: 2, paddingRight: 2}}
                                    >   <Typography style={{
                                        maxWidth: isMobile ? "50px" :"150px",
                                        whiteSpace: "nowrap",
                                        overflow: "hidden",
                                        textOverflow: "ellipsis",
                                        fontSize: isMobile ? "8px" : "11px", color: theme.palette.grey['800'],
                                        fontWeight: key === JSON.parse(breadCrumbData).data.length - 1 ? "bold" : "normal",
                                    }}>
                                            {index.title}
                                            {index.title === t('search_results_title') && JSON.parse(breadCrumbData).searchString.length > 0 && " (" + JSON.parse(breadCrumbData).searchString + ")"}

                                        </Typography>

                                    </Button>
                                </Tooltip>
                            }
                        </span>
                        )
                    })
                }

            </CustomBreadcrumbs >
        </div>
    )
}