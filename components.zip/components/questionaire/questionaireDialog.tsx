import { IconButton, Dialog as MuiDialog, Box, Typography, Button } from "@material-ui/core";
import { Theme, makeStyles, withStyles } from "@material-ui/core/styles";
import CloseIcon from "@material-ui/icons/Close";

import { DialogContent, DialogTitle } from "components";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";

const useStyles = makeStyles((theme: Theme) => ({
  DialogContainer: {
    margin: `${theme.spacing(2)}px`,
  }
}));

const StyledDialog = withStyles((theme: Theme) => ({
  root: {},
  paper: { borderRadius: 0 } ,
}))(MuiDialog);

const RejectActionButton = withStyles((theme:Theme) => ({
  root: {
    borderRadius:0,
  },
}))(Button);

const ConfirmActionButton = withStyles((theme:Theme) => ({
  root: {
    borderRadius:0,
    color: portalSettingsManager.buttonColors?.themed?.active?.text || theme.palette.primary.main,
    border: `1px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
  },
}))(Button);

type QuestionaireConfirmationDialogProps = {
  open: boolean;
  onClose: (params:{confirmed:boolean}) => void;
};

const QuestionaireConfirmationDialog = ({ open, onClose }: QuestionaireConfirmationDialogProps) => {
  const { t } = useTranslation();
  const handleConfirmation = () => {
    onClose({confirmed:true});
  };

  const handleRejection = () => {
    onClose({confirmed:false});
  };

  return (
    <StyledDialog open={open} disableBackdropClick={true}>
      <DialogTitle>
        <IconButton
          aria-label="aria_label_close_report_dialog"
          onClick={handleRejection}
          style={{ padding: "5px" }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent style={{ display: "flex", flexDirection: "column", overflowY: "visible", height: "100%" }}>
        <Box style={{ width: "300px" }}>
          <Box style={{ marginBottom: "12px", marginTop: "-6px" }}>
            {t('questionare_confirmation_add_skills', "Adding Skills")}
          </Box>
          <Box style={{ fontSize: "14px", wordSpacing: "6px" }}>
            {t(
              'questionare_confirmation_text',
              "In order to add a skill to your profile, you must first take the corresponding skills assessment. Are you prepared to take that assessment now?"
            )}
          </Box>
          <Box style={{ display: "flex", justifyContent: "end", marginTop: 20, marginBottom: 15 }}>
            <RejectActionButton
              onClick={handleRejection}
              variant="outlined"
              role="link"
              aria-label="No"
              style={{ marginRight: 20 }}
            >
              {t('no')}
            </RejectActionButton>
            <ConfirmActionButton
              onClick={handleConfirmation}
              variant="outlined"
              aria-label="Yes"
            >
              {t('yes')}
            </ConfirmActionButton>
          </Box>
        </Box>
      </DialogContent>
    </StyledDialog>
  );
};

type QuestionaireNavigatorProps = {
  onClose: (params:{confirmed:boolean}) => void;
};

export const QuestionaireNavigator: React.FC<QuestionaireNavigatorProps> = ({
  onClose,
}: QuestionaireNavigatorProps) => {
  const showConfirmation = true;
  if (showConfirmation) {
    return <QuestionaireConfirmationDialog open={showConfirmation} onClose={onClose} />;
  }
  return <div></div>;
};
