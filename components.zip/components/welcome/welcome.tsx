import { Box, Button, Typography, useMediaQuery } from "@material-ui/core";
import { Theme, withStyles, useTheme } from "@material-ui/core/styles";
import certificationIcon from "assets/icons/icon-certification-landing.svg";
import { RequiredLearningIconLanding, CourseCompletionIconLanding, CourseRequiredIconLanding } from "components/common-icons/common-icons";
import { RenderHTML } from "components";
import { useFocusStyles } from "hooks/focusBorder";
import { useState } from "react";
import { useAppDispatch } from "store";
import { useHistory } from "react-router-dom";
import { CATEGORY_CODE_ALL, REQUIRED_LEARNING, COURSES_COMPLETE, CERTIFICATIONS_ACQUIRED, CATEGORY_CODE_REQUIRED, SORT_DEFAULT } from "utils/constants";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";
import { SvgIcon } from "@material-ui/core";

const MatrixBox = withStyles((theme: Theme) => ({
  root: (props: any) => ({
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center",
    marginBottom: "20px",
    cursor: "pointer",
    [theme.breakpoints.down("sm")]: {
       display: "block",
    },
  }),
}))(Box);

const MessageTextBox = withStyles((theme: Theme) => ({
  root: {
    // "& p:first-child": { display: "none" },
    "& p": { textAlign: "left !important", fontSize: "14px", fontFamily: "Arial" },
  },
}))(Box);

const Matrix = ({ bg, label, count, handleMetricSearch, metricsType, labelColor, iconBackground, metricsColor }: any): JSX.Element => {
  const theme = useTheme();
  return (
    <MatrixBox onClick={() => handleMetricSearch(metricsType)} tabIndex={0}>
      <Box
        style={{
          backgroundColor: iconBackground,
          height: "48px",
          width: "52px",
          minWidth: "52px",
          borderRadius: "50%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
      <div style={{ cursor: "pointer", height: "27px" }} >{bg}</div>
      </Box>
      <Box style={{ display: "flex", flexDirection: "column", marginLeft: "10px" }}>
        <Typography
          style={{
            fontSize: "24px",
            fontWeight: "bold",
            lineHeight: "31px",
            textAlign: "start",
            color: metricsColor
          }}
        >
          {count}
        </Typography>
        <Typography
          style={{
            fontSize: "11px",
            lineHeight: "16px",
            textAlign: "start",
            minWidth: "75px",
            maxWidth: "75px",
            color: labelColor
          }}
        >
          {label}
        </Typography>
      </Box>
    </MatrixBox>
  );
};

type IconProps = React.ComponentProps<typeof SvgIcon>;

export const Welcome = ({
  name,
  message,
  learningCount,
  completionCount,
  isLandingPage,
  certificationCount,
  metricsList,
}: any): JSX.Element => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const focusClass = useFocusStyles();
  const [isExpanded, setIsExpanded] = useState(portalSettingsManager.application?.common?.isWelcomeMessagePersistent);

  function toggleIsExpanded() {
    setIsExpanded(!isExpanded);
  }

  const isGreetByName = portalSettingsManager.application?.common?.greetLearnerByName;
  const dispatch = useAppDispatch();
  const history = useHistory();
  const { t } = useTranslation();
  const haldeMetricSearch = (type: string) => {
    dispatch({
      type: "metrics/filter",
      payload: type,
    });
    if (type === "Required") {
      dispatch({
        type: "subheader/title",
        payload: REQUIRED_LEARNING,
      });
    } else if (type === "Courses") {
      dispatch({
        type: "subheader/title",
        payload: COURSES_COMPLETE,
      });
    } else if (type === "Certifications") {
      dispatch({
        type: "subheader/title",
        payload: CERTIFICATIONS_ACQUIRED,
      });
    }
    dispatch({
      type: "search/setSearchFilters",
      payload: {
        sort: SORT_DEFAULT,
        text: "",
        code: isLandingPage ? CATEGORY_CODE_REQUIRED : CATEGORY_CODE_ALL
      },
    });

    history.push("/catalog");
  };

  message = (message && message !== null  && message !== '' )? message.replace(/^"(.*)"$/, "$1").replace(/\\n/g, "").replace(/\/n/g, "").replace(/\\/g, ""):'';

  return ( 
    <Box
      p={isMobile?"25px 60px 25px 25px":"25px 60px 25px 70px"} 
      borderBottom="1px solid #c9c9c9"
      style={{ display: "flex", flexDirection : (isMobile ? "column" : "row"), color: portalSettingsManager?.landingPageSubHeader?.colors?.base?.text, backgroundColor: portalSettingsManager?.landingPageSubHeader?.colors?.base?.back}}
    >
      <Box style={{ marginRight:"40px" }}>
        <Typography component="h1" style={{ fontSize: "22px", marginBottom: "6px", color: portalSettingsManager?.landingPageSubHeader?.colors?.base?.text }} role="presentation">
          {t("welcome_text")}
          <strong> {(isGreetByName) ? name : ""}</strong>
          {message && message !== null  && message !== '' && (
            <Button
              style={{
                marginLeft: "20px",
                borderRadius: 0,
                padding: "10px 14px",
                height: "36px",
                color: portalSettingsManager?.buttonColors?.showHideWelcomeText?.active?.text,
                border: `1px solid ${portalSettingsManager?.buttonColors?.showHideWelcomeText?.active?.border}`,
                fontSize: "12px",
                backgroundColor: portalSettingsManager?.buttonColors?.showHideWelcomeText?.active?.back || theme.palette.primary.main,
              }}
              aria-expanded={isExpanded}
              className= {`${focusClass.primaryHover} ${focusClass.focusItem}`} 
              onClick={toggleIsExpanded}
            >
              {isExpanded ? t("close_message") : t("view_message")}
            </Button>
          )}
          </Typography>        
        {isExpanded && message && (
          <Box
            style={{ display: "flex", width: "100%", lineHeight: "21px", backgroundColor: portalSettingsManager?.landingPageSubHeader?.colors?.welcomeText?.back, color: portalSettingsManager?.landingPageSubHeader?.colors?.welcomeText?.text}}
            textAlign={{ xs: "center", sm: "left" }}
          >
            <MessageTextBox>
              {" "}
              <RenderHTML
                content={message}
              />
            </MessageTextBox>
          </Box>
        )}

      </Box>
      {metricsList && ((learningCount !== undefined && learningCount !== 0) || (completionCount !== undefined && completionCount !== 0) || (certificationCount !== undefined && certificationCount !== 0)) && (
        <Box style={{ marginLeft: (isMobile ? "0px" : "auto"), maxWidth:"400px"}} display={"block"}>
          <Typography style={{ fontSize: "1em", color: portalSettingsManager?.landingPageSubHeader?.colors?.base?.text}}>{t("my_progress")}</Typography>
          <Box style={{ display: "flex",  marginTop: "16px" }} role="link">
            {learningCount !== undefined && learningCount !== 0 && (
              <Matrix
                bg={
                  <RequiredLearningIconLanding
                    htmlColor={
                      portalSettingsManager?.landingPageSubHeader?.colors?.requiredIcon?.text
                    }
                    height="100%"
                    width="100%"
                  />
                }
                label={t('required_learning_metric')}
                className={focusClass.focusItem}
                count={learningCount}
                handleMetricSearch={haldeMetricSearch}
                inputProps={{ tabIndex: 0 }}
                metricsType="Required"
                role="link"
                labelColor= {portalSettingsManager?.landingPageSubHeader?.colors?.metricsNumbers?.required}
                iconBackground={portalSettingsManager?.landingPageSubHeader?.colors?.requiredIcon?.back}
                metricsColor={portalSettingsManager?.landingPageSubHeader?.colors?.metricsNumbers?.required}
              />)}
            {completionCount !== undefined && completionCount !== 0 && (
              <Matrix
                bg={
                  <CourseCompletionIconLanding
                    htmlColor={
                      portalSettingsManager?.landingPageSubHeader?.colors?.completeIcon?.text
                    }
                    height="100%"
                    width="100%"
                  />
                }
                label={t('courses_complete_metric')}
                count={completionCount}
                className={focusClass.borderItem}
                handleMetricSearch={haldeMetricSearch}
                metricsType="Courses"
                labelColor= {portalSettingsManager?.landingPageSubHeader?.colors?.metricsNumbers?.complete}
                iconBackground={portalSettingsManager?.landingPageSubHeader?.colors?.completeIcon?.back}
                metricsColor={portalSettingsManager?.landingPageSubHeader?.colors?.metricsNumbers?.complete}
              />
            )}
            {certificationCount !== undefined && certificationCount !== 0 && (
              <Matrix
                bg={
                  <CourseRequiredIconLanding
                    htmlColor={
                      portalSettingsManager?.landingPageSubHeader?.colors?.certificateIcon?.text
                    }
                    height="100%"
                    width="100%"
                  />
                }
                label={t('certifications_acquired_metric')}
                className={focusClass.focusItem}
                count={certificationCount}
                handleMetricSearch={haldeMetricSearch}
                metricsType="Certifications"
                labelColor= {portalSettingsManager?.landingPageSubHeader?.colors?.metricsNumbers?.certificate}
                iconBackground={portalSettingsManager?.landingPageSubHeader?.colors?.certificateIcon?.back}
                metricsColor={portalSettingsManager?.landingPageSubHeader?.colors?.metricsNumbers?.certificate}
              />
            )}
          </Box>
        </Box>
      )}
    </Box>
  );
};
