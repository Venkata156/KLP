import { useQuery } from "@apollo/client";
import { Typography, Box, useMediaQuery, FormLabel } from "@material-ui/core";
import { withStyles, styled, makeStyles, Theme, useTheme } from "@material-ui/core/styles";
import { Dialog, DialogActions, DialogContent, Action } from "components";
import * as PlaylistTypes from "utils/graphql/Playlist";
import React, { useEffect, useState} from "react";
import { PLAYLISTS } from "utils/queries";
import errorIcon from "assets/icons/icon-triangle.svg";
import sanitizeHtml from "sanitize-html"
import { useAppDispatch } from "store";
import { useTranslation } from "react-i18next";

const useStyles = makeStyles(() => ({
  root: {
    "& .MuiPaper-root": {
      borderRadius: "0px",
    },
  },
}));

const Label = withStyles(() => ({  
  root: {
    display: "block",
    fontSize: "12px",
    color: "#999999",
    marginTop: "29px",
    marginBottom: "10px",
  },
}))(FormLabel);

const PlaylistName = styled("input")({
  marginTop: 2,
  borderWidth:"1px",
  padding: "10px 7px",
  width: "calc(100% - 5%)",
  "&:disabled": {
    color: "#999999",
  },
});

const ErrorMessage = styled("div")(() => ({
  background: "#d0021b",
  color: "#fff",
  fontSize: 11,
  padding: "5px 20px",
  marginLeft: 2,
}));

const Description = styled("textarea")({
  padding: "10px 10px",
  width: "calc(100% - 6%)",
  marginTop:"4px",
  borderWidth:"1px"
});

export const PlayListEditDialog: React.FC<{
  open: boolean;
  title?: string;
  updatePlaylist: (name: string, summary: string) => void;
  handleClose: () => void;
  itemDetail: any;
}> = ({ open, updatePlaylist, itemDetail, handleClose}) => {
  const [playlistName, setPlaylistName] = useState(itemDetail.name);
  const [playlistSummary, setPlaylistSummary] = useState(itemDetail.summary);
  const [isPlaylistExist, setIsPlaylistExist] = useState(false);
  const classes = useStyles();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const { t } = useTranslation();
  const dispatch = useAppDispatch();  
  const isPad = useMediaQuery(theme.breakpoints.down("sm"));
  const RequiredLabel = withStyles((theme: Theme) => ({
    root: {
      display: "block",
      fontSize: "12px",
      color: theme.palette.grey['500'],  
      marginTop: "-20px",
      marginLeft: "80px", 
      paddingBottom: "5px",
      "&:after": {
        content: `" *"`,
        color: "red",
      },
    },
  }))(Box);
  const { data, loading } = useQuery<PlaylistTypes.Playlist>(PLAYLISTS);

  useEffect(() => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: loading, message: t("playlist_loading", "") },
    });
}, [loading]);

  const validatePlaylist = () => {
    const result = data?.playlists?.filter(item => item?.id.replaceAll("-", "") !== itemDetail.id.replaceAll("-", "") && item?.title?.toLowerCase().trim() === playlistName.toLowerCase().trim());
    let isExist = true
    if (!result?.length) {
      isExist = false;
      updatePlaylist(sanitizeHtml(playlistName), sanitizeHtml(playlistSummary))
    }
    setIsPlaylistExist(isExist)
  }

  return (
    <Dialog
      id="editplaylist"      
      onClose={handleClose}
      aria-modal= "true"
      role="dialog"  
      aria-labelledby="edit_playlist_label"
      open={open}
      minWidth={isMobile ? undefined : 430}      
      minHeight={isPad ? 359 : 430}
      className={classes.root}
      showCloseIcon      
    >
      <DialogContent style={{ padding: "8px 35px" }}>
        <Typography
        id="edit_playlist_label"
          component={'h2'}
          style={{ fontSize: "16px", color: "#333333", fontWeight: 400, paddingBottom: "5px" }}
        >
          {t('edit_playlist')}
        </Typography>
        <Typography
          style={{ fontSize: "12px", color: "#333333", lineHeight: "18px", fontWeight: 400 }}
        >
          {t('playlistedit_name')}
        </Typography>

        
        <Label style={{marginTop : (isPad ? "5px" : "29px"), marginBottom : (isPad ? "9px" : "10px") }} htmlFor='playlist-name'>{t('playlist_editname')}</Label><RequiredLabel></RequiredLabel>
        <PlaylistName
          id='playlist-name'
          placeholder={t('choose')}
          value={playlistName}
          aria-label={t('aria_label_enter_playlist_name')}
          aria-required="true"
          onChange={(event) => setPlaylistName(event.target.value.length > 48 ? playlistName : event.target.value)}
        />
        {isPlaylistExist ? <ErrorMessage>
          <img style={{ width: 10, marginRight: 5 }} alt={t('error_icon')} src={errorIcon} /> {t('duplicate_playlist_name_message')}
        </ErrorMessage> : ""}
        <Box style={{ marginTop:(isPad ? "5px" : "30px") }}>
          <Label style={{marginTop : (isPad ? "5px" : "29px"), marginBottom : (isPad ? "5px" : "10px") }} htmlFor="playlist-description">{t('playlist_edit_description')}</Label>
          <Description
            id='playlist-description'
            aria-label={t('aria_label_enter_playlist_description')}
            rows={4}
            placeholder={t('choose')}
            value={playlistSummary}
            onChange={(event) => setPlaylistSummary(event.target.value)}
          />
        </Box>        
        
      </DialogContent>

      <DialogActions style={{ padding: "18px 35px 29px 35px" }}>
        <Action type="dialog-alt" onClick={handleClose}>
          {t('cancel_and_close')}
        </Action>
        <Action
          type="dialog-primary"
          disabled={playlistName === "" || (playlistName === itemDetail.name && playlistSummary === itemDetail.summary)}
          onClick={() => validatePlaylist()}
          style={{ height: "32px" }}
        >
          {t('save')}
        </Action>
      </DialogActions>
    </Dialog>
  );
};
