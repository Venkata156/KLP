import { Typography, DialogContent, Button as MuiButton, Box, Divider,useMediaQuery, MenuItem } from "@material-ui/core";
import { Theme, withStyles, styled, makeStyles, useTheme } from "@material-ui/core/styles";
import { Dialog, DialogActions } from "components";
import { useEffect, useState } from "react";
import { PLAYLISTS, ADD_CONTENT_TO_PLAYLIST, SAVE_PLAYLIST} from "utils/queries";
import * as PlaylistTypes from "utils/graphql/Playlist";
import { useMutation, useQuery } from "@apollo/client";
import errorIcon from "assets/icons/icon-triangle.svg";
import sanitizeHtml from "sanitize-html"
import {
  PlaylistPermission,
  SavePlaylistContentInput,
  SavePlaylistParametersInput,
} from "utils/graphql/Global";
import { useAppDispatch } from "store";
import { useFocusStyles } from "hooks/focusBorder";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";
import MuiSelect from "@material-ui/core/Select";

const useStyles = makeStyles(() => ({
  root: {
    "& .MuiPaper-root": {
      borderRadius: "0px",
    },
  },
}));

const Button = withStyles((theme: Theme) => ({
  root: {
    flex: 1,
    borderRadius: 0,
    color: portalSettingsManager.buttonColors?.themed?.active?.text || theme.palette.primary.main,
  },
  label: {
    fontSize: 11,
    fontWeight: 700,
  },
  outlined: {
    border: `1px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
  },
  disabled: {
    color: theme.palette.grey["500"],
  },
}))(MuiButton);

const Clear = withStyles((theme: Theme) => ({
  root: {
    borderRadius: 0,
    color: portalSettingsManager.application?.common?.themeColor,
    fontSize: "12px",
    fontWeight: 700,
    padding: "0px",
    paddingLeft: "22px",
  },
  outlined: {
    border: `1px solid ${portalSettingsManager.application?.common?.themeColor}`,
  },
  disabled: {
    color: theme.palette.grey["500"],
  },
}))(MuiButton);

const Label = withStyles((theme: Theme) => ({
  root: {
    display: "block",
    fontSize: "12px",
    color: theme.palette.grey["500"],
    marginTop: "29px",
    marginBottom: "10px",
  },
}))(Box);

const PlaylistName = styled("input")(({ theme }) => ({
  marginLeft: "1px",
  padding: "10px 7px",
  width: "calc(100% - 5%)",
  fontFamily: "Arial",
  fontSize: "12px",
  "&:disabled": {
    color: theme.palette.grey["500"],
  },
  "&.error": {
    color: "#d0021b",
  },
}));

const ErrorMessage = styled("div")(({ theme }) => ({
  background: "#d0021b",
  color: "#fff",
  fontSize: 11,
  padding: "5px 20px",
  marginLeft: 2,
}));

const Description = styled("textarea")({
  padding: "10px 10px",
  width: "calc(100% - 20px)",
  fontFamily: "Arial",
  fontSize: "12px",
});

const CtlWrapper = withStyles((theme: Theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    width: "calc(100% - 0%)",
    minHeight: "40px",
    marginTop: "5px",
    overflow: "visible",
    "& input": {
      color: theme.palette.primary.main,
      border: "none",
      width: "100%",
      "&:focus": {
        outline: "none",
      },
    },
    "& select": {
      color: theme.palette.primary.main,
      border: `1px solid ${theme.palette.grey["A100"]}`,
      width: "100%",
      "&:focus": {
        outline: "none",
      },
      "&:disabled": {
        color: theme.palette.grey["500"],
      },
      padding: "13px 0px 13px 5px",
    },
  },
}))(Box);

const MobileSelect = withStyles((theme) => ({
  root: {
    color: portalSettingsManager.application?.common?.themeColor,
    border: `1px solid ${theme.palette.grey["A100"]}`,
    width: "100%",
    fontSize:13,
    "&:focus": {
      outline: "none",
    },
    "&:disabled": {
      color: theme.palette.grey["500"],
    },
    padding: "13px 0px 13px 5px",
  },

}))(MuiSelect);
const MobileMenu = withStyles((theme) => ({
  root: {
    color: portalSettingsManager.application?.common?.themeColor,  
  },

}))(MenuItem);


export const PlayListDialog = ({
  open,
  title,
  contentId,
  contentType,
  isLanding,
  reload,
  handleClose,
  description,
}: any): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const [newPlayList, setNewPlayList] = useState("");
  const [playlistSummary, setPlaylistSummary] = useState("");
  const [existingPlaylist, setExistingPlaylist] = useState("");
  const [isNewPlaylistSelected, setIsNewPlaylistSelected] = useState(false);
  const [isPlaylistExist, setIsPlaylistExist] = useState(false);
  const [isExistingPlaylisSelected, setIsExistingPlaylisSelected] = useState(false);
  const classes = useStyles();
  const dispatch = useAppDispatch();
  const [addContentToPlaylist] = useMutation(ADD_CONTENT_TO_PLAYLIST);
  const [savePlaylist] = useMutation(SAVE_PLAYLIST);
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const validatePlaylist = () => {
    const result = data?.playlists?.filter(item => item?.title?.toLowerCase().trim() === newPlayList.toLowerCase().trim());
    let isExist = true
    if(!result?.length) {
      isExist = false;
      savePlaylistWithContent()
    }
    setIsPlaylistExist(isExist)
  }
  const savePlaylistWithContent = () => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: true, message: t('add_course_to_playlist') },
    });
    const playlistContent: SavePlaylistContentInput = {
      contentId: contentId,
      contentType: contentType,
    };
    const payload: SavePlaylistParametersInput = {
      playlistId: null,
      title: sanitizeHtml(newPlayList),
      summary: sanitizeHtml(playlistSummary),
      permission: PlaylistPermission.PRIVATE,
      contents: [playlistContent],
    };
    savePlaylist({ variables: { payload: payload } })
      .then(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('add_course_to_playlist') },
        });
        handleClose();
        if (isLanding) {
          reload(true);
        }
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('playlist_saved_alert_title'),
            message: t('playlist_saved_alert_message'),
          },
        });
      })
      .catch(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('add_course_to_playlist') },
        });
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('playlist_saved_alert_title'),
            message: t('playlist_error_alert_message'),
          },
        });
      });
  };
  const playlistAddContent = () => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: true, message: t('add_course_to_playlist') },
    });
    addContentToPlaylist({
      variables: { playlistId: existingPlaylist, contentId: contentId, contentType: contentType },
    })
      .then(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('add_course_to_playlist') },
        });
        handleClose();
        if (isLanding) {
          reload(true);
        }
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('playlist_content'),
            message: t('playlist_content_add_success_message'),
          },
        });
      })
      .catch(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('add_course_to_playlist') },
        });
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('playlist_content'),
            message: t('playlist_content_added_error_message'),
          },
        });
      });
  };

  const onClose = () => {
    handleClose();
  };

  const updatePlayListValues = (value: string) => {
    setExistingPlaylist(value);
    setIsExistingPlaylisSelected(true);
    setIsNewPlaylistSelected(false);
  };

  const onClear = () => {
    setExistingPlaylist("");
    setNewPlayList("");
    setPlaylistSummary("");
    setIsExistingPlaylisSelected(false);
    setIsPlaylistExist(false);
    setIsNewPlaylistSelected(false);
  };

  const onNewPlaylist = (event: any) => {
    setNewPlayList(event.target.value.length > 48 ? newPlayList : event.target.value);
    if (event.target.value.length >= 1) {
      setIsExistingPlaylisSelected(false);
      setIsNewPlaylistSelected(true);
    } else {
      setIsExistingPlaylisSelected(false);
      setIsNewPlaylistSelected(false);
    }
  };
  
  const { data, loading } = useQuery<PlaylistTypes.Playlist>(PLAYLISTS, {
    notifyOnNetworkStatusChange: true,
    fetchPolicy: "no-cache",
  });
  const focusClass = useFocusStyles();

  useEffect(() => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: loading, message: t('playlist_loading') },
    });
}, [loading]);

  return (
    <Dialog
      id="playlistdialog"
      title={title}
      onClose={() => onClose()}
      role="dialog"  
      //aria-labelledby="dialog1_label" 
      open={open}
      minWidth={isMobile ? 0 : 430 }
      className={classes.root}
      showCloseIcon
      minHeight={600}
      aria-modal="true"
    >
      <DialogContent style={{ padding: "8px 35px", minWidth:  isMobile ? 0 : 360  }}>
        <Typography
          style={{
            fontSize: "16px",
            color: theme.palette.grey["800"],
            fontWeight: 400,
            paddingBottom: "5px",
          }}
          component="h2"
          id="dialog1_label"
          role="heading"
           aria-level={2}
        >
          {title}
        </Typography>
        <Typography
          style={{
            fontSize: "12px",
            color: theme.palette.grey["800"],
            lineHeight: "18px",
            fontWeight: 400,
          }}
          component="h3"
        >
          {description}
        </Typography>
        <Box style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <Label>{t('add_to_existing_playlist')}</Label>
          <Clear className={focusClass.focusItem} onClick={onClear}>{t('clear').toUpperCase()}</Clear>
        </Box>


        <Box style={{ width: "100%"}} aria-label="selExisting">
          <MobileSelect
          aria-label="Please select Exisitng Playlist from the available options"
          style={{ width: "100%"}}
            disabled={isNewPlaylistSelected}
            multiple={false}
            value={existingPlaylist || ""}
            placeholder=""
            // className={classes.select}
            onChange={(event: any) => updatePlayListValues(event.target.value)}
            tabIndex={0}
            className={focusClass.focusItem}
          >
            {<MobileMenu value="" selected disabled hidden>
              {""}
            </MobileMenu>}
            {!(data &&
              (data.playlists || []).length > 0) && <MobileMenu style={{ fontSize: 100 }} value="" disabled>
                {""}
              </MobileMenu>}
            {data &&
              (data.playlists || [])
                .filter((item: PlaylistTypes.Playlist_playlists | null) => !(item?.contentIds && item?.contentIds?.length > 1 && item?.contentIds?.includes(contentId)))
                .map((element: PlaylistTypes.Playlist_playlists | null) => 
                <MobileMenu key={element?.id} value={element?.id} className={focusClass.focusItem}>
                  {element?.title}
                </MobileMenu>)
            }
          </MobileSelect>
          </Box>

        

        <Divider style={{ flex: 1, margin: "30px 0px" }} />
        <Label>{t('create_new_playlist')}</Label>
        <PlaylistName
          placeholder=""
          value={newPlayList}
          disabled={isExistingPlaylisSelected}
          className={isPlaylistExist?"error":""}
          onChange={(event) => onNewPlaylist(event)}
        />
        {isPlaylistExist?<ErrorMessage>
          <img style={{width:10, marginRight: 5}} alt={t('error_icon')} src={errorIcon} />{t('duplicate_playlist_name_message')}
        </ErrorMessage>:""}
        <Box style={{ marginTop: "30px" }}>
          <Label>{t('description_optional')}</Label>
          <Description
            rows={4}
            placeholder=""
            value={playlistSummary}
            disabled={isExistingPlaylisSelected}
            onChange={(event) => setPlaylistSummary(event.target.value)}
          />
        </Box>

        <Divider style={{ flex: 1, margin: "30px 0px 3px 0px" }} />
      </DialogContent>

      <DialogActions style={{ padding: "18px 35px 29px 35px" }}>
        <Button
          onClick={() => onClose()}
          style={{
            color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["500"],
            maxWidth: "max-content",
            paddingRight: "30px",
          }}
          className={`${focusClass.secondaryHover} ${focusClass.focusItem}`}
        >
          {t('cancel_and_close')}
        </Button>
        <Button
          onClick={() => {
            isExistingPlaylisSelected ? playlistAddContent() : validatePlaylist();
          }}
          color="primary"
          variant="outlined"
          disabled={!(isNewPlaylistSelected || isExistingPlaylisSelected)}
          style={{
            maxWidth: "130px",
            lineHeight: "30px",
            height:"42px",
            color: portalSettingsManager.buttonColors?.themed?.active?.text || theme.palette.primary.main,
            border: `1px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
            backgroundColor: portalSettingsManager.buttonColors?.themed?.active?.back 
          }}
          className={`${focusClass.primaryHover} ${focusClass.focusItem}`}
        >
          {t('confirm')}
        </Button>
      </DialogActions>
    </Dialog>
  );
};
