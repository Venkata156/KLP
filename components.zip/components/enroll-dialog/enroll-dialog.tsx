import {
  Box,
  Typography,
  Checkbox,
  Switch,
  FormControlLabel as MuiFormControlLabel,
  Button,
  SvgIcon,
  useMediaQuery,
  Tooltip
} from "@material-ui/core";
import { DatePicker, MultiViewCalendar } from "@progress/kendo-react-dateinputs";
import { IntlProvider, LocalizationProvider } from "@progress/kendo-react-intl";
import { ToggleButton } from '@progress/kendo-react-dateinputs';
import { Theme, withStyles, styled, createStyles, useTheme, makeStyles } from "@material-ui/core/styles";
import { fill, get, partial, range } from "lodash";
import { useEffect, useState } from "react";
import { emailRegex } from "utils/helpers";
import { ReactComponent as arrowIcon } from "assets/icons/icon-arrow.svg";
import { useTranslation } from "react-i18next";
import {
  ADMIN_CONFIRM_STEP,
  ADMIN_ENROLL_STEP,
  ENROLLMENT_STEP_ENROLLEE,
  ENROLLMENT_STEP_PREREQUISITES,
  ENROLLMENT_STEP_TERMS,
  ENROLLMENT_STEP_WORKSHOPS,
  ENROLLMENT_DIALOG_TYPES
} from "utils/constants";
import {
  CourseEnrollment_enrollmentData_activities,
  CourseEnrollment_enrollmentData_activities_availableSessions,
  CourseEnrollment_enrollmentData_learnerDetails,
} from "utils/graphql/CourseEnrollment";
import { EnrollmentStepType } from "utils/types";
import {
  UserSearch,
  UserSelected,
  Dialog,
  DialogContent,
  DialogActions,
  RenderHTML,
  Action,
  Loader,
  CheckIcon,
  FilledCheckboxIcon,
  CustomCheckBoxIcon,
} from "components";
import portalSettingsManager from "utils/portalSettingsManager";


const Progress = withStyles((theme: Theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    "& > span": {
      "&:nth-child(1)": {
        fontSize: "14px",
        color: theme.palette.primary.main,
        lineHeight: "16px",
        marginRight: "7px",
      },

      "&:nth-child(2)": {
        flex: 1,
        fontSize: "14px",
        "&:last-child": {
          fontWeight: 700,
        },
        color: theme.palette.primary.main,
        lineHeight: "16px",
      },
    },
  },
}))(Box);

const NonEditableField = withStyles((theme: Theme) => ({
  root: {
    "& label": {
      display: "block",
      fontSize: "11px",
      color: theme.palette.grey["500"],
    },
    "& span": {
      fontSize: "14px",
      color: theme.palette.grey["800"],
      fontWeight: 700,
    },
    "& button": {
      border: `1px solid ${theme.palette.primary.main}`,
      color: theme.palette.primary.main,
      position: "relative",
      left: "15px",
      top: "-7px",
    },
    "& p": {
      fontSize: "11px",
      color: theme.palette.grey["500"],
    },
  },
}))(Box);
const TableHeader = withStyles((theme: Theme) => ({
  root: {
    display: "flex",
    paddingTop: "18px",
    paddingBottom: "18px",
    borderBottom: `1px solid ${theme.palette.grey["300"]}`,
    "& > span": {
      fontSize: "12px",
      fontWeight: 700,
      color: theme.palette.grey["800"],
      display: "inline-block",
      "&:nth-child(1)": {
        marginLeft: "30px",
        width: "200px",
      },
      "&:nth-child(2)": {
        width: "200px",
      },
      "&:nth-child(3)": {
        width: "85px",
      },
      "&:nth-child(4)": {
        width: "85px",
        textAlign: "center",
      },
    },
  },
}))(Box);

const CustomCheckbox = withStyles((theme: Theme) => ({
  root: {
    position: "absolute",
    left: -5,
    top: 9,
    "&$checked": {
      "& .MuiIconButton-label": {
        position: "relative",
        zIndex: 0,
      },
    },
  },
  checked: {},
}))(Checkbox);


const FormControlLabel = withStyles((theme: Theme) => ({
  label: {
    fontSize: 12,
    color: theme.palette.grey["800"],
  },
}))(MuiFormControlLabel);

const Title = withStyles((theme: Theme) => ({
  root: {
    fontSize: "16px",
    color: theme.palette.grey["800"],
  },
}))(Typography);

const Desc = withStyles((theme: Theme) => ({
  root: {
    fontSize: "12px",
    color: theme.palette.grey["800"],
    lineHeight: "16px",
    margin: "10px 0 24px 0",
  },
}))(Typography);

const Activity = withStyles((theme: Theme) => ({
  root: {
    display: "flex",
    paddingTop: "18px",
    paddingBottom: "18px",
    borderBottom: `1px solid ${theme.palette.grey["300"]}`,
    position: "relative",
    "& > span": {
      fontSize: "12px",
      color: theme.palette.grey["800"],
      display: "inline-block",
      "&:nth-child(2)": {
        marginLeft: "30px",
        width: "200px",
      },
      "&:nth-child(3)": {
        width: "200px",
      },
      "&:nth-child(4)": {
        width: "85px",
      },
      "&:nth-child(5)": {
        width: "85px",
        textAlign: "center",
      },
    },
  },
}))(Box);

const ReadonlyEnrolleeDetails = withStyles((theme: Theme) => ({
  root: {
    display: "flex",
    "& > div": {
      marginRight: "38px",
      "& > span": {
        display: "block",
        color: theme.palette.grey["800"],
        fontSize: "12px",
        fontWeight: 700,
      },
    },
    flexWrap: "wrap",
  },
}))(Box);

const Label = styled("label")(({ theme }) => ({
  display: "block",
  fontSize: "12px",
  color: theme.palette.grey["500"],
  marginTop: "29px",
  marginBottom: "10px",
}));

const RequiredLabel = withStyles((theme: Theme) => ({
  root: {
    display: "block",
    fontSize: "12px",
    color: theme.palette.grey["500"],
    marginTop: "29px",
    marginBottom: "10px",
    "&:after": {
      content: `" *"`,
      color: theme.palette.error.main,
    },
  },
}))(Box);
const LabelField = withStyles(() => ({
  root: {
    display: "block",
    fontSize: "12px",
    color: "#999999",
    marginTop: "29px",
    marginBottom: "10px",
  },
}))(Box);

const Email = styled("input")({
  padding: "10px 8px",
  width: "calc(100% - 30px)",
});

const Request = styled("textarea")({
  padding: "10px 8px",
  width: "calc(100% - 30px)",
  border: "1px solid #9e9e9e",
});
const PathwayTable = withStyles((theme: Theme) => ({
  root: {
    display: "flex",
    paddingTop: (props: any) => props.paddingTop,
    paddingBottom: (props: any) => props.paddingBottom,
    borderBottom: `1px solid ${theme.palette.grey["300"]}`,
    justifyContent: "space-between",
    alignItems: "center",
    "& > span": {
      fontSize: "12px",
      color: theme.palette.grey["800"],
      fontWeight: (props: any) => (props.fontWeight ? props.fontWeight : ""),
      display: "inline-block",
      "&:nth-child(1)": {
        marginLeft: "30px",
        width: "200px",
      },
      "&:nth-child(2)": {
        width: "200px",
        textAlign: "center",
      },
    },
  },
}))(Box);

interface GenericStepProps {
  stepLabel: string;
  output: boolean;
  outputHandler: (data: unknown) => void;
  handleShowPathwayCourses: any;
  dialogType: string;
}
interface EnrolleContentProps {
  stepLabel: string;
  output: boolean;
  outputHandler: (data: unknown) => void;
  captureSpecialRequirements: boolean;
  captureManagerEmail: boolean;
  canEditLineManagerEmail: boolean;
  lineManagerEmail: string;
  specialRequirements: string;
  setSpecialRequirements: (value: string) => void;
  setLineManagerEmail: (value: string) => void;
  setEnrolleeCheck: (value: boolean) => void;
  enrolleeCheck: boolean;
  handleShowPathwayCourses: any;
  dialogType: string;
}
interface AdminStepProps {
  stepLabel: string;
  output: unknown;
  outputHandler: (data: unknown) => void;
  setSelectedUsers: (data: unknown[]) => void;
  handleRemoveEnrollment: (data: unknown) => void;
  selectedUsers: any;
  addedUsers: any;
  setAddedUsers: (data: unknown[]) => void;
  requiredCourse: boolean;
  setRequiredCourse: (value: boolean) => void;
  setDueDate: (value: string) => void;
  dueDate: string;
  setTermsCheck: (value: boolean) => void;
  termsCheck: boolean;
  prerequisitesCheck: boolean;
  setPrerequisitesCheck: (value: boolean) => void;
  isTermsAvailable: boolean;
  isPreRequisitesAvailable: boolean;
  courseId: number;
  minDueDate: Date | null;
  selectedSessionDate:Date | null;
}
interface SessionContentProps extends GenericStepProps {
  activity: CourseEnrollment_enrollmentData_activities;
  setSessionDate:any;
  handleOpenWorkshop: any;
}

const SessionContent = ({
  activity,
  stepLabel,
  output,
  outputHandler,
  dialogType,
  handleShowPathwayCourses,
  handleOpenWorkshop,
  setSessionDate
}: SessionContentProps) => {
  const { t } = useTranslation();
  const theme = useTheme();
  const [selectedSession, setSelectedSession] = useState<unknown>(output);

  const selectRow = (session: any | null) => {    
    setSelectedSession(session.id);
    setSessionDate(new Date(session.endDateTime));    
  };

  useEffect(() => {
    setSelectedSession(output);
  }, [activity, output]);

  useEffect(() => {
    outputHandler(selectedSession);
    // TODO: replace with redux, adding outputHandler causes an infinite loop due to rerenders
  }, [selectedSession]);

  return (
    <DialogContent>
      {dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY && (
        <PathwayHeaderButton
          aria-controls="home-button"
          aria-haspopup="true"
          startIcon={
            <SvgIcon
              component={arrowIcon}
              style={{
                transform: "rotate(180deg) translate(25%, 30%)",
                fontSize: "30px",
                marginRight: "0",
                marginTop:1
              }}
            />
          }
          onClick={handleShowPathwayCourses}
        >
          {t('add_to_pathway')}
        </PathwayHeaderButton>
      )}
      <Title id="course_confirm_label" role="heading" aria-level={2}>{t('course_confirmation_placeholder')}</Title>
      <Desc>{t('complete_enrollment_wizard')}</Desc>
      <Progress>
        <span>{stepLabel}:</span>
        <span style={{ fontWeight:700 }}>{t('available_sessions')}</span>
        <Action type="dialog-black" onClick={() => handleOpenWorkshop(activity.id)}>
          {t('suggest_a_date').toUpperCase()}
        </Action>
      </Progress>
      <h5
        style={{
          fontSize: "14px",
          fontWeight: 700,
          color: theme.palette.grey["800"],
          margin: "32px 0 30px 0",
        }}
      >
        {activity.name}
      </h5>
      <div role="table" aria-label={t('course_confirmation_tbl')}>
        <div role="rowgroup">
          <TableHeader role="row">
            <span role="columnheader">{t('start_date_time')}</span>
            <span role="columnheader">{t('end_date_time')}</span>
            <span role="columnheader">{t('location')}</span>
            <span role="columnheader">{t('open_seats')}</span>
          </TableHeader>
        </div>

        <Box
          height="250px"
          minHeight="250px"
          maxHeight="250px"
          style={{ overflowX: "hidden", overflowY: "auto" }}
        >
          {(activity.availableSessions || []).map((session, index) => {
            return (
              <div key={index} role="rowgroup" aria-label={t('select_available_session')}>
                {!!session && (
                  <Activity role="row">
                    <CustomCheckbox
                      icon={<CustomCheckBoxIcon width={"15px"} height={"15px"} />}
                      checkedIcon={<FilledCheckboxIcon width={"15px"} height={"15px"} />}
                      checked={selectedSession === session.id}
                      onChange={() => selectRow(session)}
                      value="e"
                      color="primary"
                      name="activity"
                      inputProps={{ "aria-label": session.startDateTimeDisplay + " " + session.location }}
                      size="small"
                      disabled={session.noOfSeatsAvailable == 0}
                    />
                    <span role="cell">{session.startDateTimeDisplay}</span>
                    <span role="cell">{session.endDateTimeDisplay}</span>
                    <span role="cell">{session.location}</span>
                    <span role="cell">{session.noOfSeatsAvailable}</span>
                  </Activity>
                )}
              </div>
            );
          })}
        </Box>
      </div>
    </DialogContent>
  );
};

interface EnrolleeContentProps extends EnrolleContentProps {
  details: Partial<CourseEnrollment_enrollmentData_learnerDetails>;
  isLineManagerEmailRequired: boolean;
}
const PathwayHeaderButton = withStyles((theme: Theme) => ({
  root: {
    fontSize: "11px",
    color: theme.palette.grey["800"],
    textTransform: "none",
    padding: "0",
    marginBottom: "23px",
    " & span": {
      " & span:nth-child(1)": {
        marginRight: "0",
      },
    },
  },
}))(Button);
const EnrolleeContent = ({
  dialogType,
  handleShowPathwayCourses,
  details,
  stepLabel,
  captureSpecialRequirements,
  captureManagerEmail,
  lineManagerEmail,
  canEditLineManagerEmail,
  specialRequirements,
  setSpecialRequirements,
  setLineManagerEmail,
  enrolleeCheck,
  setEnrolleeCheck,
  isLineManagerEmailRequired
}: EnrolleeContentProps) => {
  const { t } = useTranslation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  return (
    <DialogContent isMobile={isMobile}>
      {dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY && (
        <PathwayHeaderButton
          aria-controls="home-button"
          aria-haspopup="true"
          startIcon={
            <SvgIcon
              component={arrowIcon}
              style={{
                transform: "rotate(180deg) translate(25%, 30%)",
                fontSize: "30px",
                marginRight: "0",
              }}
            />
          }
          onClick={handleShowPathwayCourses}
        >
          {t('add_to_pathway')}
        </PathwayHeaderButton>
      )}
      <Title id="course_confirm_label" role="heading" aria-level={2}>{t('course_confirmation_placeholder')}</Title>
      <Desc>{t('complete_enrollment_wizard')}</Desc>
      <Progress>
        <span>{stepLabel}:</span>
        <span>{t('enrollee_details')}</span>
      </Progress>
      <ReadonlyEnrolleeDetails>
        <div>
          <Label>{t('first_name')}</Label>
          <span>{details.firstName}</span>
        </div>
        <div>
          <Label>{t('last_name')}</Label>
          <span>{details.lastName}</span>
        </div>
        <div>
          <Label>{t('email')}</Label>
          <span>{details.email}</span>
        </div>
      </ReadonlyEnrolleeDetails>
      {function () {
        if (!captureManagerEmail) {
          return "";
        }
        if (canEditLineManagerEmail) {
          return (
            <>
              {/* <Label>Manager&apos;s Email</Label> */}
              <div style={{ display: "flex", marginTop: 29, marginBottom: 10 }}>
                <Label style={{ display: "flex", marginTop: 0, marginBottom: 0 }}>
                  {t('managers_email')}
                </Label>
                {isLineManagerEmailRequired && (
                  <Label
                    style={{
                      color: "red",
                      marginLeft: 3,
                      marginTop: -2,
                      marginBottom: 0,
                      fontSize: 15,
                    }}
                  >
                    *
                  </Label>
                )}
              </div>

              <Email
                value={lineManagerEmail}
                onChange={(e) => setLineManagerEmail(e.target.value)}
              />
            </>
          );
        }
        return (
          <NonEditableField>
            {/* <Label>Manager&apos;s Email</Label> */}
            <div style={{display:"flex", marginTop:29, marginBottom:10}}>
            <Label style={{display:"flex", marginTop:0, marginBottom:0}}>{t('managers_email')}</Label>
           {isLineManagerEmailRequired && <Label style={{color:"red", marginLeft:3, marginTop:-2, marginBottom:0, fontSize:15}}>*</Label>}
            </div>
            <span>{lineManagerEmail}</span>
          </NonEditableField>
        );
      }.call(1)}
      {captureSpecialRequirements && (
        <>
          <Label>{t('adjustment_requests')}</Label>
          <Request
            value={specialRequirements}
            onChange={(e) => setSpecialRequirements(e.target.value)}
          />
        </>
      )}
      <FormControlLabel
        control={
          <Checkbox
            icon={<CustomCheckBoxIcon width={"15px"} height={"15px"} />}
            checkedIcon={<FilledCheckboxIcon width={"15px"} height={"15px"} />}
            checked={enrolleeCheck}
            color="primary"
            inputProps={{ "aria-label": t('values_label') }}
            onChange={() => setEnrolleeCheck(!enrolleeCheck)}

            aria-required="true"
          />
        }

        label={t('values_label')}
      />
    </DialogContent>
  );
};

interface TermsContentProps extends GenericStepProps {
  terms: string;
  setTermsCheck: (value: boolean) => void;
  termsCheck: any;
  dialogType: any;
  handleShowPathwayCourses: any;
}

const TermsContent = ({
  stepLabel,
  terms,
  outputHandler,
  setTermsCheck,
  termsCheck,
  dialogType,
  handleShowPathwayCourses,
}: TermsContentProps) => {
  const theme = useTheme();
  const { t } = useTranslation();

  return (
    <>
      <div style={{ padding: "0 24px" }}>
        {dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY && (
          <PathwayHeaderButton
            aria-controls="home-button"
            aria-haspopup="true"
            startIcon={
              <SvgIcon
                component={arrowIcon}
                style={{
                  transform: "rotate(180deg) translate(25%, 30%)",
                  fontSize: "30px",
                  marginRight: "0",
                }}
              />
            }
            onClick={handleShowPathwayCourses}
          >
            {t('add_to_pathway')}
          </PathwayHeaderButton>
        )}
        <Title id="course_confirm_label" role="heading" aria-level={2}>{t('course_confirmation_placeholder')}</Title>
        <Desc>
          {t('complete_enrollment_wizard')}
        </Desc>
        <Progress>
          <span>{stepLabel}:</span>
          <span>{t('Terms')}</span>
        </Progress>
      </div>
      <DialogContent style={{ overflow: "auto" }}>
        <div
          style={{
            fontSize: "14px",
            color: theme.palette.grey["800"],
            letterSpacing: 0,
            lineHeight: "21px",
            fontWeight: 400,
            margin: "23px 0",
          }}
        >
          <RenderHTML content={terms} />
        </div>
        <FormControlLabel
          control={
            <Checkbox

              icon={<CustomCheckBoxIcon width={"15px"} height={"15px"} />}
              checkedIcon={<FilledCheckboxIcon width={"15px"} height={"15px"} />}
              checked={termsCheck}
              color="primary"
              inputProps={{ "aria-label": t('agree_terms') }}
              onChange={(event) => {
                outputHandler(event.target.checked);
                setTermsCheck(!termsCheck);
              }}
            />
          }
          label={t('agree_above_terms')}
        />
      </DialogContent>
    </>
  );
};

interface PrerequisitesContentProps extends GenericStepProps {
  prerequisites: string;
  prerequisitesCheck: any;
  setPrerequisitesCheck: any;
}

const PrerequisitesContent = ({
  stepLabel,
  prerequisites,
  outputHandler,
  prerequisitesCheck,
  setPrerequisitesCheck,
  dialogType,
  handleShowPathwayCourses,
}: PrerequisitesContentProps) => {
  const theme = useTheme();
  const { t } = useTranslation();

  return (
    <>
      <div style={{ padding: "0 24px" }}>
        {dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY && (
          <PathwayHeaderButton
            aria-controls="home-button"
            aria-haspopup="true"
            startIcon={
              <SvgIcon
                component={arrowIcon}
                style={{
                  transform: "rotate(180deg) translate(25%, 30%)",
                  fontSize: "30px",
                  marginRight: "0",
                }}
              />
            }
            onClick={handleShowPathwayCourses}
          >
            {t('add_to_pathway')}
          </PathwayHeaderButton>
        )}
        <Title id="course_confirm_label" role="heading" aria-level={2}>{t('course_confirmation_placeholder')}</Title>
        <Desc>{t('complete_enrollment_wizard')}</Desc>
        <Progress>
          <span>{stepLabel}:</span>
          <span>{t('prerequisites_placeholder')}</span>
        </Progress>
      </div>
      <DialogContent style={{ overflow: "auto" }}>
        <div
          style={{
            fontSize: "14px",
            color: theme.palette.grey["800"],
            letterSpacing: 0,
            lineHeight: "21px",
            fontWeight: 400,
            margin: "23px 0",
          }}
        >
          <RenderHTML content={prerequisites} />
        </div>
        <FormControlLabel
          control={
            <Checkbox

              icon={<CustomCheckBoxIcon width={"15px"} height={"15px"} />}
              checkedIcon={<FilledCheckboxIcon width={"15px"} height={"15px"} />}
              checked={prerequisitesCheck}
              color="primary"
              inputProps={{ "aria-label": t('agree_prerequisites') }}
              onChange={(event) => {
                outputHandler(event.target.checked);
                setPrerequisitesCheck(!prerequisitesCheck);
              }}
            />
          }
          label={t('agree_prerequisites')}
        />
      </DialogContent>
    </>
  );
};


export const ToggleDatepickerButton = (props: any) => {
  return <ToggleButton {...props} title={null} />;
};
//interface AdminEnrollContentProps extends AdminStepProps {}

const AntSwitch = withStyles((theme: Theme) =>
  createStyles({
    root: {
      width: 38,
      height: 22,
      padding: 0,
      display: "flex",
    },
    switchBase: {
      padding: 2,
      color: "#D8D8D8",
      "&$checked": {
        transform: "translateX(15px)",
        color: "#0091DA",
        "& + $track": {
          opacity: 1,
          border: `1px solid #0091DA`,
          backgroundColor: "#FFFFFF",
        },
      },
    },
    thumb: {
      width: 17,
      height: 17,
      boxShadow: "none",
    },
    track: {
      height: "auto",
      border: `1px solid #D8D8D8`,
      borderRadius: 10,
      opacity: 1,
      backgroundColor: "white",
      transition: theme.transitions.create(["background-color", "border"]),
    },
    checked: {},
  })
)(Switch);
const useStyles = makeStyles({
  root: {
    "& .k-datepicker": {
      border: "1px solid #979797",
      height: "32px",
      borderRadius: "2px",
      width: "119px"
    },
    "& .k-picker-wrap": {
      border: "0px solid black",
    },
    "& .k-input": {
      padding: "0px",
      height: "100%",
      lineHeight: "100%",
      color: "#0091DA",
      paddingTop: "9px",
      paddingBottom: "9px",
      paddingLeft: "11px",
      fontSize: "12px"
    },
    "& .k-icon": {
      fontSize: "12px",
      color: "#0091DA",
      paddingRight: "4px"
    },
    "& .k-input::placeholder": {
      color: "#0091DA",
      opacity: 1,
      fontweight: 400,
    },

    '& .k-input:-ms-input-placeholder': {
      color: "#0091DA",
      fontweight: 400,
    },

    '& .k-input::-ms-input-placeholder': {
      color: "#0091DA",
      fontweight: 400,

    }
  },
  calendarPopup: {
    zIndex: 3000,
  },
});

const CourseRequired = ({
  requiredCourse,
  setRequiredCourse,
  dueDate,
  setDueDate,
  minDueDate,
  selectedSessionDate
}: any) => {
  const DateSyles = useStyles();

  const { t } = useTranslation();
  const currentDate = new Date();
  const handleChangeDate = (e: any) => {
    const selectedDate = new Date(e.target.value).toISOString().split("T")[0]
    if (selectedDate >= currentDate.toISOString().split("T")[0]) {
      setDueDate(e.target.value);
    } else {
      setDueDate("");
    }
  };
  useEffect(() => {
    if (!requiredCourse) {
      setDueDate("");
    }
  }, [requiredCourse]);

  const handlefocus = () => {
    document.querySelector("#course-req-switch")?.setAttribute("aria-label", t('course_required_alert'));
  };
  document.querySelector("#duedate")?.setAttribute("aria-label", t('due_date_required_alert'));
  document.querySelector("#course-req-switch")?.setAttribute("aria-label", t('course_required_alert'));
  //document.querySelector("#user-search-box")?.setAttribute("aria-label", t('searchenrolleename _required_alert'));
  //document.querySelector("#user-search-box")?.setAttribute("aria-required", 'true');
  return (

    <Box display="flex" style={{ marginBottom: "20px", height: "6rem" }}>
      <div style={{ marginRight: "40px" }}>
        <LabelField>{t('course_required_alert')}</LabelField>
        <AntSwitch
          checked={requiredCourse}
          onFocus={() => handlefocus()}
          onChange={() => {
            setRequiredCourse(!requiredCourse);
          }}
          id="course-req-switch"
          name="requiredCourse"
          color="primary"
          tabIndex={0}
        />
      </div>
      {requiredCourse && (
        <div>
          <RequiredLabel>{t('due_date')}</RequiredLabel>
          <Box
            className={DateSyles.root}
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            marginTop="10px"
            fontSize="10px"
          >         
            <LocalizationProvider language={"en-US"}>
              <IntlProvider locale={"en"}>
                <DatePicker
                  id="duedate"
                  min={currentDate}
                  title={`Due date. Use Alt+Down Arrow to Open the popup and moves the focus to the displayed calendar.
                  Use Alt+Up Arrow	to close the popup and moves the focus to the input element. Use Esc to close the popup and moves the focus to the input element.`}
                  value={dueDate}
                  formatPlaceholder="formatPattern"
                  format="dd MMM yy"
                  aria-valuetext="DAY_NUMBER_STRING"
                  placeholder="dd MMM yy"
                  calendar={(props: any) => (
                    <MultiViewCalendar views={1} min={selectedSessionDate} ref={props._ref}
                      value={props.value} onChange={props.onChange} />
                  )}
                  toggleButton={ToggleDatepickerButton}
                  popupSettings={{ popupClass: DateSyles.calendarPopup, appendTo: document.body }}
                  onChange={(e) => handleChangeDate(e)}
                />
              </IntlProvider>
            </LocalizationProvider>
          </Box>
        </div>
      )}
    </Box>
  );
};
const PathwayEnrollment = ({
  pathwayEnrolldata,
  handlePathwayCourseClick,
  setPathwayCourseId,
  pathwayTitle,
}: any) => {
  const { t } = useTranslation();
  return (
    <DialogContent style={{ display: "flex", flexDirection: "column", overflow: "auto" }}>
      <Title id="course_confirm_label" role="heading" aria-level={2}>{t('add_to_pathway')}</Title>
      <Desc>
        {t('pathwayenrollment_desc')}
      </Desc>
      <Progress fontWeight={800}>
        <span>{pathwayTitle}</span>
      </Progress>
      <PathwayTable fontWeight={800} paddingTop={30} paddingBottom={10}>
        <span>{t('course_name')}</span>
        <span>{t('enrollment')}</span>
      </PathwayTable>
      <Box
        height="300px"
        minHeight="300px"
        maxHeight="300px"
        style={{ overflowX: "hidden", overflowY: "auto" }}
      >
        {pathwayEnrolldata.map((item: any, index: any) => {
          return (
            <PathwayTable key={index} paddingTop={18} paddingBottom={18}>
              <span>{item.courseName}</span>
              {item.canEnroll && !item.isEnrolled && (
                <span>
                  <Action
                    type="dialog-grey"
                    onClick={() => {
                      handlePathwayCourseClick(item.courseId);
                      setPathwayCourseId(item.courseId);
                    }}
                  >
                    {t('enroll')}
                  </Action>
                </span>
              )}
              {!item.canEnroll && item.isEnrolled && (
                <span>
                  <CheckIcon width={"20px"} height={"20px"} />
                </span>)}
              {((item.canEnroll && item.isEnrolled) || (!item.canEnroll && !item.isEnrolled)) && (
                <Tooltip title="Course enrollment is currently unavailable.  Please try again later.">
                  <span>{t('enrollment_unavilable')}</span>
                </Tooltip>)}

            </PathwayTable>
          );
        })}
      </Box>
    </DialogContent>
  );
};
const AdminEnrollContent = ({
  minDueDate,
  dueDate,
  setDueDate,
  requiredCourse,
  setRequiredCourse,
  stepLabel,
  outputHandler,
  setSelectedUsers,
  selectedUsers,
  addedUsers,
  setAddedUsers,
  handleRemoveEnrollment,
  selectedSessionDate
}: AdminStepProps) => {
  const { t } = useTranslation();
  return (
    <DialogContent style={{ display: "flex", flexDirection: "column", overflow: "auto" }}>
      <Title id="course_confirm_label" role="heading" aria-level={2}>{t('course_confirmation_placeholder')}</Title>
      <Desc>{t('complete_enrollment_wizard')}</Desc>
      <Progress>
        <span>{stepLabel}:</span>
        <span>
          <span>{t('add')}</span> {t('enrollees')}
        </span>
      </Progress>
      <CourseRequired
        minDueDate={minDueDate}
        requiredCourse={requiredCourse}
        setRequiredCourse={setRequiredCourse}
        dueDate={dueDate}
        setDueDate={setDueDate}
        selectedSessionDate = {selectedSessionDate}
      />
      <UserSearch
        setaddedUsers={setAddedUsers}
        addedUsers={addedUsers}
        setSelectedUsers={setSelectedUsers}
        selectedUsers={selectedUsers}
        outputHandler={outputHandler}
        label={t('enrollee_name')}
        placeHolder={t('searchbyname_placeholder')}
        isRoleBased={true}
      //title='This is mandatory'
      //aria-label='It is mandatory'
      />
      <UserSelected selectedUsers={selectedUsers} handleRemoveEnrollment={handleRemoveEnrollment} />
    </DialogContent>
  );
};

const AdminConfirmContent = ({
  termsCheck,
  prerequisitesCheck,
  setDueDate,
  dueDate,
  stepLabel,
  selectedUsers,
  handleRemoveEnrollment,
  requiredCourse,
  setRequiredCourse,
  setTermsCheck,
  setPrerequisitesCheck,
  isTermsAvailable,
  isPreRequisitesAvailable,
  selectedSessionDate
}: AdminStepProps) => {
  const theme = useTheme();
  const { t } = useTranslation();

  return (
    <DialogContent>
      <Title id="course_confirm_label" role="heading" aria-level={2}>{t('course_confirmation_placeholder')}</Title>
      <Desc>{t('complete_enrollment_wizard')}</Desc>
      <Progress>
        <span>{stepLabel}:</span>
        <span>{t('summary')}</span>
      </Progress>
      <CourseRequired
        requiredCourse={requiredCourse}
        setRequiredCourse={setRequiredCourse}
        dueDate={dueDate}
        setDueDate={setDueDate}
        selectedSessionDate={selectedSessionDate}
      />
      <Typography
        style={{
          fontSize: "12px",
          color: theme.palette.grey["500"],
          borderBottom: `1px solid ${theme.palette.grey["300"]}`,
          marginBottom: 30,
          paddingBottom: 5,
        }}
      >
        {t('all_enrolled')}
      </Typography>
      <UserSelected selectedUsers={selectedUsers} handleRemoveEnrollment={handleRemoveEnrollment} maxHeight="100px" />
      <Box
        display="flex"
        style={{ borderTop: `1px solid ${theme.palette.grey["300"]}`, marginTop: 15 }}
      >
        {isTermsAvailable && (
          <div style={{ marginRight: 20 }}>
            <Label>{t('terms_above_placeholder')}</Label>
            <FormControlLabel
              control={
                <Checkbox
                  icon={<CustomCheckBoxIcon width={"15px"} height={"15px"} />}
                  checkedIcon={<FilledCheckboxIcon width={"15px"} height={"15px"} />}
                  checked={termsCheck}
                  color="primary"
                  inputProps={{ "aria-label": t('agree_terms') }}
                  onChange={() => {
                    setTermsCheck(!termsCheck);
                  }}
                />
              }
              label={t('agree_terms')}
            />
          </div>
        )}
        {isPreRequisitesAvailable && (
          <div>
            <Label>{t('prerequisites_placeholder')}</Label>
            <FormControlLabel
              control={
                <Checkbox
                  icon={<CustomCheckBoxIcon width={"15px"} height={"15px"} />}
                  checkedIcon={<FilledCheckboxIcon width={"15px"} height={"15px"} />}
                  checked={prerequisitesCheck}
                  color="primary"
                  inputProps={{ "aria-label": t('agree_prerequisites') }}
                  onChange={() => {
                    setPrerequisitesCheck(!prerequisitesCheck);
                  }}
                />
              }
              label={t('agree_prerequisites')}
            />
          </div>
        )}
      </Box>
    </DialogContent>
  );
};

export const EnrollDialog = ({
  course,
  open,
  handleClose,
  dialogType,
  courseLearnerId,
  handleOpenWorkshop,
  data,
  handleConfirmEnrollment,
  learnerEmail,
  pathwayEnrolldata,
  handlePathwayCourseClick,
  setShowPathwayList,
  showPathwayList,
  canEditLineManagerEmail,
  showLoader,
  title,
}: any): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [activities, setActivities] = useState<CourseEnrollment_enrollmentData_activities[]>([]);
  const [selectedSessionDate, setSessionDate] = useState(new Date());
  const [steps, setSteps] = useState<EnrollmentStepType[]>([]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [stepOutput, setStepOutput] = useState<any[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<any[]>([]);
  const [addedUsers, setaddedUsers] = useState<any[]>([]);
  const [requiredCourse, setRequiredCourse] = useState(false);
  const [termsCheck, setTermsCheck] = useState(false);
  const [prerequisitsCheck, setPrerequisitsCheck] = useState(false);
  const [dueDate, setDueDate] = useState<string>("");
  const [lineManagerEmail, setLineManagerEmail] = useState<string>("");
  const [specialRequirements, setSpecialRequirements] = useState<string>("");
  const [userEmail, setUserEmail] = useState<string>("");
  const [enrolleeCheck, setEnrolleeCheck] = useState(false);
  const [confirmAdmin, setConfirmAdmin] = useState(false);
  const [pathwayCourseId, setPathwayCourseId] = useState("");
  const [minDueDate, setMinDueDate] = useState<Date | null>(null);

  useEffect(() => {
    if (selectedUsers.length <= 0 || (requiredCourse && !dueDate)) {
      setOutputForStep(currentStepIndex, null);
    }
    if (selectedUsers.length > 0 && ((requiredCourse && !!dueDate) || !requiredCourse)) {
      setOutputForStep(currentStepIndex, 2);
    }
  }, [selectedUsers.length, requiredCourse, dueDate]);
  useEffect(() => {
    const lmEmail = lineManagerEmail === null ? lineManagerEmail : lineManagerEmail.toLowerCase().trim();
    const lnEmail = learnerEmail === null ? learnerEmail : learnerEmail.toLowerCase().trim();
    const isLmEmailValid = isLineManagerEmailRequired ? lmEmail !== null && lmEmail !== "" && new RegExp(emailRegex).test(lmEmail) && lmEmail !== lnEmail : true;

    if (!isLmEmailValid) {
      setOutputForStep(currentStepIndex, null);
    } else if (enrolleeCheck) {
      setOutputForStep(currentStepIndex, true);
    } else if (!enrolleeCheck) {
      setOutputForStep(currentStepIndex, null);
    }
  }, [lineManagerEmail, enrolleeCheck]);

  useEffect(() => {
    if (
      selectedUsers.length <= 0 ||
      (requiredCourse && !dueDate) ||
      (data?.enrollmentData?.isTermsAndConditionAvailable && !termsCheck) ||
      (data?.enrollmentData?.isPreRequisitesAvailable && !prerequisitsCheck)
    ) {
      setConfirmAdmin(true);
    } else {
      setConfirmAdmin(false);
    }
  }, [selectedUsers.length, requiredCourse, dueDate, termsCheck, prerequisitsCheck]);
  const handleRemoveEnrollment = (user: any) => {
    setSelectedUsers(selectedUsers.filter((item: any) => user.id !== item.id));
    // setaddedUsers(uniq([...addedUsers, user]));
  };
  const getPreviousStepIndex = () => {
    return currentStepIndex > 0 ? currentStepIndex - 1 : -1;
  };

  const getNextStepIndex = () => {
    return currentStepIndex < steps.length ? currentStepIndex + 1 : -1;
  };

  const getStepLabel = (stepIndex: number) => {
    if (dialogType === ENROLLMENT_DIALOG_TYPES.COURSE || dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY) {
      const step = get(steps, stepIndex, null);

      switch (step) {
        case ENROLLMENT_STEP_WORKSHOPS:
          return t('session')
        //   return get(activities, [stepIndex, "name"], "Workshop");
        case ENROLLMENT_STEP_ENROLLEE:
          return t('enrollee_placeholder');
        case ENROLLMENT_STEP_TERMS:
          return t('terms_above_placeholder');
        case ENROLLMENT_STEP_PREREQUISITES:
          return t('prerequisites_placeholder');
        default:
          return "";
      }
    } else {
      const step = get(steps, stepIndex, null);

      switch (step) {
        case ENROLLMENT_STEP_WORKSHOPS:
          return t('session')
        // return get(activities, [stepIndex, "name"], "Workshop");
        case ADMIN_ENROLL_STEP:
          return t('enrollees_placeholder');
        case ENROLLMENT_STEP_TERMS:
          return t('terms_above_placeholder');
        case ENROLLMENT_STEP_PREREQUISITES:
          return t('prerequisites_placeholder');
        case ADMIN_CONFIRM_STEP:
          return t('summary');
        default:
          return "";
      }
    }
  };

  const setOutputForStep = (stepIndex: number, value: any) => {
    stepOutput[stepIndex] = value;
    setStepOutput([...stepOutput]);
  };

  const processEnrollment = () => {
    const data = {
      courseId: dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY ? String(pathwayCourseId) : String(course.id),
      activityEnrolls: activities.map((activity, index) => {
        return {
          activityId: String(activity.id),
          sessionId: String(stepOutput[index]),
        };
      }),
    };
    if (dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY) {
      setShowPathwayList(true);
      setSteps([]);
      setCurrentStepIndex(0);
      setTermsCheck(false);
      setPrerequisitsCheck(false);
      setEnrolleeCheck(false);
      const attendeesObj = {
        attendees: [
          {
            learnerId: courseLearnerId,
            emailAddress: userEmail,
            lineManagerEmail: lineManagerEmail,
            specialRequirements: specialRequirements,
          },
        ],
      };
      handleConfirmEnrollment(ENROLLMENT_DIALOG_TYPES.PATHWAY, data, attendeesObj);
    } else if (dialogType === ENROLLMENT_DIALOG_TYPES.COURSE) {
      const attendeesObj = {
        attendees: [
          {
            learnerId: courseLearnerId,
            emailAddress: userEmail,
            lineManagerEmail: lineManagerEmail,
            specialRequirements: specialRequirements,
          },
        ],
      };
      handleConfirmEnrollment(ENROLLMENT_DIALOG_TYPES.COURSE, data, attendeesObj);
    } else {
      let attendeesObj;
      if (dueDate) {
        const dueDateVal = new Date(dueDate).toISOString().split("T")[0]
        attendeesObj = {
          dueDate: dueDateVal,
          attendees: selectedUsers.map((item) => {
            return { learnerId: item.id, emailAddress: item.email };
          }),
        };
      } else {
        attendeesObj = {
          attendees: selectedUsers.map((item) => {
            return { learnerId: item.id, emailAddress: item.email };
          }),
        };
      }
      handleConfirmEnrollment(ENROLLMENT_DIALOG_TYPES.ADMIN, data, attendeesObj);
    }
  };

  useEffect(() => {
    if (data && data.enrollmentData) {
      const activities = (data.enrollmentData?.activities || []).flatMap((activity: any) =>
        activity ? [activity] : []
      );
      const currentDate = new Date()
      if (activities.length > 0) {
        const sessions = [].concat.apply([], activities.map((item: CourseEnrollment_enrollmentData_activities) => {
          return item.availableSessions && item.availableSessions.map((availableSession: CourseEnrollment_enrollmentData_activities_availableSessions | null) => availableSession && availableSession.endDateTime)
        }))
        const sessionDate = sessions ? new Date(sessions.reduce((i, j) => { return new Date(i) > new Date(j) ? i : j; })) : currentDate
        setMinDueDate(sessionDate > currentDate ? sessionDate : currentDate)
      } else {
        setMinDueDate(currentDate)
      }
      const steps: EnrollmentStepType[] = [...activities.map(() => ENROLLMENT_STEP_WORKSHOPS)];
      if (
        data.enrollmentData?.captureManagerEmail ||
        data.enrollmentData?.captureSpecialRequirements
      ) {
        steps.push(ENROLLMENT_STEP_ENROLLEE);
      }
      if (data.enrollmentData?.isTermsAndConditionAvailable) {
        steps.push(ENROLLMENT_STEP_TERMS);
      }
      if (data.enrollmentData?.isPreRequisitesAvailable) {
        steps.push(ENROLLMENT_STEP_PREREQUISITES);
      }

      setActivities(activities);
      if (dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY) {
        setSpecialRequirements(data?.enrollmentData?.learnerDetails?.reasonableAdjusmentRequest);
        setLineManagerEmail(data?.enrollmentData?.learnerDetails?.managersEmail);
        setUserEmail(data?.enrollmentData?.learnerDetails?.email);
        setSteps(steps);
      } else if (dialogType === ENROLLMENT_DIALOG_TYPES.COURSE) {
        setSpecialRequirements(data?.enrollmentData?.learnerDetails?.reasonableAdjusmentRequest);
        setLineManagerEmail(data?.enrollmentData?.learnerDetails?.managersEmail);
        setUserEmail(data?.enrollmentData?.learnerDetails?.email);
        setSteps(steps);
      } else if (dialogType === ENROLLMENT_DIALOG_TYPES.ADMIN) {
        const adminSteps: EnrollmentStepType[] = [
          ...activities.map(() => ENROLLMENT_STEP_WORKSHOPS),
          ADMIN_ENROLL_STEP,
        ];
        if (data.enrollmentData?.isTermsAndConditionAvailable) {
          adminSteps.push(ENROLLMENT_STEP_TERMS);
        }
        if (data.enrollmentData?.isPreRequisitesAvailable) {
          adminSteps.push(ENROLLMENT_STEP_PREREQUISITES);
        }
        adminSteps.push(ADMIN_CONFIRM_STEP);
        setSteps(adminSteps);
      }
      setStepOutput(fill(range(0, steps.length), null));
    }
  }, [data]);

  useEffect(() => {
    if (!open) {
      setCurrentStepIndex(0);
      setStepOutput(steps.length ? fill(range(0, steps.length), null) : []);
    }
  }, [open, steps]);

  const handleConfirm = () => {
    if ((dialogType === ENROLLMENT_DIALOG_TYPES.COURSE || dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY) && !stepOutput[currentStepIndex]) {
      return true;
    } else if (dialogType === ENROLLMENT_DIALOG_TYPES.ADMIN) {
      return confirmAdmin;
    }
  };

  const previousLabel = getStepLabel(getPreviousStepIndex());
  const nextLabel = getStepLabel(getNextStepIndex());
  const stepLabel = `${currentStepIndex + 1} / ${steps.length}`;
  const handleShowPathwayCourses = () => {
    setShowPathwayList(true);
    setSteps([]);

    setCurrentStepIndex(0);
    setTermsCheck(false);
    setPrerequisitsCheck(false);
    setEnrolleeCheck(false);
  };
  const handleDialogClose = () => {
    setSteps([]);
    setCurrentStepIndex(0);
    setTermsCheck(false);
    setPrerequisitsCheck(false);
    setEnrolleeCheck(false);
    handleClose();
  };

  const isLineManagerEmailRequired = portalSettingsManager.application.features.isLineManagerRequiredInF2FEnrollment;

  return (
    <Dialog
      id="enrolldialog"
      onClose={handleDialogClose}
      minWidth={isMobile ? undefined : "540px"}
      minHeight={isMobile ? undefined : "652px"}
      role="dialog"
      aria-labelledby="course_confirm_label" aria-modal="true"
      open={open}
      isMobile={isMobile}
      showCloseIcon
    >
      {showLoader && (
        <Box style={{ display: "flex", height: "500px", justifyContent: "center" }}>
          <Loader isDisplay={showLoader} type="component" message={"Loading"} />
        </Box>
      )}
      {dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY && showPathwayList && !showLoader && (
        <PathwayEnrollment
          pathwayEnrolldata={pathwayEnrolldata}
          handlePathwayCourseClick={handlePathwayCourseClick}
          showLoader={showLoader}
          setPathwayCourseId={setPathwayCourseId}
          pathwayTitle={title}
        />
      )}
      {steps[currentStepIndex] === ADMIN_ENROLL_STEP && (      
        <AdminEnrollContent
          minDueDate={minDueDate}
          stepLabel={stepLabel}
          termsCheck={termsCheck}
          prerequisitesCheck={prerequisitsCheck}
          setTermsCheck={setTermsCheck}
          setPrerequisitesCheck={setPrerequisitsCheck}
          requiredCourse={requiredCourse}
          setRequiredCourse={setRequiredCourse}
          addedUsers={addedUsers}
          setAddedUsers={setaddedUsers}
          handleRemoveEnrollment={handleRemoveEnrollment}
          selectedUsers={selectedUsers}
          setSelectedUsers={setSelectedUsers}
          output={stepOutput[currentStepIndex]}
          setDueDate={setDueDate}
          dueDate={dueDate}
          outputHandler={partial(setOutputForStep, currentStepIndex)}
          isTermsAvailable={data?.enrollmentData?.isTermsAndConditionAvailable ? true : false}
          isPreRequisitesAvailable={data?.enrollmentData?.isPreRequisitesAvailable ? true : false}
          courseId={course.id}
          selectedSessionDate={selectedSessionDate}
        />
      )}
      {steps[currentStepIndex] === ADMIN_CONFIRM_STEP && (
        <AdminConfirmContent
          minDueDate={minDueDate}
          isTermsAvailable={data?.enrollmentData?.isTermsAndConditionAvailable ? true : false}
          isPreRequisitesAvailable={data?.enrollmentData?.isPreRequisitesAvailable ? true : false}
          termsCheck={termsCheck}
          prerequisitesCheck={prerequisitsCheck}
          setTermsCheck={setTermsCheck}
          setPrerequisitesCheck={setPrerequisitsCheck}
          requiredCourse={requiredCourse}
          setRequiredCourse={setRequiredCourse}
          addedUsers={addedUsers}
          setAddedUsers={setaddedUsers}
          handleRemoveEnrollment={handleRemoveEnrollment}
          selectedUsers={selectedUsers}
          setSelectedUsers={setSelectedUsers}
          stepLabel={stepLabel}
          output={stepOutput[currentStepIndex]}
          setDueDate={setDueDate}
          dueDate={dueDate}
          outputHandler={partial(setOutputForStep, currentStepIndex)}
          courseId={course.id}
          selectedSessionDate={selectedSessionDate}
        />
      )}
      {steps[currentStepIndex] === ENROLLMENT_STEP_WORKSHOPS && activities[currentStepIndex] && (
        <SessionContent
          activity={activities[currentStepIndex]}
          stepLabel={stepLabel}
          output={stepOutput[currentStepIndex]}
          outputHandler={partial(setOutputForStep, currentStepIndex)}
          handleShowPathwayCourses={handleShowPathwayCourses}
          dialogType={dialogType}
          handleOpenWorkshop={handleOpenWorkshop}
          setSessionDate={setSessionDate}
        />
      )}
      {(steps[currentStepIndex] === ENROLLMENT_STEP_ENROLLEE ||
        (steps[currentStepIndex] === ENROLLMENT_STEP_ENROLLEE && activities.length === 0)) && (
          <EnrolleeContent
            details={data?.enrollmentData?.learnerDetails || {}}
            stepLabel={stepLabel}
            output={stepOutput[currentStepIndex]}
            outputHandler={partial(setOutputForStep, currentStepIndex)}
            captureManagerEmail={data?.enrollmentData?.captureManagerEmail}
            captureSpecialRequirements={data?.enrollmentData?.captureSpecialRequirements}
            canEditLineManagerEmail={canEditLineManagerEmail}
            lineManagerEmail={lineManagerEmail}
            specialRequirements={specialRequirements}
            setLineManagerEmail={setLineManagerEmail}
            setSpecialRequirements={setSpecialRequirements}
            enrolleeCheck={enrolleeCheck}
            setEnrolleeCheck={setEnrolleeCheck}
            handleShowPathwayCourses={handleShowPathwayCourses}
            dialogType={dialogType}
            isLineManagerEmailRequired={isLineManagerEmailRequired}
          />
        )}
      {steps[currentStepIndex] === ENROLLMENT_STEP_TERMS && (
        <TermsContent
          terms={data?.enrollmentData?.termsandConditions || ""}
          stepLabel={stepLabel}
          output={stepOutput[currentStepIndex]}
          outputHandler={partial(setOutputForStep, currentStepIndex)}
          termsCheck={termsCheck}
          setTermsCheck={setTermsCheck}
          handleShowPathwayCourses={handleShowPathwayCourses}
          dialogType={dialogType}
        />
      )}
      {steps[currentStepIndex] === ENROLLMENT_STEP_PREREQUISITES && (
        <PrerequisitesContent
          prerequisites={data?.enrollmentData?.preRequisites || ""}
          stepLabel={stepLabel}
          output={stepOutput[currentStepIndex]}
          outputHandler={partial(setOutputForStep, currentStepIndex)}
          prerequisitesCheck={prerequisitsCheck}
          setPrerequisitesCheck={setPrerequisitsCheck}
          handleShowPathwayCourses={handleShowPathwayCourses}
          dialogType={dialogType}
        />
      )}
      <DialogActions
        alignContent={dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY && showPathwayList ? "flex-end" : "space-between"}
      >
        {dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY && showPathwayList && !showLoader && (
          <Action type="dialog-alt" onClick={handleDialogClose}>
            {t('close').toUpperCase()}
          </Action>
        )}
        <div>
          {!!previousLabel && (
            <Action type="dialog-grey" onClick={() => setCurrentStepIndex(getPreviousStepIndex())}>
              {t('prev_placeholder')} {previousLabel}
            </Action>
          )}
        </div>
        <div>
          {!!nextLabel && (
            <Action
              type="dialog-primary"
              onClick={() => setCurrentStepIndex(getNextStepIndex())}
              disabled={!stepOutput[currentStepIndex]}
              style={{ width: "160px", height: "32px" }}
            >

              {nextLabel === t('summary') ? nextLabel : t('next_placeholder') + nextLabel}
            </Action>
          )}
          {currentStepIndex === steps.length - 1 && (
            <Action type="dialog-primary" onClick={processEnrollment} disabled={handleConfirm()} style={{ height: "32px", width: `${dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY ? "260px" : "160px"}` }}>
              {dialogType === ENROLLMENT_DIALOG_TYPES.PATHWAY ? t('confirm_pathway') : (t('confirm_course'))}
            </Action>
          )}
        </div>
      </DialogActions>
    </Dialog>
  );
};
