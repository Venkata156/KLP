import { Box, Container } from "@material-ui/core";
import { ReactChild } from "react";
import { useTranslation } from "react-i18next";

export const Layout = ({
  header,
  footer,
  main,
}: {
  header: ReactChild;
  footer: ReactChild;
  main: ReactChild;
}): JSX.Element => {
    const { t } = useTranslation();

  const isFullScreen = () => {
     return location.pathname.toLowerCase().indexOf('/player') !== -1;
  }

  return (
    <Box display="flex" flexDirection="column" minHeight="100vh">
      {header && (
        <Box
          position="fixed"
          top="0"
          left="0"
          right="0"
          height={{ xs: "50px", sm: "70px" }}
          zIndex="999"
          style={{ backgroundColor: "#ffffff" }}
          component='header'
          role='banner'
          aria-label={t('aria_label_header')}
        >
          {header}
        </Box>
      )}
     <Box flex="1"
           marginTop={isFullScreen() ? { xs: "0px", sm: "0px", md: "0px" } : { xs: "50px", sm: "50px", md: "70px" }}
           overflow="hidden" role='main' component='main' aria-label={t('aria_label_main_content')}>
        {main}
      </Box>
      <Box borderTop="1px solid #c9c9c9" component='footer' role='contentinfo' aria-label={t('aria_label_footer')}>
        <Container>{footer}</Container>
      </Box>
    </Box>
  );
};
