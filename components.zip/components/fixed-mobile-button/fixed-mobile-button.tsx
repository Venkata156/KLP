import { Box, Button, ButtonProps, useTheme } from "@material-ui/core";
import React, { useEffect } from "react";
import { useAppDispatch } from "store";
import { setPageButton } from "store/core";

const BottomButton = (props: ButtonProps) => (
  <Button
    {...props}
    style={{ flex: "auto", borderRadius: "0px", color: "white", fontSize: "11px", fontWeight: "bold", height: "100%", ...props.style }}
  />
);

type MobileBottomContainerProps = {
  bgcolor?: string;
  children: React.ReactNode | React.ReactNode[];
};
export const MobileBottomContainer = ({
  bgcolor,
  children,
}: MobileBottomContainerProps): JSX.Element => {
  const theme = useTheme();
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(setPageButton(true));
    return () => {
      dispatch(setPageButton(false));
    };
  }, [dispatch]);

  return (
    <Box
      display={{ xs: "flex", sm: "none" }}
      position="fixed"
      bottom="0"
      left="0"
      width="100%"
      height="42px"
      bgcolor={bgcolor ?? theme.palette.primary.main}
      zIndex={10}
    >
      {children}
    </Box>
  );
};

MobileBottomContainer.Button = BottomButton;
