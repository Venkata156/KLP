import React from "react";
import { Box, Typography } from "@material-ui/core";
import { Theme, withStyles } from "@material-ui/core/styles";
import { Star, StarBorder, StarHalf } from "@material-ui/icons";
import { useTranslation } from "react-i18next";

type ContainerProps = {
  mobile?: boolean;
  editable: boolean;
  margin?:any
};
const Container = withStyles((theme: Theme) => ({
  root: {
    display: "flex",
    alignItems: "center",
    margin: (props: ContainerProps) => props.margin || (props.mobile ? "0 0" : "10px 0"),
    fontStyle: "italic",
    fontSize: "11px",
    color: theme.palette.grey["800"],
    cursor: (props: ContainerProps) => (props.editable ? "pointer" : "default"),
    "& svg": {
      width: "14px",
      color: "#FFD157",
    },
    "& span": {
      marginLeft: "10px",
    },
  },
}))(Box);

export const Rating = ({
  score,
  numberOfReviews,
  onSubmit,
  display,
  mobile,
}: {
  score: number;
  numberOfReviews: number;
  onSubmit?: () => void;
  display?: boolean | string;
  mobile?: boolean;
}): JSX.Element => {
  const handleClick = () => {
    if (typeof onSubmit === "function") {
      onSubmit();
    }
  };
  const { t } = useTranslation();

  return (
    <Container
      display="flex"
      alignItems="center"
      mobile={mobile}
      editable={typeof onSubmit === "function"}
      aria-label={t('aria_label_average_rating_for_course')+' '+ score}

    >
      {/* Ugly, but functional. */}
      <Box onClick={handleClick} tabIndex={0} role="link" aria-label={t('aria_label_average_rating_for_course') +' '+ score}>
        {score < 1 ? score === 0.5 ? <StarHalf /> : <StarBorder /> : <Star />}
        {score < 2 ? score === 1.5 ? <StarHalf /> : <StarBorder /> : <Star />}
        {score < 3 ? score === 2.5 ? <StarHalf /> : <StarBorder /> : <Star />}
        {score < 4 ? score === 3.5 ? <StarHalf /> : <StarBorder /> : <Star />}
        {score < 5 ? score === 4.5 ? <StarHalf /> : <StarBorder /> : <Star />}
      </Box>
      <Typography
        component="span"
        style={{ fontStyle: "italic", fontSize: "11px", marginLeft: "10px" }}
        aria-label={t('aria_label_average_rating_for_course') +' '+ score}
      >
        {display
          ? `(${numberOfReviews})`
          : t('number_of_reviews', { count: numberOfReviews })
        }
      </Typography>
    </Container>
  );
};
