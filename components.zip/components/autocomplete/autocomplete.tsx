import React, {useEffect, useState} from "react";
import MenuItem from "@material-ui/core/MenuItem";
import Box from "@material-ui/core/Box";
import { ClickAwayListener, IconButton, Popper } from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";

export const Autocomplete = (props:any): JSX.Element => {
  const { 
    id,
    renderOption=(s: any) => s, 
    onChange,
    options,
    renderInput=(s:any) => s,
    getOptionLabel=(s:any) => s,
  } = props;
  const [show, setShow] = useState(false);
  const [suggestions, setSuggestions] = useState<any[]>(options);
  const [highlightedIdx, setHighlightedIdx] = useState(0);
  const [inputValue, setInputvalue] = useState('');
  const [inputType,setInputType] = useState<any>();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.persist()
    setInputType(e);
    const valueType = e.target.value;
    filterData(valueType);
    setInputvalue(valueType);
  };

  const filterData = (valueType:any = inputValue) => {
    let suggestionsT = [];
    if (valueType.length > 0) {
      suggestionsT = options.filter((v: any) =>{
        return getOptionLabel(v).toLowerCase().indexOf(valueType.toLowerCase()) !==-1;
      });
      setSuggestions(suggestionsT);
      setShow(true);
    } else {
      setShow(false);
    }
  }

  useEffect(() => {
    filterData();
  }, [options]);

  const handleSelect = (event:any,idx: number) => {
    inputType.target.value = '';
    if (onChange) {
      onChange(event,suggestions[idx]);
      setSuggestions([]);
      setShow(false);
    }
  };

  const handleKeyDown = (e:any) => {
    const UP = 38;
    const DOWN = 40;
    const ENTER = 13;
    const INITIAL_IDX = 0;
    const key = e.keyCode;
    if(!anchorEl)
    setAnchorEl(e.currentTarget);
    if (key === DOWN) {
      e.preventDefault();
      const idx = highlightedIdx;
      const nextIdx = idx !== undefined ? idx + 1 : INITIAL_IDX;
      if (nextIdx < suggestions.length) {
        setHighlightedIdx(nextIdx);
      } else {
        setHighlightedIdx(INITIAL_IDX);
      }
    }

    if (key === UP) {
      e.preventDefault();
      const lastIdx = suggestions.length - 1;
      const idx = highlightedIdx;
      const prevIdx = idx !== undefined ? idx - 1 : lastIdx;
      if (prevIdx >= 0) {
        setHighlightedIdx(prevIdx);
      } else {
        setHighlightedIdx(lastIdx);
      }
    }

    if (key === ENTER && highlightedIdx !== undefined) {
      handleSelect(e,highlightedIdx);
    }
  };
  const shouldShowSuggestions = suggestions.length > 0 && show;
  const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(null);
  return (
    <Box> 
      {renderInput({
        autoComplete:'off',
        fullWidth:true,
        ref:setAnchorEl,
        InputProps : {
          style:{paddingRight:0},
          endAdornment: (
            <IconButton disabled>
              <SearchIcon />
            </IconButton>
          )
        },
        id:id,
        onKeyUp:handleChange,
        onKeyDown: handleKeyDown,
      })}
      { /*suggestions.length === 0 && show? (
        <Box style={{
          padding: '14px 16px'}} color="secondary">No Options</Box>
        ) : null*/}
      <ClickAwayListener onClickAway={()=>setShow(false)}>
        <Popper  
          id={id}
          anchorEl={anchorEl}
          open={shouldShowSuggestions}
          style={{
            overflowY: 'auto',
            zIndex: 2900,
            display: 'flex',
            background:'white',
            flexDirection: 'column',
            width: anchorEl ? anchorEl.clientWidth : '100%',
            boxShadow: '0 1px 2px 0',
            top:'50px'
          }}
        >
          { shouldShowSuggestions && suggestions.map((suggestion, idx) => (
            <MenuItem
              key={`suggestion-${idx}`}
              onClick={(e) => handleSelect(e,idx)}
              selected={highlightedIdx === idx}
            >
              {renderOption(suggestion)}
            </MenuItem>
          ))}
        </Popper>
      </ClickAwayListener>
    </Box>
  );
};
