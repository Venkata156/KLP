import React from "react";
import { Box, Typography, IconButton as MuiIconButton } from "@material-ui/core";
import { Theme, withStyles, useTheme } from "@material-ui/core/styles";
import CloseIcon from "@material-ui/icons/Close";
import CheckIcon from "@material-ui/icons/Check";
import ErrorIcon from "@material-ui/icons/PriorityHigh";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";

const IconButton = withStyles((theme: Theme) => ({
  root: {
    "& svg": {
      borderRadius: "50%",
      width: "20px",
      height: "20px",
    },
  },
  label: {
    color: `${theme.palette.common.white} !important`,
  }
}))(MuiIconButton);

export const Alert = ({ type, title, message, onClose }: {
  type: string;
  title: string;
  message: string;
  onClose?: React.MouseEventHandler<HTMLButtonElement>;
}): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const icon =
    type == "success" ? (
      <CheckIcon fontSize="inherit" style={{ background: "#43B02A" }} />
    ) : type == "error" ? (
      <ErrorIcon fontSize="inherit" style={{ background: "#D0021B" }} />
    ) : (
      ""
    );
  return (    
    <Box display="flex" style={{ background: theme.palette.grey['800'] }}>      
      <Box m="11px" aria-hidden="true">
        <IconButton size="small" aria-hidden="true" tabIndex="-1" >{icon}</IconButton>
      </Box>
      <Box flex="1" m="11px 0">
        <Typography aria-hidden="true" style={{
          fontSize: portalSettingsManager.fonts?.toaster?.titleFont?.size || "11px",
          fontFamily: portalSettingsManager.fonts?.toaster?.titleFont?.name || "inherit",
          color: portalSettingsManager.fonts?.toaster?.titleFont?.color || `${theme.palette.common.white}`,
          fontWeight: 700,
          lineHeight: "18px",
        }}
        >
          {title}
        </Typography>
        <Typography aria-hidden="true" style={{
          fontSize: portalSettingsManager.fonts?.toaster?.summaryFont?.size || "11px",
          fontFamily: portalSettingsManager.fonts?.toaster?.summaryFont?.name || "inherit",
          color: portalSettingsManager.fonts?.toaster?.summaryFont?.color || theme.palette.grey['300'],
          lineHeight: "14px"
        }}                  
        ><span id="msg">{message}</span></Typography>
      </Box>
      <Box m="5px" aria-hidden="true">
        <IconButton aria-hidden="true" aria-label={t('aria_label_close_alerts_dialog')} size="small" onClick={onClose}>
          <CloseIcon />
        </IconButton>
      </Box>
    </Box>
  );
};
