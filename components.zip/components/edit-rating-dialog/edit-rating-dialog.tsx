import React, { useState } from "react";
import { Box, Typography } from "@material-ui/core";
import MuiDialogActions from "@material-ui/core/DialogActions";
import MuiDialogContent from "@material-ui/core/DialogContent";
import { Star, StarBorder, StarHalf } from "@material-ui/icons";
import { withStyles, useTheme } from "@material-ui/core/styles";
import { Dialog, Action } from "components";
import { useTranslation } from "react-i18next";

const DialogContent = withStyles(() => ({
  root: {
    overflow: "hidden",
    "& svg": {
      color: "lightgray",
      transform: "scale(1.5)",
      width: "30px",
      height: "30px",
      marginRight: "23px",
    },
    "& svg.fill": {
      fill: "#FFD157",
    },
  },
}))(MuiDialogContent);
DialogContent.displayName = "DialogContent";

const DialogActions = withStyles(() => ({
  root: {
    display: "flex",
    padding: "0px 25px 30px 25px",
    height: "42px",
  },
}))(MuiDialogActions);
DialogActions.displayName = "DialogActions";

export const EditRatingDialog = ({
  score,
  type,
  open,
  onClose,
  onSubmitRating,
}: any): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const [rating, setRating] = useState<number>(score);

  const onSubmit = (e: any) => {
    e.preventDefault();
    e.stopPropagation();
    if (rating >= 1) {
      onSubmitRating(rating);
    }
  };

  const onSelectRatingClick = (e: any, number: number) => {
    e.preventDefault();
    e.stopPropagation();
    setRating(number);
  };

  return (
    <Dialog id="editratingdialog" onClose={onClose} role="dialog"  aria-labelledby="rating_dialog" aria-modal="true" open={open} showCloseIcon>
      <DialogContent title="Rating-Dialog-box">
        <Typography
          style={{ fontSize: "16px", color: theme.palette.grey["800"], fontWeight: "bold" }}
          component="h2"
          id="rating_dialog"
        >
          {`${t('rate_this')} ${t(type.toLowerCase())} `}
        </Typography>
        <Typography
          style={{
            fontSize: "12px",
            color: theme.palette.grey["800"],
            lineHeight: "16px",
            paddingTop: "12px",
          }}
          component="h3"
        >
          { t('course_rating_dialog',{type: type?.toLowerCase()}) }
        </Typography>
        <Box m="25px 0 40px 0" style={{ display: "flex", cursor: "pointer" }} tabIndex={0}>
          <div onClick={(e: any) => onSelectRatingClick(e, 1)}>
            {rating < 1 ? (
              rating === 0.5 ? (
                <StarHalf />
              ) : (
                <StarBorder />
              )
            ) : (
              <Star className="fill" />
            )}
          </div>
          <div onClick={(e: any) => onSelectRatingClick(e, 2)}>
            {rating < 2 ? (
              rating === 1.5 ? (
                <StarHalf />
              ) : (
                <StarBorder />
              )
            ) : (
              <Star className="fill" />
            )}
          </div>
          <div onClick={(e: any) => onSelectRatingClick(e, 3)}>
            {rating < 3 ? (
              rating === 2.5 ? (
                <StarHalf />
              ) : (
                <StarBorder />
              )
            ) : (
              <Star className="fill" />
            )}
          </div>
          <div onClick={(e: any) => onSelectRatingClick(e, 4)}>
            {rating < 4 ? (
              rating === 3.5 ? (
                <StarHalf />
              ) : (
                <StarBorder />
              )
            ) : (
              <Star className="fill" />
            )}
          </div>
          <div onClick={(e: any) => onSelectRatingClick(e, 5)}>
            {rating < 5 ? (
              rating === 4.5 ? (
                <StarHalf />
              ) : (
                <StarBorder />
              )
            ) : (
              <Star className="fill" />
            )}
          </div>
        </Box>
      </DialogContent>
      <DialogActions>
        <Action type="dialog-alt" onClick={onClose}>
        {t('cancel')}
        </Action>
        <Action type="dialog-primary" onClick={onSubmit} disabled={rating < 1} style={{ width: "125px" }}>
        {t('submit_rating_dialog')}
        </Action>
      </DialogActions>
    </Dialog>
  );
};
