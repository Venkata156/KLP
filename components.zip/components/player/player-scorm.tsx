import { CoursePlayer } from "../../utils/graphql/CoursePlayer";

export const ScormPlayer = ({ player }: CoursePlayer): JSX.Element => {

    const validateURL = (url) => {  
        const parsed = new URL(url);  
        return parsed.toString(); 
   }

    const customWindow: any = window;
    let scormPaths: any = player?.playerBodyModel?.scormPaths;
    let portalBaseUrl: string = window?.location?.origin;

    const addScriptFile = (filePath: string) => {
        const script = document.createElement("script");

        script.src = filePath;
        script.async = true;

        document.head.appendChild(script);
    }

    addScriptFile(scormPaths?.portHoleJSPath);
    addScriptFile(scormPaths?.bundleJSPath);

    const iniatScorm = () => {
        var properties = {
            activityId: player?.playerBodyModel?.activityModel?.id,
            programmeId: player?.playerBodyModel?.id,
            activityName: player?.playerBodyModel?.activityModel?.name,
            studentId: player?.playerBodyModel?.learnerModel?.id,
            studentName: `${player?.playerBodyModel?.learnerModel?.lastName}, ${player?.playerBodyModel?.learnerModel?.firstName}`,
            containerId: 'scormScoContainer',
            iframe: {
                src: player?.playerBodyModel?.uri,
                width: '99%',
                height: '98%',
                style: 'border: #9a9a9a solid 2px'
            },
            encryptedTenantId: player?.playerBodyModel?.encryptedTenantId,
            test: false, // optional
            debug: true, // optional
            scormDataModel: JSON.parse(player?.playerBodyModel?.scormDataModel || '{}') || {}
        };
        customWindow.swotWindowProxyUrl = { proxyHtmlPath : scormPaths?.proxyHtmlPath };
        customWindow.swotFrameProxy = {};
        customWindow.properties = properties;

        customWindow.onbeforeunload = unloadWindow;
        customWindow.onunload = unloadWindow;
        function unloadWindow() {
            customWindow.opener.Publishers.RestPublisher.encryptedTenantId = player?.playerBodyModel?.encryptedTenantId;
            customWindow.opener.submitScormData(properties.scormDataModel);
        }
    }

    const loadScorm = () => {
        customWindow.properties.publisherEndPoints = [customWindow.Publishers.RestPublisher];
        customWindow.Porthole.trace("onload");
        customWindow.swotFrameProxy = new customWindow.Porthole.WindowProxy(scormPaths.proxyHtmlPath, 'swotFrame');

        customWindow.swotFrameProxy.post(customWindow.properties);
        customWindow.document.title = customWindow.properties.activityName;
    };

    setTimeout(() => {
        iniatScorm();
        loadScorm();
    }, 5000);

    const unloadScorm = () => {
        console.info('unloadScorm');
        customWindow.opener.Publishers.RestPublisher.encryptedTenantId = player?.playerBodyModel?.encryptedTenantId;
        customWindow.opener.submitScormData(customWindow.properties.scormDataModel);
    }

    window.addEventListener("beforeunload", unloadScorm);

    window.removeEventListener("beforeunload", unloadScorm);

    return (
        <div>
            <iframe
                name="swotFrame"
                id="swotFrame"
                style={{
                    width: "99%",
                    height: "850px",
                    border: "#9a9a9a solid 2px"
                }}
                src={validateURL(scormPaths?.contentWrapperHtmlPath + "?parent=" + portalBaseUrl)}
                scrolling="no"></iframe>
        </div>
    );
};
