import { AzureMP } from 'react-azure-mp'

export const MediaPlayer = (
    {
        mediaUrl,
        imageUrl,
    }
        :
    {
        mediaUrl: string;
        imageUrl: string;
    }): JSX.Element => {

    return (
        <div>
            <AzureMP
                skin="amp-flush"
                options={{
                    controls: true,
                    autoplay: false,
                    poster: imageUrl,
                    width: '99%',
                    height: '98%'
                }}
                src={[{
                    src: mediaUrl,
                    type: "application/vnd.ms-sstr+xml"
                }]}
            />
        </div>
    );
};
