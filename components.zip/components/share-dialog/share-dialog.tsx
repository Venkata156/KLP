import { Typography, useMediaQuery } from "@material-ui/core";
import MuiButton from "@material-ui/core/Button";
import { Theme, withStyles, useTheme } from "@material-ui/core/styles";
import {
  DialogActions,
  Dialog,
  DialogContent,
  UserSearch,
  UserSelected,
  Tooltip,
  RenderHTML,
  Action,
} from "components";
import { useEffect, useState } from "react";
import { SHARE_CONTENT } from "utils/queries";
import { useMutation } from "@apollo/client";
import { useAppDispatch } from "store";
import { useFocusStyles } from "hooks/focusBorder";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";


const Button = withStyles((theme: Theme) => ({
  root: {
    borderRadius: 0,
    color: portalSettingsManager.buttonColors?.themed?.active?.text || theme.palette.primary.main,
    height: "42px",
    width: "120px",
  },
  label: {
    fontSize: 11,
    fontWeight: 700,
  },
  outlined: {
    border: `1px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
  },
  disabled: {
    color: theme.palette.grey["500"],
  },
}))(MuiButton);

type ShareDialogProps = {
  open: boolean;
  handleClose: () => void;
  shareLink?: string;
  [x: string]: any;
};
export const ShareDialog: React.FC<ShareDialogProps> = ({
  open,
  handleClose,
  course,
  contentType,
  shareLink
}) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const dispatch = useAppDispatch();
  const [selectedUsers, setSelectedUsers] = useState<any[]>([]);
  const [addedUsers, setaddedUsers] = useState<any[]>([]);
  const [shareContent] = useMutation(SHARE_CONTENT);
  const [shareTitle, setShareTitle] = useState<string>("");
  const { t } = useTranslation();
  const handleRemoveEnrollment = (user: any) => {
    setSelectedUsers(selectedUsers.filter((item: any) => item.id !== user.id));
  };
  useEffect(() => {
    setShareTitle("Share " + course?.name);
  }, [course]);
  const handleShareContent = () => {
    handleClose()
    dispatch({
      type: "loader/showandhide",
      payload: { show: true, message: t('share_content_loading') },
    });
    const users = selectedUsers.map((i: any) => {
      const obj = {
        firstName: i.firstName,
        lastName: i.lastName,
        email: i.email,
      };
      return obj;
    });
    const payloadData = {
      recipients: users,
      contentName: course?.name,
      contentSummary: course?.summary,
      contentPortalUri: shareLink,
    };
    shareContent({ variables: { payload: payloadData } })
      .then(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('share_content_loading') },
        });
        setSelectedUsers([]);
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('sharedcontent_success_alert_title'),
            message:t('sharedcontent_success_alert_message'),
          },
        });
      })
      .catch((e) => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('share_content_loading') },
        });
        setSelectedUsers([]);
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('share'),
            message:t('shared_content_error_alert_message'),
          },
        });
      });
  };

  const stringLength = isMobile ? 140 : 180;
  const courseDesc = `${t('share_this_description')} ${t(contentType?.toLowerCase())} ${t('share_this_description_rest')}`;
  const focusClass = useFocusStyles();

  return (
    <Dialog
      id="sharedialog" 
      onClose={handleClose}
      role="dialog"  aria-labelledby="share_dialog_label" aria-modal="true"
      open={open}
      minWidth={isMobile ? undefined : 474}
      fullScreen={isMobile}
      showCloseIcon
    >
      <DialogContent
        style={{ display: "flex", flexDirection: "column", overflowY: "visible", height: "100%" }}
      >
        <Typography
          style={{
            fontSize: "16px",
            fontWeight: isMobile ? "bold" : undefined,
            color: theme.palette.grey["800"],
          }}
          component="h2"
          id="share_dialog_label"
        >
          <RenderHTML content={shareTitle} />
        </Typography>
        <Typography
          style={{
            fontSize: isMobile ? "14px" : "12px",
            color: theme.palette.grey["800"],
            lineHeight: "18px",
            marginTop: "15px",
            marginBottom: "26px",
          }}
          component="h3"
        >
          <div>
            {courseDesc.length > stringLength ? (
              <Tooltip
                title=""
                filter={(ele) => ele.tagName === "SPAN"}
                parentTitle={true}
                tooltipStyle={{ maxWidth: "200px" }}
              >
                <p title="" style={{ display: "inline" }}>
                  {courseDesc.slice(0, stringLength)}
                  <span
                    title={courseDesc.slice(stringLength, courseDesc.length)}
                    style={{ display: "inline" }}
                  >
                    {"..."}
                  </span>
                </p>
              </Tooltip>
            ) : (
              <RenderHTML content={courseDesc} />
            )}
          </div>
        </Typography>
        <UserSearch
          setaddedUsers={setaddedUsers}
          addedUsers={addedUsers}
          setSelectedUsers={setSelectedUsers}
          selectedUsers={selectedUsers}
          outputHandler={() => {
            return false;
          }}
          label={t('recipient')}
          placeHolder={t('search')}
          isRoleBased={false}
          aria-autocomplete={"list"}
        />
        <UserSelected
          selectedUsers={selectedUsers}
          handleRemoveEnrollment={handleRemoveEnrollment}
          style={{ overflowY: "visible" }}
        />
      </DialogContent>
      <DialogActions>
        <Action type="dialog-alt" onClick={handleClose}>
        {t('cancel_and_close')}
        </Action>
        <Button
          variant="outlined"
          onClick={handleShareContent}
          disabled={selectedUsers.length === 0}
          style= {{ 
            color: portalSettingsManager.buttonColors?.themed?.active?.text || theme.palette.primary.main,
            backgroundColor: portalSettingsManager.buttonColors?.themed?.active?.back,
            border: `1px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
          }}
          className={`${focusClass.primaryHover} ${focusClass.focusItem}`}
        >
          {t('share').toUpperCase()}
        </Button>
      </DialogActions>
    </Dialog>
  );
};
