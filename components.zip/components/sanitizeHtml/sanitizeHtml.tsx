import { Box } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import sanitizeHtml from "sanitize-html";

const Container = withStyles(() => ({
  root: {
    "& a": {
      textDecoration: "underline",
      color: "#0000EE"
    },
  },
}))(Box);

export const RenderHTML = ({ content }: { content: string }): JSX.Element => {
  if (!content) return (<></>)
  return (
    <Container
      dangerouslySetInnerHTML={{
        __html: sanitizeHtml(content, { allowedTags: false, allowedAttributes: false, }),
      }}
    />
  );
};
