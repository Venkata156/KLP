// used https://www.materialui.co/colors to generate the color palette
export const colors = {
  green: {
    "300": "#81C784",
    "500": "#3A833C", //"#4CAF50",
    "800": "#2E7D32",
    A100: "#B9F6CA",
  },
  orange: {
    "400": "#ff980a",
    "500": "#f68d2e"
  },
};
