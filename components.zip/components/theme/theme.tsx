import { createMuiTheme } from "@material-ui/core/styles";

export const theme = createMuiTheme({
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 960,
      lg: 1280,
      xl: 1920,
    },
  },
  typography: {
    fontFamily: [
      "arial",
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      "Oxygen",
      "Ubuntu",
      "Cantarell",
      '"Fira Sans"',
      '"Droid Sans"',
      '"Helvetica Neue"',
      "sans-serif",
    ].join(","),
    caption: {
      fontFamily: "Arial",
      fontSize: "11px",
      fontWeight: 400,
      color: "#999999",
    },
  },
  palette: {
    primary: {
      light: "#007AB8",
      main: "#007AB8",
      dark: "#007AB8",
    },
    grey: {
      "300": "#d8d8d8",
      "500": "#767676",
      "800": "#333333",
      A100: "#979797",
      "100": "#ffffff",
      "200": "#0091da",
      '50': '#fafafa',
      "400": "#999999",
      "A400": "#007AB8",
      "A700": "#757575"

    },
    background: {
      default: "#00a3a1"
    },
  },
});
