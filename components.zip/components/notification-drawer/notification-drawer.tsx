import { useMutation } from "@apollo/client";
import { Box, Typography, makeStyles, Theme, useMediaQuery } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import { Close } from "@material-ui/icons";
import { ConfirmDialog, RenderHTML } from "components";
import { useEffect, useState } from "react";
import { useAppDispatch } from "store";
import { Notifications, Notifications_notificationByLearnerId } from "utils/graphql/Notifications";
import { DELETE_ALL_NOTIFICATIONS, DELETE_NOTIFICATION, MARK_NOTIFICATIONS_AS_READ } from "utils/queries";
import { useHistory } from "react-router-dom";
import { useTranslation, TFunction } from "react-i18next";


const useStyles = makeStyles((theme: Theme) => ({
    root: {
        position: "relative",
    },
    viewLess: {
        " & div:nth-child(1)": {
            textAlign: "justify",
            display: "-webkit-box",
            "-webkit-line-clamp": 4,
            "-webkit-box-orient": "vertical",
            overflow: "hidden",
            fontSize: "12px",
            wordBreak: "break-word"
        },
    },
    viewMore: {
        " & div:nth-child(1)": {
            textAlign: "justify",
            fontSize: "12px",
            wordBreak: "break-word"

        }
    },
    courseTitle: {
        " & div:nth-child(1)": {
            fontSize: "13px",
            fontWeight: 700, color: theme.palette.primary.main,
            letterSpacing: 0, cursor: "pointer",
            whiteSpace: "break-spaces",
            width: "389px",
            overflow: "hidden"
        }

    }
}));

interface ReadMoreProps {
    content: string;
    isHidden: boolean;
    setIsHidden: (value: boolean) => void;
    diplayTime: string;
}

const timeIntervals = [
    { label: 'year', seconds: 31536000 },
    { label: 'month', seconds: 2592000 },
    { label: 'week', seconds: 604800 },
    { label: 'day', seconds: 86400 },
    { label: 'hour', seconds: 3600 },
    { label: 'minute', seconds: 60 },
    { label: 'second', seconds: 1 }
];

const timeSince = (date: string, t: TFunction<"translation", undefined>) => {
    const seconds = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
    const interval = timeIntervals.find(i => i.seconds < seconds);
    if (interval) {
        const count = Math.floor(seconds / interval?.seconds);
        return `${count} ${interval?.label}${count !== 1 ? 's' : ''} ${t('ago')}`;
    } else {
        return " "
    }
}
const NotificationContent = ({ content, isHidden, diplayTime, setIsHidden }: ReadMoreProps): JSX.Element => {
    const classes = useStyles();
    const { t } = useTranslation();
    return (
        <>
            <Box marginTop="4px" style={{ whiteSpace: "break-spaces" }} className={isHidden ? classes.viewLess : content.length > 240 ? classes.viewMore : ""}>
                <RenderHTML content={content} />

            </Box>
            <Box display="flex" justifyContent="space-between" marginTop="10px">
                <Typography
                    style={{
                        fontSize: "12px",
                        color: "#767676"
                    }}
                >                   {timeSince(diplayTime, t)}

                </Typography>
                {content.length > 240 && <Typography style={{
                    fontSize: "12px",
                    color: "#0091DA", cursor: "pointer"
                }} onClick={() => setIsHidden(!isHidden)}
                    tabIndex={0}>
                    {isHidden ? t('notification_view_more') : t('notification_view_less')}
                </Typography>
                }
            </Box>
        </>
    );
}
const NotificationItem = ({ item, handleDeleteNotification, type, closeHandler, isMobile, ...props }: any): JSX.Element => {
    const theme = useTheme();
    const history = useHistory();
    const [isHidden, setIsHidden] = useState(true);
    const classes = useStyles();
    const typeObject: { [key: string]: string } = {
        "PATHWAY": "PATHWAY",
        "PROGRAMME": "COURSE"
    }
    return (
        <Box display="flex" justifyContent="space-between" m="20px 0">
             <Box style={{ width: "100%" }}>
                <Box
                    display="flex"
                    alignItems={{ xs: "start", sm: "center" }}
                    justifyContent="space-between"
                    flexDirection={{ xs: "column", sm: "row" }}
                >
                    <Box className={classes.courseTitle}
                        style={{ width: isMobile ? "85vw" : undefined }}
                        onClick={() => { sessionStorage.setItem("relatedItemClick", "true"); closeHandler(); history.push(`/${typeObject[item.type]}/${eval(item.metadata)}`) }}
                        tabIndex={0}>
                        <RenderHTML content={item.title} />
                    </Box>
                </Box>
                <NotificationContent content={item.body} diplayTime={item.createdOn} isHidden={isHidden} setIsHidden={setIsHidden} />
            </Box>
            <Box>
                <Close tabIndex={0}
                    aria-hidden="false"
                    fontSize="small"
                    cursor="pointer"
                    onClick={() => handleDeleteNotification(item, type)}
                />
            </Box>

        </Box >
    );
};
export const NotificationDrawer = ({
    closeHandler,
    showSurvey,
    handleHeaderClick,
    notificationResult,
    handleRefetchNotifications,
    isSurveyCompleted,
    setIsClearNotification,
    surveyStartDate
}: {
    closeHandler: () => void;
    showSurvey?: boolean;
    handleHeaderClick: (value: string) => void;
    notificationResult?: Notifications;
    handleRefetchNotifications: () => void;
    isSurveyCompleted: boolean;
    setIsClearNotification: (value: boolean) => void;
    surveyStartDate: string
}): JSX.Element => {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
    const dispatch = useAppDispatch();
    const { t } = useTranslation();

    const [newNotification, setNewNotification] = useState<Notifications_notificationByLearnerId[]>([])
    const [oldNotification, setOldNotification] = useState<Notifications_notificationByLearnerId[]>([])
    const [deleteAllNotifications] = useMutation(DELETE_ALL_NOTIFICATIONS);
    const [deleteNotifications] = useMutation(DELETE_NOTIFICATION);
    const [markNotificationasRead] = useMutation(MARK_NOTIFICATIONS_AS_READ);

    useEffect(() => {
        markNotificationasRead()
    }, [])

    useEffect(() => {
        if (notificationResult) {
            handleNotification(notificationResult)

        }
    }, [])
    const handleNotification = (data: Notifications) => {
        const newNotify: Notifications_notificationByLearnerId[] = [];
        const oldNotify: Notifications_notificationByLearnerId[] = [];
        data?.notificationByLearnerId?.map((i) => {
            if (i) {
                if (i.readOn) {
                    oldNotify.push(i)
                } else {
                    newNotify.push(i)
                }
            }
        })
        setOldNotification(oldNotify.sort((a: Notifications_notificationByLearnerId, b: Notifications_notificationByLearnerId) => {
            return Math.abs(new Date(b.createdOn).valueOf() - new Date(a.createdOn).valueOf());

        }));
        setNewNotification(newNotify.sort((a: Notifications_notificationByLearnerId, b: Notifications_notificationByLearnerId) => {
            return Math.abs(new Date(b.createdOn).valueOf() - new Date(a.createdOn).valueOf());

        }));

    }
    const [showConfirmDialog, setConfirmDialog] = useState<boolean>(false)

    const handleDeleteNotification = (item: Notifications_notificationByLearnerId, type: string) => {
        if (type === "old") {
            const res = oldNotification.filter((i: Notifications_notificationByLearnerId) => i.id !== item.id)
            setOldNotification(res)
        } else {
            const res = newNotification.filter((i: Notifications_notificationByLearnerId) => i.id !== item.id)
            setNewNotification(res)
        }
        if ((oldNotification.length === 1 && newNotification.length === 0 && (!showSurvey || isSurveyCompleted)) ||
            (oldNotification.length === 0 && newNotification.length === 1 && (!showSurvey || isSurveyCompleted))) {
            setIsClearNotification(true)
            closeHandler()
        }
        deleteNotifications({ variables: { notificationId: item.id } }).then(() => {
            handleRefetchNotifications()
        })

    }


    const handleClearAllnotifications = () => {
        setNewNotification([])
        setOldNotification([])
        if (!showSurvey || isSurveyCompleted) {
            closeHandler()
            setIsClearNotification(true)
        }
        deleteAllNotifications().then(() => {
            handleRefetchNotifications()
            dispatch({
                type: "alert/show",
                payload: {
                    type: "success",
                    title: t('notification_cleared_success_title'),
                    message: t('notification_cleared_success_message'),
                },
            });
        })
            .catch(() => {
                dispatch({
                    type: "alert/show",
                    payload: {
                        type: "error",
                        title: t('notification_survay_submitted_title'),
                        message: t('notification_survay_submitted_error_message'),
                    },
                });
            });

        setConfirmDialog(false)
    }
    return (

        <Box style={{ maxWidth: isMobile? "100vw": "500px", minWidth: "376px" }}>
            <Box >
                <Close
                    fontSize="small"
                    onClick={closeHandler}
                    tabIndex={0}
                    style={{
                        position: "absolute",
                        top: "12px",
                        right: "12px",
                        cursor: "pointer",
                    }}
                    role="button"
                    aria-hidden="false"
                    aria-label={'close notification'}
                />
            </Box>
            <Box m="44px 40px 0px 30px">
                <Box style={{ display: "flex", justifyContent: "space-between", borderBottom: "1px solid #D8D8D8" }}>

                    <Typography aria-level={2} role="heading" style={{
                        fontSize: "16px",
                        color: "#333333",
                        letterSpacing: 0,
                        fontWeight: 400,
                        marginBottom: "13px",
                    }}>{t('notifications')}</Typography>
                    {(newNotification.length > 0 || oldNotification.length) > 0 &&
                        <Typography
                            tabIndex={0}
                            aria-label={'clear all'}
                            style={{
                                color: theme.palette.primary.main,
                                fontSize: "12px",
                                letterSpacing: 0,
                                textAlign: "right",
                                fontWeight: 700,
                                cursor: "pointer"
                            }} onClick={() => setConfirmDialog(true)}>{t('notification_clear_all')}</Typography>
                    }
                </Box>

                {(newNotification.length > 0 || (showSurvey && !isSurveyCompleted)) &&
                    <Box borderBottom="1px solid #c9c9c9" paddingBottom="12px">
                        <Typography style={{
                            marginTop: "20px", fontWeight: 700, fontSize: "12px",
                            color: "#767676",
                            letterSpacing: 0
                        }}
                        >
                            {t('new').toUpperCase()} ({(showSurvey && !isSurveyCompleted) ? newNotification.length + 1 : newNotification.length})
                        </Typography>
                        <Box >
                            {(showSurvey && !isSurveyCompleted) && <Box style={{ marginTop: "22px" }}>
                                <Box>
                                    <Typography
                                        tabIndex={0}
                                        aria-label={t('notification_survey_ready')}
                                        style={{
                                            fontSize: "13px", fontWeight: 700, color: theme.palette.primary.main,
                                            letterSpacing: 0, cursor: "pointer",
                                            wordBreak: "break-word"
                                        }}
                                        onClick={() => handleHeaderClick("survey")}
                                    >
                                        {t('notification_survey_ready')}
                                    </Typography>
                                    <Box style={{ fontSize: "12px", marginTop: "4px", lineHeight: "16px", marginBottom: "10px" }}>Please take <u style={{ cursor: "pointer" }} onClick={() => handleHeaderClick("survey")} tabIndex={0}>this survey</u>. Once completed, this notification will be removed</Box>
                                    {surveyStartDate && <Typography
                                        style={{
                                            fontSize: "12px",
                                            color: "#767676",
                                            marginBottom: "20px"
                                        }}
                                    >                    {timeSince(surveyStartDate, t)}
                                    </Typography>}
                                    {newNotification.length > 0 &&
                                        <Typography style={{ borderBottom: "1px solid #D8D8D8", width: "30px" }}></Typography>
                                    }
                                </Box>
                            </Box>
                            }
                            {newNotification.map((i: Notifications_notificationByLearnerId, item: number) => {
                                return (
                                    <>
                                        <NotificationItem key={i.id} closeHandler={closeHandler} item={i} type="new" handleDeleteNotification={handleDeleteNotification} isMobile={isMobile}/>
                                        {item !== newNotification.length - 1 &&
                                            <Typography style={{ borderBottom: "1px solid #D8D8D8", width: "30px" }}></Typography>
                                        }
                                    </>
                                )
                            })}
                        </Box>
                    </Box>
                }
                {oldNotification.length > 0 &&
                    <Box>
                        <Typography
                            style={{
                                marginTop: "20px", fontWeight: 700, fontSize: "12px",
                                color: "#767676",
                                letterSpacing: 0
                            }}
                        >
                            {t('notification_older')} ({oldNotification.length})
                        </Typography>
                        <Box >
                            {oldNotification.map((i: Notifications_notificationByLearnerId, item: number) => {
                                return (
                                    <>
                                        <NotificationItem key={i.id} closeHandler={closeHandler} item={i} type="old" handleDeleteNotification={handleDeleteNotification} isMobile={isMobile}/>
                                        {item !== oldNotification.length - 1 &&
                                            <Typography style={{ borderBottom: "1px solid #D8D8D8", width: "30px" }}></Typography>
                                        }
                                    </>)
                            })}
                        </Box>
                    </Box>
                }
            </Box>

            {showConfirmDialog && (
                <ConfirmDialog
                    open={showConfirmDialog}
                    title={t('notification_clear_confirm_title')}
                    message={t('notification_clear_confirm_message')}
                    handleConfirmed={handleClearAllnotifications}
                    handleClose={() => setConfirmDialog(false)}
                    style={{ position: "absolute", right: 0 }}
                    isNotificationDrawer={true}
                />
            )}
        </Box>
    );
};
