import { Button, IconButton, Box, Typography, useMediaQuery } from "@material-ui/core";
import { PathwayType } from "utils/types";
import contentBg from "assets/images/course.png";
import {
  ArrowIcon,
  ChannelIcon,
  CourseIcon,
  PathwayIcon,
  PlayListIcon,
  ShareIcon,
  CloseIcon,
  SaveToListIcon,
  TimeIcon,
  CertificationIcon,
  Rating,
  NewIcon,
} from "components";

import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Theme, withStyles, useTheme } from "@material-ui/core/styles";
import { formatTime } from "utils/helpers";
import sanitizeHtml from "sanitize-html";
import { ContentSource } from "utils/graphql/Global";
import linkedInIcon from "assets/icons/icon-logo-linkedIn.svg";
import opensesameIcon from "assets/icons/icon-logo-opensesame.svg";
import linkedmobileIcon from "assets/icons/icon-bug-linkedIn.svg";
import opensesamemobileIcon from "assets/icons/icon-bug-opensesame.svg";
import { useTranslation } from "react-i18next";
import { useFocusStyles } from "hooks/focusBorder";
import portalSettingsManager from "utils/portalSettingsManager";
import { Tooltip } from "components";
import { KeyboardArrowDown, KeyboardArrowUp } from "@material-ui/icons";

const htmlEnhancer = (html: string) => {
  if (!html) {
    return html;
  }
  html = html.replace("<p>", "<div>");
  html = html.replace("</p>", "</div>");
  return html;
};

type PathwayContentTileProps = {
  item?: any;
  selectTile?: any;
  type: PathwayType;
  handleShareContentTile?: any;
  setConfirmRemoveCourse?: any;
  setIsOpenPlaylist: (open: boolean) => void;
  setOpenActivity: (open: boolean) => void;
  toggleIsExpanded?: (item:any, isExpanded:boolean) => void;
  isExpanded?: boolean;
  hideSeparator?:boolean
  isChild? :boolean
};
export const PathwayContentTile: React.FC<PathwayContentTileProps> = ({
  item,
  selectTile,
  type,
  handleShareContentTile,
  setConfirmRemoveCourse,
  setIsOpenPlaylist,
  setOpenActivity,
  toggleIsExpanded,
  isExpanded,
  hideSeparator,
  isChild
}) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("xs"));
  const isXLScreen = useMediaQuery(theme.breakpoints.up("xl"));
  const isMediumScreen = useMediaQuery(theme.breakpoints.between("lg", "xl"));
  const [contentIcon, setContentIcon] = useState<any>(null);
  const [mouseEnter, setMouseEnter] = useState<boolean>(false);
  const [conIconMouseEvent, setConIconMouseEvent] = useState<boolean>(false);
  const summaryRef = React.useRef(null);
  const [showEllipsis, setShowEllipsis] = React.useState(false);
  const { t } = useTranslation();
  const summary = item.summary ?? "";
  const maxHeight = 60;
  const showTitleTooltip = (item?.name || "").length > 30;
  const handleToggle = () => {
    toggleIsExpanded(item, !isExpanded);
  };


  React.useEffect(() => {
    if (summaryRef.current !== null) {
      const checkSizeandSetEllipsis = (): any => {
        const { clientHeight, clientWidth, scrollWidth } = summaryRef.current || { clientHeight: 0, clientWidth: 0, scrollWidth: 0 };
        setShowEllipsis(scrollWidth > clientWidth);
      };
      checkSizeandSetEllipsis();
      window.addEventListener("resize", checkSizeandSetEllipsis);
      return window.removeEventListener("resize", checkSizeandSetEllipsis);
    }
  }, [setShowEllipsis, summary, summaryRef]);

  useEffect(() => {
    switch (item.contentType.toLowerCase()) {
      case PathwayType.playlist:
        setContentIcon(
          <Tooltip title="Playlist">
            <PlayListIcon width="18px" height="14px" stroke="#000000" />
          </Tooltip>
        );
        break;
      case PathwayType.channel:
        setContentIcon(
          <Tooltip title="Channel">
            <ChannelIcon width="18px" height="14px" stroke="#000000" />
          </Tooltip>
        );
        break;
      case PathwayType.pathway:
        setContentIcon(
          <Tooltip title="Pathway">
            <PathwayIcon width="18px" height="14px" stroke="#000000" />
          </Tooltip>
        );
        break;
      default:
        setContentIcon(
          <Tooltip title="Course">
            <CourseIcon width="18px" height="14px" stroke="#000000" />
          </Tooltip>
        );
        break;
    }
  }, [item.contentType]);

  const conIconMouseEnter = () => {
    setConIconMouseEvent(true);
  };

  const conIconMouseLeave = () => {
    setConIconMouseEvent(false);
  };
  const focusClass = useFocusStyles()

  const hasChildren = item.contentType.toLowerCase() === PathwayType.pathway && item.children && item.children.length > 0

  const footer = (
    <Box
      display={{ xs: "none", sm: "flex" }}
      alignItems="flex-end"
      justifyContent="space-between"
      height="34px"
    >
      {item.hasActivities  && !hasChildren && (
        <Button
          style={{
            fontSize: "12px",
            color: theme.palette.primary.main,
            textTransform: "none",
            position: "relative",
            left: "-7px",
            padding: "0px 8px",
          }}
          onClick={(e) => {
            e.preventDefault();
            setOpenActivity(true);
            selectTile(item);
          }}
          aria-label={t('aria_label_click_to_view_activities') + item.name}
          className={focusClass.focusItem}
        >
          {t('view_activities')}
        </Button>
      )}
      {portalSettingsManager.application?.features?.allowShareContent && item.contentType.toLowerCase() !== "playlist" && (
        <IconButton
          aria-label={t('aria_label_click_to_share') + item.name}
          style={{
            padding: "4px",
            marginLeft: "10px",
          }}
          onClick={(e) => {
            e.preventDefault();
            handleShareContentTile(item);
          }}
          className={`${focusClass.greyBorder} ${focusClass.focusItem}`}
        >
          <ShareIcon
            stroke="#000000"
            style={{ transform: "translate(20%, 25%)" }}
            itemName={item.name}
          />
        </IconButton>
      )}
      {portalSettingsManager.application?.features?.allowCreatePlaylist && item.contentType.toLowerCase() === "course" && (
        <IconButton
          aria-label={t('aria_label_click_to_add_course_to_playlist', { course: item.name })}
          style={{
            padding: "4px",
            marginLeft: "10px",
          }}
          onClick={(e) => {
            e.preventDefault();
            setIsOpenPlaylist(true);
            selectTile(item);
          }}
          className={`${focusClass.greyBorder} ${focusClass.focusItem}`}
        >
          <SaveToListIcon
            fill={"#000000"}
            style={{ transform: "translate(20%, 25%)" }}
            contentType={item.contentType.toLowerCase()}
          />
        </IconButton>
      )}

      <IconButton
        role="link"
        aria-label={t('aria_label_go_to_course_details', { course: item.name })}
        style={{
          padding: "4px",
          marginLeft: "10px",
          border: `1px solid ${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`
        }}
        className={`${focusClass.borderItem} ${focusClass.focusItem}`}
      >
        <ArrowIcon
          stroke={`${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`}
          style={{ transform: "translate(20%, 25%)" }}
          contentType={`${t("arrowicon_tooltip_title")} ${t(item.contentType.toLowerCase())}`}    
        />
      </IconButton>
    </Box>
  );
  const Summary = withStyles((theme: Theme) => ({
    root: {
      " & *": {
        fontSize: portalSettingsManager.fonts?.wideTile?.summaryFont?.size || "13px",
        fontFamily: portalSettingsManager.fonts?.wideTile?.summaryFont?.name || "inherit",
        color: portalSettingsManager.fonts?.wideTile?.summaryFont?.color || theme.palette.grey["500"],
        lineHeight: "19px",
        whiteSpace: "break-spaces",
      },
    },
  }))(Box);

  const mouseEvent = () => {
    setMouseEnter(!mouseEnter);
  };
  const certification = () => {
    return (
      <Tooltip
        open={mouseEnter}
        title={`${t('certified')} ${t(item.contentType.toLowerCase())}`}
      >
        <Box onMouseEnter={mouseEvent} onMouseLeave={mouseEvent}>
          <CertificationIcon
            width="22px"
            height="24px"
            stroke={theme.palette.grey["800"]}
          />
        </Box>
      </Tooltip>
    );
  };
  const externalCourseIcons = (type: ContentSource) => {
    const courseIcons = {
      [ContentSource.OPEN_SESAME]: !isMobile ? opensesameIcon : opensesamemobileIcon,
      [ContentSource.LINKED_IN]: !isMobile ? linkedInIcon : linkedmobileIcon,
      [ContentSource.KLP]: "",
      [ContentSource.NONE]: "",
    };

    const srcUrl = courseIcons[type];
    return srcUrl !== "" ? (
      <div
        style={{
          backgroundImage: `url(${srcUrl})`,
          backgroundPosition: "center right",
          backgroundRepeat: "no-repeat",
          marginRight: "10px",
          height: "20px",
          width: isMobile ? undefined : "150px"
        }}
      ></div>
    ) : (
      ""
    )
  }

  let toolTipText = t(item.contentType.toLowerCase());
  if (
    item &&
    item.contentType &&
    item.contentType.toUpperCase() == "COURSE" &&
    item.studyModes &&
    item.studyModes.length > 0
  ) {
    if (item.studyModes.length > 1) {
      toolTipText = t('hybrid');
    } else {
      if (item.studyModes.length == 1) {
        toolTipText = t(item.studyModes[0].toLowerCase());     
      }
    }
  }

  return (
    <Box style={{backgroundColor:'transparent',  borderBottom: hideSeparator? undefined: `1px solid ${theme.palette.grey["300"]}`}}>
      <Box style={{ display: "flex", alignItems: "center" , backgroundColor: hasChildren? "white": undefined}}>
        {hasChildren && (
          <IconButton
            size="small"
            onClick={handleToggle}
            style={{ height: "25px", width: "25px", color: "white", backgroundColor: "#004D40", marginRight: "25px"}}
          >
            {isExpanded ? <KeyboardArrowUp /> : <KeyboardArrowDown />}
          </IconButton>
        )}
        <Link to={`/${item.contentType}/${item.id}`} role="presentation" style={{ width: "100%" }}>
          <Box
            display="flex"
            width="100%"
            paddingBottom="20px"
            margin="24px 0 0px 0px"
            style={{ cursor: "default", borderBottom: isChild && !hideSeparator? `1px solid ${theme.palette.grey["300"]}`: undefined }}
            overflow="hidden"
          >
            <Box
              style={{
                backgroundImage: `url(${item.imageUrl || contentBg})`,
                backgroundPosition: "center center",
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                height: "100px",
                position: "relative",
                width: "120px",
                minWidth: "120px"
              }}
            >
              <Box display="flex">{item.isNew && <NewIcon />}</Box>
              {type === PathwayType.pathway && (
                <Box
                  display="flex"
                  justifyContent="center"
                  width="100%"
                  style={{ position: "absolute", bottom: 0 }}
                >
                  {item.isEnrolled && item.statusCode === "InProgress" && (
                    <Typography
                      style={{
                        background: `${portalSettingsManager.statusColors?.inprogress?.back || "#005EB8"}`,
                        width: "100%",
                        textAlign: "center",
                        fontSize: "10px",
                        fontWeight: 700,
                        color: portalSettingsManager.statusColors?.enrolled?.text || theme.palette.common.white,
                        letterSpacing: "2px",
                        padding: "5px 8px",
                      }}
                    >
                      {t('inprogress')}
                    </Typography>
                  )}
                  {item.isEnrolled && item.statusCode === "Enrolled" && (
                    <Typography
                      style={{
                        background: `${portalSettingsManager.statusColors?.enrolled?.back || "#C6007E"}`,
                        width: "100%",
                        textAlign: "center",
                        fontSize: "10px",
                        fontWeight: 700,
                        color: portalSettingsManager.statusColors?.enrolled?.text || theme.palette.common.white,
                        letterSpacing: "2px",
                        padding: "5px 8px",
                        textTransform: "uppercase",
                      }}
                    >
                      {t('enrolled')}
                    </Typography>
                  )}
                  {item.isEnrolled && item.statusCode === "Completed" && (
                    <Typography
                      style={{
                        background: `${portalSettingsManager.statusColors?.completed?.back || "#16837D" }`,
                        width: "100%",
                        textAlign: "center",
                        fontSize: "10px",
                        fontWeight: 700,
                        color: portalSettingsManager.statusColors?.completed?.text || theme.palette.common.white,
                        letterSpacing: "2px",
                        padding: "5px 8px",
                        textTransform: "uppercase",
                      }}
                    >
                      {t('completed')}
                    </Typography>
                  )}
                </Box>
              )}
            </Box>

            <Box flex="1" margin="" style={{ cursor: "pointer", margin: isMobile ? "0 10px" : "-1px 0 0 20px", overflow: "hidden" }}>
              <Box display="flex" style={{ height: "30px" }}>
                <Tooltip
                  open={conIconMouseEvent}
                  title={
                    item.contentType.toUpperCase() == "COURSE"
                      ? t('course') + "-" + toolTipText
                      : toolTipText
                  }
                >
                  <div onMouseEnter={conIconMouseEnter} onMouseLeave={conIconMouseLeave}>
                    {contentIcon}
                  </div>
                </Tooltip>
                <Tooltip
                  title={
                    item.contentType.toUpperCase() == "COURSE"
                      ? t('course') + "-" + toolTipText
                      : toolTipText
                  }
                >
                  <Typography
                    style={{
                      fontSize: "10px",
                      color: theme.palette.grey["800"],
                      letterSpacing: "2px",
                      textTransform: "uppercase",
                      fontWeight: 700,
                      marginLeft: "5px",
                    }}
                  >
                    {item.contentType.toUpperCase() === "COURSE" ? toolTipText : toolTipText}
                  </Typography>
                </Tooltip>
                <Typography
                  style={{
                    flex: 1,
                    marginLeft: "9px",
                    fontStyle: "italic",
                    fontWeight: 400,
                    fontSize: "12px",
                    marginTop: "-2px",
                    textTransform: "lowercase",
                  }}
                >
                  {item?.statusCode?.toUpperCase() === "NOTENROLLED" ? "" : t(item.statusCode?.toLowerCase())}{" "}
                </Typography>
                {/* {{item?.statusDate}} */}
                {item?.source && externalCourseIcons(item?.source)}
                {item?.hasCertificate && certification()}
                {type === PathwayType.playlist && (
                  <IconButton
                    role="button"
                    aria-label={`${t('aria_label_click_to_delete')} ${t(item.name)} `}
                    style={{
                      border: `1px solid ${theme.palette.grey["A100"]}`,
                      padding: "2px",
                      marginLeft: "10px",
                      height: "20px",
                      width: "20px",
                      marginTop: "1px"
                    }}
                    onClick={(e) => {
                      e.preventDefault();
                      setConfirmRemoveCourse(true);
                      selectTile(item);
                    }}
                    className={focusClass.focusItem}
                  >
                    <CloseIcon
                      fill="#000000"
                      stroke="#000000"
                      style={{ transform: "translate(20%, 25%)", width: "1rem", height: "1rem" }}
                    />
                  </IconButton>
                )}
              </Box>
              <span style={{display: "flex", width:"80%"}}>
                <Box
                  fontSize={portalSettingsManager.fonts?.wideTile?.titleFont?.size || "15px"}
                  style={{
                    marginTop: "0px",
                    fontFamily: portalSettingsManager.fonts?.wideTile?.titleFont?.name || "inherit",
                    fontWeight: 700,
                    color: portalSettingsManager.fonts?.wideTile?.titleFont?.color || theme.palette.grey["800"],
                    lineHeight: "21px",
                    width: "auto",
                    overflow: "hidden",
                    whiteSpace: "nowrap",
                    textOverflow: "ellipsis"
                  }}
                >
                  {item.name}
                </Box>
                {showTitleTooltip && (
                  <Tooltip title={item.name || ""} tooltipStyle={{ maxWidth: "250px" }}>
                    <span
                      style={{
                        display: "inline-block",
                        marginTop: "5px",
                        marginLeft: "-25px",
                        minWidth: "30px",
                        minHeight: "10px",
                        cursor: "pointer",
                        color: "transparent",
                        alignSelf: "flex-end",
                        backgroundColor: "transparent",
                      }}
                    >
                      {"..."}
                    </span>
                  </Tooltip>
                )}
              </span>
              <Summary
                style={{
                  margin: "5px 0px 0px 0px",
                  maxHeight: "20px",
                  overflow: "hidden",
                  position: "relative",
                  whiteSpace: "initial",
                }}
              >
                {!isMobile && (
                  <>
                    <Box style={{ display: "flex", height: "18px" }}>
                      <div
                        ref={summaryRef}
                        style={{
                          maxWidth: `${isXLScreen ? "850px" : isMediumScreen ? "850px" : "calc(100vw - 570px)"}`,
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis"
                        }}
                        dangerouslySetInnerHTML={{
                          __html: sanitizeHtml(htmlEnhancer(summary), {
                            allowedTags: false,
                            allowedAttributes: false,
                          }),
                        }}
                      />
                      {/* FYI: Aligning the tooltip with the ellipsis dots shown by the html */}
                      {/* // Questions: Are we using this? */}
                      {showEllipsis && (
                        <Tooltip title={summary}>
                          <div
                            style={{
                              background: "#fff",
                              cursor: "pointer",
                              marginLeft: "-25px",
                              width: "25px",
                              height:"15px",
                              backgroundColor: "transparent",
                            }}
                          >
                            {/* {"...   "} */}
                          </div>
                        </Tooltip>
                      )}
                    </Box>
                  </>
                )}

                {/* {!isMobile && <RenderHTML content={item.summary ? item.summary : ""} />} */}
              </Summary>
              <Box
                display="flex"
                alignItems="flex-end"
                flex="1"
                marginTop={type !== PathwayType.playlist ? "-6px" : "0px"}
              >
                {!!item.durationDisplay && (
                  <Box
                    style={{
                      display:"flex",
                      alignItems: "center",
                      marginRight: item.durationDisplay ? "20px" : "0px",
                    }}
                  >
                    <>
                      <TimeIcon width="15px" height="15px" stroke={theme.palette.grey["800"]} />
                      <Typography
                        style={{
                          fontSize: "12px",
                          color: theme.palette.grey["800"],
                          letterSpacing: 0,
                          fontWeight: 400,
                          float: "right",
                          marginLeft: "5px",
                        }}
                      >
                        {formatTime(item.durationDisplay)}
                      </Typography>
                    </>
                  </Box>
                )}
                <Box display={{ xs: "none", sm: "flex" }} style={{ marginTop: "0px", height: "16px" }}>
                  {type !== PathwayType.playlist && (
                    <Rating
                      score={item.rating || 0}
                      numberOfReviews={item.numberOfPeopleWhoRated || 0}
                      display={true}
                    />
                  )}
                </Box>
                <Box style={{ marginLeft: "auto" }}> {footer}</Box>
              </Box>
            </Box>
          </Box>
        </Link>
      </Box>

      {hasChildren && isExpanded && (
        <Box style={{paddingLeft:25, marginTop:-110, paddingBottom:75}}>
          <ul>
            {item.children.map((child:any,index:number) => (
              <li style={{ listStyle: "none" }} key={index}>
                <Box
                  style={{
                    border: "1px solid gray",
                    borderTopWidth: 0,
                    borderRightWidth: 0,
                    height: 150,
                  }}
                >
                  <Box
                    style={{
                      top: 80,
                      left: 20,
                      backgroundColor: "white",
                      width: "calc(100% - 40px)",
                      paddingTop:80,
                      marginLeft:40,
                    }}
                  >
                    <PathwayContentTile
                      item={child}
                      type={type}
                      setIsOpenPlaylist={setIsOpenPlaylist}
                      setOpenActivity={setOpenActivity}
                      selectTile={selectTile}
                      handleShareContentTile={handleShareContentTile}
                      hideSeparator={index==item.children.length-1}
                      isChild={true}
                    ></PathwayContentTile>
                  </Box>
                </Box>
              </li>
            ))}
          </ul>
        </Box>
      )}
    </Box>
  );
};
