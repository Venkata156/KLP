import React from "react";
import { Button as MuiButton } from "@material-ui/core";
import { Theme, withStyles, useTheme } from "@material-ui/core/styles";
import { useFocusStyles } from '../../hooks/focusBorder';
import portalSettingsManager from "utils/portalSettingsManager";

export interface ButtonProps {
  type?: "dialog-primary" | "dialog-alt" | "course-primary" | "dialog-grey" | "dialog-black" | "dialog-alt-contrast";
  disabled?: boolean;
  onClick?: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  autoFocus?: boolean;
  style?: React.CSSProperties;
  className?: string;
}

const DialogButton = withStyles((theme: Theme) => ({
  root: {
    borderRadius: 0,
    color: portalSettingsManager.buttonColors?.themed?.active?.text || theme.palette.primary.main,
    backgroundColor: portalSettingsManager.buttonColors?.themed?.active?.back,
    "&:focus": { border: "2px solid #000000" }
  },
  label: {
    fontSize: 11,
    fontWeight: 700,
  },
  outlined: {
    border: `1px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
  },
  disabled: {
    color: theme.palette.grey["500"],
  },
}))(MuiButton);

const PrimaryDialogButton = withStyles((theme: Theme) => ({
  root: {
    "&:hover": {
      border: `2px solid ${portalSettingsManager.buttonColors?.themed?.hover?.border || theme.palette.primary.main} !important`,
    },
  },
}))(DialogButton);

export const Action: React.FC<ButtonProps> = ({ type, style = {}, ...props }): JSX.Element => {
  const theme = useTheme();
  const focusClass = useFocusStyles();
  switch (type) {
    case "dialog-primary":
      return <PrimaryDialogButton variant="outlined" {...props} style={style}></PrimaryDialogButton>;
    case "dialog-alt":
      return <DialogButton className={focusClass.secondaryHover} style={{ backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back, color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["500"] }} {...props}></DialogButton>;
    case "dialog-alt-contrast":
      return <DialogButton className={focusClass.secondaryHover} style={{ backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back, color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["A700"] }} {...props}></DialogButton>;
    case "dialog-black":
      return (
        <DialogButton
          style={{
            backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back,
            color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
          }}
          variant="outlined"
          className={`${focusClass.greyBorder} ${focusClass.secondaryHover}`}
          {...props}
        ></DialogButton>
      );
    case "dialog-grey":
      return (
        <DialogButton
          style={{
            backgroundColor: portalSettingsManager.buttonColors?.normal?.active?.back,
            color: portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
          }}
          className={`${focusClass.border800} ${focusClass.secondaryHover}`}
          variant="outlined"
          {...props}
        ></DialogButton>
      );
    default:
      return <MuiButton {...props}></MuiButton>;
  }
};
