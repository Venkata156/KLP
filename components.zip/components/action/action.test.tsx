import { render, screen, userEvent, theme } from 'test/index';
import { Action } from './action';

describe('Action Component', () => {
    describe('when redered with default props', () => {
        it('renders correctly without any errors', () => {
            const { container } = render(<Action />);
            expect(container).not.toBeNull();
        });
        it('should call the callback function, if passed', () => {
            const mockCallback = jest.fn();
            render(<Action onClick={mockCallback} />);
            const buttonElement = screen.getByRole('button');
            userEvent.click(buttonElement);
            expect(mockCallback).toHaveBeenCalled();
        });
    });
    describe('when redered with type "dialog-alt"', () => {
        it('renders correctly without any errors, should have the grey[500] style', () => {
            render(<Action type="dialog-alt" />);
            const buttonElement = screen.getByRole('button');
            // anotherway of getting the button element styles
            // const buttonElementStyle = window.getComputedStyle(buttonElement);
            expect(buttonElement).toHaveStyle({
                color: theme.palette.grey['500'],
            });
        });
    });
    describe('when redered with type "dialog-grey"', () => {
        it('renders correctly without any errors, should have the grey[800] style', () => {
            render(<Action type="dialog-grey" />);
            const buttonElement = screen.getByRole('button');
            expect(buttonElement).toHaveStyle({
                color: theme.palette.grey['800'],
            })
        });
    });
    describe('when redered with type "dialog-primary"', () => {
        it('should have the primary outlined class', () => {
            render(<Action type="dialog-primary" />);
            const buttonElement = screen.getByRole('button');
            expect(buttonElement.classList.contains('MuiButton-outlinedPrimary')).toBeTruthy();
        });
    });
});