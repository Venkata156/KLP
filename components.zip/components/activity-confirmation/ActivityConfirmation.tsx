/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box, Typography, useTheme, Button, makeStyles, Theme } from "@material-ui/core";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";
import { CheckmarkCircleIcon } from "components";
import { CSSProperties } from "@material-ui/core/styles/withStyles";
import { useFocusStyles } from "hooks/focusBorder";

const style: CSSProperties = {
    paddingTop: "16px",
    paddingBottom: "16px",
    borderRadius: "0px",
    margin: "20px",
    fontSize: "11px",
    fontWeight: "bold",
    minWidth: '128px',
    textTransform: "uppercase",
};

const useButtonStyles = makeStyles((theme: Theme) => ({
    backButton: {
        ...style,
        color: 'gray',
        borderColor: 'gray'
    },
    landingButton: {
        ...style,
        color: (props: any) => props?.portalSettingsManager?.application?.common?.themeColor || `${theme.palette.primary.main}`,
        borderColor: (props: any) => props?.portalSettingsManager?.application?.common?.themeColor || `${theme.palette.primary.main}`,
    }
}));

export const ActivityConfirmation = ({ programName, activityName, totalLearnersSubmitted, navigateToStart, navigateToLanding }: any): JSX.Element => {
    const { t } = useTranslation();
    const theme = useTheme();
    const focusClass = useFocusStyles();
    const buttonStyles = useButtonStyles({
        portalSettingsManager,
    });
    return (
        <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center" flexGrow={1}>
            <CheckmarkCircleIcon style={{ fontSize: `80px`, marginBottom: `20px` }} />
            <Typography style={{
                "color": theme.palette.grey['800'],
                "fontSize": "22px",
            }}>
                {t('activity_successful_confirmation')}
            </Typography>
            <Typography style={{
                "color": theme.palette.grey['800'],
                "fontSize": "12px",
                "fontWeight": "bold"
            }}>
                {programName}
            </Typography>
            <br />
            <br />
            <Typography style={{
                "color": `${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`,
                "fontSize": "16px",
                "fontWeight": "bold"
            }}>
                {activityName}
            </Typography>
            <Typography style={{
                "color": `${portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main}`,
                "fontSize": "14px",
                "lineHeight": "16px"
            }}>
                {t('learner_activities_submitted', { count: totalLearnersSubmitted })}
            </Typography>
            <br />
            <br />
            <Typography style={{
                "color": theme.palette.grey['800'],
                "fontSize": "12px"
            }}>
                {t('attendance_confirmation_thank_you')}
            </Typography>
            <br />
            <Box display={'flex'} justifyContent='center'>
                <Button variant="outlined"
                    role="link"
                    onClick={navigateToStart}
                    className={`${buttonStyles.backButton} ${focusClass.focusItem}`}
                >
                    {t('return_to_activities')}
                </Button>
                <Button variant="outlined"
                    role="link"
                    onClick={navigateToLanding}
                    className={`${buttonStyles.landingButton} ${focusClass.focusItem}`}
                >
                    {t('return_to_my_landing')}
                </Button>
            </Box>
        </Box>
    );
};
