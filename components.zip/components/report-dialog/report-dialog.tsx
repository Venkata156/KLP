import { useEffect } from "react";
import { useQuery } from "@apollo/client";
import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from 'powerbi-client';
import { useAppDispatch } from "store";
import {
    IconButton,
    Dialog as MuiDialog
} from "@material-ui/core";
import { Theme, makeStyles } from "@material-ui/core/styles";
import CloseIcon from "@material-ui/icons/Close";

import * as EmbedParams from "utils/graphql/EmbedParams";
import {
    DialogContent,
    DialogTitle
} from "components";
import { GET_EMBEDDED_PBI_PARAMS } from "utils/queries";
import { useTranslation } from "react-i18next";

const useStyles = makeStyles((theme: Theme) => (
    {
        embeddedReport: {
            width: "100%",
            height: "100%",
            padding: `${theme.spacing()}px`,
            '& iframe': {
                border: "none",
            }
        },
        DialogContainer: {
            margin: `${theme.spacing(2)}px`,
        }
    }
));

type ReportDialogProps = {
    open: boolean;
    handleClose: () => void;
};
export const ReportDialog: React.FC<ReportDialogProps> = ({
    open,
    handleClose,
}) => {
    const classes = useStyles();
    const { t } = useTranslation();
    const dispatch = useAppDispatch();
    const {
        loading,
        data: reportParams
    } = useQuery<EmbedParams.EmbedParams>(GET_EMBEDDED_PBI_PARAMS);
    useEffect(() => {
        dispatch({ type: "loader/showandhide", payload: { show: loading, message: t('report_loading') } })
    }, [loading, dispatch]);
    return (
        <MuiDialog open={open} disableBackdropClick={true} fullScreen fullWidth className={classes.DialogContainer}>
            <DialogTitle>
                <IconButton aria-label={t('aria_label_close_report_dialog')} onClick={handleClose}>
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent
                style={{ display: "flex", flexDirection: "column", overflowY: "visible", height: "100%" }}
            >
                {reportParams?.embedParams?.embedToken && <PowerBIEmbed
                    embedConfig={{
                        type: 'report',   // Supported types: report, dashboard, tile, visual and qna
                        id: reportParams.embedParams.reportId,
                        embedUrl: reportParams.embedParams.embedUrl || "",
                        accessToken: reportParams.embedParams.embedToken,
                        tokenType: models.TokenType.Embed,
                        settings: {
                            panes: {
                                filters: {
                                    expanded: false,
                                    visible: false
                                }
                            },
                            //background: models.BackgroundType.Transparent,
                        }
                    }}
                    eventHandlers={
                        new Map([
                            ['loaded', function () { console.log('Report loaded'); }],
                            ['rendered', function () { console.log('Report rendered'); }],
                            ['error', function (event: any) { console.log(event.detail); }]
                        ])
                    }
                    cssClassName={classes.embeddedReport}
                />}
            </DialogContent>
        </MuiDialog>
    );
};