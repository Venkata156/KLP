import { useLazyQuery } from "@apollo/client";
import { Box, Button, Typography, useMediaQuery, IconButton } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import { Close } from "@material-ui/icons";
import { Activity, Loader, ActivityWarning, Tooltip } from "components";
import { Link } from "react-router-dom";
import * as ActivityTypes from "utils/graphql/Activities";
import * as CanLaunchCourseByPathWays from "utils/graphql/CanLaunchCourseBySequencialPathway";
import { GET_ACTIVITIES, CAN_LAUNCH_COURSE_BY_PATHWAY } from "utils/queries";
import React, { useEffect, useState } from "react";
import { useFocusStyles } from "hooks/focusBorder";
import portalSettingsManager from "utils/portalSettingsManager";
import { useTranslation } from "react-i18next";
import { ActivityType } from "utils/graphql/Global";

export const ActivityDrawer = ({
  course,
  closeHandler,
  handleEnroll,
  handleContentRefresh,
  handleOpenWorkshop,
}: {
  course?: any;
  closeHandler?: any;
  handleEnroll?: any;
  handleContentRefresh?: any;
  handleOpenWorkshop?: any;
}): JSX.Element => {
  const { t } = useTranslation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const [showAction, setShowAction] = useState<boolean>(false);
  const [showTitleTooltip, setShowTitleTooltip] = useState(false);
  const titleRef = React.useRef(null);

  useEffect(() => {
    if (titleRef.current !== null) {
      const windowResizeCallback = (): any => {
        const { clientWidth, scrollWidth} = titleRef.current || {
          clientWidth: 0,
          scrollWidth: 0,
        };
        setShowTitleTooltip(scrollWidth > clientWidth);
      };
      windowResizeCallback();
      window.addEventListener("resize", windowResizeCallback);
      return () => {
        window.removeEventListener("resize", windowResizeCallback);
      };
    }
  }, [course.name, titleRef]);

  const [fetchcanLaunchCourseByPathWay, { data: canLaunchCourseByPathWay, loading: canLaunchCourseByPathWayLoading }] = useLazyQuery<CanLaunchCourseByPathWays.CanLaunchCourseBySequencialPathway>(CAN_LAUNCH_COURSE_BY_PATHWAY, {
    variables: {
      courseId: String(course.id),
    },
    onCompleted: (data) => {
      if (data && data.canLaunchCourseBySequencialPathway && course?.isEnrolled) {
        setShowAction(data.canLaunchCourseBySequencialPathway.canLaunch);
      }
    },
  });
  const [fetchActivities, { data, refetch: activitiesRefetch, loading: loadingAcitivities }] = useLazyQuery<ActivityTypes.Activities>(GET_ACTIVITIES, {
    variables: {
      courseId: String(course.id),
    },
  });
  const [loader, setLoader] = useState(false);
  const handleActivityRefresh = () => {
    setLoader(true);
    setTimeout(() => {
      try {
        activitiesRefetch && activitiesRefetch();
        handleContentRefresh();
        setLoader(false);
      } catch (err) {
        setLoader(false);
        console.log("Error while refreshing", err);
      }
    }, 5000);
  };
  useEffect(() => {
    if (course?.isEnrolled) {
      if (course?.id) {
        fetchcanLaunchCourseByPathWay();
      } else {
        setShowAction(true);
      }
    }
    fetchActivities();
  }, [course?.id, course?.isEnrolled, fetchcanLaunchCourseByPathWay, fetchActivities]);
  const focusClass = useFocusStyles()

  const handlePathwayClick = () => {
    if (closeHandler) {
      closeHandler();
    }
  };
  let showHeader: boolean = true; 
  let prevActivityType: ActivityType = ActivityType.DIVIDER;
  let isFirstActivity: boolean | null = null; 
  return (
    <>
      <Loader isDisplay={loader || canLaunchCourseByPathWayLoading || loadingAcitivities} message={t('refreshing_content')} />
      <Box p={isMobile ? "" : "56px 30px"} maxWidth={730} style={{ position: "relative" }}  role="dialog"  aria-labelledby="activity_drawer_label" aria-modal="true">
        <IconButton  aria-label={t('close_view_activities')} onClick={closeHandler} style={{
          position: "absolute",
          top: "6px",
          right: "14px",
          cursor: "pointer",
        }}
          className={focusClass.focusItem}
          tabIndex={0}
          role='button'>
          <Close
            fontSize="small"
          />         
        </IconButton>
        <Box
          paddingTop={isMobile ? "50px" : "0px"}
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          marginBottom={canLaunchCourseByPathWay?.canLaunchCourseBySequencialPathway?.blockingPathways?.length || 0 > 0 ? `10px` : `39px`}
        >
          <Box width={isMobile ? undefined : "600px"}>
            <Typography
              style={{
                fontSize: "14px",
                lineHeight: "16px",
                marginBottom: "2px",
                color: theme.palette.grey["500"],
              }}
              component="h2" id="activity_drawer_label"
            >
              {t('activities')}
            </Typography>
            <Box display={"flex"} zIndex={10000}>
              <Typography
                style={{
                  fontSize: "18px",
                  fontWeight: "bold",
                  lineHeight: "21px",
                  width: isMobile ? "200px" : "575px",
                  whiteSpace: "nowrap",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  paddingRight: "10px",
                }}
                component="h2"
                ref={titleRef}
              >
                {course.name}
              </Typography>
              {showTitleTooltip && (
                <Tooltip
                  position="bottom"
                  zIndex={10000}
                  title={course.name}
                  tooltipStyle={{ zIndex: 10000 }}
                >
                  <div
                    style={{
                      marginLeft: "-50px",
                      cursor: "pointer",
                      minWidth: "50px",
                      minHeight: "20px",
                      backgroundColor: "transparent",
                    }}
                  ></div>
                </Tooltip>
              )}
            </Box>
          </Box>
          <Link to={`/course/${course.id}`} onClick={closeHandler}>
            <Button
              style={{
                fontSize: "10px",
                fontWeight: "bold",
                lineHeight: "11px",
                border: `1px solid ${portalSettingsManager.buttonColors?.themed?.active?.border || theme.palette.primary.main}`,
                borderRadius: 0,
                color: portalSettingsManager.buttonColors?.themed?.active?.text ||  theme.palette.primary.main,
                backgroundColor: portalSettingsManager.buttonColors?.themed?.active?.back,
                height: "38px",
                width: "125px",
              }}
              className={`${focusClass.primaryHover}`} 
              role='presentation'     
              tabIndex={'-1'}
            >
              {t('course_details')}
            </Button>
          </Link>
        </Box>
        {canLaunchCourseByPathWay && <ActivityWarning data={canLaunchCourseByPathWay} onClick={handlePathwayClick} />}
        {!!data &&
          (data.activities || []).map((activity, index) => {
            showHeader = prevActivityType === ActivityType.DIVIDER && activity.type !== ActivityType.DIVIDER; 
            prevActivityType = activity.type;
            isFirstActivity = (activity.type !== ActivityType.DIVIDER && isFirstActivity === null) ? true: isFirstActivity === null? null: false;
            return (
              <>
                {!!activity && (
                  <Activity
                    key={index}
                    courseID={String(course.id)}
                    activity={activity}
                    source={course.source}
                    showHeader={showHeader}
                    isFirstActivity={isFirstActivity}
                    showAction={showAction}
                    showSession={false}
                    handleEnroll={handleEnroll}
                    handleActivityRefresh={handleActivityRefresh}
                    handleOpenWorkshop={handleOpenWorkshop}
                  />
                )}
              </>
            );
          })}
      </Box>
    </>
  );
};
