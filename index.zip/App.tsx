import { useLazyQuery, useMutation, useQuery } from "@apollo/client";
import { Box, Drawer, Snackbar } from "@material-ui/core";
import {
  Alert,
  Chatbot,
  Footer,
  Header,
  Layout,
  Loader,
  NotificationDrawer,
  ReportDialog,
  SessionTimeoutDialog,
  SurveyConfirmation,
  SurveyDialog,
} from "components";
import { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { Prompt, useLocation } from "react-router-dom";
import { RootState, useAppDispatch } from "store";
import * as UserContextTypes from "utils/graphql/UserContext";
import * as PortalDisplayTypes from "utils/graphql/PortalDisplayInfo";
import * as LocalizationTypes from "utils/graphql/Localization";
import { GET_NOTIFICATIONS, GET_NOTIFICATIONS_METRICS, GET_USER_CONTEXT, SKIP_SURVEY, PORTAL_DISPLAY_INFO, LOCALIZATION } from "utils/queries";
import "@progress/kendo-theme-material/dist/all.css";
import "./App.css";
import routes from "./routes";
import { HEADER_CLICK_TYPES, KLP_SERVICE_NOW_WINDOW_NAME } from "utils/constants";
import { tenantSettings } from "utils/authentication/tenantSettings";
import SessionManager from "utils/sessionManager";
import { Notifications } from "utils/graphql/Notifications";
import i18n, { local_keys, TRANSLATION_STORAGE_KEY } from "utils/i18n";
import { useTranslation } from "react-i18next";
import { pick } from 'lodash';
import portalSettingsManager from "utils/portalSettingsManager";
import { logger } from "utils/logger";
import { NotificationMetrics } from "utils/graphql/NotificationMetrics";
import { openContactUs } from "utils/helpers";
import { openUrlUtil } from "hooks/open-url";

interface AppProps {
  onSilentRenew: () => void,
  onLogout: () => void,
  isAuthenticated: boolean
}

function App({ onSilentRenew, isAuthenticated, onLogout }: AppProps): JSX.Element {
  const dispatch = useAppDispatch();
  const location = useLocation();
  const { t } = useTranslation();
  const [openSurvey, setOpenSurvey] = useState<boolean>(false);
  const [isSurveyCompleted, setIsSurveyCompleted] = useState<boolean>(false);
  const [surveyConfirmation, setSuveyConfirmation] = useState<boolean>(false);
  const [showReportDialog, setShowReportDialog] = useState<boolean>(false);
  const navigationBlocked = useSelector((state: RootState) => state.core.navigationBlocked);
  const courseInProgress = useSelector((state: RootState) => state.core.courseInProgress);
  const [isClearNotification, setIsClearNotification] = useState<boolean>(false);
  const [isTranslationsLoaded, setIsTranslationsLoaded] = useState<boolean>(false);
  const [isPortalSettignsLoaded, setIsPortalSettignsLoaded] = useState<boolean>(false);
  const [totalNotificationsCount, setTotalNotificationsCount] = useState<number>(0);
  const [totalUnreadNotificationsCount, setTotalUnreadNotificationsCount] = useState<number>(0);

  const navigationBlockMessage = useSelector(
    (state: RootState) => state.core.navigationBlockMessage
  );
  const isLoading = useSelector((state: RootState) => state.core.loader);

  const isContentPage = location.pathname.toLowerCase().indexOf('/player') === -1;

  const { data } = useQuery<UserContextTypes.UserContext>(GET_USER_CONTEXT, {
    skip: !isAuthenticated || !isContentPage,
  });

  useQuery<PortalDisplayTypes.PortalDisplayInfo>(PORTAL_DISPLAY_INFO, {
    skip: !isAuthenticated || !isContentPage,
    onCompleted: (data) => {
      if (data && data.portalDisplayInformation) {
        portalSettingsManager.Initialize(data.portalDisplayInformation || []);
        setIsPortalSettignsLoaded(true);
      }
    },
    onError: (error) => {
      logger.error(error?.message);
      setIsPortalSettignsLoaded(true);
    },
  });

  useQuery<LocalizationTypes.Localization>(LOCALIZATION, {
    skip: !isAuthenticated || !isContentPage,
    onCompleted: (data) => {
      const translations: { [key: string]: string } = {};
      data?.localizationData?.forEach((localization: LocalizationTypes.Localization_localizationData | null) => {
        if (localization?.code && localization?.localText) {
          translations[localization.code] = localization.localText;
        } else {
          logger.error(`Localization data is not in the correct format: ${JSON.stringify(localization)}`);
        }
      });
      i18n.addResourceBundle("en", "translation", translations, true, true);
      setIsTranslationsLoaded(true);
      sessionStorage.setItem(TRANSLATION_STORAGE_KEY, JSON.stringify(pick(translations, local_keys)));
    },
    onError: (error) => {
      logger.error(`get translations failed ${error}`);
      setIsTranslationsLoaded(true);
    }
  });

  const [skipSurvey] = useMutation(SKIP_SURVEY);
  const toasterAlert = useSelector((state: RootState) => state.core.toasterAlert);
  const [openNotification, setOpenNotification] = useState<boolean>(false);

  const handleSkipSurvey = () => {
    skipSurvey({ variables: { surveyId: data?.userContext?.surveyId } });
  };
  const [loadNotifications, { data: notificationResult }] = useLazyQuery<Notifications>(
    GET_NOTIFICATIONS
  );
  const [loadNotificationMetrics, { data: notificationMetrics }] = useLazyQuery<NotificationMetrics>(
    GET_NOTIFICATIONS_METRICS
  );

  const handleRefetchNotifications = () => {
    loadNotifications()
    loadNotificationMetrics()
  }
  useEffect(() => {
    if (isAuthenticated && isContentPage) {
      if (data) {
        loadNotifications()
        loadNotificationMetrics()
      }
      dispatch({ type: "userContext/load", payload: data });
      logger.setAuthenticatedUserContext(data?.userContext?.learnerEmail, data?.userContext?.learnerId, true);
      if (data?.userContext?.isSurveySkipped === false && data?.userContext?.showSurvey === true) {
        setSuveyConfirmation(true);
      }
    }
  }, [dispatch, data, isAuthenticated]);

  useEffect(() => {
    if (courseInProgress) {
      SessionManager.renew();
      SessionManager.enableAutoRenewal();
    } else {
      SessionManager.disableAutoRenewal();
    }
  }, [courseInProgress]);

  const hideToast = () => {
    setTimeout(function () {
      dispatch({ type: "alert/hide" });
    }, 5000);
  };
  toasterAlert.type == "success" ? hideToast() : "";
  const handleHeaderClick = (type: string) => {
    switch (type) {
      case HEADER_CLICK_TYPES.SURVEY:
        setOpenSurvey(true);
        break;
      case HEADER_CLICK_TYPES.REPORT:
        setShowReportDialog(true);
        break;
      case HEADER_CLICK_TYPES.LOGOUT:
        handleLogout();
        break;
      case HEADER_CLICK_TYPES.SERVICENOW:
        handleServiceNow();
        break;
      case HEADER_CLICK_TYPES.CONTACTUS:
        openContactUs();
        break;
      default:
        break;
    }
  };

  const { openUrl } = openUrlUtil();

  function handleServiceNow() {
    openUrl(tenantSettings.customConfig.serviceNowUrl, KLP_SERVICE_NOW_WINDOW_NAME);
  }

  function closeSessionTimeoutDialog() {
    setIsTimeout(false);
    handleLogout();
  }

  async function resetTimer() {
    setIsTimeout(false);
    SessionManager.tracker();
    SessionManager.startInterval();
    onSilentRenew();
  }

  function handleLogout() {
    sessionStorage.removeItem("_expiredTime");
    sessionStorage.removeItem("relatedItemClick");
    sessionStorage.removeItem("breadCrumbs");
    localStorage.clear();
    onLogout();
  }

  const [isTimeout, setIsTimeout] = useState(false);
  const alertElement = useRef<HTMLElement>(null)
  useEffect(() => {
    sessionStorage.removeItem("_expiredTime");
    SessionManager.initialize({
      timeout: tenantSettings?.customConfig?.timeout || 1800, //open Idle timer modal after 30 Mints
      onTimeout: () => {
        setIsTimeout(true);
      },
      onExpired: () => {
        //do something if expired on load
        logger.log("onExpired ");
      },
    });
    return () => {
      SessionManager.cleanUp();
    };
  }, []);

  useEffect(() => {
    console.log("silentRenew UseEffect");
    SessionManager.onAutoRenew = onSilentRenew;
  }, [onSilentRenew]);

  const handleShowSurvey = () => {
    setSuveyConfirmation(false);
    setOpenSurvey(true);
  };

  const handleSurveyCompleted = () => {
    setIsSurveyCompleted(true)
    if (!notificationResult?.notificationByLearnerId?.length || notificationResult?.notificationByLearnerId?.length === 0) {
      setOpenNotification(false)
    }
  }

  const showHeaderFooter = () => {
    return location.pathname !== "/logout"
      && isContentPage;
  }

  useEffect(() => {
    const surveyCount: number = (data?.userContext?.showSurvey && !isSurveyCompleted) ? 1 : 0;
    const totalNotificationCount: number = notificationMetrics?.notificationsMetrics?.totalNotificationsCount || 0;
    setTotalNotificationsCount(surveyCount + totalNotificationCount);
    const unreadNotificationsCount: number = notificationMetrics?.notificationsMetrics?.unreadNotificationsCount || 0;
    setTotalUnreadNotificationsCount(surveyCount + unreadNotificationsCount);
  }, [notificationMetrics]);

  return (
    ((!isTranslationsLoaded || !isPortalSettignsLoaded) && isContentPage) ?
      <Loader isDisplay={!isTranslationsLoaded || !isPortalSettignsLoaded}></Loader>
      :
      <>
        <Layout
          header={
            showHeaderFooter() ? <Header
              userContext={data?.userContext}
              showSearch={portalSettingsManager?.application?.features?.allowContentSearch}
              onClick={handleHeaderClick}
              isSurveyCompleted={isSurveyCompleted}
              setOpenNotification={setOpenNotification}
              notificationCount={totalNotificationsCount}
              isClearNotification={isClearNotification}
              newNotificationCount={totalUnreadNotificationsCount}
            /> : ""
          }
          footer={showHeaderFooter() ? <Footer /> : ""}
          main={routes}
        />
        <Loader type="component" isDisplay={isLoading.show} message={isLoading.message}></Loader>
        {surveyConfirmation && isContentPage && (
          <SurveyConfirmation
            open={surveyConfirmation}
            handleClose={() => setSuveyConfirmation(false)}
            handleShowSurvey={handleShowSurvey}
            handleSkipSurvey={handleSkipSurvey}
            userDisplayName={data?.userContext?.userDisplayName ?? ""}
          />
        )}
        {data?.userContext?.showSurvey && openSurvey && isContentPage && (
          <SurveyDialog
            open={openSurvey}
            handleClose={() => setOpenSurvey(false)}
            onSubmit={() => handleSurveyCompleted()}
            handleSkipSurvey={handleSkipSurvey}
          />
        )}
        <Drawer open={openNotification && isContentPage} anchor="right" onClose={() => { setOpenNotification(false) }}>
          <NotificationDrawer notificationResult={notificationResult}
            handleRefetchNotifications={handleRefetchNotifications}
            closeHandler={() => setOpenNotification(false)}
            setIsClearNotification={setIsClearNotification}
            showSurvey={data?.userContext?.showSurvey}
            surveyStartDate={data?.userContext?.surveyStartDate}
            isSurveyCompleted={isSurveyCompleted} handleHeaderClick={handleHeaderClick} />
        </Drawer>
        <SessionTimeoutDialog
          open={isTimeout && isContentPage}
          handleClose={() => closeSessionTimeoutDialog()}
          reset={() => resetTimer()}
        />
        <Prompt
          when={navigationBlocked}
          message={navigationBlockMessage || t('Are_you_sure_want_to_leave')}
        />
        <Snackbar
          open={toasterAlert.show}
          anchorOrigin={{ vertical: "top", horizontal: "right" }}
          style={{ boxShadow: "0 14px 20px 0 rgba(0,0,0,0.30)" }}
          autoHideDuration={10000}
          ref={alertElement}
          role='alert' aria-modal='true'
          aria-labelledby="msg" aria-describedby="msg"
          tabIndex={-1}
        >
          <Box width={{ xs: "100%", sm: "auto" }}>
            <Alert
              type={toasterAlert.type}
              title={toasterAlert.title}
              message={toasterAlert.message}
              onClose={() => dispatch({ type: "alert/hide" })}
            />
          </Box>
        </Snackbar>
        {portalSettingsManager?.application?.features?.allowChat && (
          <Chatbot />
        )}
        {showReportDialog && <ReportDialog
          open={true}
          handleClose={() => setShowReportDialog(false)}
        />}
      </>
  );
}

export default App;