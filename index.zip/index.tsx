import { ThemeProvider } from "@material-ui/core/styles";
import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { BrowserRouter as Router, Switch, Route, Redirect } from "react-router-dom";
import { theme } from "components";
import "./index.css";
import store from "./store";
import "./web.config";
import { Logout } from "./pages/logout/logout";
import { Unauthorized } from "./pages/unauthorized/unauthorized";
import { tenantSettings } from "utils/authentication/tenantSettings";
import { isEmpty } from "lodash";
import "utils/i18n";
import { withLogging } from "utils/logger";
import { TenantAuthProvider } from "components/authentication/tenantAuthProvider";

const Component = <React.StrictMode>
  <Provider store={store}>
    <ThemeProvider theme={theme}>
      <Router>
        <Switch>
          <Route exact path="/logout">
            <Logout />
          </Route>
          <Route exact path="/unauthorized">
            <Unauthorized />
          </Route>
          {isEmpty(tenantSettings) ?
            <Redirect to="/unauthorized" /> :
            <Route>
              <TenantAuthProvider>
              </TenantAuthProvider>
            </Route>}
        </Switch>
      </Router>
    </ThemeProvider>
  </Provider>
</React.StrictMode>;

const Root = withLogging(() => (
  Component
));

ReactDOM.render(
  Root,
  document.getElementById("root")
);

