import { useEffect } from "react";
import { useSelector } from "react-redux";
import { Redirect, Route } from "react-router-dom";
import { RootState, useAppDispatch } from "store";
import { RouteProps } from "react-router-dom";
interface ProtectedRouteProps extends RouteProps {
  children: React.ReactNode;
  permissions?: string[];
}

function ProtectedRoute({ children, permissions, ...rest }: ProtectedRouteProps): JSX.Element {
  const userContext = useSelector((state: RootState) => state.core.userContext?.userContext);
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch({ type: "loader/showandhide", payload: { show: !userContext } })
  }, [userContext, dispatch]);

  const isAuthorized = () => {
    if (!!userContext && permissions && permissions.length > 0) {
      const userHasPermission = permissions?.some(permission => userContext?.permissions && userContext.permissions.length > 0 && userContext.permissions.includes(permission));
      return userHasPermission;
    }
    return true;
  }

  return (
    <Route
      {...rest}
      render={() => {
        const isContentPage = location.pathname.toLowerCase().indexOf('/player') === -1;
        return (
          (!!userContext || !isContentPage) && (
            isAuthorized() ? children : <Redirect to="/unauthorized" />
          )
        )
      }}
    />
  );
}

export default ProtectedRoute;
