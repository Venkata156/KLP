import { About } from "pages/about/about";
import { Error } from "pages/error/error";
import { Logout } from "pages/logout/logout";
import { Catalog } from "pages/catalog/catalog";
import { Channel } from "pages/channel/channel";
import { Course } from "pages/course/course";
import { Landing } from "pages/landing/landing";
import { Pathway } from "pages/pathway/pathway";
import { Playlist } from "pages/playlist/playlist";
import { Profile } from "pages/profile/profile";
import { Route, Switch } from "react-router-dom";
import ProtectedRoute from "routes/protected-route";
import { Attendance } from "pages/attendance/attendance";
import { Attendees } from "pages/attendees/attendees";
import { AttendanceConfirmation } from "pages/attendance-confirmation/AttendanceConfirmation";
import { SelectActivity } from "pages/attendance-confirmation/activity/SelectActivity";
import { ActivityAttendeesComp as ActivityAttendees } from "pages/attendance-confirmation/activity/ActivityAttendees";
import { SubmitAttendance } from "pages/submit-attendance/submit-attendance";
import { Player } from "pages/player/player";
import { PERMISSIONS } from "utils/constants";

const routes = (
  <Switch>
    <ProtectedRoute exact path="/">
      <Landing />
    </ProtectedRoute>
    <ProtectedRoute path="/course/:id">
      <Course />
    </ProtectedRoute>
    <Route path="/about">
      <About />
    </Route>
    <Route path="/error">
      <Error />
    </Route>
    <Route path="/logout">
      <Logout />
    </Route>
    <ProtectedRoute path="/attendance" permissions={[PERMISSIONS.CAN_MANAGE_ATTENDANCE]}>
      <Attendance />
    </ProtectedRoute>
    <ProtectedRoute path="/attendees/:sessionId" permissions={[PERMISSIONS.CAN_MANAGE_ATTENDANCE]}>
      <Attendees />
    </ProtectedRoute>
    <ProtectedRoute path="/submit/:sessionId" permissions={[PERMISSIONS.CAN_MANAGE_ATTENDANCE]}>
      <SubmitAttendance />
    </ProtectedRoute>
    <ProtectedRoute path="/attendance-confirmation/activity/:activityId" permissions={[PERMISSIONS.CAN_MANAGE_ATTENDANCE]}>
      <ActivityAttendees />
    </ProtectedRoute>
    <ProtectedRoute path="/attendance-confirmation/activity" permissions={[PERMISSIONS.CAN_MANAGE_ATTENDANCE]}>
      <SelectActivity />
    </ProtectedRoute>
    <ProtectedRoute path="/attendance-confirmation" permissions={[PERMISSIONS.CAN_MANAGE_ATTENDANCE]}>
      <AttendanceConfirmation />
    </ProtectedRoute>
    <ProtectedRoute path="/catalog/:category?">
      <Catalog />
    </ProtectedRoute>
    <ProtectedRoute path="/profile/:activeTabId?">
      <Profile />
    </ProtectedRoute>
    <ProtectedRoute path="/pathway/:id">
      <Pathway />
    </ProtectedRoute>
    <ProtectedRoute path="/parent_pathway/:id">
      <Pathway />
    </ProtectedRoute>
    <ProtectedRoute path="/playlist/:id">
      <Playlist />
    </ProtectedRoute>
    <ProtectedRoute path="/channel/:id">
      <Channel />
    </ProtectedRoute>
    <ProtectedRoute path="/player/:contentId/:activityId">
      <Player />
    </ProtectedRoute>
  </Switch >
);

export default routes;
