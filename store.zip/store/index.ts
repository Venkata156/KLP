import { configureStore } from "@reduxjs/toolkit";
import { useDispatch } from "react-redux";
import { Dispatch } from "redux";
import coreReducer from "./core";

const reducer = {
  core: coreReducer,
};

const store = configureStore({
  reducer,
  devTools: process.env.NODE_ENV !== "production",
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export const useAppDispatch = (): Dispatch => useDispatch<AppDispatch>();

export * from "./actionTypes";
export default store;
