import { createAction, createReducer } from "@reduxjs/toolkit";
import { isUndefined } from "lodash";
import { CATEGORY_CODE_ALL, SORT_ALPHABETICAL_ASCENDING } from "utils/constants";
import { UserContext } from "utils/graphql/UserContext";
import { PortalSettingsProps } from "utils/portalSettingsManager";
import { CategoryCode, SortType } from "utils/types";
import { UPDATE_COURSE_IN_PROGRESS_FLAG } from "./actionTypes";

export interface ToasterAlert {
  show: boolean;
  type: string;
  title: string;
  message: string;
}
export interface Loader {
  show: boolean;
  message: string;
}
export interface CoreState {
  userContext: UserContext | null;
  portalDisplaySettings: PortalSettingsProps | null;
  navigationBlocked: boolean;
  toasterAlert: ToasterAlert;
  navigationBlockMessage: string;
  searchText: string;
  searchSort: SortType;
  searchCategory: CategoryCode;
  loader: Loader;
  captureSearch: boolean;
  selectedMetrics: string;
  pageButtonEnabled: boolean;
  customCatalogTitle: boolean;
  subHeaderTitle: string;
  courseInProgress: boolean;
}

const initialState: CoreState = {
  userContext: null,
  portalDisplaySettings: null,
  navigationBlocked: false,
  navigationBlockMessage: "",
  toasterAlert: { show: false, type: "", title: "", message: "" },
  searchText: "",
  searchSort: SORT_ALPHABETICAL_ASCENDING,
  searchCategory: CATEGORY_CODE_ALL,
  loader: { show: false, message: "" },
  captureSearch: false,
  selectedMetrics: "",
  pageButtonEnabled: false,
  customCatalogTitle: false,
  subHeaderTitle: "",
  courseInProgress: false,
};

const loadUserContext = createAction<UserContext>("userContext/load");
const loadPortalInfo = createAction<PortalSettingsProps>("portalDisplayInfo/load");
const blockNavigation = createAction<string>("navigation/block");
const unblockNavigation = createAction("navigation/unblock");
const showAlertMsg = createAction("alert/show");
const hideAlertMsg = createAction("alert/hide");
const courseInProgress = createAction(UPDATE_COURSE_IN_PROGRESS_FLAG);
const setSearchFilters = createAction<{
  text?: string;
  sort?: SortType;
  code?: CategoryCode;
  captureSearch?: boolean;
}>("search/setSearchFilters");
export const clearSearch = createAction("search/clearSearch");
const displayLoader = createAction("loader/showandhide");
const metricsFilter = createAction("metrics/filter");
const setSubheaderTitle = createAction("subheader/title")
export const setCustomCatalogTitle = createAction<boolean>("title/customTitle");

export const setPageButton = createAction<boolean>("page/button"); // used to determine the position of the chatbot icon/button

const coreReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(loadUserContext, (state, action) => {
      state.userContext = action.payload;
    })
    .addCase(loadPortalInfo, (state, action) => {
      state.portalDisplaySettings = action.payload;
    })
    .addCase(blockNavigation, (state, action) => {
      state.navigationBlocked = true;
      state.navigationBlockMessage = action.payload;
    })
    .addCase(unblockNavigation, (state) => {
      state.navigationBlocked = false;
      state.navigationBlockMessage = "";
    })
    .addCase(showAlertMsg, (state, action) => {
      const result: ToasterAlert = action.payload as unknown as ToasterAlert;
      state.toasterAlert = {
        show: true,
        type: result.type || "",
        title: result.title || "",
        message: result.message || "",
      };
    })
    .addCase(hideAlertMsg, (state) => {
      state.toasterAlert = {
        show: false,
        type: "",
        title: "",
        message: "",
      };
    })
    .addCase(clearSearch, (state) => {
      state.searchText = "";
      state.captureSearch = false;
      state.searchCategory = CATEGORY_CODE_ALL;
      state.searchSort = SORT_ALPHABETICAL_ASCENDING;
    })
    .addCase(setSearchFilters, (state, action: any) => {
      if (!isUndefined(action.payload.text)) {
        state.searchText = action.payload.text || "";
      }
      if (!isUndefined(action.payload.captureSearch)) {
        state.captureSearch = action.payload.captureSearch || false;
      }

      if (!isUndefined(action.payload.sort)) {
        state.searchSort = action.payload.sort || SORT_ALPHABETICAL_ASCENDING;
      }

      if (!isUndefined(action.payload.code)) {
        state.searchCategory = action.payload.code || CATEGORY_CODE_ALL;
      }
    })
    .addCase(metricsFilter, (state, action) => {
      if (!isUndefined(action.payload)) {
        state.selectedMetrics = action.payload || "";
      }
    })
    .addCase(setCustomCatalogTitle, (state, action) => {
      state.customCatalogTitle = action.payload;

    })
    .addCase(displayLoader, (state, action) => {
      const result: Loader = action.payload as unknown as Loader;
      state.loader = {
        show: result.show,
        message: result.message,
      };
    })
    .addCase(setPageButton, (state, action) => {
      state.pageButtonEnabled = action.payload;
    })
    .addCase(setSubheaderTitle, (state, action) => {
      if (!isUndefined(action.payload)) {
        state.subHeaderTitle = action.payload || "";
      }
    })
    .addCase(courseInProgress, (state, action) => {
      state.courseInProgress = Boolean(action.payload);
    });
});

export default coreReducer;
