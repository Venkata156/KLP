import { useQuery } from "@apollo/client";
import { Box, withStyles, Theme, Button } from "@material-ui/core";
import { theme } from "components";
import { get } from "lodash";
import { CSSProperties, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { useHistory, useParams } from "react-router-dom";
import { useAppDispatch } from "../../store";
import { EXCEPTIONS_CODES } from "../../utils/constants";
import { AttendanceStatus } from "../../utils/graphql/Global";
import { SessionAttendees, SessionAttendees_sessionAttendees } from "../../utils/graphql/SessionAttendees";
import { mobileDateString } from "../../utils/helpers";
import { GET_ATTENDANCES } from "../../utils/queries";
import { useFocusStyles } from "hooks/focusBorder";

const Header = withStyles((theme: Theme) => ({
    root: {
        display: "block",
        textAlign: 'center',
        padding: '15px 0',
        fontSize: '16px',
        borderBottom: `1px solid ${theme.palette.grey['300']}`,
        fontFamily: "Arial",
        letterSpacing: '2px',
    },
}))(Box);

const Container = withStyles(() => ({
    root: {
        display: "block",
        fontFamily: "Arial",
        height: (props: any) => (props.background ? "150px" : "auto"),
        marginLeft: (props: any) => (props.background || props.mobile ? "0" : "30%"),
        marginRight: (props: any) => (props.background || props.mobile ? "0" : "30%"),
        marginTop: (props: any) => (props.background || props.mobile ? "0" : "5%"),
    },
}))(Box);

const TitleText = withStyles((theme: Theme) => ({
    root: {
        fontSize: `22px`,
        color: theme.palette.grey['800'],
        letterSpacing: `0`,
        fontWeight: 400,
        display: 'block',
        marginBottom: '30px'
    },
}))(Box);

const CloseWindowText = withStyles(() => ({
    root: {
        fontSize: '14px',
        letterSpacing: '0',
        lineHeight: '21px',
        fontWeight: 400,
        marginBottom: '30px',
    },
}))(Box);

const HeaderField = withStyles((theme: Theme) => ({
    root: {
        marginBottom: "2px",
        "& span": {
            fontSize: "12px",
            color: theme.palette.grey["800"],
        }
    },
}))(Box);
HeaderField.displayName = "HeaderField";

const CountText = withStyles((theme: Theme) => ({
    root: {
        fontSize: `14px`,
        color: theme.palette.grey['200'],
        fontWeight: 700,
        marginTop: '15px',
        marginBottom: '20px',
    },
}))(Box);

const style: CSSProperties = {
    paddingTop: "16px",
    paddingBottom: "16px",
    borderRadius: "0px",
    marginTop: "20px",
    fontSize: "11px",
    color: "#0091DA",
    borderColor: "#0091DA",
    fontWeight: "bold",
    minWidth: '128px'
};

const anotherBtnStyle: CSSProperties = {
    ...style,
    color: 'gray',
    borderColor: 'gray',
    marginRight: '20px'
}

export const SubmitAttendance = ({ background, mobile = false }: any): JSX.Element => {
    const dispatch = useAppDispatch();
    const { t } = useTranslation();
    const [attendeesData, setAttendeesData] = useState<SessionAttendees_sessionAttendees | null>(null);
    const [attendeesCount, setAttendeesCount] = useState<number>(0);

    const params = useParams();
    const history = useHistory();

    const sessionId = useMemo(() => {
        return get(params, "sessionId", "-1");
    }, [params]);

    const { loading, data, refetch } = useQuery<SessionAttendees>(GET_ATTENDANCES, {
        fetchPolicy: "no-cache",
        variables: {
            sessionId: sessionId
        },
        onError: ({ graphQLErrors }) => {
            if (graphQLErrors?.find(err => Object.getOwnPropertyNames(err?.extensions)?.find(p => p.indexOf(EXCEPTIONS_CODES.UnAuthorized) != -1))) {
                history.push("/unauthorized");
            }
        }
    });

    useEffect(() => {
        if (data) {
            if (data.sessionAttendees) {
                setAttendeesData(data.sessionAttendees);
                setAttendeesCount(data.sessionAttendees?.attendees?.filter((a) => a?.attendanceStatus == AttendanceStatus.ATTENDED)?.length || 0);
            }
        }
    }, [data]);

    useEffect(() => {
        dispatch({ type: "loader/showandhide", payload: { show: loading, message: 'Loading attendance data' } })
    }, [loading, dispatch]);

    const focusClass = useFocusStyles();

    return (
        <Box display="flex" flexDirection="column" justifyContent="top" height="100vh">
            <Header>
            {t('header_title')}
            </Header>
            <Container background={!!background} mobile={mobile}>
                <TitleText role="heading" aria-level={2}>
                    {t('attendance_submitted')}
                </TitleText>
                <Box paddingTop={{ xs: "30px", sm: "0" }}>
                    <HeaderField style={{ marginBottom: '10px' }}>
                        <span style={{
                            fontSize: '16px',
                            color: theme.palette.grey['200'],
                            fontWeight: 700,
                        }}>{attendeesData?.activityName}</span>
                    </HeaderField>
                    <HeaderField>
                        <span>{attendeesData?.startDate ? `${mobileDateString(new Date(attendeesData?.startDate))} ${new Date(attendeesData?.startDate).toLocaleTimeString()}` : '-'}</span>
                    </HeaderField>
                    <HeaderField>
                        <span>{attendeesData?.endDate ? `${mobileDateString(new Date(attendeesData?.endDate))} ${new Date(attendeesData?.endDate).toLocaleTimeString()}` : '-'}</span>
                    </HeaderField>
                    <HeaderField>
                        <span>{attendeesData?.location}</span>
                    </HeaderField>
                </Box>
                <CountText>
                    {attendeesCount} Attendees
                </CountText>
                <CloseWindowText>
                    {t('attendance_dialog')}
                </CloseWindowText>
                <Box display={'flex'} justifyContent='flex-end'>
                    <Button variant="outlined"
                        role="link"
                        className={focusClass.focusItem}
                        tabIndex={0}
                        onClick={() => history.push(`/attendance`)}
                        style={anotherBtnStyle} aria-label={'choose_another_course_link'}>
                        {t('choose_another_course')}
                    </Button>
                    <Button variant="outlined"
                        role="link"
                        className={focusClass.focusItem}
                        tabIndex={0}
                        onClick={() => history.push(`/`)}
                        style={style}
                        aria-label={'return_to_mylearning_link'}>
                        {t('return_to_mylearning')}
                    </Button>
                </Box>
            </Container>
        </Box>
    );
};
