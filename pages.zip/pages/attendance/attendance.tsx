import { Box, Button, IconButton, InputBase, Radio, SvgIcon, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@material-ui/core";
import { Theme, withStyles, makeStyles } from "@material-ui/core/styles";
import { ReactComponent as searchIcon } from "assets/icons/icon-search.svg";
import CloseIcon from "@material-ui/icons/Close";
import { debounce, noop, range } from "lodash";
import React, { FormEvent, useState, useEffect, useMemo } from "react";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "store";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";
import { useBreadCrumbs } from "hooks";
import {
    Paginator,
    SubHeader,
    theme,
} from "components";
import { CSSProperties } from "@material-ui/core/styles/withStyles";
import { useHistory } from "react-router-dom";
import { useLazyQuery } from "@apollo/client";
import { GET_ALL_SESSIONS } from "utils/queries";
import { mobileDateString } from "../../utils/helpers";
import { AllSessions, AllSessions_allSessions_data } from "../../utils/graphql/AllSessions";
import { ATTENDANCE, EXCEPTIONS_CODES } from "utils/constants";
const SearchIconButton = withStyles((theme: Theme) => ({
    root: {
        "&:hover": {
            backgroundColor: theme.palette.grey["300"],
        }
    },
}))(IconButton);
const style: CSSProperties = {
    paddingTop: "16px",
    paddingBottom: "16px",
    borderRadius: "0px",
    marginTop: "20px",
    fontSize: "11px",
    color: "#0091DA",
    borderColor: "#0091DA",
    fontWeight: "bold",
};
const backButtonStyle: CSSProperties = {
    ...style,
    color: 'gray',
    borderColor: 'gray'
};
const styleDisabled: CSSProperties = {
    ...style,
    color: "#ddd",
    borderColor: "#ddd",
};

const Container = withStyles((theme: Theme) => ({
    root: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "95%",
        height: (props: any) => (props.background ? "150px" : "auto"),
        position: "relative",
        margin: (props: any) => (props.background || props.mobile ? "0" : "auto"),
        zIndex: 1,
        "& > div": {
            background: "transparent",
        },
        "& form": {
            display: "flex",
            alignItems: "center",
            backgroundColor: (props: any) => (props.background ? "rgba(255, 255, 255, 0.8)" : "#F5F5F5"),
            backgroundPosition: "center center",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
            width: "90%",
            maxWidth: (props: any) => (props.background ? "1240px" : "420px"),
            height: (props: any) => (props.background ? "70px" : "100%"),
            borderRadius: 0,
            "& > div": {
                width: "100%",
                "& > div": {
                    width: (props: any) => (props.background ? "calc(100% - 65px)" : "calc(100% - 48px)"),
                    "& input": {
                        padding: "0 20px",
                        fontSize: (props: any) => (props.background ? "22px" : "16px"),
                        color: theme.palette.grey["800"],
                        position: "relative",
                        top: "3px",
                        "&::placeholder": {
                            opacity: (props: any) => (props.background ? 1 : 0.4),
                        },
                    },
                },
            },
        },
    },
}))(Box);
const useStyles = makeStyles({
    attendRadio: {
        border:"2px solid #000 !important"
    },
  });
export const Attendance = ({ background, onSubmit, mobile = false }: any): JSX.Element => {
    const dispatch = useAppDispatch();
    const focusClass = useFocusStyles();
    const classes = useStyles();
    const history = useHistory();
    const [searchText, setSearchText] = useState('');
    const captureIntitialSearch = useSelector((state: RootState) => state.core.captureSearch);
    const [captureSearch, setCaptureSearch] = useState(captureIntitialSearch);
    const { t } = useTranslation();
    const [pages, setPages] = useState<number[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [attendeesData, setAttendeesData] = useState<(AllSessions_allSessions_data | null)[] | null>([]);
    const [selectedSessionId, setSessionId] = useState<string | null>('');
    const [onApiError, setOnApiError] = useState(false);
    const [skipCount, setSkipCount] = useState<number>(0);

    const variables = {
        searchTerm: '',
        count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
        skip: skipCount
    };

    const { handleBreadCrumb, handleBreadCrumbNavigation, breadCrumbData } = useBreadCrumbs();
    useEffect(() => {
        if (breadCrumbData) {
            handleBreadCrumb(
                { title: t('attendance'), path: location.pathname, type: ATTENDANCE },
                ATTENDANCE,
                ""
            );
        }
    }, []);

    const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
        handleBreadCrumbNavigation(path, breadCrumbKey);
    };

    const updateSearchText = (value: string) => {
        setSearchText(value);
    };

    const handleSubmit = (event: FormEvent) => {
        event.preventDefault();
    };

    const navigateToSessiondetails = () => {
        history.push(`/attendees/${selectedSessionId}`)
    }

    const [loadAttendances, { loading, data, refetch }] = useLazyQuery<AllSessions>(
        GET_ALL_SESSIONS,
        {
            variables,
            notifyOnNetworkStatusChange: true,
            onError: ({ graphQLErrors }) => {
                if (graphQLErrors?.find(err => Object.getOwnPropertyNames(err?.extensions)?.find(p => p.indexOf(EXCEPTIONS_CODES.UnAuthorized) != -1))) {
                    history.push("/unauthorized");
                }
                else {
                    dispatch({
                        type: "alert/show",
                        payload: {
                            type: "error",
                            title: t('search_result'),
                            message: t('search_error_message'),
                        },
                    });
                    setOnApiError(true);

                    setAttendeesData([]);
                }
            }
        }
    );

    const refetchDebounced = useMemo(() => debounce(refetch ? refetch : noop, 100), [refetch]);

    useEffect(() => {
        loadAttendances({
            variables: {
                searchTerm: searchText,
                count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
                skip: skipCount
            }
        });
    }, [loadAttendances]);

    useEffect(() => {
        if (data) {
            // remove null values
            if (data.allSessions && data.allSessions?.data) {
                setAttendeesData(
                    data.allSessions?.data
                );
                const totalPages = Math.ceil(data.allSessions?.totalCount / Number(process.env.REACT_APP_ATTENDANCE_COUNT))
                setPages(range(1, totalPages + 1))
            }
        }
    }, [data]);

    useEffect(() => {
        setSkipCount(Number(process.env.REACT_APP_ATTENDANCE_COUNT) * (currentPage - 1))
    }, [attendeesData, currentPage]);

    useEffect(() => {
        if (refetchDebounced && (data || onApiError)) {
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
            refetchDebounced({
                searchTe: searchText,
                count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
                skip: skipCount
            });
        }
    }, [skipCount])
    useEffect(() => {
        if (refetchDebounced && (data || onApiError)) {
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
            setCurrentPage(1);
            refetchDebounced({
                searchTerm: searchText,
                count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
                skip: skipCount
            });
        }
    }, [
        refetchDebounced,
        captureSearch
    ]);

    const performSearch = () => {
        if (refetchDebounced && (data || onApiError)) {
            dispatch({
                type: "subheader/title",
                payload: "",
            });
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
            setCurrentPage(1);
            refetchDebounced({
                searchTerm: searchText,
            });
        }
    };

    useEffect(() => {
        dispatch({ type: "loader/showandhide", payload: { show: loading, message: t('search_loading') } });
    }, [loading]);

    return (<>
        <Box display={{ xs: "none", sm: "block" }}>
            <SubHeader
                contentType={ATTENDANCE}
                breadCrumbData={breadCrumbData}
                handleBreadCrumbClick={handleBreadCrumbClick}
            />
        </Box>
        <Box paddingTop={{ xs: "30px", sm: "0" }}>
            <Container background={!!background} mobile={mobile}>
                <Box style={{ width: mobile ? undefined : "1100px" }}>
                    <div style={{
                        fontSize: '24px',
                        color: theme.palette.grey['800'],
                        margin: '20px 0',
                        fontWeight: 400
                    }}>{t('1_choose_a_course')}</div>
                    <Box>
                        <form noValidate onSubmit={handleSubmit}

                            aria-label={t('Course_Or_Session_Search')}>
                            <Box boxShadow={background ? 0 : 0} className={focusClass.focusItem} tabIndex={-1}
                            >
                                <InputBase
                                    placeholder={t('search_placeholder')}
                                    inputProps={{
                                        'aria-label': t('Press_Escape_key_To_Clear'),
                                        "title": t('search_title'),
                                        "placeholder": t('search_course_or_session')
                                    }}
                                    value={searchText}
                                    onChange={(event) => updateSearchText(event.target.value)}
                                    type="search"
                                    className={focusClass.focusItem}
                                />
                                {mobile && searchText ? (
                                    <IconButton
                                        type="button"
                                        className={focusClass.focusItem}
                                        aria-label={t('aria_label_clear_search')}
                                        onClick={(e) => {
                                            e.preventDefault();
                                            updateSearchText("");
                                        }}
                                    >
                                        <CloseIcon fontSize={background ? "large" : "inherit"} />
                                    </IconButton>
                                ) : (
                                    <SearchIconButton
                                        onClick={(e) => {
                                            e.preventDefault();
                                            performSearch();
                                        }}
                                        type="submit" aria-label={t('search').toLowerCase()} style={{ height: "48px", width: "48px" }} className={focusClass.focusItem}>
                                        <SvgIcon
                                            component={searchIcon}
                                            style={{
                                                position: "absolute",
                                                margin: "16px 6px 8px 10px",
                                                fontSize: background ? "30px" : "22px",
                                            }}
                                        />
                                    </SearchIconButton>
                                )}
                            </Box>
                        </form>
                    </Box>
                    <Box margin="30px 0px">
                        <Box marginBottom={{ xs: "10px", sm: "20px" }} style={{ display: "flex" }}>
                            <TableContainer>
                                <Table aria-label={'Available sessions, please select any of the session to proceed'} role="table">
                                    <TableHead role="rowgroup">
                                        <TableRow role="row">
                                            {mobile ? (
                                                <>
                                                    <TableCell align="left" style={{ fontWeight: 700 }} role="columnheader">
                                                        {t('course_name')}
                                                    </TableCell>
                                                    <TableCell></TableCell>
                                                </>
                                            ) : (
                                                <>
                                                    <TableCell align="left" style={{ fontWeight: 700 }} scope="col" role="columnheader">
                                                        {t('session_name')}
                                                    </TableCell>
                                                    <TableCell align="left" style={{ fontWeight: 700, whiteSpace: 'nowrap' }} scope="col" role="columnheader">
                                                        {t('session_id')}
                                                    </TableCell>
                                                    <TableCell align="left" style={{ fontWeight: 700, textTransform: 'capitalize' }} scope="col" role="columnheader">
                                                        {t('activity')}
                                                    </TableCell>
                                                    <TableCell align="left" style={{ fontWeight: 700 }} scope="col" role="columnheader">
                                                        {t('course_name')}
                                                    </TableCell>
                                                    <TableCell align="center" style={{ fontWeight: 700 }} scope="col" role="columnheader">
                                                        {t('start_date_time')}
                                                    </TableCell>
                                                    <TableCell align="center" style={{ fontWeight: 700 }} scope="col" role="columnheader">
                                                        {t('end_date_time')}
                                                    </TableCell>
                                                    <TableCell align="left" style={{ fontWeight: 700 }} scope="col" role="columnheader">
                                                        {t('location')}
                                                    </TableCell>
                                                </>
                                            )}
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {mobile
                                            ? attendeesData?.map((row, index) => {
                                                return (
                                                    <React.Fragment key={"mobile_" + index}>
                                                        <TableRow>
                                                            <TableCell align="left" >
                                                                <Box>{row?.activityName}</Box>
                                                                <Box>{row?.programmeName}</Box>
                                                            </TableCell>
                                                        </TableRow>
                                                    </React.Fragment>
                                                );
                                            })
                                            : attendeesData?.map((row, index) => {
                                                return (
                                                    <React.Fragment key={index}>
                                                        {row && (
                                                            <TableRow key={index} className={row.sessionId === selectedSessionId ? 'selected' : ''} >
                                                                <TableCell align="left" color="red" style={{ color: row.sessionId === selectedSessionId ? theme.palette.grey['200'] : theme.palette.grey['800'] }}>
                                                                    <Box style={{ display: "flex", alignItems: 'center' }}>
                                                                        <Radio
                                                                            focusVisibleClassName={classes.attendRadio}
                                                                            inputProps={{ 'aria-label': row?.sessionName }}
                                                                            name={row?.sessionId || index.toString()}
                                                                            value={row?.sessionId}
                                                                            checked={row.sessionId === selectedSessionId}
                                                                            color="primary"
                                                                            onClick={() => setSessionId(row.sessionId)}
                                                                            aria-label={'Available sessions, please select any of the session to proceed'}
                                                                        />
                                                                        <div>
                                                                            {row?.sessionName}
                                                                        </div>
                                                                    </Box>
                                                                </TableCell>
                                                                <TableCell align="left" style={{ color: row.sessionId === selectedSessionId ? theme.palette.grey['200'] : theme.palette.grey['800'] }}>
                                                                    {row?.externalSessionId}
                                                                </TableCell>
                                                                <TableCell align="left" style={{ color: row.sessionId === selectedSessionId ? theme.palette.grey['200'] : theme.palette.grey['800'] }}>
                                                                    {row?.activityName}
                                                                </TableCell>
                                                                <TableCell align="left" style={{ color: row.sessionId === selectedSessionId ? theme.palette.grey['200'] : theme.palette.grey['800'] }}>
                                                                    {row?.programmeName}
                                                                </TableCell>
                                                                <TableCell align="center" style={{ color: row.sessionId === selectedSessionId ? theme.palette.grey['200'] : theme.palette.grey['800'] }}>
                                                                    {row?.startDate ? `${mobileDateString(new Date(row?.startDate))} ${new Date(row?.startDate).toLocaleTimeString()}` : '-'}
                                                                </TableCell>
                                                                <TableCell align="center" style={{ color: row.sessionId === selectedSessionId ? theme.palette.grey['200'] : theme.palette.grey['800'] }}>
                                                                    {row?.startDate ? `${mobileDateString(new Date(row?.endDate))} ${new Date(row?.endDate).toLocaleTimeString()}` : '-'}
                                                                </TableCell>
                                                                <TableCell align="left" style={{ color: row.sessionId === selectedSessionId ? theme.palette.grey['200'] : theme.palette.grey['800'] }}>
                                                                    {row?.location}
                                                                </TableCell>
                                                            </TableRow>
                                                        )}
                                                    </React.Fragment>
                                                );
                                            })}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Box>
                        <Box>
                            <Paginator
                                pages={pages}
                                currentPage={currentPage}
                                isMobile={mobile}
                                onChange={setCurrentPage}
                            />
                        </Box>
                        <Box display={'flex'} justifyContent='space-between'>
                            <Button variant="outlined"
                                role="link"
                                onClick={() => history.push(`/attendance-confirmation/`)}
                                className={focusClass.focusItem}
                                style={backButtonStyle}
                                aria-label={t('back_colon_start')}
                            >
                                {t('back_colon_start')}
                            </Button>
                            <Button variant="outlined"
                                role="link"
                                className={focusClass.focusItem}
                                aria-label={t('next_attendees')}
                                onClick={navigateToSessiondetails}
                                disabled={!selectedSessionId}
                                style={selectedSessionId ? style : styleDisabled}
                            >
                                <span role="link">{t('next_attendees')}</span>
                            </Button>
                        </Box>
                    </Box>
                </Box>
            </Container>
        </Box>
    </>);
};
