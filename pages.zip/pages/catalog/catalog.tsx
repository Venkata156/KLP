import { useLazyQuery } from "@apollo/client";
import { Box, Container, Drawer, Typography, Button, useMediaQuery } from "@material-ui/core";
import {
  ActivityDrawer,
  ContentTile,
  Filter,
  Paginator,
  Select,
  SubHeader,
  ShareDialog,
  PlayListDialog,
} from "components";
import { useTheme } from "@material-ui/core/styles";
import { cloneDeep, debounce, get, noop, range } from "lodash";
import React, { useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "store";
import { clearSearch, setCustomCatalogTitle } from "store/core";

import {
  SORT_ALPHABETICAL_ASCENDING,
  SORT_ALPHABETICAL_DESCENDING,
  SORT_DURATION_ASCENDING,
  SORT_DURATION_DESCENDING,
  SORT_PRICE_ASCENDING,
  SORT_PRICE_DESCENDING,
  CATEGORY_CODE_ALL,
  CATEGORY_CODE_REQUIRED,
  CATEGORY_CODE_CHANNEL,
  CATEGORY_CODE_PARENTPATHWAY,
  FILTER_ENROLLED,
  FILTER_IN_PROGRESS,
  FILTER_PROCESSING,
  CATEGORY_CODE_MYINTEREST,
  SORT_DEFAULT,
  CATEGORY_CODE_RECOMMENDED,
  CATEGORY_CODE_POPULAR
} from "utils/constants";
import * as CategoryTypes from "utils/graphql/Category";
import { getContentType, parseSortType } from "utils/helpers";
import { GET_CATEGORIES } from "utils/queries";
import { SortType } from "utils/types";
import { useParams, useLocation } from "react-router-dom";
import { useBreadCrumbs } from "hooks";
import { useTranslation } from "react-i18next";
const FilterContainer: React.FC<{
  isMobile: boolean;
  showFilter: boolean;
  hideFilter: () => void;
  numCourses: number;
  handleClearAll: () => void;
  clearAll: boolean;
}> = ({ isMobile, showFilter, hideFilter, children, numCourses, handleClearAll, clearAll }) => {
  const { t } = useTranslation();
  if (!isMobile && showFilter) return <Box marginRight="20px">{children}</Box>;
  else
    return (
      <Drawer anchor="right" open={showFilter}>
        <Box
          style={{
            width: "100vw",
            height: "100vh",
            maxHeight: "100vh",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <Typography
            style={{ margin: "20px", fontSize: "14px", fontWeight: "bold", marginBottom: "0px" }}
          >
            {t('filters_mobile')}
          </Typography>
          <Typography style={{ marginLeft: "20px", fontSize: "10px", marginBottom: "5px" }}>
            {numCourses} &nbsp;{t('search_results_no_mobile')}
          </Typography>
          <Box
            style={{
              margin: "20px",
              marginRight: "0px",
              paddingLeft: "0px",
              flex: 1,
              overflowY: "auto",
              display: "flex",
              justifyContent: "flex-start",
              flexDirection: "column",
            }}
          >
            {children}
          </Box>
          <Button
            style={{
              fontSize: "11px",
              fontWeight: "bold",
              height: "42px",
              borderTop: "1px solid #979797",
            }}
            fullWidth
            onClick={hideFilter}
          >
            {t('close_filters_mobile')}
          </Button>
          <Button
            style={{
              fontSize: "11px",
              fontWeight: "bold",
              height: "42px",
              borderTop: "1px solid #979797",
            }}
            fullWidth
            onClick={handleClearAll}
            disabled={!clearAll}
          >
            {t('clear_filters_mobile')}
          </Button>
        </Box>
      </Drawer>
    );
};

export const Catalog = (): JSX.Element => {
  const theme = useTheme();
  const { t } = useTranslation();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const PAGE_SIZE = 10;

  const dispatch = useAppDispatch();
  const params = useParams();
  const location = useLocation();

  const urlParam = useMemo(() => {
    return get(params, "category", -1);
  }, [params]);
  const searchText = useSelector((state: RootState) => state.core.searchText);
  const searchSort = useSelector((state: RootState) => state.core.searchSort);
  const searchCategory = useSelector((state: RootState) => state.core.searchCategory);
  const captureSearch = useSelector((state: RootState) => state.core.captureSearch);
  const captureMetrics = useSelector((state: RootState) => state.core.selectedMetrics);
  const customCatalogTitle = useSelector((state: RootState) => state.core.customCatalogTitle);
  const [courses, setCourses] = useState<CategoryTypes.Category_contentListByCategory_contents[]>(
    []
  );
  const [isOpenPlaylist, setIsOpenPlaylist] = useState<boolean>(false);
  const [visibleCourses, setVisibleCourses] = useState<
    CategoryTypes.Category_contentListByCategory_contents[]
  >([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pages, setPages] = useState<number[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<any>(null);
  const [showFilter, setShowFilter] = useState(true);
  const [clearDateRange, setClearDateRange] = useState(false);
  const [viewActivityClick, setViewActivityClick] = useState(false);
  const [openShareContent, setOpenShareContent] = useState<boolean>(false);
  const [openActivity, setOpenActivity] = useState<boolean>(false);
  const { handleBreadCrumb, breadCrumbData, handleBreadCrumbNavigation } = useBreadCrumbs();

  useEffect(() => {
    setShowFilter(!isMobile && (Boolean(captureMetrics)
      || urlParam === CATEGORY_CODE_REQUIRED
      || urlParam === CATEGORY_CODE_RECOMMENDED
      || urlParam === CATEGORY_CODE_POPULAR
      || urlParam === CATEGORY_CODE_MYINTEREST
      || urlParam === CATEGORY_CODE_CHANNEL
      || urlParam === CATEGORY_CODE_PARENTPATHWAY));
  }, [isMobile]);

  const [switchFilter, setSwitchFilter] = useState<{
    Required: boolean;
    IsNew: boolean;
    Hascertificate: boolean;
    Status: any[];
    Location: any[];
    StartDate: any;
    Availability: any;
    ContentCategory: any[];
    DeliveryType: any[];
  }>({
    Required: false,
    IsNew: false,
    Hascertificate: false,
    Status: [],
    Location: [],
    StartDate: { minimumDate: "", maximumDate: "" },
    Availability: {},
    ContentCategory: [],
    DeliveryType: [],
  });
  const [sortTitle, setSortTite] = useState<string>(t('sort_by'))
  const [shareLink, setShareLink] = useState<string>("");

  const [sessionStartDate, setSessionStartDate] = useState("");
  const [sessionEndDate, setSessionEndDate] = useState("");
  const [clearAll, setClearAll] = useState(false);

  const [onApiError, setOnApiError] = useState(false);
  const [skipCount, setSkipCount] = useState<number>(0)
  const [totalCourseCount, setTotalCourseCount] = useState<number>(0)

  const getCategoryCodeByUrlParam = () => {
    return [CATEGORY_CODE_CHANNEL, CATEGORY_CODE_REQUIRED].includes(urlParam) ? CATEGORY_CODE_REQUIRED : urlParam;
  };
  
  const variables = {
    categoryCode: searchCategory,
    sort: parseSortType(SORT_DEFAULT),
    count: Number(process.env.REACT_APP_CATALOG_COUNT),
    skip: skipCount
  };
  useEffect(() => {
    if (selectedCourse) {
      setShareLink(window.location.origin + `/${selectedCourse.contentType}/${selectedCourse?.id}`);
    }
  }, [selectedCourse]);
  useEffect(() => {

    if (urlParam === CATEGORY_CODE_REQUIRED) {
      dispatch({
        type: "subheader/title",
        payload: "",
      });
      setClearAll(true);
      setSwitchFilter({
        ...switchFilter,
        Status: [
          { code: FILTER_ENROLLED },
          { code: FILTER_IN_PROGRESS },
        ],
        ContentCategory: [
          { "code": "Programme" },
          { "code": "Pathway" }
        ]
      });
      setShowFilter(!isMobile); // only show the filters on page load if it isn't mobile
    }

    if (urlParam && urlParam !== -1 && urlParam.toLowerCase() === CATEGORY_CODE_CHANNEL.toLowerCase()) {
      dispatch({
        type: "subheader/title",
        payload: "",
      });
      setClearAll(true);
      setSwitchFilter({
        ...switchFilter,
        Status: [
          { code: FILTER_ENROLLED }
        ],
        ContentCategory: [
          { code: CATEGORY_CODE_CHANNEL },
        ]
      });
      setShowFilter(!isMobile); // only show the filters on page load if it isn't mobile
    }

    if (urlParam && urlParam !== -1 && urlParam.toLowerCase() === CATEGORY_CODE_PARENTPATHWAY.toLowerCase()) {
      dispatch({
        type: "subheader/title",
        payload: "",
      });
      setClearAll(true);
      setSwitchFilter({
        ...switchFilter,
        Status: [
          { code: FILTER_ENROLLED }
        ],
        ContentCategory: [
          { code: CATEGORY_CODE_PARENTPATHWAY },
        ]
      });
      setShowFilter(!isMobile); // only show the filters on page load if it isn't mobile
    }
  }, [urlParam, isMobile]);

  if (urlParam === CATEGORY_CODE_REQUIRED) {
    Object.assign(variables, {
      filters: [
        {
          items: [
            { code: FILTER_ENROLLED },
            { code: FILTER_IN_PROGRESS },
            { code: FILTER_PROCESSING },
          ],
          type: "MultiSelect",
          code: "Status",
        },
      ],
      searchTerm: searchText,
    });
  }

  if (urlParam && urlParam !== -1 && urlParam.toLowerCase() === CATEGORY_CODE_CHANNEL.toLowerCase()) {
    Object.assign(variables, {
      filters: [
        {
          items: [
            { code: FILTER_ENROLLED }
          ],
          type: "MultiSelect",
          code: "Status",
        },
      ],
      searchTerm: searchText,
      categoryCode: CATEGORY_CODE_REQUIRED,
    });
  }

  if (urlParam && urlParam !== -1 && urlParam.toLowerCase() === CATEGORY_CODE_PARENTPATHWAY.toLowerCase()) {
    Object.assign(variables, {
      filters: [
        {
          items: [
            { code: FILTER_ENROLLED }
          ],
          type: "MultiSelect",
          code: "Status",
        },
      ],
      searchTerm: searchText,
      categoryCode: CATEGORY_CODE_PARENTPATHWAY,
    });
  }

  const [loadCourses, { loading, data, refetch }] = useLazyQuery<CategoryTypes.Category>(
    GET_CATEGORIES,
    {
      variables,
      notifyOnNetworkStatusChange: true,
      onError: () => {
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('search_result'),
            message: t('search_error_message'),
          },
        });
        setOnApiError(true);

        setCourses([]);
      },

      fetchPolicy: "no-cache",
    }
  );
  const refetchDebounced = useMemo(() => debounce(refetch ? refetch : noop, 1000), [refetch]);
  type categoryOptions = {
    [key: string]: string;
  };
  const categoryData: categoryOptions = {
    Popular: t('popular_items'),
    MyLearning: t('my_learning'),
    Recommendations: t('recommendations'),
    Playlist: t('playlist'),
    ParentPathway: t('parentpathway')
  };

  const categoryLoader: categoryOptions = {
    Popular: t('loading_popular_items'),
    MyLearning: t('loading_my_learning'),
    Recommendations: t('loading_recommendations'),
    Playlist: t('loading_playlist'),
    ParentPathway: t('loading_parentpathway')
  };
  useEffect(() => {
    if (!data) {
      const urlParamInLowerCase = urlParam && urlParam !== -1 ? urlParam.toLowerCase() : "";
      if (urlParamInLowerCase === CATEGORY_CODE_REQUIRED.toLowerCase() || urlParamInLowerCase === CATEGORY_CODE_CHANNEL.toLowerCase() || urlParamInLowerCase === CATEGORY_CODE_PARENTPATHWAY.toLowerCase()) {
        let res: object;
        switch (urlParamInLowerCase) {
          case CATEGORY_CODE_CHANNEL.toLowerCase():
             res = {
              ...switchFilter,
              Status: [
                { code: FILTER_ENROLLED },
              ],
              ContentCategory: [
                { code: "Channel" }
              ]
            }
            break;
          case CATEGORY_CODE_PARENTPATHWAY.toLowerCase():
              res = {
                ...switchFilter,
                Status: [
                  { code: FILTER_ENROLLED },
                ],
                ContentCategory: [
                  { code: "ParentPathway" }
                ]
              }
            break;
          default:
              res = {
              ...switchFilter,
              Status: [
                { code: FILTER_ENROLLED },
                { code: FILTER_IN_PROGRESS }
              ],
              ContentCategory: [
                { code: "Programme" },
                { code: "Pathway" }
              ]
            }
          }

        const filterOptions = getSwithOptions(res)
        loadCourses({
          variables: {
            categoryCode: urlParam !== -1 ? getCategoryCodeByUrlParam() : CATEGORY_CODE_ALL,
            sort: parseSortType(searchSort),
            searchTerm: searchText,
            filters: filterOptions,
            count: Number(process.env.REACT_APP_CATALOG_COUNT),
            skip: skipCount
          },
        });
      } else {
        const filterOptions = getSwithOptions(switchFilter)
        loadCourses({
          variables: {
            categoryCode: urlParam !== -1 ? urlParam : CATEGORY_CODE_ALL,
            sort: parseSortType(searchSort),
            searchTerm: searchText,
            filters: filterOptions,
            count: Number(process.env.REACT_APP_CATALOG_COUNT),
            skip: skipCount
          },
        });
      }
    }
    handleBreadCrumb(
      {
        title:
          urlParam !== -1 ? (categoryData[urlParam] ? categoryData[urlParam] : urlParam) : t('search'),
        path: location.pathname,
      },
      urlParam !== -1 ? "catalog" : "search",
      searchText ? searchText : ""
    );
  }, [location.pathname]);
  const handleFilter = (value: any) => {
    setShowFilter(value);
  };

  const handleSort = (value: SortType) => {
    const sortObject: { [key: string]: string } = {
      "SORT_ALPHABETICAL_ASCENDING": t('sort_by_name_asc'),
      "SORT_ALPHABETICAL_DESCENDING": t('sort_by_name_desc'),
      "SORT_DURATION_ASCENDING": t('sort_by_duration_asc'),
      "SORT_DURATION_DESCENDING": t('sort_by_duration_desc'),
      "SORT_PRICE_ASCENDING": t('sort_by_price_asc'),
      "SORT_PRICE_DESCENDING": t('sort_by_price_desc')
    }
    setSortTite(sortObject[value])
    dispatch({ type: "search/setSearchFilters", payload: { sort: value } });
  };

  const [radioFilter, setRadioFilter] = useState({ Status: [], Test: [] });
  const [availabilityValue, setAvailabilityValue] = useState([0, 200]);
  const handleFilters = (type: string, filterName: string, event: any) => {
    switch (type) {
      case "switch":
        setSwitchFilter({
          ...switchFilter,
          [filterName]: event.target.checked,
        });
        break;
      case "radio":
        setRadioFilter({ ...radioFilter, [filterName]: event.target.value });
        break;
      case "checkbox":
        let status = [];
        if (filterName == "Location") {
          status = cloneDeep(switchFilter.Location);
        } else if (filterName == "Status") {
          status = cloneDeep(switchFilter.Status);
        } else if (filterName == "DeliveryType") {
          status = cloneDeep(switchFilter.DeliveryType);
        } else if (filterName == "ContentCategory") {
          status = cloneDeep(switchFilter.ContentCategory);
        }
        const { name, checked } = event.target;
        if (checked && status.filter((item: any) => item.code == name).length <= 0) {
          const statusItem = { code: name };
          status.push(statusItem);
          setSwitchFilter({ ...switchFilter, [filterName]: status });
        } else if (!checked) {
          status = status.filter((item: any) => item.code != name);
          setSwitchFilter({ ...switchFilter, [filterName]: [...status] });
        }
        break;
      case "sessionDate":
        setClearDateRange(false);
        if (filterName == "sessionStartDate") {
          setSessionStartDate(event.target.value);
        } else {
          setSessionEndDate(event.target.value);
        }
        break;
      case "rangeSlider":
        // setClearDateRange(false);
        setSwitchFilter({
          ...switchFilter,
          [filterName]: {
            minimumNumber: availabilityValue[0],
            maximumNumber: availabilityValue[1],
          },
        });
        break;
      case "slider":
        setSwitchFilter({
          ...switchFilter,
          [filterName]: { minimumNumber: 0, maximumNumber: event.target.ariaValueNow },
        });
        break;
    }
  };
  const handleSliderChange = (type: string, filterName: string, event: any, newValue: any) => {
    if (filterName == "Availability") {
      setAvailabilityValue(newValue);
    }
  };
  const handleClearAll = () => {
    setSwitchFilter({
      Required: false,
      IsNew: false,
      Hascertificate: false,
      Status: [],
      Location: [],
      StartDate: { minimumDate: "", maximumDate: "" },
      Availability: {},
      ContentCategory: [],
      DeliveryType: [],
    });
    setSessionStartDate("");
    setSessionEndDate("");
    setClearDateRange(true);
    setAvailabilityValue([0, 200]);
  };
  const handleClear = (type: string, filterName: string) => {
    switch (type) {
      case "checkbox":
        setSwitchFilter({ ...switchFilter, [filterName]: [] });
        break;
      case "rangeSlider":
        setAvailabilityValue([0, 200]);
        setSwitchFilter({
          ...switchFilter,
          [filterName]: {},
        });
        break;
      case "sessionDate":
        setClearDateRange(true);
        setSessionStartDate("");
        setSessionEndDate("");
        setSwitchFilter({
          ...switchFilter,
          StartDate: { minimumDate: "", maximumDate: "" },
        });
        break;
    }
  };

  useEffect(() => {
    if (captureMetrics) {
      const filterParams = [];
      setShowFilter(true);
      setClearAll(true);
      switch (captureMetrics) {
        case "Required":
          const requiredFilter = { ...switchFilter, Required: true };
          setSwitchFilter(requiredFilter);
          filterParams.push(...getSwithOptions(requiredFilter));
          break;
        case "Courses":
          const courseFilter = {
            ...switchFilter,
            ContentCategory: [{ code: "Programme" }, { code: "Pathway" }],
            Status: [{ code: "Completed" }],
          };
          setSwitchFilter(courseFilter);
          filterParams.push(...getSwithOptions(courseFilter));
          break;
        case "Certifications":
          const certificationFilter = {
            ...switchFilter,
            Hascertificate: true,
            Status: [{ code: "Completed" }],
          };
          setSwitchFilter(certificationFilter);
          filterParams.push(...getSwithOptions(certificationFilter));
          break;
      }
      loadCourses({
        variables: {
          categoryCode: urlParam !== -1 ? getCategoryCodeByUrlParam() : searchCategory,
          sort: parseSortType(searchSort),
          searchTerm: searchText,
          filters: filterParams,
          count: Number(process.env.REACT_APP_CATALOG_COUNT),
          skip: skipCount
        },
      });
      dispatch({ type: "metrics/filter", payload: "" });
    }
  }, [loadCourses]);

  useEffect(() => {

    if (data) {
      // remove null values
      if (data.contentListByCategory && data.contentListByCategory?.contents) {
        setCourses(
          data.contentListByCategory.contents.flatMap((course) => (course ? [course] : []))
        );
        setTotalCourseCount(data.contentListByCategory.contentCount)
        const totalPages = Math.ceil(data.contentListByCategory.contentCount / Number(process.env.REACT_APP_CATALOG_COUNT))
        setPages(range(1, totalPages + 1))
      }
      // setCourses(
      //   (
      //     (data.contentListByCategory && data.contentListByCategory?.contents) ||
      //     []
      //   ).flatMap((course) => (course ? [course] : []))
      // );
    }
  }, [data]);

  useEffect(() => {
    setSkipCount(Number(process.env.REACT_APP_CATALOG_COUNT) * (currentPage - 1))
    setVisibleCourses(courses)
  }, [courses, currentPage]);
  useEffect(() => {
    if (sessionStartDate !== "" && sessionEndDate !== "") {
      setClearAll(true);
      if (sessionEndDate < sessionStartDate) {
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('search_date_range_error_title'),
            message: t('search_date_range_error_message'),
          },
        });
      } else {
        setSwitchFilter({
          ...switchFilter,
          StartDate: { minimumDate: sessionStartDate, maximumDate: sessionEndDate },
        });
      }
    }
  }, [sessionStartDate, sessionEndDate]);

  const getSwithOptions = (object: any) => {
    const filterObj = [];

    for (const key in object) {
      if (object[key]) {
        let filterObjItem;
        if (Array.isArray(object[key])) {
          if (object[key].length == 1) {
            filterObjItem = {
              type: "MultiSelect",
              code: key,
              items: object[key],
            };
          } else if (object[key].length > 1) {
            filterObjItem = {
              type: "MultiSelect",
              code: key,
              items: object[key],
            };
          }
        } else if (typeof object[key] == "boolean") {
          filterObjItem = { type: "Boolean", code: key, isTrue: true };
        } else if (key == "StartDate") {
          if (object[key]["minimumDate"] != "" && object[key]["maximumDate"] != "") {
            filterObjItem = {
              type: "DateRange",
              code: key,
              minimumDate: object[key]["minimumDate"],
              maximumDate: object[key]["maximumDate"],
            };
          }
        } else if (key == "Availability") {
          if (parseInt(object[key]["maximumNumber"]) > 0)
            filterObjItem = {
              type: "NumberRange",
              code: key,
              minimumNumber: object[key]["minimumNumber"],
              maximumNumber: object[key]["maximumNumber"],
            };
        } else {
          filterObjItem = { type: typeof object[key], code: key, value: object[key] };
        }
        if (filterObjItem) filterObj.push(filterObjItem);
      }
    }
    return filterObj;
  };

  useEffect(() => {
    if (refetchDebounced && (data || onApiError)) {
      dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });

      const filterParams = [];
      const switchFilterParams = getSwithOptions(switchFilter);
      if (switchFilterParams.length > 0) {
        setClearAll(true);
        filterParams.push(...switchFilterParams);
      } else {
        setClearAll(false);
      }
      if (filterParams.length > 0) {
        refetchDebounced({
          categoryCode: searchCategory,
          filters: filterParams,
          sort: parseSortType(searchSort),
          searchTerm: searchText,
          count: Number(process.env.REACT_APP_CATALOG_COUNT),
          skip: skipCount
        });
      } else {
        refetchDebounced({
          categoryCode: searchCategory,
          filters: filterParams,
          sort: parseSortType(searchSort),
          searchTerm: searchText,
          count: Number(process.env.REACT_APP_CATALOG_COUNT),
          skip: skipCount
        });
      }
    }
  }, [skipCount])
  useEffect(() => {
    //setSpinner(true)
    if (refetchDebounced && (data || onApiError)) {
      dispatch({ type: "loader/showandhide", payload: { show: true, message: categoryLoader[urlParam] ? categoryLoader[urlParam] : t('search_loading') } });
      setCurrentPage(1);

      const filterParams = [];
      const switchFilterParams = getSwithOptions(switchFilter);
      if (switchFilterParams.length > 0) {
        setClearAll(true);
        filterParams.push(...switchFilterParams);
      } else {
        setClearAll(false);
      }
      if (filterParams.length > 0) {
        refetchDebounced({
          categoryCode: searchCategory,
          filters: filterParams,
          sort: parseSortType(searchSort),
          searchTerm: searchText,
          count: Number(process.env.REACT_APP_CATALOG_COUNT),
          skip: skipCount
        });
      } else {
        refetchDebounced({
          categoryCode: searchCategory,
          filters: filterParams,
          sort: parseSortType(searchSort),
          searchTerm: searchText,
          count: Number(process.env.REACT_APP_CATALOG_COUNT),
          skip: skipCount
        });
      }
    }
  }, [
    refetchDebounced,
    searchSort,
    searchCategory,
    switchFilter,
    radioFilter
  ]);



  useEffect(() => {
    if (refetchDebounced && (data || onApiError)) {
      dispatch({
        type: "subheader/title",
        payload: "",
      });
      handleClearAll()
      setSortTite(t('sort_by'))
      dispatch(setCustomCatalogTitle(false));
      dispatch({ type: "search/setSearchFilters", payload: { sort: SORT_ALPHABETICAL_ASCENDING } });
      dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
      setCurrentPage(1);
      refetchDebounced({
        categoryCode: searchCategory,
        sort: parseSortType(SORT_ALPHABETICAL_ASCENDING),
        searchTerm: searchText,
      });

    }
  }, [searchText,
    captureSearch]);
  useEffect(() => {
    dispatch({ type: "loader/showandhide", payload: { show: loading, message: categoryLoader[urlParam] ? categoryLoader[urlParam] : t('search_loading') } });
  }, [loading]);
  const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
    handleBreadCrumbNavigation(path, breadCrumbKey);
  };
  return (
    <>
      {courses && searchCategory && (
        <SubHeader
          contentType={searchCategory === CATEGORY_CODE_MYINTEREST || CATEGORY_CODE_PARENTPATHWAY ? CATEGORY_CODE_REQUIRED : searchCategory}
          breadCrumbData={breadCrumbData}
          handleBreadCrumbClick={handleBreadCrumbClick}
        />
      )}
      <Container>
        {
          <Box
            display={{ xs: "flex", sm: "none" }}
            justifyContent="space-between"
            alignItems="flex-end"
            margin="20px 0 30px"
          >
            <div>
              <Typography
                style={{
                  fontSize: "12px",
                  fontWeight: 700,
                  color: theme.palette.grey["800"],
                  lineHeight: "30px",
                  letterSpacing: "2.4px",
                }}
              >
                {isMobile && searchText === "" ? t('all_items') : t('search_results_title')}
              </Typography>
              <Typography style={{ fontSize: "12px", marginRight: "5px" }}>
                {totalCourseCount}&nbsp;
                {isMobile && searchText === "" && t('search_results_no_mobile')}
                {(searchText || !isMobile) && " " + t('search_results_no') + " "}
                {searchText && t('search_results_searchtext') + " "}
                <Typography
                  style={{
                    display: "inline-block",
                    fontSize: "12px",
                    fontWeight: 700,
                    fontStyle: "italic",
                  }}
                >
                  {searchText ?? ""}
                </Typography>
              </Typography>
            </div>
            <div
              onClick={() => {
                dispatch(clearSearch());
                handleClearAll();
              }}
              style={{
                color: theme.palette.primary.main,
                fontSize: "12px",
                display: isMobile && !searchText ? "none" : undefined,
              }}
            >
              {t('clear_search')}
            </div>
          </Box>
        }
        <Box
          display="flex"
          alignItems="center"
          marginTop={{ xs: "0", sm: "60px" }}
          color={theme.palette.grey["800"]}
        >
          <Box aria-expanded={true}
            mr={{ xs: "20px", sm: "20px", md: "36px" }}
            width={{ xs: "104px", sm: "104px", md: "151px" }}
          >
            <Select
              title={showFilter ? t('hide_filters_button') : t('show_filters_button')}
              options={isMobile ? [{ title: t('hide_filters_button'), id: true }] : [
                { title: t('show_filters_button'), id: false },
                { title: t('hide_filters_button'), id: true },
              ]}
              toggle={true}
              onChange={handleFilter}
              width="100%"
            />
          </Box>
          {
            <Box flex="1" display={{ xs: "none", sm: "block" }}>
              {customCatalogTitle ?
                <Typography display="inline" style={{ fontSize: "18px", marginRight: "5px" }}>
                  {t('add_an_item')} ({totalCourseCount} {t('available')}) {!!searchText && t('search_results_searchtext')}
                </Typography>
                :
                <Typography display="inline" style={{ fontSize: "18px", marginRight: "5px" }}>
                  {totalCourseCount} &nbsp;{t('search_results_no')} {!!searchText && t('search_results_searchtext')}

                </Typography>
              }
              <Typography
                display="inline"
                style={{ flex: 1, fontSize: "18px", fontWeight: 700, fontStyle: "italic" }}
              >
                {!!searchText && `${searchText}`}
              </Typography>
            </Box>
          }
          {courses.length > 0 && sortTitle && (
            <>
              <Select
                title={t("sort_by")}
                aria-label={sortTitle}
                options={[
                  { title: t('sort_by_name_asc'), id: SORT_ALPHABETICAL_ASCENDING },
                  { title: t('sort_by_name_desc'), id: SORT_ALPHABETICAL_DESCENDING },
                  { title: t('sort_by_duration_asc'), id: SORT_DURATION_ASCENDING },
                  { title: t('sort_by_duration_desc'), id: SORT_DURATION_DESCENDING },
                  { title: t('sort_by_price_asc'), id: SORT_PRICE_ASCENDING },
                  { title: t('sort_by_price_desc'), id: SORT_PRICE_DESCENDING },
                ]}
                value={searchSort}
                onChange={handleSort}
                pagenation={true}
                key={searchSort}
                aria-expanded='true'
              />

              <Box
                display={{ xs: "none", sm: "none", md: "flex" }}
                flexDirection={{ xs: "column", sm: "row" }}
                alignItems="center"
                justifyContent="flex-start"
                marginLeft={{ xs: "10px", sm: "41px" }}
              >
                <Box marginRight={{ xs: 0, sm: "10px" }}>
                  <Typography style={{ fontSize: "10px" }}>{t('page')}</Typography>
                </Box>

                <Select
                  title={t('page')}
                  aria-label={`${currentPage}`}
                  options={pages.map((page) => {
                    return { title: page, id: page };
                  })}
                  value={currentPage}
                  onChange={setCurrentPage || { title: currentPage, id: currentPage }}
                  pagenation={true}
                />
                <Box marginLeft={{ xs: 0, sm: "10px" }}>
                  <Typography style={{ fontSize: "10px" }}>{t('of_placeholder')} {pages.length}</Typography>
                </Box>
              </Box>
            </>
          )}{" "}
        </Box>
        {clearAll && !showFilter && (
          <Button
            style={{
              fontSize: "11px",
              color: theme.palette.primary.main,
              padding: 0,
              textTransform: "none",
              justifyContent: "left",
              marginTop: "2px",
            }}
            onClick={handleClearAll}
          >
            {t('clear_selected_text')}
          </Button>
        )}
        <Box display="flex" marginTop="10px" paddingTop="10px">
          <FilterContainer
            isMobile={isMobile}
            showFilter={showFilter}
            hideFilter={() => setShowFilter(false)}
            numCourses={courses.length}
            handleClearAll={handleClearAll}
            clearAll={clearAll}
          >
            {clearAll && !isMobile && (
              <Button
                style={{
                  fontSize: "11px",
                  color: theme.palette.primary.main,
                  padding: 0,
                  textTransform: "none",
                  justifyContent: "left",
                }}
                onClick={handleClearAll}
              >
                {t('clear_selected_text')}
              </Button>
            )}
            <Filter
              type="switch"
              handleFilters={handleFilters}
              switchValue={switchFilter.Required}
              filterName={"Required"}
              options={{ label: t('required') }}
              handleClear={handleClear}
              switchFilter={switchFilter}
            />
            <Filter
              type="switch"
              handleFilters={handleFilters}
              switchValue={switchFilter.IsNew}
              options={{ label: t('new') }}
              filterName={"IsNew"}
              handleClear={handleClear}
              switchFilter={switchFilter}
            />
            <Filter
              type="switch"
              handleFilters={handleFilters}
              switchValue={switchFilter.Hascertificate}
              options={{ label: t('certification_filter_title') }}
              filterName={"Hascertificate"}
              handleClear={handleClear}
              switchFilter={switchFilter}
            />
            <Filter
              type="checkbox"
              handleFilters={handleFilters}
              checkboxValue={switchFilter.ContentCategory}
              title={t('content_category_filter_title')}
              filterName={"ContentCategory"}
              options={[
                { label: t('course'), value: "Programme" },
                { label: t('pathway'), value: "Pathway" },
                { label: t('channel'), value: "Channel" },
                { label: t('parent_pathway'), value: "ParentPathway" },
              ]}
              handleClear={handleClear}
              switchFilter={switchFilter}
              showClear={Object.keys(switchFilter.ContentCategory).length > 0}
            />
            <Filter
              type="checkbox"
              handleFilters={handleFilters}
              checkboxValue={switchFilter.DeliveryType}
              title={t('delivery_type_filter_title')}
              filterName={"DeliveryType"}
              options={[
                { label: t('face_to_face'), value: "FaceToFace" },
                { label: t('e_learning'), value: "ELearning" },
                { label: t('literature'), value: "Literature" },
                { label: t('video'), value: "Video" },
                { label: t('audio'), value: "Audio" },
              ]}
              handleClear={handleClear}
              switchFilter={switchFilter}
              showClear={Object.keys(switchFilter.DeliveryType).length > 0}
            />
            <Filter
              type="checkbox"
              handleFilters={handleFilters}
              checkboxValue={switchFilter.Status}
              title={t('status')}
              filterName={"Status"}
              options={[
                { label: t('completed'), value: "Completed" },
                { label: t('enrolled'), value: "Enrolled" },
                { label: t('status_filter_inprogress'), value: "InProgress" },
                { label: t('status_filter_paymentawaited'), value: "PaymentAwaited" },
              ]}
              handleClear={handleClear}
              switchFilter={switchFilter}
              showClear={Object.keys(switchFilter.Status).length > 0}
            />
            <Filter
              type="sessionDate"
              handleFilters={handleFilters}
              aria-valuetext="DAY_NUMBER_STRING"
              title={t('sessiondate_filter_title')}
              filterName={"StartDate"}
              handleClear={handleClear}
              switchFilter={switchFilter}
              showClear={sessionStartDate && sessionEndDate}
              clearDateRange={clearDateRange}
            />
            {/* Note: "According to story:926342, "Availability" filter is suppressed and It will be revisited */}
            {
              // <Filter
              //   type="rangeSlider"
              //   sliderValue={availabilityValue}
              //   sliderStep={10}
              //   sliderMaxValue={200}
              //   handleSliderChange={handleSliderChange}
              //   handleFilters={handleFilters}
              //   title="Availability"
              //   filterName={"Availability"}
              //   handleClear={handleClear}
              //   switchFilter={switchFilter}
              //   showClear={availabilityValue[0] !== 0 || availabilityValue[1] !== 200}
              // />
            }
            {/* <Filter
              type="slider"
              sliderStep={10}
              sliderMaxValue={200}
              handleFilters={handleFilters}
              title="Availability"
              filterName={"Availability"}
            /> */}
            {/* <Filter
              type="checkbox"
              handleFilters={handleFilters}
              checkboxValue={switchFilter.Status}
              title="Location"
              filterName={"Location"}
              options={[
                { label: "Manhattan, NY" },
                { label: "Brooklyn, NY" }
              ]}
            /> */}
          </FilterContainer>

          {
            <Box
              style={{ flex: 1, borderTop: "1px solid #c9c9c9", overflow:"hidden"}}
            >
              {!!visibleCourses.length && (
                <>
                  {visibleCourses.map((item, idx) => {
                    return (
                      <ContentTile
                        key={idx}
                        item={item}
                        selectTile={setSelectedCourse}
                        setIsOpenPlaylist={setIsOpenPlaylist}
                        display="section"
                        setOpenShareContent={setOpenShareContent}
                        setOpenActivity={setOpenActivity}
                      />
                    );
                  })}
                  <Paginator
                    pages={pages}
                    currentPage={currentPage}
                    isMobile={isMobile}
                    onChange={setCurrentPage}
                  />
                </>
              )}
            </Box>
          }
        </Box>
      </Container>
      <Drawer
        anchor="right"
        open={openActivity}
        onClose={() => {
          setOpenActivity(false);
          setSelectedCourse(null);
        }}
      >
        {openActivity && (
          <ActivityDrawer
            course={selectedCourse}
            handleContentRefresh={() => setViewActivityClick(!viewActivityClick)}
            closeHandler={() => {
              setOpenActivity(false);
              setSelectedCourse(null);
            }}
          />
        )}
      </Drawer>
      {openShareContent && selectedCourse && (
        <ShareDialog
          open={openShareContent}
          course={selectedCourse}
          contentType={selectedCourse?.contentType}
          shareLink={shareLink}
          handleClose={() => setOpenShareContent(false)}
          role="button"
        />
      )}
      {isOpenPlaylist ? (
        <PlayListDialog
          title={t('playlist_dialog_title')}
          description={
            t('playlist_dialog_discription')
          }
          open={isOpenPlaylist}
          contentId={selectedCourse && selectedCourse.id}
          contentType={getContentType("course")}
          handleClose={() => setIsOpenPlaylist(false)}
        />
      ) : (
        ""
      )}
    </>
  );
};
