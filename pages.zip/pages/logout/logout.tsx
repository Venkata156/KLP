import { Box, Typography, withStyles, Theme, useTheme } from "@material-ui/core";
import { useTranslation } from "react-i18next";
import { LogoutIcon } from "components";
import { useHistory, useParams } from "react-router-dom";
import { SESSION_STOREAGE_KEYS } from "utils/constants";

const LogoutText = withStyles((theme: Theme) => ({
  root: {
    fontFamily: `Arial`,
    fontSize: `50px`,
    color: sessionStorage.getItem(SESSION_STOREAGE_KEYS.THEME_COLOR) || theme.palette.grey["200"],
    letterSpacing: `1.25px`,
    fontWeight: 700,
    textAlign: `center`,
    textTransform: `uppercase`,
  },
}))(Typography);

const GreyText = withStyles((theme: Theme) => ({
  root: {
    color: theme.palette.grey['500'],
    letterSpacing: 0,
    textAlign: "center",
    lineHeight: "39px",
    fontWeight: 400,
  },
}))(Typography);

const CloseWindowText = withStyles(() => ({
  root: {
    fontSize: "26px",
  },
}))(GreyText);


export const Logout = (): JSX.Element => {
  const { t } = useTranslation();
  const history = useHistory();
  const theme = useTheme();
  return (
    <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center" height="100vh">
      <LogoutIcon stroke={sessionStorage.getItem(SESSION_STOREAGE_KEYS.THEME_COLOR) || theme.palette.primary.main}/>
      <LogoutText>
        {t('logout_complete_label', 'Log out Complete')}
      </LogoutText>
      <CloseWindowText>
        {t('logout_complete_dialog', 'You have logged out successfully from the application. You can now close the window.')}
      </CloseWindowText>
      <p>{t('loginback',"If you'd like to log back in, click")} <a style={{color:"#007AB8", fontWeight:500}} href="" onClick={() => history.push(`/`)}>{t('here','here')}</a></p>
    </Box>
  );
};
