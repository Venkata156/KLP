import { Box, Button, IconButton, InputBase, SvgIcon, Switch, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@material-ui/core";
import { Theme, withStyles, makeStyles } from "@material-ui/core/styles";
import { ReactComponent as searchIcon } from "assets/icons/icon-search.svg";
import CloseIcon from "@material-ui/icons/Close";
import React, { FormEvent, useState, useEffect, useMemo } from "react";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "store";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";
import { useBreadCrumbs } from "hooks";
import {
    Paginator,
    SubHeader,
    theme,
} from "components";
import { AttendanceStatus, ContentType } from "utils/graphql/Global";
import { CSSProperties } from "@material-ui/core/styles/withStyles";
import { useHistory, useParams } from "react-router-dom";
import { useMutation, useQuery } from "@apollo/client";
import { GET_ATTENDANCES, UPDATE_ATTENDANCE } from "../../utils/queries";
import { debounce, get, noop, range } from "lodash";
import { mobileDateString } from "../../utils/helpers";
import { SessionAttendees, SessionAttendees_sessionAttendees, SessionAttendees_sessionAttendees_attendees } from "../../utils/graphql/SessionAttendees";
import _ from "lodash";
import { EXCEPTIONS_CODES } from "../../utils/constants";
const SearchIconButton = withStyles((theme: Theme) => ({
    root: {
        "&:hover": {
            backgroundColor: theme.palette.grey["300"],
        }
    },
}))(IconButton);

const style: CSSProperties = {
    paddingTop: "16px",
    paddingBottom: "16px",
    borderRadius: "0px",
    marginTop: "20px",
    fontSize: "11px",
    color: "#0091DA",
    borderColor: "#0091DA",
    fontWeight: "bold",
    minWidth: '128px'
};

const backBtnStyle: CSSProperties = {
    ...style,
    color: 'gray',
    borderColor: 'gray'
}

const Container = withStyles((theme: Theme) => ({
    root: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "95%",
        height: (props: any) => (props.background ? "150px" : "auto"),
        position: "relative",
        margin: (props: any) => (props.background || props.mobile ? "0" : "auto"),
        zIndex: 1,
        "& > div": {
            background: "transparent",
        },
        "& form": {
            display: "flex",
            alignItems: "center",
            backgroundColor: (props: any) => (props.background ? "rgba(255, 255, 255, 0.8)" : "#F5F5F5"),
            backgroundPosition: "center center",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
            maxWidth: (props: any) => (props.background ? "1240px" : "auto"),
            height: (props: any) => (props.background ? "70px" : "auto"),
            borderRadius: 0,
            "& > div": {
                width: "100%",
                "& > div": {
                    width: (props: any) => (props.background ? "calc(100% - 65px)" : "calc(100% - 48px)"),
                    "& input": {
                        padding: "0 20px",
                        fontSize: (props: any) => (props.background ? "22px" : "16px"),
                        color: theme.palette.grey["800"],
                        position: "relative",
                        top: "3px",
                        "&::placeholder": {
                            opacity: (props: any) => (props.background ? 1 : 0.4),
                        },
                    },
                },
            },
        },
    },
}))(Box);

const HeaderField = withStyles((theme: Theme) => ({
    root: {
        marginBottom: "5px",
        fontSize: '12px',
        lineHeight: '16px',
        textAlign: 'right',
        "& span": {
            color: theme.palette.grey["800"],
        }
    },
}))(Box);
HeaderField.displayName = "HeaderField";
const switchStyles = makeStyles(() => {
    return {
        root: {
            width: '34px',
            height: '20px',
            padding: 0,
            margin: '0 6px',
            overflow: 'unset',
        },
        thumb: {
            boxShadow: 'none',
            backgroundColor: theme.palette.grey['300'],
            width: '14px',
            height: '14px',
        },
        switchBase: {
            padding: '3px 4px',
            '&$checked': {
                color: theme.palette.grey['100'],
                transform: `translateX(calc(56px - 32px - 12px))`,
                '& + $track': {
                    backgroundColor: 'transparent',
                    opacity: 1,
                    border: `1px solid ${theme.palette.grey['200']}`,
                },
                '& $thumb': {
                    backgroundColor: theme.palette.grey['200'],
                },
            },
        },
        track: {
            borderRadius: 40,
            border: `1px solid ${theme.palette.grey['300']}`,
            backgroundColor: theme.palette.grey['100'],
            opacity: 1,
            boxSizing: 'border-box',
        },
        checked: {
            "& $thumb": {
                backgroundColor: theme.palette.grey['100']
            }
        },
    };
});

const useStyles = makeStyles({
    attendRadio: {
        border:"2px solid #000 !important"
    },
  });


export const Attendees = ({ background, onSubmit, mobile = false }: any): JSX.Element => {
    const dispatch = useAppDispatch();
    const focusClass = useFocusStyles();
    const classes = useStyles();
    const initialSearchTerm = useSelector((state: RootState) => state.core.searchText);
    const [searchText, setSearchText] = useState(initialSearchTerm);
    const { t } = useTranslation();
    const history = useHistory();
    const params = useParams();
    const customSwitch = switchStyles();
    const [totalCount, setTotalCount] = useState<number>(0);
    const [pages, setPages] = useState<number[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [skipCount, setSkipCount] = useState<number>(0);

    const [attendeesData, setAttendeesData] = useState<SessionAttendees_sessionAttendees | null>(null);
    const [attendees, setAttendees] = useState<(SessionAttendees_sessionAttendees_attendees | null)[] | null>([]);

    const [allAttended, setAllAttended] = useState(false);

    const { handleBreadCrumb, handleBreadCrumbNavigation, breadCrumbData } = useBreadCrumbs();

    useEffect(() => {
        if (breadCrumbData) {
            handleBreadCrumb(
                { title: "Attendees", path: location.pathname, type: "Attendees" },
                "Attendees",
                ""
            );
        }
    }, []);

    const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
        handleBreadCrumbNavigation(path, breadCrumbKey);
    };

    const sessionId = useMemo(() => {
        return get(params, "sessionId", "-1");
    }, [params]);

    const { loading, data, refetch } = useQuery<SessionAttendees>(GET_ATTENDANCES, {
        fetchPolicy: "no-cache",
        variables: {
            sessionId: sessionId
        },
        onError: ({ graphQLErrors }) => {
            if (graphQLErrors?.find(err => Object.getOwnPropertyNames(err?.extensions)?.find(p => p.indexOf(EXCEPTIONS_CODES.UnAuthorized) != -1))) {
                history.push("/unauthorized");
            }
        }
    });

    useEffect(() => {
        if (data) {
            if (data.sessionAttendees) {
                setAttendeesData(data.sessionAttendees);

                pagingAttendees(data.sessionAttendees?.attendees);

                const totalCount = data.sessionAttendees?.attendees?.length || 0;

                setTotalCount(totalCount);

                setAllAttended((totalCount > 0
                    && data?.sessionAttendees?.attendees?.every((a) => a?.attendanceStatus == AttendanceStatus.ATTENDED))
                    || false);
            }
        }
    }, [data]);

    useEffect(() => {
        setSkipCount(Number(process.env.REACT_APP_ATTENDEES_COUNT) * (currentPage - 1))
    }, [attendeesData, currentPage]);

    useEffect(() => {
        pagingAttendees(attendeesData?.attendees);
    }, [skipCount]);

    useEffect(() => {
        setCurrentPage(1);
        pagingAttendees(attendees);
    }, [searchText]);

    const pagingAttendees = (attendeesList: (SessionAttendees_sessionAttendees_attendees | null)[] | null | undefined) => {
        if (attendeesList) {
            const attendeesPage = _.chain(attendeesList)
                .drop(skipCount)
                .take(Number(process.env.REACT_APP_ATTENDEES_COUNT))
                .value();

            setAttendees(attendeesPage);

            const count = attendeesList?.length || 0;

            const totalPages = Math.ceil(count / Number(process.env.REACT_APP_ATTENDEES_COUNT));
            setPages(range(1, totalPages + 1));
        }
        else {
            setAttendees([]);
            setPages([]);
        }
    };

    useEffect(() => {
        dispatch({ type: "loader/showandhide", payload: { show: loading, message: 'Loading attendees' } })
    }, [loading, dispatch]);

    const updateSearchText = (value: string) => {
        setSearchText(value);

        if (value && value.trim() != '') {
            setAttendees((attendeesData?.attendees || []).filter((attendaee) => {
                return (`${attendaee?.firstName} ${attendaee?.lastName}`)?.toLowerCase()?.includes(value.toLowerCase())
                         || attendaee?.email?.toLowerCase()?.includes(value.toLowerCase())
            }))
        } else {
            setAttendees(attendeesData?.attendees || [])
        }
    };

    const changeAllAttended = (event: any) => {

        const checked = event.target.checked;

        setAllAttended(checked);

        if (checked === true) {
            attendeesData?.attendees?.forEach((attendee) => {
                if (attendee != null)
                    attendee.attendanceStatus = AttendanceStatus.ATTENDED;
                return attendee;
            });
        } else {
            attendeesData?.attendees?.forEach((attendee) => {
                if (attendee != null)
                    attendee.attendanceStatus = AttendanceStatus.DID_NOT_ATTEND;
                return attendee;
            });
        }

        setAttendees([...attendees || []]);
    }

    const changeAttended = (event: any, attendee: SessionAttendees_sessionAttendees_attendees | null) => {
        if (event.target.checked === true) {
            if (attendee != null)
                attendee.attendanceStatus = AttendanceStatus.ATTENDED;
        } else {
            setAllAttended(false);
            if (attendee != null)
                attendee.attendanceStatus = AttendanceStatus.DID_NOT_ATTEND;
        }

        setAllAttended(attendeesData?.attendees?.every((a) => a?.attendanceStatus == AttendanceStatus.ATTENDED) || false);

        setAttendees([...attendees || []]);
    }

    const handleSubmit = (event: FormEvent) => {
        event.preventDefault();

        handleSaveAttendance();
    };

    const [updateAttendance] = useMutation(UPDATE_ATTENDANCE);

    const handleSaveAttendance = () => {
        dispatch({ type: "loader/showandhide", payload: { show: true } });
        const postData = {
            sessionId: sessionId,
            activityId: attendeesData?.activityId,
            activityType: attendeesData?.activityType,
            externalSessionId: attendeesData?.externalSessionId,
            programmeId: attendeesData?.programmeId,
            updatedAttendanceByLearnerId: attendeesData?.attendees?.map((attendee) => {
                return {
                    key: attendee?.learnerId,
                    value: attendee?.attendanceStatus
                }
            }),
            deletedLearnerIds: []
        };
        updateAttendance({ variables: { model: postData } })
            .then(() => {
                dispatch({ type: "loader/showandhide", payload: { show: false } });
                history.push(`/submit/${sessionId}`);
            })
            .catch(() => {
                dispatch({ type: "loader/showandhide", payload: { show: false } });
                dispatch({
                    type: "alert/show",
                    payload: {
                        type: "error",
                        title: 'Attendance Update',
                        message: 'Attendance Update Failed'
                    },
                });
            });
    };

    return (<>
        <Box display={{ xs: "none", sm: "block" }}>
            <SubHeader
                contentType="Attendance"
                breadCrumbData={breadCrumbData}
                handleBreadCrumbClick={handleBreadCrumbClick}
            />
        </Box>
        <Box paddingTop={{ xs: "30px", sm: "0" }}>
            <Container background={!!background} mobile={mobile}>
                <Box style={{ width: mobile ? undefined : "1100px" }}>
                    <Box style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <Box style={{ width: '48%' }}>
                            <Box style={{ fontSize: '22px', fontWeight: 400 }} paddingBottom="15px">{t('2_confirm_attendance')}</Box>
                            <form noValidate onSubmit={handleSubmit}
                                tabIndex={0}
                                aria-label={t('Attendee_Search_Bar')}>
                                <Box boxShadow={background ? 0 : 0} className={focusClass.focusItem}>
                                    <InputBase
                                        tabIndex={0}
                                        inputProps={{
                                            "placeholder": t('search_attendee'),
                                            'aria-label': t('Press_Escape_key_To_Clear')
                                        }}
                                        value={searchText}
                                        onChange={(event) => updateSearchText(event.target.value)}
                                        type="search"
                                        className={focusClass.focusItem}
                                    />
                                    {mobile && searchText ? (
                                        <IconButton
                                            type="button"
                                            className={focusClass.focusItem}
                                            aria-label={t('aria_label_clear_search')}
                                            onClick={(e) => {
                                                e.preventDefault();
                                                updateSearchText("");
                                            }}
                                        >
                                            <CloseIcon fontSize={background ? "large" : "inherit"} />
                                        </IconButton>
                                    ) : (
                                        <SearchIconButton
                                            onClick={(e) => {
                                                e.preventDefault();
                                                updateSearchText(searchText);
                                            }}
                                            type="submit" aria-label={t('search').toLowerCase()} style={{ height: "48px", width: "48px" }} className={focusClass.focusItem}>
                                            <SvgIcon
                                                component={searchIcon}
                                                style={{
                                                    position: "absolute",
                                                    margin: "16px 6px 8px 10px",
                                                    fontSize: background ? "30px" : "22px",
                                                }}
                                            />
                                        </SearchIconButton>
                                    )}
                                </Box>
                            </form>
                        </Box>
                        <Box paddingTop={{ xs: "30px", sm: "0" }}>
                            <HeaderField>
                                <span style={{ fontWeight: 'bold' }}>{attendeesData?.programmeName}</span>
                            </HeaderField>
                            <HeaderField>
                                <span>{attendeesData?.activityName}</span>
                            </HeaderField>
                            <HeaderField>
                                <span>{attendeesData?.sessionName}: {attendeesData?.externalSessionId}</span>
                            </HeaderField>
                            <HeaderField>
                                <span> {attendeesData?.startDate ? `${mobileDateString(new Date(attendeesData?.startDate))} ${new Date(attendeesData?.startDate).toLocaleTimeString()}` : '-'}</span>
                            </HeaderField>
                            <HeaderField>
                                <span>{attendeesData?.location}</span>
                            </HeaderField>
                        </Box>
                    </Box>
                    <Box margin="30px 0px">
                        <Box marginBottom={{ xs: "10px", sm: "20px" }} style={{ display: "flex" }}>
                            <TableContainer>
                                <Table aria-label={t('Attendees_table')}>
                                    <TableHead>
                                        <TableRow>
                                            {mobile ? (
                                                <>
                                                    <TableCell align="left" style={{ fontWeight: 700 }}>
                                                        {t('attendee')}
                                                    </TableCell>
                                                    <TableCell>
                                                        {t('email')}
                                                    </TableCell>
                                                    <TableCell>

                                                    </TableCell>
                                                </>
                                            ) : (
                                                <>
                                                    <TableCell align="left" style={{ fontWeight: 700 }} scope="col">
                                                        {t('attendee')}
                                                    </TableCell>
                                                    <TableCell align="center" scope="col">
                                                        <Box style={{ fontWeight: 400, fontSize: '16px', color: theme.palette.grey["200"], display: "inline-block" }} paddingRight="10px">{attendees?.length}</Box>{t('total')}
                                                    </TableCell>
                                                    <TableCell align="right" style={{ fontWeight: 700 }} scope="col">
                                                        {t('attended')} <Switch
                                                            focusVisibleClassName={classes.attendRadio}
                                                            inputProps={{ 'aria-label': t('Mark_As_All_Attended') }}
                                                            color='primary'
                                                            name="switch"
                                                            checked={allAttended}
                                                            classes={customSwitch}
                                                            onClick={changeAllAttended}
                                                            disabled={totalCount == 0}
                                                        />
                                                    </TableCell>
                                                </>
                                            )}
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {attendees?.length ? mobile 
                                            ? attendees?.map((row, index) => {
                                                return (
                                                    <React.Fragment key={"mobile_" + index}>
                                                        <TableRow>
                                                            <TableCell align="left"  >
                                                                <Box>{row?.firstName + ' ' + row?.lastName}</Box>
                                                                <Box>{row?.email}</Box>
                                                            </TableCell>
                                                        </TableRow>
                                                    </React.Fragment>
                                                );
                                            })
                                            : 
                                                attendees?.map((row, index) => {
                                                return (
                                                    <React.Fragment key={index}>
                                                        {row && (
                                                            <TableRow key={index}>
                                                                <TableCell align="left">
                                                                    {row?.firstName + ' ' + row?.lastName}
                                                                </TableCell>
                                                                <TableCell align="left">
                                                                </TableCell>
                                                                <TableCell align="right"  >
                                                                    <Switch
                                                                        focusVisibleClassName={classes.attendRadio}
                                                                        tabIndex={0}
                                                                        inputProps={{ 'aria-label': row?.firstName + ' ' + row?.lastName }}
                                                                        color='primary'
                                                                        name="switch"
                                                                        classes={customSwitch}
                                                                        checked={row?.attendanceStatus == AttendanceStatus.ATTENDED}
                                                                        onChange={(e) => changeAttended(e, row)}
                                                                    />
                                                                </TableCell>
                                                            </TableRow>

                                                        )}
                                                    </React.Fragment>
                                                );
                                            }):
                                                <TableRow><TableCell colSpan={3} style={{ textAlign: 'center' }}>
                                                    {t('no_users')}
                                                </TableCell></TableRow>}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Box>
                        <Box>
                            <Paginator
                                pages={pages}
                                currentPage={currentPage}
                                isMobile={mobile}
                                onChange={setCurrentPage}
                            />
                        </Box>
                        <Box display={'flex'} justifyContent='space-between'>
                            <Button variant="outlined"
                                onClick={() => history.push('/attendance')}
                                className={focusClass.focusItem}
                                role="link"
                                style={backBtnStyle}

                            >
                                {t('back_sessions')}
                            </Button>
                            <Button variant="outlined"
                                className={focusClass.focusItem}
                                role="link"
                                onClick={() => handleSaveAttendance()}
                                style={style}
                                disabled={totalCount == 0}
                            >
                                {t('submit')}
                            </Button>
                        </Box>
                    </Box>
                </Box>
            </Container>
        </Box>
    </>);
};