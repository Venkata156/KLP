import { useQuery } from '@apollo/client';
import React, { useEffect, useState } from 'react'
import { GET_COURSE_PLAYER } from '../../utils/queries';
import { CoursePlayer } from "../../utils/graphql/CoursePlayer";
import { useHistory, useParams } from 'react-router-dom';
import { MediaPlayer, ScormPlayer } from '../../components';
import { ActivityType } from '../../utils/graphql/Global';
import { useTranslation } from 'react-i18next';
import { useAppDispatch } from 'store';
import { EXCEPTIONS_CODES } from '../../utils/constants';

export const Player = (): JSX.Element => {
    const dispatch = useAppDispatch();
    const { t } = useTranslation();
    const history = useHistory();

    const { contentId = -1, activityId = -1 } = useParams<{ contentId?: string, activityId?: string }>();

    const [mediaUrl, setMediaUrl] = useState<string>('');
    const [imageUrl, setImageUrl] = useState<string>('');
    const [loadSuccessful, setLoadSuccessful] = useState<boolean>(true);
    const [activityType, setActivityType] = useState<string>(ActivityType.NONE);
    
    const { loading, data, refetch } = useQuery<CoursePlayer>(GET_COURSE_PLAYER, {
        fetchPolicy: "no-cache",
        variables: {
            programmeId: contentId,
            activityId: activityId
        },
        onError: ({ graphQLErrors }) => {
            if (graphQLErrors?.find(err => Object.getOwnPropertyNames(err?.extensions)?.find(p => p.indexOf(EXCEPTIONS_CODES.UnAuthorized) != -1))) {
                history.push("/unauthorized");
            }
        }
    });

    useEffect(() => {
        if (data && data.player) {
            setLoadSuccessful(data?.player?.loadSuccessful || false);
            setImageUrl(data?.player?.playerBodyModel?.audioPosterUrl || '');
            setMediaUrl(data?.player?.playerBodyModel?.activityModel?.url || '');
            setActivityType(data?.player?.playerBodyModel?.activityModel?.type || ActivityType.NONE);
        }
    }, [data]);

    useEffect(() => {
        dispatch({ type: "loader/showandhide", payload: { show: loading, message: 'Loading The Player' } })
    }, [loading, dispatch]);

    return (
        <div>
            {data
                ? (<div>
                    {
                        loadSuccessful
                            ? (activityType === ActivityType.E_LEARNING
                                ? <ScormPlayer player={data.player} />
                                : <MediaPlayer mediaUrl={mediaUrl} imageUrl={imageUrl} />)
                            : <div>{t('player_source_not_found')}</div>
                    }
                   </div>)
                : (<div></div>)
            }
        </div>
    )
}