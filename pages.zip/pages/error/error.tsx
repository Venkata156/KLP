import courseIcon from "assets/icons/icon-course.svg";
import { Box, Typography, Button as MuiButton } from "@material-ui/core";
import { Theme, withStyles, styled, useTheme } from "@material-ui/core/styles";

const Figure = styled("figure")({
  display: "flex",
  flexDirection: "column",
  margin: "auto",
});

const ImageIcon = styled("img")({
  height: "89px",
  opacity: "0.5",
  marginBottom: "10px",
});

const Button = withStyles((theme: Theme) => ({
  root: {
    borderRadius: 0,
    color: theme.palette.primary.main,
    width: "143px",
    height: "42px",
    margin: "0 auto",
  },
  label: {
    fontSize: 11,
    fontWeight: 700,
  },
  outlined: {
    border: `1px solid ${theme.palette.primary.main}`,
  },
  disabled: {
    color: theme.palette.grey['500'],
  },
}))(MuiButton);

export const Error = (): JSX.Element => {
  const theme = useTheme();
  
  return (
    <Box display="flex" flexDirection="column" padding="45px 51px">
      <Box>
        <Figure>
          <ImageIcon src={courseIcon} alt="Course" />
        </Figure>
      </Box>
      <Box style={{ textAlign: "center", marginBottom: "67px" }}>
        <Typography
          style={{ fontSize: " 50px", color: theme.palette.primary.main, letterSpacing: "1.25px", fontWeight: 700 }}
        >
          PAGE NOT FOUND{" "}
        </Typography>
        <Typography
          style={{
            width: "861px",
            margin: "0 auto",
            fontSize: "26px",
            color: theme.palette.grey['500'],
            letterSpacing: 0,
            textAlign: "center",
            lineHeight: "39px",
            fontWeight: 400,
          }}
        >
          Well, this is odd. Seems you’ve found a page that no longer exists. Please utilize the
          navigation above or head back to the previous page via the button below
        </Typography>
      </Box>
      <Button variant="outlined" onClick={window.history.back}>
        Go Back
      </Button>
    </Box>
  );
};
