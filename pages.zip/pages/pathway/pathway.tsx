import { useLazyQuery } from "@apollo/client";
import { Container, Drawer } from "@material-ui/core";
import {
  ActivityDrawer,
  PathwayContentHeader,
  PathwayContentTile,
  SubHeader,
  ShareDialog,
  PlayListDialog,
  EditRatingDialog,
  ConfirmDialog,
  EnrollDialog,
  WorkshopDialog,
} from "components";
import { useRating, useBreadCrumbs, useEnrollment, useWorkshop } from "hooks";
import { get } from "lodash";
import { useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useParams } from "react-router-dom";
import { RootState, useAppDispatch } from "store";
import * as ContainerContentTypes from "utils/graphql/ContentContainer";
import { ContentType } from "utils/graphql/Global";
import { getContentType } from "utils/helpers";
import { GET_CONTENT_LIST } from "utils/queries";
import { PathwayType } from "utils/types";
import { useTranslation } from "react-i18next";
import { PERMISSIONS, ENROLLMENT_DIALOG_TYPES } from "utils/constants";

export const Pathway = (): JSX.Element => {
  const { t } = useTranslation();
  const [selectedCourse, setSelectedCourse] = useState<any>([]);
  const [openShareContent, setOpenShareContent] = useState<boolean>(false);
  const [openActivity, setOpenActivity] = useState<boolean>(false);
  const [isOpenPlaylist, setIsOpenPlaylist] = useState<boolean>(false);
  const [shareLink, setShareLink] = useState<string>("");
  const [openEnroll, setOpenEnroll] = useState<boolean>(false);
  const userContext = useSelector((state: RootState) => state.core.userContext);
  const [pathwayEnrolldata, setPathwayEnrollData] = useState<any>([]);
  const [showPathwayList, setShowPathwayList] = useState(false);
  const [openWorkshop, setWorkShop] = useState<boolean>(false);
  const [selectedActivity, setSelectedActivity] = useState<string>("");
  const [selectedWorkshopDate, setSelectedWorkshopDate] = useState<string>("");
  const [selectedWorkshopLocation, setSelectedWorkshopLocation] = useState<string>("");
  const [selectedWorkshopCourse, setSelectedWorkshopCourse] = useState<string>("");
  const params = useParams();
  const dispatch = useAppDispatch();
  const location = useLocation();

  const pageType = location.pathname.toLowerCase().startsWith("/pathway/") ? PathwayType.pathway : PathwayType.parentpathway;

  const id = useMemo(() => {
    return get(params, "id", -1);
  }, [params]);
  const [param] = useState({
    parentId: id,
    parentType: pageType === "pathway" ? "Pathway" : "parentpathway",
  });
  const [fetchPathway, {
    loading: pathwayLoading,
    data: pathway,
    refetch: pathwayRefetch,
  }] = useLazyQuery<ContainerContentTypes.ContentContainer>(GET_CONTENT_LIST, {
    variables: param,
    notifyOnNetworkStatusChange: true,
    fetchPolicy: "no-cache",
  });

  useEffect(() => {
    fetchPathway({
      variables: {
        parentId: id,
        parentType: pageType === "pathway" ? "Pathway" : "parentpathway",
      },
    })
  }, [id, fetchPathway]);

  useEffect(() => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: pathwayLoading, message: pageType === "pathway" ? t('pathway_loading') : t('loading_parentpathway') },
    });
  }, [pathwayLoading]);

  const handleExpressInterest = () => {
    const expressObj = {
      activityId: selectedActivity,
      interestedDate: selectedWorkshopDate,
      programmeId: selectedWorkshopCourse,
      location: selectedWorkshopLocation,
    };
    expressInterest(expressObj);
    handleExpressClose();
  };
  const handleExpressClose = () => {
    setSelectedCourse("");
    setSelectedWorkshopDate("");
    setSelectedWorkshopLocation("");
    setWorkShop(false);
  };
  const handleDateSelection = (val: string) => {
    setSelectedWorkshopDate(val);
  };
  const handleLocationSelection = (val: string) => {
    setSelectedWorkshopLocation(val);
  };
  const handleOpenWorkshop = (id: string) => {
    setWorkShop(true);
    setSelectedActivity(id);
    loadWorkshopData({ variables: { activityId: id } });
  };
  const handleEnroll = () => {
    dispatch({ type: "loader/showandhide", payload: { show: true, message: pageType === "pathway" ? t('pathway_loading') : t('loading_parentpathway') } });
    setTimeout(() => {
      try {
        pathwayRefetch();
      } catch (err) {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: pageType === "pathway" ? t('pathway_loading') : t('loading_parentpathway') },
        });
      }
    }, 5000);
  };
  const handleSharContentHeader = () => {
    setOpenShareContent(true);
    setSelectedCourse(pathway?.contentListById);
    setShareLink(window.location.href);
  };

  const handleShareContentTile = (item: any) => {
    setSelectedCourse(item);
    setOpenShareContent(true);
    setShareLink(window.location.origin + `/${item.contentType}/${item?.id}`);
  };

  const handleShareClose = () => {
    setOpenShareContent(false);
    setSelectedCourse([]);
    setShareLink("");
  };

  const {
    rating: editRating,
    openRating,
    onSubmit,
    isEditRatingOpen,
    closeEditRatingDialog,
    isConfirmationOpen,
    closeConfirmationDialog,
  } = useRating(
    pathway?.contentListById?.id,
    ContentType.PATHWAY,
    pathwayRefetch,
    pathway?.contentListById?.statusCode
  );
  const { handleBreadCrumb, handleBreadCrumbNavigation, breadCrumbData } = useBreadCrumbs();
  const {
    handleEnrollmentData,
    handleCompleteEnrollment,
    handlePathwayEnrollment,
    pathwayEnrollResult,
    enrollmentResult,
    setShowLoader,
    showLoader,
    setEnrollmentResult,
  } = useEnrollment(handleEnroll);
  const { loadWorkshopData, expressInterest, workshopData } = useWorkshop();

  useEffect(() => {
    if (breadCrumbData && pathway?.contentListById?.name) {
      handleBreadCrumb(
        { title: pathway?.contentListById?.name, path: location.pathname, type: pageType === "pathway" ? "pathway" : "parentpathway" },
        `${pageType === "pathway" ? "pathway" : "parentpathway"}`,
        ""
      );
    }
  }, [pathway]);

  useEffect(() => {
    if (pathwayEnrollResult && pathwayEnrollResult.completePathwayEnrollment) {
      dispatch({
        type: "loader/showandhide",
        payload: { show: false, message: t('add_to_mylearning') },
      });
      if (
        pathwayEnrollResult.completePathwayEnrollment.some(
          (item: any) => item.canEnroll && !item.isEnrolled
        )
      ) {
        setShowPathwayList(true);
        setOpenEnroll(true);
        setPathwayEnrollData(pathwayEnrollResult.completePathwayEnrollment);
      } else if (!showPathwayList) {
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: pageType === "pathway" ? t('pathway') : t('parent_pathway'),
            message: pageType === "pathway" ? t('Add_pathway_success_dialog') : t('add_parent_pathway_success_dialog')
          },
        });
        handleEnroll();
      }
    }
  }, [pathwayEnrollResult]);

  useEffect(() => {
    if (enrollmentResult && enrollmentResult?.enrollmentData) {
      const res = enrollmentResult?.enrollmentData;
      if (userContext?.userContext?.permissions?.includes(PERMISSIONS.CAN_ENROLL_USERS)) {
        setOpenEnroll(true);
        setShowPathwayList(false);
      } else {
        if (
          res?.activities?.length ||
          res?.captureManagerEmail ||
          res?.captureSpecialRequirements ||
          res?.isPreRequisitesAvailable ||
          res?.isTermsAndConditionAvailable
        ) {
          setOpenEnroll(true);
          setShowPathwayList(false);
        } else {
          const courseData = {
            courseId: String(id),
          };
          const attendeesObj = {
            attendees: [
              {
                learnerId: userContext?.userContext?.learnerId,
              },
            ],
          };
          handleCompleteEnrollment(ENROLLMENT_DIALOG_TYPES.PATHWAY, courseData, attendeesObj);
        }
      }
    }
  }, [enrollmentResult]);

  const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
    handleBreadCrumbNavigation(path, breadCrumbKey);
  };
  const handleEnrollClose = () => {
    setShowPathwayList(false);
    setOpenEnroll(false);
    setEnrollmentResult([]);
    handleEnroll();

    dispatch({
      type: "alert/show",
      payload: {
        type: "success",
        title: pageType === "pathway" ? t('pathway') : t('parentpathway'),
        message: pageType === "pathway" ? t('Add_pathway_success_dialog') : t('Add_parent_pathway_success_dialog'),
      },
    });
  };
  const handleAddToLearning = () => {
    dispatch({ type: "loader/showandhide", payload: { show: true, message: t('add_to_mylearning') } });
    handlePathwayEnrollment(id);
  };
  const handlePathwayCourseClick = (courseId: any) => {
    setSelectedWorkshopCourse(String(courseId));
    handleEnrollmentData(String(courseId));
  };
  const handleConfirmEnrollment = (type: string, data: any, attendees: any) => {
    handleCompleteEnrollment(type, data, attendees);
  };

  const [expandedItem, setExpandedItem] = useState(null);
  const handleIsExpandedChange = (item: any, isExpanded: boolean) => {
    setExpandedItem(isExpanded ? item : null);
  };
  useEffect(() => {
    const item = (pathway?.contentListById?.contents || []).find((i) => {
      if (!i.children) {
        return false;
      }
      return i.children.find((c) => c.statusCode !== "Completed") != null;
    });
    setExpandedItem(item);
  }, [pathway?.contentListById?.contents]);

  return (
    <>
      {pathway?.contentListById && (
        <SubHeader
          contentType={pageType === "pathway" ? "Pathway" : "parentpathway"}
          breadCrumbData={breadCrumbData}
          handleBreadCrumbClick={handleBreadCrumbClick}
        />
      )}
      <Container>
        <div>
          <PathwayContentHeader
            id={pathway?.contentListById?.id}
            title={pathway?.contentListById?.name}
            type={pageType === "pathway" ? PathwayType.pathway : PathwayType.parentpathway}
            updatedOnDisplay={pathway?.contentListById?.updatedOnDisplay}
            tags={pathway?.contentListById?.tags}
            contentMetrics={pathway?.contentListById?.contentMetrics}
            hasCertificate={pathway?.contentListById?.hasCertificate}
            isEnrolled={pathway?.contentListById?.isEnrolled}
            percentageComplete={pathway?.contentListById?.percentageComplete}
            rating={pathway?.contentListById?.rating}
            numberOfPeopleWhoRated={pathway?.contentListById?.numberOfPeopleWhoRated}
            handleSharContentHeader={handleSharContentHeader}
            openRating={openRating}
            handleRefetch={handleEnroll}
            handleAddToLearning={handleAddToLearning}
            isNew={pathway?.contentListById?.isNew}
            description={pathway?.contentListById?.description}
          />
          <div>
            {pathway?.contentListById?.contents?.map((item: any, idx: number) => {
              const isExpanded = item === expandedItem;
              return (
                <PathwayContentTile
                  key={idx}
                  item={item}
                  type={PathwayType.pathway}
                  selectTile={setSelectedCourse}
                  setIsOpenPlaylist={setIsOpenPlaylist}
                  handleShareContentTile={handleShareContentTile}
                  setOpenActivity={setOpenActivity}
                  toggleIsExpanded={handleIsExpandedChange}
                  isExpanded={isExpanded}
                />
              );
            })}
          </div>
        </div>
      </Container>
      <Drawer
        anchor="right"
        open={openActivity}
        onClose={() => {
          setOpenActivity(false);
          setSelectedCourse([]);
        }}
      >
        {openActivity && (
          <ActivityDrawer
            course={selectedCourse}
            handleContentRefresh={pathwayRefetch}
            closeHandler={() => {
              setOpenActivity(false);
              setSelectedCourse([]);
            }}
          />
        )}
      </Drawer>
      {openShareContent && selectedCourse && (
        <ShareDialog
          open={openShareContent}
          course={selectedCourse}
          contentType={selectedCourse?.contentType ? selectedCourse.contentType : pageType === "pathway"? "pathway": "parentpathway"}
          shareLink={shareLink}
          handleClose={() => handleShareClose()}
        />
      )}
      {isOpenPlaylist ? (
        <PlayListDialog
          title={t('playlist_dialog_title')}
          description={t('playlist_dialog_discription')}
          open={isOpenPlaylist}
          contentId={selectedCourse.id}
          contentType={getContentType("course")}
          handleClose={() => setIsOpenPlaylist(false)}
        />
      ) : (
        ""
      )}

      {isEditRatingOpen && (
        <EditRatingDialog
          score={editRating}
          type={ContentType.PATHWAY}
          open={isEditRatingOpen}
          onClose={closeEditRatingDialog}
          onSubmitRating={onSubmit}
        />
      )}
      <ConfirmDialog
        disableBackdropClick
        open={isConfirmationOpen}
        title={t('confirmation')}
        message={t('submit_rating')}
        handleConfirmed={onSubmit as () => void}
        handleClose={closeConfirmationDialog}
      />
      {openWorkshop && workshopData && (
        <WorkshopDialog
          open={openWorkshop}
          handleClose={() => handleExpressClose()}
          data={workshopData && workshopData}
          handleLocationSelection={handleLocationSelection}
          handleDateSelection={handleDateSelection}
          selectedWorkshopDate={selectedWorkshopDate}
          selectedWorkshopLocation={selectedWorkshopLocation}
          handleExpressInterest={handleExpressInterest}
        />
      )}
      {openEnroll && (
        <EnrollDialog
          title={pathway?.contentListById?.name}
          data={enrollmentResult}
          pathwayEnrolldata={pathwayEnrolldata}
          open={openEnroll && pathwayEnrollResult}
          handleConfirmEnrollment={handleConfirmEnrollment}
          handlePathwayCourseClick={handlePathwayCourseClick}
          handleClose={() => handleEnrollClose()}
          courseLearnerId={userContext?.userContext?.learnerId}
          dialogType={ENROLLMENT_DIALOG_TYPES.PATHWAY}
          showLoader={showLoader}
          setShowLoader={setShowLoader}
          learnerEmail={userContext?.userContext?.learnerEmail}
          showPathwayList={showPathwayList}
          setShowPathwayList={setShowPathwayList}
          handleOpenWorkshop={handleOpenWorkshop}
        />
      )}
    </>
  );
};
