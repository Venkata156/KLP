import { Box, Typography, withStyles, Theme, useTheme } from "@material-ui/core";
import { LockOutlined as LockIcon } from '@material-ui/icons';
import { useTranslation } from "react-i18next";
import { SESSION_STOREAGE_KEYS } from "utils/constants";

const TitleText = withStyles((theme: Theme) => ({
    root: {
        fontFamily: `ArialMT`,
        fontSize: `50px`,
        color: sessionStorage.getItem(SESSION_STOREAGE_KEYS.THEME_COLOR) || theme.palette.primary.main,
        letterSpacing: `1.25px`,
        fontWeight: 700,
        textAlign: `center`,
        textTransform: `uppercase`,
    },
}))(Typography);

const GreyText = withStyles((theme: Theme) => ({
    root: {
        color: theme.palette.grey['500'],
        letterSpacing: 0,
        textAlign: "center",
        lineHeight: "39px",
        fontWeight: 400,
    },
}))(Typography);

const CloseWindowText = withStyles(() => ({
    root: {
        fontSize: "26px",
        width: "90%",
    },
}))(GreyText);

export const Unauthorized = (): JSX.Element => {
    const { t } = useTranslation();
    const theme = useTheme();
    return (
        <Box display="flex" flexDirection="column" alignItems="center" justifyContent="center" height="100vh">
            <LockIcon style={{ fontSize: '76px' }} htmlColor={sessionStorage.getItem(SESSION_STOREAGE_KEYS.THEME_COLOR) || theme.palette.primary.main} />
            <TitleText>
                {t('not_authorized', "Access Denied")}
            </TitleText>
            <CloseWindowText>
                {t('not_authorized_dialog', "You do not have access this site. If you feel you have received this message in error, please contact the help desk to request the appropriate access.")}
            </CloseWindowText>
        </Box>
    );
};
