import { useMediaQuery } from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import { LearningSection, Tabs, TabPanel } from "components";
import React, { useState } from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { RootState, useAppDispatch } from "store";
import { CATEGORY_CODE_REQUIRED, CATEGORY_CODE_MYINTEREST } from "utils/constants";
import { usePageTitle } from "hooks";
import { useTranslation } from "react-i18next";

export const MyLearning = (): JSX.Element => {
  const history = useHistory();
  const dispatch = useAppDispatch();
  usePageTitle("Learning Platform");
  const userContext = useSelector((state: RootState) => state.core.userContext?.userContext);
  const [selectedCourse, setSelectedCourse] = useState<any>([]);
  const renderOrder = [CATEGORY_CODE_REQUIRED, CATEGORY_CODE_MYINTEREST];
  const [activeTab, setActiveTab] = useState(renderOrder[0]);
  const [viewActivityClick, setViewActivityClick] = useState(false);
  const [openShareContent, setOpenShareContent] = useState<boolean>(false);
  const [openActivity, setOpenActivity] = useState<boolean>(false);
  const [reloadPlaylist, setReloadPlaylist] = useState<boolean>(false);
  const [shareLink, setShareLink] = useState<any>("");
  const [isOpenPlaylist, setIsOpenPlaylist] = useState<boolean>(false);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const { t } = useTranslation();
  const learningSections: any = {};
  const handleChange = (event: React.ChangeEvent<unknown>, newValue: any) => {
    setActiveTab(newValue);
  };
  (learningSections[CATEGORY_CODE_REQUIRED] = {
    code: CATEGORY_CODE_REQUIRED,
    title: t("my_learning"),
    subTitle: t("my_learning_subtitle"),
    setIsOpenPlaylist: setIsOpenPlaylist,
    selectTileHandler: setSelectedCourse,
    setOpenShareContent: setOpenShareContent,
    setOpenActivity: setOpenActivity,
  }),
    (learningSections[CATEGORY_CODE_MYINTEREST] = {
      code: CATEGORY_CODE_MYINTEREST,
      title: t("learningsection_myplaylist_title"),
      subTitle: t("learningsection_myplaylist_subtitle"),
      reload: reloadPlaylist,
      setReload: setReloadPlaylist,
      setIsOpenPlaylist: setIsOpenPlaylist,
      selectTileHandler: setSelectedCourse,
      setOpenShareContent: setOpenShareContent,
      setOpenActivity: setOpenActivity,
    });
  return (
    <>
      <Tabs
        value={activeTab}
        aria-label={t("aria_label_course_details_activities_tabs")}
        tabs={renderOrder.map((section: string) => {
          const tabData: any = {};
          tabData.label = learningSections[section].title;
          tabData.value = section;
          return tabData;
        })}
        onChange={handleChange}
      />
      {renderOrder.map((section: string) => (
        <TabPanel key={section} value={activeTab} index={section} style={{ padding: "24px 0" }}>
          <LearningSection key={section} {...learningSections[section]} />
        </TabPanel>
      ))}
    </>
  );
};
