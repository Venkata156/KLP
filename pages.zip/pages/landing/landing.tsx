import { useQuery } from "@apollo/client";
import { Box, Container, Drawer, useMediaQuery } from "@material-ui/core";
import { Theme, useTheme, withStyles } from "@material-ui/core/styles";
import { setCustomCatalogTitle } from "store/core";
import {
  ActivityDrawer,
  Welcome,
  ShareDialog,
  PlayListDialog,
  MobileDrawer,
  LearningCarouselContainer,
} from "components";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { RootState, useAppDispatch } from "store";
import {
  CATEGORY_CODE_REQUIRED,
  CATEGORY_CODE_POPULAR,
  CATEGORY_CODE_RECOMMENDED,
  CATEGORY_CODE_MYINTEREST,
  CATEGORY_CODE_CHANNEL,
  SORT_ALPHABETICAL_ASCENDING
} from "utils/constants";
import * as WelcomeTypes from "utils/graphql/Welcome";
import { GET_LEARNER_METRICS, GET_WELCOME_MESSAGE } from "utils/queries";
import * as LearnersMetricsTypes from "utils/graphql/LearnersMetrics";
import { sum } from "lodash";
import { getContentType } from "utils/helpers";
import { useBreadCrumbs, usePageTitle } from "hooks";
import { MobileBottomContainer } from "components/fixed-mobile-button/fixed-mobile-button";
import { useTranslation } from "react-i18next";
import portalSettingsManager from "utils/portalSettingsManager";
import { MyLearningCarouselContainer } from "components/learning-carousel/mylearning-carousel-container";

const LandingContainer = withStyles((theme: Theme) => ({
  root: {
    "& hr:last-of-type": {
      display: "none",
    },
  },
}))(Container);

export const Landing = (): JSX.Element => {
  const history = useHistory();
  const dispatch = useAppDispatch();
  usePageTitle('Learning Platform')
  const userContext = useSelector((state: RootState) => state.core.userContext?.userContext);
  const [selectedCourse, setSelectedCourse] = useState<any>([]);
  const [viewActivityClick, setViewActivityClick] = useState(false);
  const [openShareContent, setOpenShareContent] = useState<boolean>(false);
  const [openActivity, setOpenActivity] = useState<boolean>(false);
  const [reloadPlaylist, setReloadPlaylist] = useState<boolean>(false);
  const [shareLink, setShareLink] = useState<any>("");
  const [isOpenPlaylist, setIsOpenPlaylist] = useState<boolean>(false);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const { t } = useTranslation();

  const {
    data: welcome,
  } = useQuery<WelcomeTypes.Welcome>(GET_WELCOME_MESSAGE, { fetchPolicy: "no-cache" });

  const {
    data: metricsList,
  } = useQuery<LearnersMetricsTypes.LearnersMetrics>(GET_LEARNER_METRICS, {
    fetchPolicy: "no-cache",
  });

  const handleViewAll = () => {
    history.push("/catalog");
  };

  useEffect(() => {
    if (selectedCourse) {
      setShareLink(window.location.href + `${selectedCourse.contentType}/${selectedCourse?.id}`);
    }
  }, [selectedCourse]);
  const { handleBreadCrumb } = useBreadCrumbs();

  useEffect(() => {
    handleBreadCrumb({ title: t('home'), path: "/" }, "home", "");
    sessionStorage.setItem("relatedItemClick", "false");
    dispatch(setCustomCatalogTitle(false));
    dispatch({
      type: "subheader/title",
      payload: "",
    });
    dispatch({ type: "search/setSearchFilters", payload: { sort: SORT_ALPHABETICAL_ASCENDING } });

  }, []);
  const learningSections: any = {};
  learningSections[CATEGORY_CODE_RECOMMENDED] = {
    code: CATEGORY_CODE_RECOMMENDED,
    title: t('learningsection_recommendations_title'),
    subTitle: t('learningsection_recommendations_subtitle'),
    setIsOpenPlaylist: setIsOpenPlaylist,
    selectTileHandler: setSelectedCourse,
    setOpenShareContent: setOpenShareContent,
    setOpenActivity: setOpenActivity
  },
    learningSections[CATEGORY_CODE_POPULAR] = {
      code: CATEGORY_CODE_POPULAR,
      title: t('popular_items'),
      subTitle: t('popular_items_subtitle'),
      setIsOpenPlaylist: setIsOpenPlaylist,
      selectTileHandler: setSelectedCourse,
      setOpenShareContent: setOpenShareContent,
      setOpenActivity: setOpenActivity
    }
  learningSections[CATEGORY_CODE_REQUIRED] = {
    code: CATEGORY_CODE_REQUIRED,
    subCategoryProps: {
      [CATEGORY_CODE_REQUIRED]: {},
      [CATEGORY_CODE_MYINTEREST]: {
        reload: reloadPlaylist,
        setReload: setReloadPlaylist,
      }, [CATEGORY_CODE_CHANNEL]: {}
    },
    title: t('my_learning'),
    subTitle: t('my_learning_subtitle'),
    reload: reloadPlaylist,
    setIsOpenPlaylist: setIsOpenPlaylist,
    selectTileHandler: setSelectedCourse,
    setOpenShareContent: setOpenShareContent,
    setOpenActivity: setOpenActivity
  }

  const numberOfSections = portalSettingsManager.application?.common?.landingPageSectionsOrder?.length || 0;
  return (
    <>
      <Welcome
        name={userContext?.userDisplayName}
        isLandingPage={true}
        message={welcome?.message?.welcomeText}
        learningCount={(metricsList?.learnersMetrics?.requiredLearning?.total && metricsList?.learnersMetrics?.requiredLearning?.total !== 0)
          ? (`${metricsList?.learnersMetrics?.requiredLearning?.complete || 0}/${metricsList?.learnersMetrics?.requiredLearning?.total || 0
            }`) : 0}
        completionCount={sum([
          metricsList?.learnersMetrics?.requiredLearning?.complete || 0,
          metricsList?.learnersMetrics?.otherLearnings?.complete || 0,
        ])}
        certificationCount={metricsList?.learnersMetrics?.certifications?.complete}
        metricsList={metricsList}
      />
      <LandingContainer style={{ width: "100%", maxWidth: "100%", paddingLeft: isMobile ? undefined : "60px", paddingRight: isMobile ? undefined : "10px" }}>
        <Box>
          {portalSettingsManager.application?.common?.landingPageSectionsOrder?.map((section, index) => {
            const showDivider = index !== (numberOfSections - 1);
            return section === CATEGORY_CODE_REQUIRED ? (
              <MyLearningCarouselContainer key={section} {...learningSections[section]} showDivider={showDivider} />
            ) : (
              <LearningCarouselContainer key={section} {...learningSections[section]} showDivider={showDivider} />
            )
          })}
        </Box>
      </LandingContainer>
      <MobileBottomContainer bgcolor={theme.palette.primary.main}>
        <MobileBottomContainer.Button onClick={handleViewAll}>
          {t('add_more_to_my_learning')}
        </MobileBottomContainer.Button>
      </MobileBottomContainer>
      {isMobile ? (
        <MobileDrawer
          isOpen={openActivity}
          onVisibilityChange={() => {
            setOpenActivity(false);
            setSelectedCourse([]);
          }}
        >
          {openActivity && (
            <ActivityDrawer
              course={selectedCourse}
              handleContentRefresh={() => setViewActivityClick(!viewActivityClick)}
              closeHandler={() => {
                setOpenActivity(false);
                setSelectedCourse([]);
              }}
            />
          )}
        </MobileDrawer>
      ) : (
        <Drawer
          anchor="right"
          open={openActivity}
          onClose={() => {
            setOpenActivity(false);
            setSelectedCourse([]);
          }}
        >
          {openActivity && (
            <ActivityDrawer
              course={selectedCourse}
              handleContentRefresh={() => setViewActivityClick(!viewActivityClick)}
              closeHandler={() => {
                setOpenActivity(false);
                setSelectedCourse([]);
              }}
            />
          )}
        </Drawer>
      )}
      {openShareContent && selectedCourse && (
        <ShareDialog
          open={openShareContent}
          course={selectedCourse}
          contentType={selectedCourse?.contentType}
          shareLink={shareLink}
          handleClose={() => {
            setOpenShareContent(false);
            setSelectedCourse([]);
          }}
        />
      )}
      {isOpenPlaylist ? (
        <PlayListDialog
          title={t('playlist_dialog_title')}
          description={t('playlist_dialog_discription')}
          isLanding={true}
          reload={setReloadPlaylist}
          open={isOpenPlaylist}
          contentId={selectedCourse.id}
          contentType={getContentType("course")}
          handleClose={() => setIsOpenPlaylist(false)}
        />
      ) : (
        ""
      )}
    </>
  );
};
