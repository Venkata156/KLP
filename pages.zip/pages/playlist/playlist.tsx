import { useMutation, useQuery } from "@apollo/client";
import { Container, Drawer } from "@material-ui/core";
import {
  ActivityDrawer,
  PathwayContentHeader,
  PathwayContentTile,
  SubHeader,
  ShareDialog,
  PlayListDialog,
  ConfirmDialog,
  PlayListEditDialog,
} from "components";
import { get } from "lodash";
import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useAppDispatch } from "store";
import { SORT_NONE } from "utils/constants";
import * as ContainerContentTypes from "utils/graphql/ContentContainer";
import { getContentType, parseSortType } from "utils/helpers";
import { EDIT_PLAYLIST, GET_CONTENT_LIST, REMOVE_CONTENT_FROM_PLAYLIST } from "utils/queries";
import { useBreadCrumbs } from "hooks";
import * as EditPlaylistTypes from "utils/graphql/EditPlaylist";
import { PathwayType } from "utils/types";
import { useTranslation } from "react-i18next";

export const Playlist = (): JSX.Element => {
  const params = useParams();

  const id = useMemo(() => {
    return get(params, "id", -1);
  }, [params]);

  const [selectedCourse, setSelectedCourse] = useState<any>([]);
  const [openShareContent, setOpenShareContent] = useState<boolean>(false);
  const [openActivity, setOpenActivity] = useState<boolean>(false);
  const [selectedSort, setSelectedSort] = useState(SORT_NONE);
  const [isOpenPlaylist, setIsOpenPlaylist] = useState<boolean>(false);
  const [isOpenEditPlaylist, setIsOpenEditPlaylist] = useState<boolean>(false);
  const [confirmRemoveCourse, setConfirmRemoveCourse] = useState<boolean>(false);
  const [removeContentFromPlaylist] = useMutation(REMOVE_CONTENT_FROM_PLAYLIST);
  const [shareLink, setShareLink] = useState<string>("");

  const [param, setParam] = useState({
    parentId: id,
    parentType: "Playlist",
  });

  const dispatch = useAppDispatch();
  const [savePlaylist] = useMutation(EDIT_PLAYLIST);
  const { t } = useTranslation();

  const updatePlaylist = (name: string, summary: string) => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: true, message: t('playlist_loading') },
    });
    const payload: EditPlaylistTypes.EditPlaylistVariables = {
      payload: {
        playlistId: playlist?.contentListById?.id,
        title: name,
        summary: summary,
      },
    };
    savePlaylist({ variables: { ...payload } })
      .then(() => {
        setIsOpenEditPlaylist(false);
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('playlist_loading') },
        });
        dispatch({
          type: "alert/show",
          payload: {
            type: t('success'),
            title: t('edit_playlist'),
            message: t('playlist_updated_successfully'),
          },
        });
        setTimeout(() => {
          updateContent();
        }, 2000);
      })
      .catch(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('playlist_loading') },
        });
        dispatch({
          type: "alert/show",
          payload: {
            type: t('error'),
            title: t('edit_playlist'),
            message: t('playlist_update_error'),
          },
        });
      });
  };

  useEffect(() => {
    if (selectedSort && selectedSort !== SORT_NONE) {
      const param = {
        parentId: id,
        parentType: "Playlist",
        sort: parseSortType(selectedSort),
      };
      setParam(param);
    }
  }, [selectedSort]);

  const removeCourseFromPlaylist = () => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: true, message: t('remove_course_from_playlist') },
    });

    removeContentFromPlaylist({
      variables: { playlistId: playlist?.contentListById?.id, contentId: selectedCourse.id },
    })
      .then(() => {
        setTimeout(() => {
          updateContent();
        }, 2000);
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('remove_course_from_playlist') },
        });
        dispatch({
          type: "alert/show",
          payload: {
            type: t('success'),
            title: t('playlist'),
            message: t('course_removed_from_playlist_success_message'),
          },
        });
      })
      .catch(() => {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('remove_course_from_playlist') },
        });
        dispatch({
          type: "alert/show",
          payload: {
            type: t('error'),
            title: t('pathway'),
            message: t('course_removed_from_playlist_error_message'),
          },
        });
      });
  };
  const {
    loading: playlistLoading,
    data: playlist,
    refetch: updateContent,
  } = useQuery<ContainerContentTypes.ContentContainer>(GET_CONTENT_LIST, {
    variables: param,
    notifyOnNetworkStatusChange: true,
    fetchPolicy: "no-cache",
  });

  useEffect(() => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: playlistLoading, message: t('playlist_loading') },
    });
  }, [playlistLoading]);

  const { handleBreadCrumb, breadCrumbData, handleBreadCrumbNavigation } = useBreadCrumbs();
  useEffect(() => {
    if (breadCrumbData && playlist?.contentListById?.name) {
      handleBreadCrumb(
        { title: playlist?.contentListById?.name, path: location.pathname, type: "playlist" },
        "playlist",
        ""
      );
    }
  }, [playlist]);

  const handleSharContentHeader = () => {
    setOpenShareContent(true);
    setSelectedCourse(playlist?.contentListById);
    setShareLink(window.location.href);
  };

  const handleShareContentTile = (item: any) => {
    setSelectedCourse(item);
    setOpenShareContent(true);
    setShareLink(window.location.origin + `/${item.contentType}/${item?.id}`);
  };

  const handleShareClose = () => {
    setOpenShareContent(false);
    setSelectedCourse([]);
    setShareLink("");
  };

  const validatePlaylistContent = () => {
    // if(playlist && playlist.contentListById && playlist.contentListById.contents && playlist.contentListById.contents.length <= 1) {
    //   dispatch({
    //     type: "alert/show",
    //     payload: {
    //       type: "error",
    //       title: "Playlist",
    //       message: "You can not delete all courses. Playlist must have atleast one course",
    //     },
    //   });
    //   return false;
    // }
    setConfirmRemoveCourse(true);
  };
  const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
    handleBreadCrumbNavigation(path, breadCrumbKey);
  };
  return (
    <>
      {playlist?.contentListById && (
        <SubHeader
          contentType='playlist'
          breadCrumbData={breadCrumbData}
          handleBreadCrumbClick={handleBreadCrumbClick}
        />
      )}
      <Container>
        <div>
          <PathwayContentHeader
            id={playlist?.contentListById?.id}
            title={playlist?.contentListById?.name}
            type={PathwayType.playlist}
            editPlaylist={() => setIsOpenEditPlaylist(true)}
            updatedOnDisplay={playlist?.contentListById?.updatedOnDisplay}
            tags={playlist?.contentListById?.tags}
            selectSort={setSelectedSort}
            contentMetrics={playlist?.contentListById?.contentMetrics}
            hasCertificate={playlist?.contentListById?.hasCertificate}
            isEnrolled={playlist?.contentListById?.isEnrolled}
            percentageComplete={playlist?.contentListById?.percentageComplete}
            course={playlist?.contentListById}
            handleSharContentHeader={handleSharContentHeader}
            isNew={playlist?.contentListById?.isNew}
            description={playlist?.contentListById?.summary}
          />
          <div>
            {playlist?.contentListById?.contents?.map((item: any, idx: number) => {
              return (
                <PathwayContentTile
                  key={idx}
                  item={item}
                  type={PathwayType.playlist}
                  selectTile={setSelectedCourse}
                  setIsOpenPlaylist={setIsOpenPlaylist}
                  setConfirmRemoveCourse={validatePlaylistContent}
                  handleShareContentTile={handleShareContentTile}
                  setOpenActivity={setOpenActivity}
                />
              );
            })}
          </div>
        </div>
      </Container>
      <Drawer
        anchor="right"
        open={openActivity}
        onClose={() => {
          setOpenActivity(false);
          setSelectedCourse([]);
        }}
      >
        {openActivity && (
          <ActivityDrawer
            course={selectedCourse}
            handleContentRefresh={updateContent}
            closeHandler={() => {
              setOpenActivity(false);
              setSelectedCourse([]);
            }}
          />
        )}
      </Drawer>
      {openShareContent && selectedCourse && (
        <ShareDialog
          open={openShareContent}
          course={selectedCourse}
          contentType={selectedCourse?.contentType ? selectedCourse.contentType : 'playlist'}
          shareLink={shareLink}
          handleClose={() => handleShareClose()}
        />
      )}
      {isOpenPlaylist ? (
        <PlayListDialog
          title={t('playlist_dialog_title')}
          description={t('playlist_dialog_discription')}
          open={isOpenPlaylist}
          contentId={selectedCourse.id}
          contentType={getContentType('course')}
          handleClose={() => setIsOpenPlaylist(false)}
        />
      ) : (
        ""
      )}
      {confirmRemoveCourse && (
        <ConfirmDialog
          open={confirmRemoveCourse}
          title={t('remove_course')}
          message={t('remove_course_message')}
          handleConfirmed={removeCourseFromPlaylist}
          handleClose={() => setConfirmRemoveCourse(false)}
        />
      )}

      {isOpenEditPlaylist && (
        <PlayListEditDialog
          itemDetail={playlist?.contentListById}
          updatePlaylist={updatePlaylist}
          open={isOpenEditPlaylist}
          title={t('edit_playlist')}
          handleClose={() => setIsOpenEditPlaylist(false)}
        />
      )}
    </>
  );
};
