import { useTranslation } from "react-i18next";

export const About = (): JSX.Element => {
  const { t } = useTranslation();
  return (
    <div>
      <h2>{t('about_page_title')}</h2>
    </div>
  );
};
