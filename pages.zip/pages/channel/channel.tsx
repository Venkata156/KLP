import { useQuery } from "@apollo/client";
import { Container, Drawer } from "@material-ui/core";
import {
  ActivityDrawer,
  PathwayContentHeader,
  PathwayContentTile,
  SubHeader,
  ShareDialog,
  PlayListDialog,
  EditRatingDialog,
  ConfirmDialog,
} from "components";
import { useRating, useBreadCrumbs } from "hooks";
import { get } from "lodash";
import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useAppDispatch } from "store";
import { SORT_NONE } from "utils/constants";
import * as ContainerContentTypes from "utils/graphql/ContentContainer";
import { ContentType } from "utils/graphql/Global";
import { getContentType, parseSortType } from "utils/helpers";
import { GET_CONTENT_LIST } from "utils/queries";
import { PathwayType } from "utils/types";
import { useTranslation } from "react-i18next";

export const Channel = (): JSX.Element => {
  const params = useParams();
  const parentType = "Channel";

  const id = useMemo(() => {
    return get(params, "id", -1);
  }, [params]);

  const [selectedCourse, setSelectedCourse] = useState<any>([]);
  const [selectedSort, setSelectedSort] = useState(SORT_NONE);
  const [openShareContent, setOpenShareContent] = useState<boolean>(false);
  const [openActivity, setOpenActivity] = useState<boolean>(false);
  const [isOpenPlaylist, setIsOpenPlaylist] = useState<boolean>(false);
  const [shareLink, setShareLink] = useState<string>("");

  const dispatch = useAppDispatch();
  const { t } = useTranslation();

  const [param, setParam] = useState({
    parentId: id,
    parentType,
  });

  const {
    loading: channelLoading,
    data: channel,
    refetch: handleChannelRefetch,
  } = useQuery<ContainerContentTypes.ContentContainer>(GET_CONTENT_LIST, {
    variables: param,
    notifyOnNetworkStatusChange: true,
    fetchPolicy: "no-cache",
  });

  useEffect(() => {
    if (selectedSort && selectedSort !== SORT_NONE) {
      const param = {
        parentId: id,
        parentType,
        sort: parseSortType(selectedSort),
      };
      setParam(param);
    }
  }, [selectedSort]);

  useEffect(() => {
    dispatch({
      type: "loader/showandhide",
      payload: { show: channelLoading, message: t('channel_loading') },
    });
  }, [channelLoading]);

  const {
    rating: editRating,
    openRating,
    onSubmit,
    isEditRatingOpen,
    closeEditRatingDialog,
    isConfirmationOpen,
    closeConfirmationDialog,
  } = useRating(
    channel?.contentListById?.id,
    ContentType.CHANNEL,
    handleChannelRefetch,
    channel?.contentListById?.statusCode.toLowerCase() === 'enrolled' ||
      channel?.contentListById?.statusCode === null
      ? 'Completed'
      : ""
  );

  const { handleBreadCrumb, breadCrumbData, handleBreadCrumbNavigation } = useBreadCrumbs();
  useEffect(() => {
    if (breadCrumbData && channel?.contentListById?.name) {
      handleBreadCrumb(
        { title: channel?.contentListById?.name, path: location.pathname, type: parentType },
        parentType,
        ""
      );
    }
  }, [channel]);

  const handleRefetch = () => {
    dispatch({ type: "loader/showandhide", payload: { show: true, message: t('channel_loading') } });
    setTimeout(() => {
      try {
        handleChannelRefetch();
      } catch (err) {
        dispatch({
          type: "loader/showandhide",
          payload: { show: false, message: t('channel_loading') },
        });
      }
    }, 5000);
  };
  const handleSharContentHeader = () => {
    setOpenShareContent(true);
    setSelectedCourse(channel?.contentListById);
    setShareLink(window.location.href);
  };

  const handleShareContentTile = (item: any) => {
    setSelectedCourse(item);
    setOpenShareContent(true);
    setShareLink(window.location.origin + `/${item.contentType}/${item?.id}`);
  };

  const handleShareClose = () => {
    setOpenShareContent(false);
    setSelectedCourse([]);
    setShareLink("");
  };
  const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
    handleBreadCrumbNavigation(path, breadCrumbKey);
  };
  return (
    <>
      {channel?.contentListById && (
        <SubHeader
          contentType={parentType}
          breadCrumbData={breadCrumbData}
          handleBreadCrumbClick={handleBreadCrumbClick}
        />
      )}
      <Container>
        <div>
          <PathwayContentHeader
            id={channel?.contentListById?.id}
            title={channel?.contentListById?.name}
            type={PathwayType.channel}
            updatedOnDisplay={channel?.contentListById?.updatedOnDisplay}
            tags={channel?.contentListById?.tags}
            contentMetrics={channel?.contentListById?.contentMetrics}
            hasCertificate={channel?.contentListById?.hasCertificate}
            isEnrolled={channel?.contentListById?.isEnrolled}
            percentageComplete={channel?.contentListById?.percentageComplete}
            selectSort={setSelectedSort}
            rating={channel?.contentListById?.rating}
            numberOfPeopleWhoRated={channel?.contentListById?.numberOfPeopleWhoRated}
            handleSharContentHeader={handleSharContentHeader}
            openRating={openRating}
            handleRefetch={handleRefetch}
            isNew={channel?.contentListById?.isNew}
            description={channel?.contentListById?.description}
            isAutoEnrolled={channel?.contentListById?.isAutoEnrolled}
          />
          <div>
            {channel?.contentListById?.contents?.map((item: any, idx: number) => {
              return (
                <PathwayContentTile
                  key={idx}
                  item={item}
                  type={PathwayType.channel}
                  selectTile={setSelectedCourse}
                  setIsOpenPlaylist={setIsOpenPlaylist}
                  handleShareContentTile={handleShareContentTile}
                  setOpenActivity={setOpenActivity}
                />
              );
            })}
          </div>
        </div>
      </Container>
      <Drawer
        anchor="right"
        open={openActivity}
        onClose={() => {
          setOpenActivity(false);
          setSelectedCourse([]);
        }}
      >
        {openActivity && (
          <ActivityDrawer
            course={selectedCourse}
            handleContentRefresh={handleChannelRefetch}
            closeHandler={() => {
              setOpenActivity(false);
              setSelectedCourse([]);
            }}
          />
        )}
      </Drawer>
      {openShareContent && selectedCourse && (
        <ShareDialog
          open={openShareContent}
          course={selectedCourse}
          contentType={selectedCourse?.contentType ? selectedCourse.contentType : parentType}
          shareLink={shareLink}
          handleClose={() => handleShareClose()}
        />
      )}
      {isOpenPlaylist ? (
        <PlayListDialog
          title={t('playlist_dialog_title')}
          description={t('playlist_dialog_discription')}
          open={isOpenPlaylist}
          contentId={selectedCourse && selectedCourse.id}
          contentType={getContentType('course')}
          handleClose={() => setIsOpenPlaylist(false)}
        />
      ) : (
        ""
      )}

      {isEditRatingOpen && (
        <EditRatingDialog
          score={editRating}
          type={ContentType.CHANNEL}
          open={isEditRatingOpen}
          onClose={closeEditRatingDialog}
          onSubmitRating={onSubmit}
        />
      )}
      <ConfirmDialog
        disableBackdropClick
        open={isConfirmationOpen}
        title={t('confirmation_placeholder')}
        message={t('submit_rating')}
        handleConfirmed={onSubmit as () => void}
        handleClose={closeConfirmationDialog}
      />
    </>
  );
};
