import { Box, Typography, makeStyles, withStyles } from "@material-ui/core";
import { AvailableSkills } from "components/skills/availableSkills";
import { CurrentSkills } from "components/skills/currentSkills";
import { useTranslation } from "react-i18next";
import { useLazyQuery } from "@apollo/client";
import { LearnerSkillAssessments } from "utils/graphql/LearnerSkillAssessments";
import { GET_LEARNER_SKILL_ASSESSMENTS } from "utils/queries";
import { useEffect, useState } from "react";
import { useAppDispatch } from "store";
import { SKILL_STATUS } from "utils/constants";
import { QuestionaireNavigator } from "components/questionaire/questionaireDialog";
import { openUrlUtil } from "hooks/open-url";
import portalSettingsManager from "utils/portalSettingsManager";
import { tenantSettings } from "utils/authentication/tenantSettings";

const useStyles = makeStyles(() => ({
  skillsWrapper: {
    display: "flex",
    flexWrap: "wrap",
    flexDirection: "row",
  },
}));

const CardsHeader = withStyles(() => ({
  root: {
    fontSize: "16px",
    lineHeight: "18px",
    marginBottom: "10px",
  },
}))(Typography);

export const MySkills = () => {
  const showConfirmation = true;
  const { t } = useTranslation();
  const classes = useStyles();
  const dispatch = useAppDispatch();
  const [dataLoadFailed, setDataLoadFailed] = useState(false);
  const { openUrl } = openUrlUtil();

  const [
    getData,
    {
    loading: learnerSkillAssessmentLoading,
    data: learnerSkillAssessmentData,
    }
   ] = useLazyQuery<LearnerSkillAssessments>(GET_LEARNER_SKILL_ASSESSMENTS, {
    onError: () => {
      setDataLoadFailed(true);
    }
  });

  useEffect(()=>{
    getData();
  },[]);

  useEffect(() => {
    dispatch({
      type: "loader/showandhide",
      payload: {
        show: learnerSkillAssessmentLoading,
        message: t('profile_skills_loading'),
      },
    });
  }, [learnerSkillAssessmentLoading, dispatch, t]);


  const handleDialogClosed = (params: { confirmed: boolean }, skill: { skillName: string, skillAssessmentId: string, externalAssesmentId: string }) => {
    const contentTYpe = portalSettingsManager?.qualnate?.routeIdentifiers?.skill
    const skillURL = (portalSettingsManager?.qualnate?.routeIdentifiers?.url).replace("{TenantId}", tenantSettings.adConfiguration.auth.clientId).replace('{ContentType}', contentTYpe).replace('{QuetionnaireId}', skill.externalAssesmentId).replace('{Id}', skill.skillAssessmentId)
    if (params.confirmed) {
      const { isSuccess, windowEvent } = openUrl(skillURL, skill.skillName);
      const closeWindow = setInterval(function () {
        if (windowEvent?.closed) {
          clearInterval(closeWindow);
         getData();
        }
      }, 500);
    }
  };

  const currentSkills =
    learnerSkillAssessmentData?.learnerSkillAssessments?.filter(
      (skill) => skill.status === SKILL_STATUS.COMPLETED
    ) || [];
  const availableSkills =
    learnerSkillAssessmentData?.learnerSkillAssessments?.filter(
      (skill) => skill.status !== SKILL_STATUS.COMPLETED
    ) || [];

  const showContent = currentSkills.length > 0 || availableSkills.length > 0;

  const getHeaderText = () => {
    if (dataLoadFailed) {
      return t('profile_skills_header_error');
    }

    if (!showContent) {
      return;
    }

    if (!dataLoadFailed) {
      return (
        <>
          <span style={{ fontWeight: "bold", marginRight: "3px" }}>
            {t(
              'profile_skills_instructions_1',
              "Please choose a skill from the Available Assessments that you would like to add to your profile."
            )}
          </span>{" "}
          {t(
            'profile_skills_instructions_2',
            "Skill ratings range from 1 (beginner) to 5 (advanced). Skill assessments can be retaken at any time."
          )}
        </>
      );
    }
  };

  const getContent = () => {
    if (dataLoadFailed) {
      return;
    }
    if (!showContent && !learnerSkillAssessmentLoading) {
      return t('profile_skills_no_content');
    }

    return getSkills();
  };

  const getSkills = () => {
    return (
      <>
        {currentSkills.length > 0 && (
          <Box style={{ marginBottom: 30 }}>
            <CardsHeader>{t('current_skills')} ({currentSkills.length})</CardsHeader>
            <Box className={classes.skillsWrapper}>
              {currentSkills.map((skill) => (
                <Box style={{ marginRight: 25 }}>
                  <NavigationWrapper onDialogClosed={handleDialogClosed} skill={skill}>
                    <CurrentSkills skill={skill} key={skill.skillAssessmentId} />
                  </NavigationWrapper>
                </Box>
              ))}
            </Box>
          </Box>
        )}
        {availableSkills.length > 0 && (
          <Box>
            <CardsHeader>{t('available_assessments')} ({availableSkills.length})</CardsHeader>
            <Box className={classes.skillsWrapper}>
              {availableSkills.map((skill) => (
                <Box style={{ marginRight: 25 }}>
                  <NavigationWrapper onDialogClosed={handleDialogClosed} skill={skill}>
                    <AvailableSkills skill={skill} key={skill.skillAssessmentId} />
                  </NavigationWrapper>
                </Box>
              ))}
            </Box>
          </Box>
        )}
      </>
    );
  };

  return (
    <Box style={{ paddingBottom: "60px" }}>
      <Box mt={3} mb={3} fontSize={14}>
        {getHeaderText()}
      </Box>
      {(!showContent && !learnerSkillAssessmentLoading) ? <Box style={{ fontWeight: "bold" }}>{getContent()} </Box>: getContent()}
    </Box>
  );
};

const NavigationWrapper = ({ children, onDialogClosed, skill }) => {
  const [isNavigatorOpen, setIsNavigatorOpen] = useState(false);

  const handleClick = () => {
    setIsNavigatorOpen(true);
  };

  const handleNavigatorClose = (params: { confirmed: boolean }) => {
    setIsNavigatorOpen(false);
    onDialogClosed(params, skill);
  };

  return (
    <>
      <Box style={{ cursor: "pointer" }} onClick={handleClick}>
        {children}
      </Box>
      {isNavigatorOpen && <QuestionaireNavigator onClose={handleNavigatorClose} />}
    </>
  );
};