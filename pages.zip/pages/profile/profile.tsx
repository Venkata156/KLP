import { useLazyQuery, useMutation, useQuery } from "@apollo/client";
import {
  Container,
  Box,
  Typography,
  Button,
  IconButton,
  useMediaQuery,
  Select,
  MenuItem,
  FormControl,
  SvgIcon,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow
} from "@material-ui/core";
import { Theme, withStyles, styled, useTheme, makeStyles } from "@material-ui/core/styles";
import { EditOutlined, ArrowDropDown, ArrowDropUp } from "@material-ui/icons";
import certificationIcon from "assets/icons/icon-certification.svg";
import otherLearningIcon from "assets/icons/icon-course.svg";
import requiredIcon from "assets/icons/icon-required.svg";
import { ReactComponent as arrowIcon } from "assets/icons/icon-arrow-blue.svg";
import { emailRegex } from "utils/helpers";
import MuiButton from "@material-ui/core/Button";
import { useSelector } from "react-redux";
import {
  Accordion,
  D3Chart,
  EmailDialog,
  SubHeader,
  TabPanel,
  Tabs,
  Toggle,
  CounseleeAccordion,
  RemindDialog,
  MobileDrawer,
  Tooltip,
  theme,
  Paginator,
} from "components";
import { first, get, includes, pull, reduce, uniq } from "lodash";
import { ChangeEvent, useEffect, useMemo, useRef, useState } from "react";
import { RootState, useAppDispatch } from "store";
import { Link } from "react-router-dom";
import {
  PROFILE_FIELD_TYPE_NUMBER,
  PROFILE_FIELD_TYPE_SINGLE_LINE_TEXT,
  PROFILE_FIELD_TYPE_SINGLE_SELECT_DROPDOWN,
  PROFILE_TAB_DETAILS,
  PROFILE_TAB_TOPICS,
  PROFILE_TAB_COUNSELEES,
  PROFILE_TAB_LEARNER,
  PROFILE_TAB_CALENDAR,
  PROFILE_TAB_SKILLS,
} from "utils/constants";
import * as GlobalTypes from "utils/graphql/Global";
import * as LearnerProfileTypes from "utils/graphql/LearnerProfile";
import {
  LearnerProfile_learnerProfile_metaData_dataPoints,
  LearnerProfile_learnerProfile_metaData_dataPoints_items,
  LearnerProfile_learnerProfile_userProfile,
  LearnerProfile_learnerProfile_userProfile_dataPoints,
} from "utils/graphql/LearnerProfile";
import * as LearnersMetricsTypes from "utils/graphql/LearnersMetrics";
import * as CounseleesTypes from "utils/graphql/LearnersByLineManager";
import * as CounseleeItemTypes from "utils/graphql/CoursesAndPathwaysByLearner";
import * as ReportTypes from "utils/graphql/Reports";
import * as LearnerWorkshopsTypes from "utils/graphql/LearnerWorkshops";
import metricsIcon from "assets/icons/icon-metrics-temp.png";
import "utils/string-prototype";
import portalSettingsManager from "utils/portalSettingsManager";

import {
  GET_LEARNER_PROFILE,
  GET_LEARNER_METRICS,
  UPDATE_USER_PROFILE,
  EMAIL_UPDATE_STATUS,
  GET_COURSES_PATHWAYS_BY_LEARNER,
  GET_LEARNERS_BY_LINEMANAGER,
  GET_REPORTS,
  GET_MY_WORKSHOPS
} from "utils/queries";
import { ProfileTabType } from "utils/types";
import { useBreadCrumbs, useLearningRecords, } from "hooks";
import { useFocusStyles } from '../../hooks/focusBorder'
import { useTranslation } from "react-i18next";
import { useParams } from "react-router-dom";
import { openUrlUtil } from "hooks/open-url";
import { LearnerWorkshops_learnerWorkshopActivities_activities } from "utils/graphql/LearnerWorkshops";
import { LearnerWorkshopActivitiesSortBy } from "utils/graphql/Global";
import { MySkills } from "./ProfileSkills";
import { getIndex } from "@progress/kendo-react-data-tools";

const useStyles = makeStyles(theme => ({
  customHoverFocus: {
    '&:focus, &.Mui-focusVisible': { backgroundColor: 'rgba(0, 0, 0, 0.04)' }
  }
}))
const CustomSelect = withStyles(() => ({
  root: {
    paddingLeft: "8px",
  }
}))(Select);

const Email = withStyles((theme: Theme) => ({
  root: {
    maxWidth: "250px",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
    cursor: "pointer",
    fontWeight: "bold",
    fontSize: "13px"
  }
}))(Box);

const Clear = withStyles((theme: Theme) => ({
  root: {
    color: portalSettingsManager.application?.common?.themeColor,
    fontSize: "12px",
    fontWeight: 700,
    padding: '0px',
    float: "right",
    cursor: "pointer",
    display: "inline-block",
    marginTop: "6px"
  },
  outlined: {
    border: `1px solid ${portalSettingsManager.application?.common?.themeColor}`,
  },
  disabled: {
    color: theme.palette.grey['500'],
  },
}))(Box);

const ProfileField = withStyles((theme: Theme) => ({
  root: {
    "& label": {
      display: "block",
      fontSize: "12px",
      color: theme.palette.grey["500"],
    },
    "& label.with-clear": {
      display: "inline-block"
    },
    "& span": {
      fontSize: "14px",
      color: theme.palette.grey["800"],
      fontWeight: 700,
    },
    "& .MuiInput-underline": {
      width: "100%",
      borderBottom: "0px",
      "&:before": {
        borderBottom: "0px !important",
      },
      "&:after": {
        borderBottom: "0px",
      },
      "& .MuiSelect-icon": {
        right: "10px",
      },
    },
    "& select": {
      color: theme.palette.primary.main,
      fontSize: "12px",
      lineHeight: "30px",
    },
    "& button": {
      border: `1px solid ${theme.palette.primary.main}`,
      color: theme.palette.primary.main,
      position: "relative",
      left: "15px",
      top: "-2px",
      "&:focus": {
        outline: "none",
        border: "2px solid #000000"
      },
    },
    "& button span": {
      color: theme.palette.primary.main,
      fontSize: 12
    },
    "& p": {
      fontSize: "11px",
      color: theme.palette.grey["500"],
    },
  },
}))(Box);
ProfileField.displayName = "ProfileField";

const SaveButton = withStyles((theme: Theme) => ({
  root: {
    flex: 1,
    borderRadius: 0,
  },
  label: {
    fontSize: 11,
    fontWeight: 700,
  },
  outlined: {
    border: `1px solid ${theme.palette.grey["A100"]}`,
  },
  disabled: {
    color: theme.palette.grey["500"],
  },
}))(MuiButton);
SaveButton.displayName = "SaveButton";

const SectionCol2 = styled("section")(({ isMobile }: { isMobile?: boolean }) => {
  return {
    display: "grid",
    gridTemplateColumns: `repeat(${isMobile ? 1 : 2}, minmax(0, 1fr))`,
    gap: "1rem",
    marginTop: isMobile ? "20px" : undefined,
  };
});
SectionCol2.displayName = "SectionCol2";

const SectionCol3 = styled("section")(({ isMobile }: { isMobile?: boolean }) => {
  return {
    display: "grid",
    gridTemplateColumns: `repeat(${isMobile ? 1 : 3}, minmax(0, 1fr))`,
    gap: "1rem",
    margin: "20px 0",
    width: "100%"
  };
});
SectionCol3.displayName = "SectionCol3";

const CtlWrapper = withStyles((theme: Theme) => ({
  root: ({ width }: { width?: string }) => ({
    display: "flex",
    alignItems: "center",
    //   border: `1px solid ${theme.palette.grey["A100"]}`,
    width: width ?? "240px",
    minHeight: "40px",
    marginTop: "5px",
    padding: "0 12px 0 0",
    overflow: "visible",
    "& input": {
      color: theme.palette.primary.main,
      border: `1px solid ${theme.palette.grey["A100"]}`,
      width: "100%",
      padding: "10px",
      height: "12px",
      "&:focus": {
        outline: "none",
        border: "2px solid #000000"
      },
    },
    "& select": {
      color: theme.palette.common.black,
      border: `1px solid ${theme.palette.grey["A100"]}`,
      padding: "10px",
      width: "100%",
      fontSize: "12px",
      lineHeight: "30px",
      "&:focus": {
        outline: "none",
        border: "2px solid #000000"
      },
    },
  }),
}))(Box);
CtlWrapper.displayName = "CtlWrapper";

const Legend = withStyles((theme: Theme) => ({
  root: {
    fontSize: "12px",
    color: theme.palette.grey["500"],
    margin: theme.breakpoints.down("sm") ? "10px" : "10px",
    "&:before": {
      content: `""`,
      display: "inline-block",
      backgroundColor: (props: any) => props.color || portalSettingsManager.statusColors?.enrolled?.back || "#c6007e",
      width: "10px",
      height: "10px",
      borderRadius: "5px",
      marginRight: "10px",
    },
  },
}))(Typography);
Legend.displayName = "Legend";

const CustomFormControl = withStyles(() => ({
  root: ({ width }: { width?: string }) => ({
    width: width ?? "240px",
    border: "1px solid black",
    padding: "2px",
    "&:focus-within": {
      border: "2px solid #000000"
    }
  })
}))(FormControl);

const MetricsContainer: React.FC<{
  mobile: boolean;
  showMetrics: boolean;
  setShowMetrics: (show: boolean) => unknown;
}> = ({ mobile, showMetrics, setShowMetrics, children }) => {
  const { t } = useTranslation();
  return mobile ? (
    <MobileDrawer
      closeMessage={t('close_metrics')}
      isOpen={showMetrics}
      onVisibilityChange={setShowMetrics}
    >
      {children}
    </MobileDrawer>
  ) : (
    <Box>{children}</Box>
  );
};

export interface Autoenrolled_topics {
  id: string | null;
  name: string | null;
}

export const Profile = (): JSX.Element => {

  const params = useParams();

  const urlParam = useMemo(() => {
    return get(params, "activeTabId", PROFILE_TAB_DETAILS);
  }, [params]);

  const showProfileReport = portalSettingsManager.application.features.hasProfileReport;
  const showSkillAssessment = portalSettingsManager.application.features.hasSkillAssessment
  const theme = useTheme();
  const { t } = useTranslation();
  const classes = useStyles()
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));
  const isSmallScreen = useMediaQuery(theme.breakpoints.down("xs"));
  const userContext = useSelector((state: RootState) => state.core.userContext);
  const dispatch = useAppDispatch();
  const [isEmailUpdateInProgress, setIsEmailUpdateInProgress] = useState<boolean | null>(true);
  const [checkStatus, setCheckStatus] = useState<boolean | null>(true);
  const [sendReminder, setSendReminder] = useState<boolean>(false);
  const [learnerName, setLearnerName] = useState<string>("");
  const [remindData, setRemindData] = useState<any>(null);
  const {
    getresult,
    result,
    sendReminder: handleSendReminder,
  } = useLearningRecords(
    remindData?.learnerId,
    remindData?.id,
    remindData?.contentType,
    remindData?.name,
    remindData?.dueDate
  );
  const [expanded, setExpanded] = useState("");
  const [editEmail, setEditEmail] = useState<boolean>(false);
  const [initials, setInitials] = useState("");
  const [profile, setProfile] = useState<
    LearnerProfile_learnerProfile_userProfile | null | undefined
  >(null);
  const [topics, setTopics] = useState<
    LearnerProfileTypes.LearnerProfile_learnerProfile_metaData_topics[]
  >([]);
  const [editablePersonalConfig, setEditablePersonalConfig] = useState<
    LearnerProfile_learnerProfile_metaData_dataPoints[]
  >([]);
  const [readonlyPersonalConfig, setReadonlyPersonalConfig] = useState<
    LearnerProfile_learnerProfile_metaData_dataPoints[]
  >([]);
  const [readonlyProfessionalConfig, setReadonlyProfessionalConfig] = useState<
    LearnerProfile_learnerProfile_metaData_dataPoints[]
  >([]);
  const [editableProfessionalConfig, setEditableProfessionalConfig] = useState<
    LearnerProfile_learnerProfile_metaData_dataPoints[]
  >([]);
  const [formValues, setFormValues] = useState<Record<string, string | null> | null>(null);
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);
  const [autoEnrolledTopics, setAutoEnrolledTopics] = useState<Autoenrolled_topics[]>([]);
  const [dirtyTabIndices, setDirtyTabIndices] = useState<ProfileTabType[]>([]);
  const [currentTabIndex, setCurrentTabIndex] = useState<ProfileTabType>(urlParam && urlParam === "1" ? PROFILE_TAB_TOPICS : PROFILE_TAB_DETAILS);
  const [certification, setCertification] = useState<any[]>([]);
  const [requiredLearning, setRequiredLearning] = useState<any[]>([]);
  const [otherLearnings, setOtherLearnings] = useState<any[]>([]);
  const [showPersonalDetails, setShowPersonalDetails] = useState<boolean>(false);
  const [showProfessionalDetails, setShowProfessionalDetails] = useState<boolean>(false);
  const [canChangeEmailAddress, setCanChangeEmailAddress] = useState<boolean>(false);

  const {
    data: profileData,
    loading: profileLoading,
    refetch: profileRefetch,
  } = useQuery<LearnerProfileTypes.LearnerProfile>(GET_LEARNER_PROFILE, {
    fetchPolicy: "no-cache",
  });

  const { data: emailUpdateInProgressData, refetch: emailUpdateInProgressRefetch } = useQuery<any>(
    EMAIL_UPDATE_STATUS,
    { fetchPolicy: "no-cache" }
  );

  const { data: metricsList, loading: metricsLoading } = useQuery<LearnersMetricsTypes.LearnersMetrics>(
    GET_LEARNER_METRICS,
    {
      fetchPolicy: "no-cache",
    }
  );

  // state for mobile metrics view
  const [showMetrics, setShowMetrics] = useState(false);

  const [
    getCounseleeItemDetail,
    {
      data: counseleeItems,
      loading: counseleeItemsLoading
      // refetch:refreshCounsleeItems
    },
  ] = useLazyQuery<CounseleeItemTypes.CoursesAndPathwaysByLearnerVariables>(
    GET_COURSES_PATHWAYS_BY_LEARNER
  );

  const { data: counseleesList, loading: counseleeListLoading } = useQuery<CounseleesTypes.LearnersByLineManager>(
    GET_LEARNERS_BY_LINEMANAGER
  );

  const [updateProfile] = useMutation(UPDATE_USER_PROFILE);

  const [learnerDiagnostics, setlearnerDiagnostics] = useState<ReportTypes.Reports>();

  const [
    getLearnerDiagonistics,
    { data: learnerDiagnosticsData, loading: learnerDiagnosticsLoading },
  ] = useLazyQuery<ReportTypes.Reports>(GET_REPORTS, {
    onError: () => {
      setLearnerReportsDataFailed(true);
    }
  });

  useEffect(() => {
    dispatch({
      type: "loader/showandhide",
      payload: {
        show:
          profileLoading ||
          counseleeItemsLoading ||
          counseleeListLoading ||
          metricsLoading ||
          learnerDiagnosticsLoading,
        message: t('profile_loading'),
      },
    });
  }, [
    profileLoading,
    counseleeItemsLoading,
    counseleeListLoading,
    metricsLoading,
    learnerDiagnosticsLoading,
    dispatch,
  ]);

  const [learnerReportsDataFailed, setLearnerReportsDataFailed] = useState(false);

  useEffect(() => {
    if (showProfileReport) {
      getLearnerDiagonistics();
    }
  }, [showProfileReport]);

  useEffect(() => {
    if (!learnerDiagnosticsLoading) {
      setlearnerDiagnostics(learnerDiagnosticsData);
    }
  }, [learnerDiagnosticsData]);

  useEffect(() => {
    if (emailUpdateInProgressData) {
      setIsEmailUpdateInProgress(
        emailUpdateInProgressData?.isUpdateEmailRequestPending ? true : false
      );
    }
  }, [emailUpdateInProgressData, checkStatus]);

  useEffect(() => {
    const colors = [
      { color: portalSettingsManager.statusColors?.enrolled?.back || "#C6007E", type: "enrolled" },
      { color: portalSettingsManager.statusColors?.inprogress?.back || "#005EB8", type: "inProgress" },
      { color: portalSettingsManager.statusColors?.completed?.back || "#16837D", type: "complete" },
    ];

    if (metricsList) {
      const learnerMetrics = metricsList.learnersMetrics || {};
      const certObject = formatMetricsObject(get(learnerMetrics, "certifications", {}));
      setCertification(certObject.map((item, i) => Object.assign({}, item, colors[i])));
      const reqLearningObject = formatMetricsObject(get(learnerMetrics, "requiredLearning", {}));
      setRequiredLearning(reqLearningObject.map((item, i) => Object.assign({}, item, colors[i])));
      const otherLearningObj = formatMetricsObject(get(learnerMetrics, "otherLearnings", {}));
      setOtherLearnings(otherLearningObj.map((item, i) => Object.assign({}, item, colors[i])));
    }
  }, [metricsList]);

  const { handleBreadCrumb, breadCrumbData, handleBreadCrumbNavigation } = useBreadCrumbs();
  useEffect(() => {
    if (breadCrumbData && profileData) {
      handleBreadCrumb({ title: t('profile'), path: "/profile", type: "profile" }, "profile", "");
    }
  }, [profileData]);

  const formatMetricsObject = (data: any) => {
    const metricsArray = [];
    for (const [key, value] of Object.entries(data)) {
      if (key !== "total" && key !== "__typename") {
        const obj = {
          value: value,
          text: value,
          type: key,
        };
        metricsArray.push(obj);
      }
    }
    return metricsArray;
  };

  const handleTabChange = (event: ChangeEvent<unknown>, newValue: ProfileTabType) => {
    setCurrentTabIndex(newValue);
  };

  const isTabDirty = (tab: ProfileTabType) => {
    return includes(dirtyTabIndices, tab);
  };

  const toggleTopic = (code: string) => {
    const originalLength = selectedTopics.length;
    pull(selectedTopics, code);

    if (selectedTopics.length === originalLength) {
      selectedTopics.push(code);
    }

    setSelectedTopics(uniq(selectedTopics).sort());
    setDirtyTabIndices(uniq([...dirtyTabIndices, PROFILE_TAB_TOPICS]));
  };

  const updateProfileValues = (gatewayCode: string, value: string | null) => {
    setFormValues({
      ...formValues,
      [gatewayCode]: value,
    });
    setDirtyTabIndices(uniq([...dirtyTabIndices, PROFILE_TAB_DETAILS]));
  };

  const createInput = (item: LearnerProfile_learnerProfile_metaData_dataPoints) => {
    const cleanOptions = (item.items || []).flatMap((option) => (option ? [option] : []));
    let value = get(formValues, item.code || "", null);
    const gatewayCode = item.code || "";

    const cleanLabel = t(item.code || "");

    if (!item.canEdit) {
      if (item.type === PROFILE_FIELD_TYPE_SINGLE_SELECT_DROPDOWN && cleanOptions && cleanOptions.length > 0) {
        const opt: LearnerProfile_learnerProfile_metaData_dataPoints_items | undefined = cleanOptions.find(o => o.code === value);
        value = opt?.name || "";
      }
      return (
        <ProfileField key={item.code}>
          <label htmlFor={cleanLabel} style={{ paddingBottom: "5px", marginTop: "6px" }}>{cleanLabel}</label>
          <Tooltip position="right" title={value ? value : ""}>
            <Email>{value}</Email>{" "}
          </Tooltip>
        </ProfileField>
      );
    }

    switch (item.type) {
      case PROFILE_FIELD_TYPE_SINGLE_LINE_TEXT:
        return (
          <ProfileField key={item.code}>
            <label tabIndex={0} aria-label={cleanLabel} htmlFor={cleanLabel} style={{ marginTop: "6px" }}>{cleanLabel}</label>
            <CtlWrapper width={isMobile ? "100%" : undefined}>
              <input
                id={cleanLabel}
                value={value || ""}
                onChange={(event) => updateProfileValues(gatewayCode, event.target.value)}
                aria-label={cleanLabel}
              />
            </CtlWrapper>
          </ProfileField>
        );
      case PROFILE_FIELD_TYPE_NUMBER:
        return (
          <ProfileField key={item.code}>
            <label htmlFor={cleanLabel}>{cleanLabel}</label>
            <CtlWrapper width={isMobile ? "100%" : undefined}>
              <input
                id={cleanLabel}
                type="number"
                value={value || ""}
                onChange={(event) => updateProfileValues(gatewayCode, event.target.value)}
              />
            </CtlWrapper>
          </ProfileField>
        );
      case PROFILE_FIELD_TYPE_SINGLE_SELECT_DROPDOWN:
        return (
          <ProfileField key={item.code}>
            <div style={{ width: isMobile ? 325 : 240 }}>
              <label id={cleanLabel} className="with-clear">{cleanLabel}</label>
              <Clear onClick={() => { value === null || value === "" ? false : updateProfileValues(gatewayCode, null) }} className={focusClass.focusItem} tabIndex={0} >{t('clear').toUpperCase()}</Clear>
            </div>
            <CtlWrapper width={isMobile ? "100%" : undefined}>
              <CustomFormControl width={isMobile ? "325px" : undefined}>
                <CustomSelect
                  id={cleanLabel}
                  aria-label={cleanLabel}
                  role="combobox"
                  tabIndex={-1}
                  // aria-expanded="true"
                  displayEmpty
                  style={{ fontSize: "12px" }}
                  value={value || ""}
                  MenuProps={{
                    anchorOrigin: {
                      vertical: "bottom",
                      horizontal: "left",
                    },
                    transformOrigin: {
                      vertical: "top",
                      horizontal: "left",
                    },
                    getContentAnchorEl: null,
                  }}
                  onChange={(event: any) => updateProfileValues(gatewayCode, event.target.value)}
                >
                  <MenuItem style={{ fontSize: "14px" }} value="" disabled className={focusClass.focusItem}
                    aria-labelledby={cleanLabel}>
                    {t('choose')}
                  </MenuItem>
                  {cleanOptions.map((item, idx) => (
                    <MenuItem style={{ fontSize: "12px" }} key={idx} value={item.code || idx} className={focusClass.focusItem}>
                      {item.name}
                    </MenuItem>
                  ))}
                </CustomSelect>
              </CustomFormControl>
            </CtlWrapper>
          </ProfileField>
        );
    }
  };

  const handleEditEmailClose = (updated: boolean) => {
    if (updated) {
      setIsEmailUpdateInProgress(true);
      setCheckStatus(!checkStatus);
      emailUpdateInProgressRefetch();
    }
    setEditEmail(false);
  };

  const handleSaveProfile = () => {
    dispatch({ type: "loader/showandhide", payload: { show: true } });
    const profileInfo = reduce(
      formValues,
      (result, value, key) => {
        result?.push({ code: key, value });
        return result;
      },
      [] as GlobalTypes.UserProfileInput[]
    );
    const subscribedChannels = selectedTopics.filter((value) => {
      return !(profile?.topicOfInterest?.findIndex(i => i.id === value) >= 0);
    });
    const unSubscribedChannels = (profileData.learnerProfile?.userProfile?.topicOfInterest || []).flatMap((topic) =>
      topic ? [topic.id] : []
    ).filter((value) => {
      return !selectedTopics.includes(value ? value : "");
    });
    const postData = {
      userProfileInput: isTabDirty(PROFILE_TAB_DETAILS) ? profileInfo : [],
      subscribedChannelIds: subscribedChannels,
      unsubscribedChannelIds: unSubscribedChannels,
    };
    updateProfile({ variables: { profile: postData } })
      .then(() => {
        setDirtyTabIndices([]);
        profileRefetch();
        dispatch({ type: "loader/showandhide", payload: { show: false } });
        dispatch({
          type: "alert/show",
          payload: {
            type: "success",
            title: t('profile_updating_dialogue_title'),
            message: t('profile_updating_success_message'),
          },
        });
      })
      .catch(() => {
        dispatch({ type: "loader/showandhide", payload: { show: false } });
        dispatch({
          type: "alert/show",
          payload: {
            type: "error",
            title: t('profile_updating_dialogue_error_title'),
            message: t('profile_updating_error_message'),
          },
        });
      });
  };

  useEffect(() => {
    return function cleanup() {
      dispatch({ type: "navigation/unblock" });
    };
  }, [dispatch]);

  useEffect(() => {
    const PERSONAL_FIELD_NAMES = ["LineManagerEmail", "AccessibilityRequirement"];
    if (profileData) {
      const config = (profileData.learnerProfile?.metaData?.dataPoints || []).flatMap((item) =>
        item ? [item] : []
      );
      const personalConfig = config.filter((item) => includes(PERSONAL_FIELD_NAMES, item.code));
      const professionalConfig = config.filter(
        (item) => !includes(PERSONAL_FIELD_NAMES, item.code) && item.code !== "LineManagerFirstName" && item.code !== "LineManagerLastName"
      );

      setProfile(profileData.learnerProfile?.userProfile);
      setEditablePersonalConfig(personalConfig.filter((item) => item.canEdit));
      setReadonlyPersonalConfig(personalConfig.filter((item) => !item.canEdit));
      setEditableProfessionalConfig(professionalConfig.filter((item) => item.canEdit));
      setReadonlyProfessionalConfig(professionalConfig.filter((item) => !item.canEdit))
      setShowPersonalDetails(portalSettingsManager?.application?.features?.showPersonalDetails || false);
      setShowProfessionalDetails(portalSettingsManager?.application?.features?.showProfessionalDetails || false);
      setCanChangeEmailAddress(portalSettingsManager?.application?.features?.canChangeEmailAddress || false);

      setTopics(
        (profileData.learnerProfile?.metaData?.topics || []).flatMap((topic) =>
          topic ? [topic] : []
        )
      );
      setSelectedTopics(
        (profileData.learnerProfile?.userProfile?.topicOfInterest || []).flatMap((topic) =>
          topic ? [topic.id] : []
        )
      );
      setAutoEnrolledTopics(
        (profileData.learnerProfile?.userProfile?.topicOfInterest || []).flatMap((topic) =>
          topic && topic?.isAutoEnrolled ? profileData.learnerProfile?.metaData?.topics.flatMap(x => x.id == topic.id ? x : []) : []
        )
      );
    }
  }, [profileData]);

  useEffect(() => {
    const dataPoints = (profile?.dataPoints || []).flatMap((item) => (item ? [item] : []));

    setInitials(`${first(profile?.firstName || "")}${first(profile?.lastName || "")}`);
    setFormValues(
      reduce(
        dataPoints,
        (
          result: { [key: string]: any },
          item: LearnerProfile_learnerProfile_userProfile_dataPoints
        ) => {
          if (item.code) {
            result[item.code] = item.value || item.values;
          }

          return result;
        },
        {}
      )
    );
  }, [profile]);

  useEffect(() => {
    if (dirtyTabIndices.length) {
      dispatch({
        type: "navigation/block",
        payload:
          t('profile_navigation_warning'),
      });
    } else {
      dispatch({ type: "navigation/unblock" });
    }
  }, [dirtyTabIndices, dispatch, t]);

  const clearChoiceClick = () => {
    setSelectedTopics([]);
    setDirtyTabIndices(uniq([...dirtyTabIndices, PROFILE_TAB_TOPICS]));
  };

  const validateEmail = () => {
    if (formValues && formValues?.LineManagerEmail && formValues?.LineManagerEmail.length > 0) {
      const userEmail = userContext?.userContext?.learnerEmail;
      if (
        userEmail &&
        userEmail.toLowerCase().trim() === formValues?.LineManagerEmail.toLowerCase().trim()
      ) {
        return true;
      }
      return !new RegExp(emailRegex).test(formValues?.LineManagerEmail.trim() || "");
    }
  };
  const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
    handleBreadCrumbNavigation(path, breadCrumbKey);
  };
  const visibleReminder = (params: any, learnerId: string) => {
    getresult();
    setSendReminder(true);
    setRemindData({ ...params?.dataItem, learnerId });
  };

  const getTabIndex = (position) => {
    if (position == 0) {
      return 0;
    }

    const indexDeciders = [
      showPersonalDetails || showProfessionalDetails,
      userContext?.userContext?.showTopicsOfInterest,
      userContext?.userContext?.isLineManager,
      showProfileReport,
      true
    ];
    const missingOffset = indexDeciders.slice(0, position).filter(f => !f).length;
    return position - missingOffset;
  }


  const profileTabs = (isMobile: boolean) => {
    const tabs: {
      label: string;
      isDirty?: boolean | undefined;
    }[] = [];

    if (showProfessionalDetails || showPersonalDetails) {
      tabs.push({ label: t('profile_details').toTitleCase(), isDirty: isTabDirty(PROFILE_TAB_DETAILS) });
    }
    if (userContext?.userContext?.showTopicsOfInterest) {
      tabs.push({ label: t('my_topics_of_interest'), isDirty: isTabDirty(PROFILE_TAB_TOPICS) });
    }
    if (userContext?.userContext?.isLineManager) {
      tabs.push({ label: t('my_team'), isDirty: isTabDirty(PROFILE_TAB_COUNSELEES) });
    }

    if (showProfileReport) {
      tabs.push({ label: t('profile_report_tab'), isDirty: isTabDirty(PROFILE_TAB_LEARNER) });
    }

    tabs.push({ label: t('my_calendar'), isDirty: isTabDirty(PROFILE_TAB_CALENDAR) });
    if (showSkillAssessment) {
      tabs.push({ label: t('my_skills'), isDirty: isTabDirty(PROFILE_TAB_SKILLS) });
    }

    return tabs;
  }

  const focusClass = useFocusStyles();
  const refreshReportDiagnositicData = () => {
    getLearnerDiagonistics();
  };
  return (
    <>
      <SubHeader
        contentType="Profile"
        breadCrumbData={breadCrumbData}
        handleBreadCrumbClick={handleBreadCrumbClick}
      />
      <Container style={{ padding: isMobile ? "12px 20px 16px 20px" : undefined }}>
        <Box display="flex" flexDirection="column">
          <Box
            display={{ xs: "flex", sm: "none" }}
            alignItems="center"
            justifyContent="space-between"
            marginTop="12px"
            marginBottom="12px"
          >
            <Typography
              style={{
                fontSize: "12px",
                fontWeight: 700,
                letterSpacing: "2px",
              }}
            >
              {t('profile_upper')}
            </Typography>
            <Box width="46px" height="46px" onClick={() => setShowMetrics(true)}>
              <img
                style={{ width: "100%", height: "100%", cursor: "pointer" }}
                src={metricsIcon}
                alt="Metrics"
              />
            </Box>
          </Box>
          <Box display="flex">
            <Box
              width="50px"
              height="50px"
              marginRight="20px"
              display="flex"
              justifyContent="center"
              alignItems="center"
              style={{ background: theme.palette.grey["800"], borderRadius: "25px" }}
            >
              <Typography
                style={{
                  fontSize: "20px",
                  fontWeight: 700,
                  color: theme.palette.common.white,
                  letterSpacing: "2px",
                }}
              >
                {initials}
              </Typography>
            </Box>
            <Box marginBottom="35px">
              <Typography
                display="block"
                style={{ fontSize: "30px", color: theme.palette.grey["800"] }}
                component='h1'
              >
                {profile?.userDisplayName}
              </Typography>
              <Typography
                display="block"
                style={{ fontSize: "12px", color: theme.palette.grey["800"] }}
              >
                {profile?.designation}
                {profile?.designation && profile?.department && ", "}
                {profile?.department}
              </Typography>
            </Box>
          </Box>
          <Box flex="1">
            <Box display={isMobile ? 'block' : isSmallScreen ? 'flex' : "flex"}>
              <Box
                flex="1"
                position="relative"
              >
                <Typography
                  style={{
                    fontSize: "18px",
                    fontWeight: 700,
                    color: theme.palette.grey["800"],
                    lineHeight: "40px",
                  }}
                  component='h2'
                  display={isMobile ? 'inline' : "block"}
                >
                  {t('profile_overview')}
                </Typography>
                {dirtyTabIndices.length > 0 && (
                  <SaveButton
                    // color="primary"
                    variant="outlined"
                    onClick={handleSaveProfile}
                    style={{
                      position: isSmallScreen ? "fixed" : isMobile ? "static" : "absolute",
                      marginLeft: isSmallScreen ? "0px" : isMobile ? "20px" : undefined,
                      right: "0px",
                      top: isSmallScreen ? undefined : "60px",
                      borderRadius: 0,
                      fontSize: "11px",
                      fontWeight: 700,
                      padding: "10px 30px",
                      letterSpacing: 0,
                      zIndex: 1,
                      color: isSmallScreen ? "#fff" : portalSettingsManager.buttonColors?.normal?.active?.text || theme.palette.grey["800"],
                      backgroundColor: isSmallScreen ? "#0091da" : portalSettingsManager.buttonColors?.normal?.active?.back,
                      border: isSmallScreen ? "1px solid #0091da" : `1px solid ${portalSettingsManager.buttonColors?.normal?.active?.border || theme.palette.grey["A100"]}`,
                      width: isSmallScreen ? "100%" : undefined,
                      bottom: isSmallScreen ? "0px" : undefined,
                    }}
                    className={`${focusClass.focusItem} ${focusClass.secondaryHover}`}
                    disabled={!dirtyTabIndices.length || validateEmail()}
                  // tabIndex={0}
                  >
                    {t('save_changes')}
                  </SaveButton>
                )}

                <Tabs
                  value={currentTabIndex}
                  mobile={isMobile}
                  tabs={profileTabs(isMobile)}
                  onChange={handleTabChange}
                />
                {(showPersonalDetails || showProfessionalDetails) && <TabPanel value={currentTabIndex} index={getTabIndex(0)} style={{ padding: "24px 0" }}>
                  {showPersonalDetails && (
                    <Accordion title={t('personal_details')} outlined mobile={isMobile}>
                      <SectionCol3 isMobile={isMobile}>
                        <ProfileField>
                          <label style={{ paddingBottom: "5px" }}>{t('my_first_name')}</label>
                          <span>{profile?.firstName}</span>
                        </ProfileField>
                        <ProfileField>
                          <label style={{ paddingBottom: "5px" }}>{t('my_last_name')}</label>
                          <span>{profile?.lastName}</span>
                        </ProfileField>
                        <ProfileField>
                          <Box display="flex">
                            <label style={{ paddingBottom: "5px" }}>{t('my_email')}</label>
                            <span>{canChangeEmailAddress && isEmailUpdateInProgress == false && (
                              <IconButton
                                tabIndex={0}
                                onClick={() => {
                                  setCheckStatus(!checkStatus);
                                  setEditEmail(true);
                                }}
                                size="small"
                                aria-label={t('my_email_edit')}
                                style={{ borderColor: portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main }}
                              >
                                <EditOutlined
                                  className={classes.customHoverFocus}
                                  fontSize="inherit"
                                  style={{ color: portalSettingsManager.application?.common?.themeColor || theme.palette.primary.main }}
                                />
                              </IconButton>
                            )}</span>
                          </Box>
                          <Tooltip title={profile ? profile.email : ""}>
                            <Email>{profile?.email}</Email>
                          </Tooltip>
                        </ProfileField>
                        {formValues && readonlyPersonalConfig.map((item) => createInput(item))}
                      </SectionCol3>
                      <SectionCol2 isMobile={isMobile}>
                        {formValues && editablePersonalConfig.map((item) => createInput(item))}
                      </SectionCol2>
                    </Accordion>)}
                  {showPersonalDetails && showProfessionalDetails && (
                    <Box
                      style={{
                        margin: "40px 0",
                        borderTop: `1px solid ${theme.palette.grey["300"]}`,
                      }}
                    />)}
                  {showProfessionalDetails && (
                    <Accordion title={t('professional_details')} outlined mobile={isMobile}>
                      <SectionCol2 isMobile={isMobile}>
                        {formValues && readonlyProfessionalConfig.map((item) => createInput(item))}
                        {formValues && editableProfessionalConfig.map((item) => createInput(item))}
                      </SectionCol2>
                    </Accordion>)}
                </TabPanel>
                }
                {userContext?.userContext?.showTopicsOfInterest && (<TabPanel value={currentTabIndex} index={getTabIndex(1)} style={{ padding: "40px 0px 15px 0px" }}>
                  <Box display="flex" alignItems="center" flexWrap="wrap" marginBottom="0">
                    <Typography
                      style={{
                        fontSize: isMobile ? "12px" : "14px",
                        fontWeight: isMobile ? 400 : 700,
                        marginRight: isMobile ? "25px" : undefined,
                        color: theme.palette.grey["800"],
                        flex: 1,
                      }}
                    >
                      {t('profile_recommendation_message')}
                    </Typography>
                    <Button
                      aria-controls="clear-button"
                      aria-label={t('clear_choices')}
                      onClick={() => clearChoiceClick()}
                      disabled={selectedTopics.length === 0}
                      className={`${focusClass.focusItem} ${!isMobile ? focusClass.border500 : ''}`}
                      style={
                        isMobile
                          ? {
                            fontSize: "11px",
                            fontWeight: "bold",
                            color: portalSettingsManager.buttonColors?.dark?.active?.text,
                            backgroundColor: portalSettingsManager.application?.common?.themeColor
                          }
                          : {
                            fontSize: isMobile ? "11px" : "12px",
                            fontWeight: isMobile ? "bold" : 400,
                            color: portalSettingsManager.buttonColors?.dark?.active?.text,
                            backgroundColor: portalSettingsManager.application?.common?.themeColor,
                            textTransform: "none",
                            borderRadius: 0,
                            padding: "9px 28px",
                            lineHeight: "14px"
                          }
                      }
                    // tabIndex='0'
                    >
                      {t('clear_choices')}
                    </Button>
                  </Box>
                  <Box display="flex" alignItems="left" flexWrap="wrap" margin="10px 0">
                    {autoEnrolledTopics?.length > 0 ?
                      <label style={{ paddingTop: "20px", color: "grey", textDecoration: "none", fontSize: "14px" }}>{t('admin_selected_topics')}</label>
                      : ""}
                  </Box>
                  <Box>
                    <span style={{ fontWeight: "bold", fontSize: "14px" }}> {autoEnrolledTopics.flatMap((item) => (item ? [item.name] : [])).join(", ")} </span>
                  </Box>
                  <Box display="flex" alignItems="left" flexWrap="wrap" margin="10px 0">
                    <label style={{ paddingTop: "20px", color: "grey", textDecoration: "none", fontSize: "14px" }}>{t('select_topics')}</label>
                  </Box>
                  <Box
                    style={{
                      display: "grid",
                      gridTemplateColumns: `repeat(${isMobile ? 1 : 3}, minmax(0, 1fr))`,
                      gap: "1rem",
                      marginTop: "30px",
                    }}
                  >
                    {topics.map((topic) => (
                      autoEnrolledTopics.findIndex(x => x.id == topic.id) == -1 ?
                        <Toggle
                          key={topic.id}
                          code={topic.id}
                          title={topic.name}
                          isOn={includes(selectedTopics, topic.id)}
                          onChange={toggleTopic}
                          role='button'
                        //tabindex='0'
                        /> : ""

                    ))}

                  </Box>
                </TabPanel>)}

                {userContext?.userContext?.isLineManager && (<TabPanel value={currentTabIndex} index={getTabIndex(2)} style={{ padding: "24px 0" }}>
                  <Box display="flex" justifyContent="space-between">
                    <Box style={{ margin: "10px 0", fontWeight: "bold" }}>
                      {t('expand_members')}
                    </Box>
                    <Box display="block" alignItems="center">
                      <Typography
                        style={{
                          fontSize: "26px",
                          fontWeight: "bold",
                          color: "#333333",
                          lineHeight: "31px",
                          textAlign: "center",
                          margin: "5px 0 5px 0",
                        }}
                      >
                        {counseleesList?.learnersByLineManager?.length}
                      </Typography>
                      <Typography
                        style={{ fontSize: "11px", color: "#333333", lineHeight: "16px" }}
                      >
                        {t('members')}
                      </Typography>
                    </Box>
                  </Box>
                  <Box
                    display="flex"
                    p="0 10px 7px 60px"
                    borderBottom="1px solid #d8d8d8"
                    style={{ fontSize: "11px", color: theme.palette.grey["800"], fontWeight: 700, marginLeft: "-14px" }}
                  >
                    <Box flex="1">
                      <span> {t('member_name')}</span>
                    </Box>
                  </Box>
                  {counseleesList?.learnersByLineManager?.map((counselee, ind) => (
                    <CounseleeAccordion
                      expanded={expanded}
                      setExpanded={setExpanded}
                      setLearnerName={setLearnerName}
                      counseleeItems={counseleeItems}
                      sendReminder={(params: any) => {
                        visibleReminder(params, counselee?.id);
                      }}
                      counseleeItemDetail={() => {
                        getCounseleeItemDetail({ variables: { learnerId: counselee?.id } })
                        dispatch({
                          type: "loader/showandhide",
                          payload: { show: true, message: t('profile_loading') },
                        });
                      }
                      }
                      data={counselee}
                      key={ind}
                    />
                  ))}
                  {sendReminder && (
                    <RemindDialog
                      open={sendReminder}
                      learnerName={learnerName}
                      data={result}
                      handleSendReminder={handleSendReminder}
                      remindData={remindData}
                      sendReminder={() => setSendReminder(false)}
                    />
                  )}
                </TabPanel>)}
                {showProfileReport && (<TabPanel value={currentTabIndex} index={getTabIndex(3)} style={{ padding: "24px 0" }}>
                  <LearnerReports dataLoading={learnerDiagnosticsLoading} reportsData={learnerDiagnostics} dataLoadFailed={learnerReportsDataFailed} refreshData={refreshReportDiagnositicData} />
                </TabPanel>)}
                <TabPanel value={currentTabIndex} index={getTabIndex(4)} style={{ padding: "0px" }}>
                  <MyCalendar />
                </TabPanel>
                {showSkillAssessment && <TabPanel value={currentTabIndex} index={getTabIndex(5)} style={{ padding: "0px" }}>
                  <MySkills />
                </TabPanel>
                }
              </Box>
              {portalSettingsManager?.application?.features?.showLearnerMetricsOnProfilePage && (
                <Box paddingLeft={isMobile ? "0px" : "25px"}
                  marginLeft={isMobile ? "10px" : "25px"}
                  position="relative"
                  borderLeft={`${isMobile ? 0 : 1}px solid ${theme.palette.grey["300"]}`}>
                  <MetricsContainer
                    mobile={isSmallScreen}
                    showMetrics={showMetrics}
                    setShowMetrics={setShowMetrics}
                  >
                    <Typography
                      style={{
                        fontSize: "18px",
                        fontWeight: 700,
                        color: theme.palette.grey["800"],
                        lineHeight: "40px",
                        marginBottom: "10px",
                      }}
                      component="h2"
                    >
                      {t('metrics')}
                    </Typography>
                    <Box style={{ borderTop: `1px solid ${theme.palette.grey["300"]}` }} />
                    <Box display="flex" justifyContent="space-around" style={{ width: "380px", height: "380px", marginLeft: "-30px" }} m="30px 0" flexWrap="wrap">
                      <D3Chart
                        metricsData={requiredLearning}
                        metricsIcon={requiredIcon}
                        metricsTitle={t('required_learning_metric')}
                      />
                      <D3Chart
                        metricsData={otherLearnings}
                        metricsIcon={otherLearningIcon}
                        metricsTitle={t('metrics_other_learning')}
                      />
                      <D3Chart
                        metricsData={certification}
                        metricsIcon={certificationIcon}
                        metricsTitle={t('metrics_certifications')}
                      />
                      <Box
                        display={{ xs: "flex", md: "none" }}
                        flexDirection="column"
                        justifyContent="center"
                      >
                        <Legend>{t('enrolled')}</Legend>
                        <Legend color={portalSettingsManager.statusColors?.inprogress?.back || '#005eb8'}>{t('inprogress')}</Legend>
                        <Legend color={portalSettingsManager.statusColors?.completed?.back || '#00a3a1'}>{t('completed')}</Legend>
                      </Box>
                    </Box>
                    <Box style={{ margin: "-22px -40px 0 0" }} display={{ xs: "none", md: "flex" }} justifyContent="center">
                      <Legend>{t('enrolled')}</Legend>&nbsp;&nbsp;
                      <Legend color={portalSettingsManager.statusColors?.inprogress?.back || '#005eb8'}>{t('inprogress')}</Legend>&nbsp;&nbsp;
                      <Legend color={portalSettingsManager.statusColors?.completed?.back || '#00a3a1'}>{t('completed')}</Legend>
                    </Box>
                  </MetricsContainer>
                </Box>)}
            </Box>
          </Box>
        </Box>
      </Container>
      <EmailDialog profile={profile} open={editEmail} handleClose={handleEditEmailClose} />
    </>
  );
};

type LearnerReportsPropType = {
  dataLoading: boolean;
  reportsData: ReportTypes.Reports;
  dataLoadFailed: boolean;
  refreshData: () => void;
};

const getDateForLearnerReports = (date: string) => {
  if (!date) {
    return date;
  }
  const datePart = date.split("T")[0];
  const [year, month, day] = datePart.split("-");
  return `${day} / ${month} / ${year.substring(2)}`;
};

const useStylesLearnerReports = makeStyles({
  tableRow: {
    height: 30,
  },
  tableCell: {
    padding: "0px 16px",
  },
});

const LearnerReports = ({ dataLoading, reportsData, dataLoadFailed, refreshData }: LearnerReportsPropType) => {
  const classes = useStylesLearnerReports();
  const reports = reportsData?.diagnosticReports || [];
  const { t } = useTranslation();
  const { openUrl } = openUrlUtil();

  const handleClick = (report: ReportTypes.Reports_diagnosticReports) => {
    const { isSuccess, windowEvent } = openUrl(report.url, report.id);
    const closeWindow = setInterval(function () {
      if (windowEvent?.closed) {
        clearInterval(closeWindow);
        refreshData();
      }

    }, 500);
  };

  const headerText = () => {
    if (dataLoadFailed) {
      return t("report_header_error");
    }

    return reports.length > 0 ? t("report_header_data") : t("report_header_no_data");
  }

  return (
    <>
      <Box style={{ fontWeight: "bold" }}>{headerText()} </Box>

      <Box style={{ borderTop: "1px solid #d8d8d8", marginTop: "20px" }}>
        {reports.map((r) => (
          <div
            style={{
              minHeight: "50px",
              display: "flex",
              alignItems: "center",
              borderBottom: "1px solid #d8d8d8",
            }}
          >
            <div style={{ width: "50%", paddingLeft: "20px" }}>{r.title}</div>
            <div style={{ width: "20%" }}>{getDateForLearnerReports(r.date)}</div>
            <div style={{ width: "20%" }}>{r.status}</div>
            <div style={{ marginLeft: "auto", marginRight: "10px" }} onClick={() => handleClick(r)}>
              <SvgIcon
                component={arrowIcon}
                style={{
                  marginTop: "20px",
                  color: theme.palette.primary.main,
                  cursor: "pointer",
                }}
              />
            </div>
          </div>
        ))}
      </Box>
    </>
  );
};

type CalendarHeaderType = {
  name: string;
  header: string;
  align?: "inherit" | "left" | "center" | "right" | "justify";
  isAscending?: boolean;
};

const getPages = (itemsPerPage: number, totalItems: number) => {
  const noOfPages = Math.ceil(totalItems / itemsPerPage);
  const pages = [];
  for (let i = 1; i <= noOfPages; i++) {
    pages.push(i);
  }
  return pages;
};

const getMyCalendarDate = (dateText: string) => {
  const date = new Date(dateText);
  // There is no time zone specified, the dates are considered to be in UTC.Change to EST.
  date.setTime(date.getTime() + 4 * 60 * 60 * 1000);
  const dateParts = date.toString().split(" ");
  const timeParts = dateParts[4].split(":");
  const hour = parseInt(timeParts[0]);
  const suffix = hour > 12 ? "pm" : "am";
  return `${dateParts[2]} ${dateParts[1]} ${dateParts[3]} / ${hour}:${timeParts[1]} ${suffix}`;
};

const MyCalendar = () => {
  const dispatch = useAppDispatch();
  const { t } = useTranslation();
  const isMobile = false;
  const [paginationState, setPaginationState] = useState({
    totalCount: 0,
    currentPage: 1,
    itemsPerPage: 10,
  });
  const [sortingState, setSortingState] = useState({
    field: LearnerWorkshopActivitiesSortBy.START_DATE,
    isAscending: false,
  });

  const [dataLoadFailed, setDataLoadFailed] = useState(false);
  const [activities, setActivities] = useState<(LearnerWorkshops_learnerWorkshopActivities_activities | null)[]>([]);
  const { totalCount, itemsPerPage, currentPage } = paginationState;
  const pages = getPages(itemsPerPage, totalCount);

  const handleCurrentPageChange = (newPage: number) => {
    setPaginationState({ ...paginationState, currentPage: newPage });
    getCalendarData(
      sortingState.field,
      sortingState.isAscending,
      (newPage - 1) * paginationState.itemsPerPage
    );
  };

  const handleSortChanged = (name: LearnerWorkshopActivitiesSortBy, isAscending: boolean) => {
    const index = headers.findIndex((h) => h.name == name);
    const newHeaders = [...headers];
    newHeaders[index] = { ...headers[index], isAscending };
    setHeaders(newHeaders);
    setSortingState({ ...sortingState, field: name, isAscending });
    getCalendarData(name, isAscending);
  };

  const [loadMyCalendar, { data: myCalendarData, loading }] = useLazyQuery<LearnerWorkshopsTypes.LearnerWorkshops>(GET_MY_WORKSHOPS, {
    onError: () => {
      setDataLoadFailed(true);
    }
  });

  useEffect(() => {
    getCalendarData(sortingState.field, sortingState.isAscending, 0);
  }, []);

  useEffect(() => {
    if (!loading) {
      let totalCount = 0;

      if (myCalendarData) {
        totalCount = myCalendarData.learnerWorkshopActivities.totalLearnerWorkshopActivitiesCount;
        setActivities(myCalendarData.learnerWorkshopActivities.activities);
      }
      setPaginationState({ ...paginationState, totalCount });
    }
  }, [myCalendarData]);

  useEffect(() => {
    dispatch({
      type: "loader/showandhide",
      payload: {
        show: loading,
        message: t('mycalendar_loading'),
      },
    });
  }, [loading]);

  const getCalendarData = (
    sortBy: string | undefined = undefined,
    isAscending = true,
    skip = 0
  ) => {
    const sortByField = undefined;
    loadMyCalendar({
      variables: {
        sort: { sortBy, isAscending },
        count: Number(process.env.REACT_APP_CATALOG_COUNT),
        skip,
      },
    });
  };

  const [headers, setHeaders] = useState<CalendarHeaderType[]>([
    { name: LearnerWorkshopActivitiesSortBy.PROGRAMME_NAME, header: t('course'), align: "left" },
    { name: LearnerWorkshopActivitiesSortBy.ACTIVITY_NAME, header: t('activity'), align: "left" },
    { name: LearnerWorkshopActivitiesSortBy.START_DATE, header: t('start_date_time'), align: "center", isAscending: true },
    { name: LearnerWorkshopActivitiesSortBy.LOCATION, header: t('location'), align: "center" },
  ]);

  const headerText = () => {
    if (dataLoadFailed) {
      return t("my_calendar_header_error");
    }
    if (!loading) {
      return totalCount > 0 ? t("my_calendar") : t("my_calendar_header_no_data");
    }
  }

  return (
    <>
      <Box style={{ margin: "30px 0px 14px 0px", fontWeight: "bold" }}>{headerText()}</Box>
      {!dataLoadFailed && totalCount > 0 && (
        <Box>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  {headers.map((h) => (
                    <TableCell style={{ fontWeight: "bold" }} align={h.align} key={h.header}>
                      <MyCalendarHeader
                        header={h.header}
                        isAscending={h.isAscending}
                        name={h.name}
                        onSortChanged={handleSortChanged}
                      />
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody style={{ fontSize: "12px" }}>
                {activities.map((activity) => (
                  <TableRow key={activity.programmeId}>
                    <MyCalendarTableCell
                      align="left"
                      text={activity.programmeName}
                      showAsLink={true}
                      link={`/COURSE/${activity.programmeId}`}
                    />
                    <MyCalendarTableCell align="left" text={activity.activityName} />
                    <MyCalendarTableCell
                      align="center"
                      text={getMyCalendarDate(activity.startDate)}
                    />
                    <MyCalendarTableCell align="center" text={activity.location} />
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <Paginator
            pages={pages}
            currentPage={currentPage}
            isMobile={isMobile}
            onChange={handleCurrentPageChange}
          />
        </Box>
      )}
    </>
  );
};

type MyCalendarHeaderPropsType = {
  name: string;
  header: string;
  isAscending: boolean;
  onSortChanged: (name: string, isAscending: boolean) => void;
};

const MyCalendarHeader = ({
  header,
  isAscending = true,
  name,
  onSortChanged,
}: MyCalendarHeaderPropsType) => {
  const handleSortClick = () => {
    onSortChanged(name, !isAscending);
  };

  return (
    <Box style={{ display: "flex" }}>
      <div>{header}</div>
      <IconButton
        size="small"
        style={{ marginLeft: "-3px", marginTop: "-6px" }}
        onClick={handleSortClick}
      >
        {isAscending ? <ArrowDropDown /> : <ArrowDropUp />}
      </IconButton>
    </Box>
  );
};

type MyCalendarTableCellPropsType = {
  align?: "inherit" | "left" | "center" | "right" | "justify";
  text: string;
  showAsLink?: boolean;
  link?: string;
};

const MyCalendarTableCell = ({ align, text, showAsLink, link }: MyCalendarTableCellPropsType) => {
  const divRef = useRef();
  const [showTooltip, setShowTooltip] = useState(false);

  useEffect(() => {
    const element = divRef.current;

    if (divRef.current) {
      const { clientWidth, scrollWidth } = divRef.current || { clientWidth: 0, scrollWidth: 0 };
      if (clientWidth < scrollWidth) {
        setShowTooltip(true);
      }
    }
  }, [divRef.current]);

  const getText = () => (
    <Box style={{ display: "flex" }}>
      <div
        style={{
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
        }}
        ref={divRef}
      >
        {text}
      </div>
      {showTooltip && (
        <Tooltip position="bottom" zIndex={10000} title={text} tooltipStyle={{ zIndex: 10000 }}>
          <div
            style={{
              marginLeft: "-20px",
              cursor: "pointer",
              minWidth: "20px",
              minHeight: "20px",
              backgroundColor: "transparent",
            }}
          ></div>
        </Tooltip>
      )}
    </Box>
  );

  const getTextAsLink = () => (
    <Link
      to={link}
      style={{
        fontSize: "12px",
        textTransform: "none",
        color: `${theme.palette.primary.main}`,
      }}
    >
      {getText()}
    </Link>
  );

  return (
    <TableCell align={align} style={{ maxWidth: "50px" }}>
      {showAsLink ? getTextAsLink() : getText()}
    </TableCell>
  );
};

