import { useQuery } from "@apollo/client";
import { Box, Container, Drawer, useMediaQuery } from "@material-ui/core";
import { CourseDetails, LearningSection, SubHeader, ActivityDrawer, ShareDialog, PlayListDialog, EditRatingDialog, ConfirmDialog, WorkshopDialog, EnrollDialog } from "components";
import { get } from "lodash";
import { useEffect, useMemo, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import { RootState, useAppDispatch } from "store";
import * as ActivityTypes from "utils/graphql/Activities";
import * as CanLaunchCourseByPathWays from "utils/graphql/CanLaunchCourseBySequencialPathway";
import * as CourseTypes from "utils/graphql/Course";
import * as RelatedCourseTypes from "utils/graphql/RelatedCourses";
import { GET_ACTIVITIES, GET_COURSE_BY_ID, GET_COURSE_RELATED_CONTENTS_BY_ID, CAN_LAUNCH_COURSE_BY_PATHWAY } from "utils/queries";
import { getContentType } from "utils/helpers";
import { useRating, useBreadCrumbs, useEnrollment, useWorkshop } from "hooks";
import { ContentType } from "utils/graphql/Global";
import { useSelector } from "react-redux";
import { useTheme } from "@material-ui/core/styles";
import { useTranslation } from "react-i18next";
import { PERMISSIONS, ENROLLMENT_DIALOG_TYPES } from "utils/constants";

export const Course = (): JSX.Element => {
  const { t } = useTranslation();
  const [refreshing, setRefreshing] = useState(false);
  const [loadMessage, setLoadMessage] = useState<string>(t('course_loading'));
  const [isOpenPlaylist, setIsOpenPlaylist] = useState<boolean>(false);
  const [openWorkshop, setWorkShop] = useState<boolean>(false);
  const [selectedWorkshopDate, setSelectedWorkshopDate] = useState<string>("");
  const [selectedWorkshopLocation, setSelectedWorkshopLocation] = useState<string>("");
  const [selectedActivity, setSelectedActivity] = useState<string>("");
  const [openEnroll, setOpenEnroll] = useState<boolean>(false);

  const params = useParams();
  const dispatch = useAppDispatch();

  const id = useMemo(() => {
    return get(params, "id", -1);
  }, [params]);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const {
    loading: courseLoading,
    data: courses,
    refetch: courseDetailsRefetch,
  } = useQuery<CourseTypes.Course>(GET_COURSE_BY_ID, {
    fetchPolicy: "no-cache",
    variables: {
      courseId: id,
    },
  });

  const {
    rating,
    openRating,
    onSubmit,
    isEditRatingOpen,
    closeEditRatingDialog,
    isConfirmationOpen,
    closeConfirmationDialog } = useRating(courses?.courseDetailsById?.id, ContentType.COURSE, courseDetailsRefetch, courses?.courseDetailsById?.statusCode);

  const [selectedCourse, setSelectedCourse] = useState<any>([]);
  const [openShareContent, setOpenShareContent] = useState<boolean>(false);
  const [showActivityAction, setShowActivityAction] = useState<boolean>(false);
  const [openActivity, setOpenActivity] = useState<boolean>(false);
  const {
    loading: activitiesLoading,
    data: activityData,
    refetch: activitiesRefetch,
  } = useQuery<ActivityTypes.Activities>(GET_ACTIVITIES, {
    variables: {
      courseId: id,
    },
  });

  const {
    data: related,
    refetch: relatedCoursesRefetch
  } = useQuery<RelatedCourseTypes.RelatedCourses>(GET_COURSE_RELATED_CONTENTS_BY_ID, {
    variables: {
      courseId: id,
    },
    notifyOnNetworkStatusChange: true,
    fetchPolicy: "no-cache"
  });

  const { data: canLaunchCourseByPathWay, loading: canLaunchCourseByPathWayLoading, refetch: refetchCanLaunchCourseByPathway } = useQuery<CanLaunchCourseByPathWays.CanLaunchCourseBySequencialPathway>(CAN_LAUNCH_COURSE_BY_PATHWAY, {
    variables: {
      courseId: String(id),
    }
  });

  const userContext = useSelector((state: RootState) => state.core.userContext);

  const handleExpressInterest = () => {
    const expressObj = {
      activityId: selectedActivity,
      interestedDate: selectedWorkshopDate,
      programmeId: id,
      location: selectedWorkshopLocation
    };
    expressInterest(expressObj)
    handleExpressClose();

  }
  const handleExpressClose = () => {
    setSelectedCourse("");
    setSelectedWorkshopDate("")
    setSelectedWorkshopLocation("")
    setWorkShop(false)
  }
  const handleContentRefresh = () => {
    try {
      relatedCoursesRefetch();
    } catch (err) {
      console.log('Error while refreshing', err)
    }
  }

  useEffect(() => {
    dispatch({ type: "loader/showandhide", payload: { show: (courseLoading || canLaunchCourseByPathWayLoading || activitiesLoading || refreshing), message: loadMessage } })
  }, [courseLoading, canLaunchCourseByPathWayLoading, activitiesLoading, refreshing, loadMessage, dispatch]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [courses?.courseDetailsById?.id]);

  useEffect(() => {
    if (courses?.courseDetailsById?.isEnrolled && canLaunchCourseByPathWay && canLaunchCourseByPathWay.canLaunchCourseBySequencialPathway) {
      setShowActivityAction(canLaunchCourseByPathWay.canLaunchCourseBySequencialPathway.canLaunch);
    }
  }, [courses?.courseDetailsById?.isEnrolled, canLaunchCourseByPathWay]);
  const handleOpenWorkshop = (id: string) => {
    setWorkShop(true)
    setSelectedActivity(id)
    loadWorkshopData({ variables: { activityId: id } });
  }

  const handleSuggestADate = () => {
    handleOpenWorkshop(null);
  };

  const handleEnroll = () => {
    setLoadMessage(t('refreshing_content'));
    setRefreshing(true);
    setTimeout(() => {
      try {
        courseDetailsRefetch();
        activitiesRefetch();
        refetchCanLaunchCourseByPathway();
        setRefreshing(false);
        setLoadMessage(t('course_loading'));
      } catch (err) {
        console.log('Error while refreshing', err)
      }
    }, 5000);
  };
  const handleDateSelection = (val: string) => {
    setSelectedWorkshopDate(val)
  }
  const handleLocationSelection = (val: string) => {
    setSelectedWorkshopLocation(val)
  }

  const { handleBreadCrumb, handleBreadCrumbNavigation, breadCrumbData } = useBreadCrumbs();
  const { handleEnrollmentData, handleCompleteEnrollment, enrollmentResult } = useEnrollment(handleEnroll);
  const { loadWorkshopData, expressInterest, workshopData } = useWorkshop();

  const location = useLocation();
  const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
    handleBreadCrumbNavigation(path, breadCrumbKey)
  }
  const handleTileClick = () => {
    sessionStorage.setItem("relatedItemClick", "true")
  }
  useEffect(() => {
    if (breadCrumbData && courses) {
      handleBreadCrumb({ title: courses?.courseDetailsById?.name, path: location.pathname, type: "course" }, "course", "")
    }
  }, [courses])

  const handleOpenEnroll = () => {
    if (!!courses?.courseDetailsById) {
      handleEnrollmentData(courses?.courseDetailsById?.id)
    }

  }

  useEffect(() => {
    if (enrollmentResult) {
      const res = enrollmentResult?.enrollmentData;

      if (userContext?.userContext?.permissions?.includes(PERMISSIONS.CAN_ENROLL_USERS)) {
        setOpenEnroll(true);
      } else {
        if (
          res?.activities?.length ||
          res?.captureManagerEmail ||
          res?.captureSpecialRequirements ||
          res?.isPreRequisitesAvailable ||
          res?.isTermsAndConditionAvailable
        ) {
          setOpenEnroll(true);
        } else {
          const courseData = {
            courseId: String(courses?.courseDetailsById?.id),
          };
          const attendeesObj = {
            attendees: [
              {
                learnerId: userContext?.userContext?.learnerId,
              },
            ],
          };
          handleConfirmEnrollment(ENROLLMENT_DIALOG_TYPES.COURSE, courseData, attendeesObj);
        }
      }
    }
  }, [enrollmentResult]);

  const handleConfirmEnrollment = (type: string, data: any, attendees: any) => {
    setOpenEnroll(false);
    handleCompleteEnrollment(type, data, attendees);

  }
  return (
    <>
      <Box display={{ xs: "none", sm: "block" }}>
        {courses?.courseDetailsById && (
          <SubHeader contentType="Course" studyModes={courses.courseDetailsById.studyModes} breadCrumbData={breadCrumbData} handleBreadCrumbClick={handleBreadCrumbClick} />
        )}
      </Box>
      <Box paddingTop={{ xs: "30px", sm: "0" }}>
        <Container>
          {courses?.courseDetailsById && (
            <CourseDetails
              handleEnroll={handleEnroll}
              handleRating={openRating}
              course={courses.courseDetailsById}
              activityData={activityData}
              handleOpenWorkshop={handleOpenWorkshop}
              handleOpenEnroll={handleOpenEnroll}
              handleSuggestADate={handleSuggestADate}
              showActivityAction={showActivityAction}
              activitiesRefetch={activitiesRefetch}
              courseDetailsRefetch={courseDetailsRefetch}
              canLaunchCourseByPathWay={canLaunchCourseByPathWay}
            />
          )}
          {related && related.relatedContents && related.relatedContents.contents && related.relatedContents.contents.length > 0 && (
            <>
              <Box style={{ width: isMobile ? undefined : "1160px" }}>
                <LearningSection
                  title={t('related_items')}
                  subTitle={t('courses_taken')}
                  list={related?.relatedContents?.contents || []}
                  selectTileHandler={setSelectedCourse}
                  setOpenShareContent={setOpenShareContent}
                  setOpenActivity={setOpenActivity}
                  setIsOpenPlaylist={setIsOpenPlaylist}
                  handleTileClick={handleTileClick}
                />
              </Box>
            </>
          )}
        </Container>
        <Drawer anchor="right" open={openActivity} onClose={() => { setOpenActivity(false); setSelectedCourse([]) }}>
          {openActivity && (
            <ActivityDrawer handleOpenWorkshop={handleOpenWorkshop} course={selectedCourse} handleContentRefresh={handleContentRefresh} closeHandler={() => { setOpenActivity(false); setSelectedCourse([]) }} />
          )}
        </Drawer>
        {openShareContent && selectedCourse && (
          <ShareDialog open={openShareContent} contentType={selectedCourse?.contentType ? selectedCourse.contentType : "course"}
            course={selectedCourse} shareLink={window.location.origin + `/${selectedCourse.contentType}/${selectedCourse?.id}`} handleClose={() => { setOpenShareContent(false); setSelectedCourse([]) }} />
        )}
        {isOpenPlaylist && selectedCourse && (<PlayListDialog
          title={t('playlist_dialog_title')}
          description={t('playlist_dialog_discription')}
          contentId={selectedCourse.id}
          contentType={getContentType("course")}
          open={isOpenPlaylist}
          handleConfirm={() => setIsOpenPlaylist(false)}
          handleClose={() => setIsOpenPlaylist(false)}
        />)}
      </Box>
      {isEditRatingOpen && <EditRatingDialog
        score={rating}
        type={ContentType.COURSE}
        open={isEditRatingOpen}
        onClose={closeEditRatingDialog}
        onSubmitRating={onSubmit}
      />}
      <ConfirmDialog
        disableBackdropClick
        open={isConfirmationOpen}
        title={t('confirmation_placeholder')}
        message={t('submit_rating')}
        handleConfirmed={onSubmit as () => void}
        handleClose={closeConfirmationDialog}
      />
      {openWorkshop && workshopData && <WorkshopDialog open={openWorkshop} handleClose={() => handleExpressClose()} data={workshopData && workshopData} handleLocationSelection={handleLocationSelection} handleDateSelection={handleDateSelection} selectedWorkshopDate={selectedWorkshopDate} selectedWorkshopLocation={selectedWorkshopLocation} handleExpressInterest={handleExpressInterest} />
      }{openEnroll && (
        <EnrollDialog
          data={enrollmentResult}
          course={courses?.courseDetailsById}
          open={openEnroll && enrollmentResult}
          handleConfirmEnrollment={handleConfirmEnrollment}
          handleEnroll={handleEnroll}
          handleClose={() => setOpenEnroll(false)}
          courseLearnerId={userContext?.userContext?.learnerId}
          canEditLineManagerEmail={userContext?.userContext?.canEditLineManagerEmail}
          dialogType={
            userContext?.userContext?.permissions?.includes(PERMISSIONS.CAN_ENROLL_USERS) ? ENROLLMENT_DIALOG_TYPES.ADMIN : ENROLLMENT_DIALOG_TYPES.COURSE
          }
          learnerEmail={userContext?.userContext?.learnerEmail}
          handleOpenWorkshop={handleOpenWorkshop}
        />
      )}
    </>
  );
};
