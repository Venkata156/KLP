/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box, Button, IconButton, InputBase, Radio, SvgIcon, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@material-ui/core";
import { Theme, withStyles, makeStyles } from "@material-ui/core/styles";
import { ReactComponent as searchIcon } from "assets/icons/icon-search.svg";
import CloseIcon from "@material-ui/icons/Close";
import { debounce, noop, range } from "lodash";
import React, { FormEvent, useState, useEffect, useMemo } from "react";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "store";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";
import { useBreadCrumbs } from "hooks";
import {
    Paginator,
    SubHeader,
    theme,
} from "components";
import { CSSProperties } from "@material-ui/core/styles/withStyles";
import { useHistory } from "react-router-dom";
import { useLazyQuery } from "@apollo/client";
import { GET_ALL_ACTIVITIES } from "utils/queries";
import { AllActivities, AllActivities_allActivities_data } from "../../../utils/graphql/AllActivities";
import { SUB_HEADER_CONTENT_TYPE } from "utils/constants";
import portalSettingsManager from "utils/portalSettingsManager";

const SearchIconButton = withStyles((theme: Theme) => ({
    root: {
        "&:hover": {
            backgroundColor: theme.palette.grey["300"],
        }
    },
}))(IconButton);
const style: CSSProperties = {
    paddingTop: "16px",
    paddingBottom: "16px",
    borderRadius: "0px",
    marginTop: "20px",
    fontSize: "11px",
    fontWeight: "bold",
};

const useButtonStyles = makeStyles((theme: Theme) => ({
    back: {
        ...style,
        color: 'gray',
        borderColor: 'gray'
    },
    active: {
        ...style,
        color: (props: any) => props?.portalSettingsManager?.application?.common?.themeColor || `${theme.palette.primary.main}`,
        borderColor: (props: any) => props?.portalSettingsManager?.application?.common?.themeColor || `${theme.palette.primary.main}`,
    },
    disabled: {
        ...style,
        color: "#ddd",
        borderColor: "#ddd",
    }
}));

const Container = withStyles((theme: Theme) => ({
    root: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "100%",
        height: (props: any) => (props.background ? "150px" : "auto"),
        position: "relative",
        marginLeft: (props: any) => (props.background || props.mobile ? "0" : "20px"),
        zIndex: 1,
        "& > div": {
            background: "transparent",
        },
        "& form": {
            display: "flex",
            alignItems: "center",
            backgroundColor: (props: any) => (props.background ? "rgba(255, 255, 255, 0.8)" : "#F5F5F5"),
            backgroundPosition: "center center",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
            width: "90%",
            maxWidth: (props: any) => (props.background ? "1240px" : "420px"),
            height: (props: any) => (props.background ? "70px" : "100%"),
            borderRadius: 0,
            "& > div": {
                width: "100%",
                "& > div": {
                    width: (props: any) => (props.background ? "calc(100% - 65px)" : "calc(100% - 48px)"),
                    "& input": {
                        padding: "0 20px",
                        fontSize: (props: any) => (props.background ? "22px" : "16px"),
                        color: theme.palette.grey["800"],
                        position: "relative",
                        top: "3px",
                        "&::placeholder": {
                            opacity: (props: any) => (props.background ? 1 : 0.4),
                        },
                    },
                },
            },
        },
    },
}))(Box);
export const SelectActivity = ({ background, onSubmit, mobile = false }: any): JSX.Element => {
    const dispatch = useAppDispatch();
    const focusClass = useFocusStyles();
    const history = useHistory();
    const [searchText, setSearchText] = useState('');
    const captureIntitialSearch = useSelector((state: RootState) => state.core.captureSearch);
    const [captureSearch] = useState(captureIntitialSearch);
    const { t } = useTranslation();
    const [pages, setPages] = useState<number[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [attendeesData, setAttendeesData] = useState<(AllActivities_allActivities_data | null)[] | null>([]);
    const [selectedActivityId, setActivityId] = useState<string | null>('');
    const [onApiError, setOnApiError] = useState(false);
    const [skipCount, setSkipCount] = useState<number>(0);
    const buttonStyles = useButtonStyles({
        portalSettingsManager,
    });
    const variables = {
        searchTerm: '',
        count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
        skip: skipCount
    };

    const { handleBreadCrumb, handleBreadCrumbNavigation, breadCrumbData } = useBreadCrumbs();

    useEffect(() => {
        handleBreadCrumb([
            { title: t('home'), path: "/" },
            { title: t('attendace_activity_completion'), path: "/attendance-confirmation" },
            { title: t('choose_an_activity'), path: "/attendance-confirmation/activity" },
        ], "override", "");
    }, []);

    const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
        GET_ALL_ACTIVITIES
        handleBreadCrumbNavigation(path, breadCrumbKey);
    };

    const updateSearchText = (value: string) => {
        setSearchText(value);
    };

    const handleSubmit = (event: FormEvent) => {
        event.preventDefault();
    };

    const navigateToActivityDetails = () => {
        history.push(`/attendance-confirmation/activity/${selectedActivityId}`)
    }

    const navigateToAttendanceConfirmation = () => {
        history.push(`/attendance-confirmation`)
    }

    const [loadAttendances, { loading, data, refetch }] = useLazyQuery<AllActivities>(
        GET_ALL_ACTIVITIES,
        {
            variables,
            notifyOnNetworkStatusChange: true,
            onError: () => {
                dispatch({
                    type: "alert/show",
                    payload: {
                        type: "error",
                        title: t('search_result'),
                        message: t('search_error_message'),
                    },
                });
                setOnApiError(true);
                setAttendeesData([]);
            }
        }
    );

    const refetchDebounced = useMemo(() => debounce(refetch ? refetch : noop, 100), [refetch]);

    useEffect(() => {
        loadAttendances({
            variables: {
                searchTerm: searchText,
                count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
                skip: skipCount
            }
        });
    }, [loadAttendances]);

    useEffect(() => {
        if (data) {
            // remove null values
            if (data.allActivities && data.allActivities?.data) {
                setAttendeesData(
                    data.allActivities?.data
                );
                const totalPages = Math.ceil(data.allActivities?.totalCount / Number(process.env.REACT_APP_ATTENDANCE_COUNT))
                setPages(range(1, totalPages + 1))
            }
        }
    }, [data]);

    useEffect(() => {
        setSkipCount(Number(process.env.REACT_APP_ATTENDANCE_COUNT) * (currentPage - 1))
    }, [attendeesData, currentPage]);

    useEffect(() => {
        if (refetchDebounced && (data || onApiError)) {
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
            refetchDebounced({
                searchTerm: searchText,
                count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
                skip: skipCount
            });
        }
    }, [skipCount])
    useEffect(() => {
        if (refetchDebounced && (data || onApiError)) {
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
            setCurrentPage(1);
            refetchDebounced({
                searchTerm: searchText,
                count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
                skip: skipCount
            });
        }
    }, [
        refetchDebounced,
        captureSearch
    ]);

    const performSearch = () => {
        if (refetchDebounced && (data || onApiError)) {
            dispatch({
                type: "subheader/title",
                payload: "",
            });
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
            setCurrentPage(1);
            refetchDebounced({
                searchTerm: searchText,
            });
        }
    };

    useEffect(() => {
        dispatch({ type: "loader/showandhide", payload: { show: loading, message: t('search_loading') } });
    }, [loading]);

    return (<>
        <Box display={{ xs: "none", sm: "block" }}>
            <SubHeader
                contentType={SUB_HEADER_CONTENT_TYPE.ACTIVITY_COMPLETION}
                breadCrumbData={breadCrumbData}
                handleBreadCrumbClick={handleBreadCrumbClick}
            />
        </Box>
        <Box paddingTop={{ xs: "30px", sm: "0" }}>
            <Container background={!!background} mobile={mobile}>
                <Box style={{ width: mobile ? undefined : "1100px" }}>
                    <div style={{
                        fontSize: '24px',
                        color: theme.palette.grey['800'],
                        margin: '20px 0',
                        fontWeight: 400
                    }}>{t('2_choose_an_activity')}</div>
                    <Box>
                        <form noValidate
                            onSubmit={handleSubmit}
                            //tabIndex={0}
                            aria-label={t('Press_Escape_key_To_Clear')}>
                            <Box boxShadow={0} className={focusClass.focusItem}>
                                <InputBase
                                    //tabIndex={0}
                                    placeholder={t('search_activity_course_placeholder')}
                                    inputProps={{
                                        "title": t('search_activity_course_placeholder'),
                                        "placeholder": t('search_activity_course_placeholder'),
                                    }}
                                    value={searchText}
                                    onChange={(event) => updateSearchText(event.target.value)}
                                    type="search"
                                    //className={focusClass.focusItem}
                                />
                                {mobile && searchText ? (
                                    <IconButton
                                        type="button"
                                        className={focusClass.focusItem}
                                        aria-label={t('aria_label_course_or_activity_search')}
                                        onClick={(e) => {
                                            e.preventDefault();
                                            updateSearchText("");
                                        }}
                                    >
                                        <CloseIcon fontSize={background ? "large" : "inherit"} />
                                    </IconButton>
                                ) : (
                                    <SearchIconButton
                                        onClick={(e) => {
                                            e.preventDefault();
                                            performSearch();
                                        }}
                                        type="submit" aria-label={t('search').toLowerCase()} style={{ height: "48px", width: "48px" }} className={focusClass.focusItem}>
                                        <SvgIcon
                                            component={searchIcon}
                                            style={{
                                                position: "absolute",
                                                margin: "16px 6px 8px 10px",
                                                fontSize: background ? "30px" : "22px",
                                            }}
                                        />
                                    </SearchIconButton>
                                )}
                            </Box>
                        </form>
                    </Box>
                    <Box margin="30px 0px">
                        <Box marginBottom={{ xs: "10px", sm: "20px" }} style={{ display: "flex" }}>
                            <TableContainer>
                                <Table aria-label={t('aria_label_activities_table')}>
                                    <TableHead>
                                        <TableRow>
                                            {mobile ? (
                                                <>
                                                    <TableCell align="left" style={{ fontWeight: 700 }}>
                                                        {t('activity_name')}
                                                    </TableCell>
                                                    <TableCell></TableCell>
                                                </>
                                            ) : (
                                                <>
                                                    <TableCell align="left" style={{ fontWeight: 700 }} scope="col">
                                                        {t('activity_name')}
                                                    </TableCell>
                                                    <TableCell align="left" style={{ fontWeight: 700 }} scope="col">
                                                        {t('course_name')}
                                                    </TableCell>
                                                </>
                                            )}
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {mobile
                                            ? attendeesData?.map((row, index) => {
                                                return (
                                                    <React.Fragment key={"mobile_" + index}>
                                                        <TableRow>
                                                            <TableCell align="left" tabIndex={0} >
                                                                <Box>{row?.activityName}</Box>
                                                                <Box>{row?.programmeName}</Box>
                                                            </TableCell>
                                                        </TableRow>
                                                    </React.Fragment>
                                                );
                                            })
                                            : attendeesData?.map((row, index) => {
                                                return (
                                                    <React.Fragment key={index}>
                                                        {row && (
                                                            <TableRow key={index} className={row.activityId === selectedActivityId ? 'selected' : ''}>
                                                                <TableCell align="left" style={{ color: row.activityId === selectedActivityId ? theme.palette.grey['200'] : theme.palette.grey['800'] }}>
                                                                    <Radio
                                                                        inputProps={{ 'aria-label': row?.activityName, 'aria-required': 'true' }} name={row?.activityId || index.toString()}
                                                                        value={row?.activityId}
                                                                        checked={row.activityId === selectedActivityId}
                                                                        color="primary"
                                                                        onClick={() => setActivityId(row.activityId)}
                                                                    />
                                                                    {row?.activityName}
                                                                </TableCell>
                                                                <TableCell align="left" style={{ color: row.activityId === selectedActivityId ? theme.palette.grey['200'] : theme.palette.grey['800'] }}>
                                                                    {row?.programmeName}
                                                                </TableCell>
                                                            </TableRow>
                                                        )}
                                                    </React.Fragment>
                                                );
                                            })}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Box>
                        <Box>
                            <Paginator
                                pages={pages}
                                currentPage={currentPage}
                                isMobile={mobile}
                                onChange={setCurrentPage}
                            />
                        </Box>
                        <Box display={'flex'} justifyContent='space-between'>
                            <Button variant="outlined"
                                role="link"
                                onClick={navigateToAttendanceConfirmation}
                                className={`${buttonStyles.back} ${focusClass.focusItem}`}
                                aria-label={t('back_colon_start')}
                            >
                                <span role="link">{t('back_colon_start')}</span>
                            </Button>
                            <Button variant="outlined"
                                role="link"
                                onClick={navigateToActivityDetails}
                                aria-label={t('next_colon_attendees')}
                                disabled={!selectedActivityId}
                                className={`${focusClass.focusItem} ${selectedActivityId ? buttonStyles.active : buttonStyles.disabled}`}
                            >
                                <span role="link">{t('next_colon_attendees')}</span>
                            </Button>
                        </Box>
                    </Box>
                </Box>
            </Container>
        </Box>
    </>);
};
