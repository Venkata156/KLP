/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box, Button, IconButton, InputBase, SvgIcon, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@material-ui/core";
import { Theme, withStyles, makeStyles, useTheme } from "@material-ui/core/styles";
import { ReactComponent as searchIcon } from "assets/icons/icon-search.svg";
import React, { FormEvent, useState, useEffect, useMemo } from "react";
import { useSelector } from "react-redux";
import { RootState, useAppDispatch } from "store";
import { useFocusStyles } from "hooks/focusBorder";
import { useTranslation } from "react-i18next";
import { useBreadCrumbs } from "hooks";
import {
    Paginator,
    SubHeader,
    CloseIcon,
    CalendarIcon,
} from "components";
import { CSSProperties } from "@material-ui/core/styles/withStyles";
import { useHistory, useParams } from "react-router-dom";
import { useMutation, useLazyQuery } from "@apollo/client";
import { GET_ACTIVITY_ATTENDEES, COMPLETE_ACTIVITY } from "../../../utils/queries";
import { get, range, debounce, noop } from "lodash";
import { ActivityAttendees_activityAttendees, ActivityAttendees_activityAttendees_attendees, ActivityAttendees } from "../../../utils/graphql/ActivityAttendees";
import { EXCEPTIONS_CODES } from "../../../utils/constants";
import { DatePicker, MultiViewCalendar } from "@progress/kendo-react-dateinputs";
import { IntlProvider, LocalizationProvider } from "@progress/kendo-react-intl";
import { ToggleButton } from '@progress/kendo-react-dateinputs';
import { ActivityConfirmation } from "components/activity-confirmation/ActivityConfirmation";
import portalSettingsManager from "utils/portalSettingsManager";
import { SUB_HEADER_CONTENT_TYPE } from "utils/constants";

const CustomPickerWrap = (props) => {
    return props.children;
};

export const ToggleCalendarButton = (props: any) => {
    return <ToggleButton {...props} title={null} />;
};

const SearchIconButton = withStyles((theme: Theme) => ({
    root: {
        "&:hover": {
            backgroundColor: theme.palette.grey["300"],
        }
    },
}))(IconButton);

const style: CSSProperties = {
    paddingTop: "16px",
    paddingBottom: "16px",
    borderRadius: "0px",
    marginTop: "20px",
    fontSize: "11px",
    fontWeight: "bold",
    width: '128px',
    height: '50px',
};

const useButtonStyles = makeStyles((theme: Theme) => ({
    back: {
        ...style,
        color: 'gray',
        borderColor: 'gray'
    },
    active: {
        ...style,
        color: (props: any) => props?.portalSettingsManager?.application?.common?.themeColor || `${theme.palette.primary.main}`,
        borderColor: (props: any) => props?.portalSettingsManager?.application?.common?.themeColor || `${theme.palette.primary.main}`,
    },
    disabled: {
        ...style,
        color: "#ddd",
        borderColor: "#ddd",
    }
}));

const Container = withStyles((theme: Theme) => ({
    root: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "100%",
        height: (props: any) => (props.background ? "150px" : "auto"),
        position: "relative",
        marginLeft: (props: any) => (props.background || props.mobile ? "0" : "20px"),
        zIndex: 1,
        "& > div": {
            background: "transparent",
        },
        "& form": {
            display: "flex",
            alignItems: "center",
            backgroundColor: (props: any) => (props.background ? "rgba(255, 255, 255, 0.8)" : "#F5F5F5"),
            backgroundPosition: "center center",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
            maxWidth: (props: any) => (props.background ? "1240px" : "auto"),
            height: (props: any) => (props.background ? "70px" : "auto"),
            borderRadius: 0,
            "& > div": {
                width: "100%",
                "& > div": {
                    width: (props: any) => (props.background ? "calc(100% - 65px)" : "calc(100% - 48px)"),
                    "& input": {
                        padding: "0 20px",
                        fontSize: (props: any) => (props.background ? "22px" : "16px"),
                        color: theme.palette.grey["800"],
                        position: "relative",
                        top: "3px",
                        "&::placeholder": {
                            opacity: (props: any) => (props.background ? 1 : 0.4),
                        },
                    },
                },
            },
        },
    },
}))(Box);

const useStyles = makeStyles({
    root: {
        "& .k-widget k-datepicker": {
            width: "auto",
        },
        "& .k-datepicker": {
            borderBottom: "1px solid rgba(0,0,0,0.54)",
            borderRadius: "2px",
            width: `130px`
        },
        "& .k-picker-wrap": {
            border: "0px solid black",
        },
        "& .k-input": {
            padding: "0px",
            height: "100%",
            lineHeight: "100%",
            marginLeft: "1px",
            border: "0px",
        },
        "& .k-icon": {
            fontSize: "13px",
            color: "black",
        },
        minHeight: "44px",
    },
    calendarPopup: {
        zIndex: 3000,
    },
    datePicker: {
        width: "auto",
    }
});

const HeaderField = withStyles((theme: Theme) => ({
    root: {
        marginBottom: "10px",
        textAlign: 'left',
        "& span": {
            color: theme.palette.grey["800"],
        }
    },
}))(Box);
HeaderField.displayName = "HeaderField";

export const ActivityAttendeesComp = ({ background, onSubmit, mobile = false }: any): JSX.Element => {
    const dispatch = useAppDispatch();
    const focusClass = useFocusStyles();

    const [searchText, setSearchText] = useState('');
    const captureIntitialSearch = useSelector((state: RootState) => state.core.searchText);
    // const [captureSearch, setCaptureSearch] = useState(captureIntitialSearch);
    const { t } = useTranslation();
    const history = useHistory();
    const params = useParams();
    const theme = useTheme();
    const DateSyles = useStyles();

    const buttonStyles = useButtonStyles({
        portalSettingsManager,
    });

    const [pages, setPages] = useState<number[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [skipCount, setSkipCount] = useState<number>(0);
    const [onApiError, setOnApiError] = useState(false);
    const [selectedCompletionDates, setSelectedCompletionDates] = useState<any>({});

    const [attendeesData, setAttendeesData] = useState<ActivityAttendees_activityAttendees | null>(null);

    const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
    const { handleBreadCrumb, handleBreadCrumbNavigation, breadCrumbData } = useBreadCrumbs();

    const activityId = useMemo(() => {
        return get(params, "activityId", "-1");
    }, [params]);

    useEffect(() => {
        handleBreadCrumb([
            { title: t('home'), path: "/" },
            { title: t('attendace_activity_completion'), path: "/attendance-confirmation" },
            { title: t('choose_an_activity'), path: "/attendance-confirmation/activity" },
            { title: t('attendee'), path: `/attendance-confirmation/activity/${activityId}` },
        ], "override", "");
    }, [activityId]);

    const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
        handleBreadCrumbNavigation(path, breadCrumbKey);
    };

    const variables = {
        searchTerm: '',
        count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
        skip: skipCount,
        activityId: activityId,
    };

    const updateSearchText = (value: string) => {
        setSearchText(value);
    };

    const [loadAttendees, { loading, data, refetch }] = useLazyQuery<ActivityAttendees>(GET_ACTIVITY_ATTENDEES, {
        variables,
        notifyOnNetworkStatusChange: true,
        onError: ({ graphQLErrors }) => {
            if (graphQLErrors?.find(err => Object.getOwnPropertyNames(err?.extensions)?.find(p => p.indexOf(EXCEPTIONS_CODES.UnAuthorized) !== -1))) {
                history.push("/unauthorized");
            }
            setOnApiError(true);
        }
    });

    const refetchDebounced = useMemo(() => debounce(refetch ? refetch : noop, 100), [refetch]);

    useEffect(() => {
        loadAttendees({
            variables: {
                ...variables,
                searchTerm: searchText,
                count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
                skip: skipCount
            }
        });
    }, [loadAttendees]);

    useEffect(() => {
        if (data) {
            if (data.activityAttendees) {
                setAttendeesData(data.activityAttendees);

                const totalPages = Math.ceil(data.activityAttendees?.numberOfAttendees / Number(process.env.REACT_APP_ATTENDANCE_COUNT));
                setPages(range(1, totalPages + 1));
            }
        }
    }, [data]);

    useEffect(() => {
        setSkipCount(Number(process.env.REACT_APP_ATTENDEES_COUNT) * (currentPage - 1))
    }, [attendeesData, currentPage]);

    useEffect(() => {
        if (refetchDebounced && (data || onApiError)) {
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
            refetchDebounced({
                ...variables,
                searchTerm: searchText,
                count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
                skip: skipCount
            });
        }
    }, [skipCount])

    useEffect(() => {
        if (refetchDebounced && (data || onApiError)) {
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
            setCurrentPage(1);
            refetchDebounced({
                ...variables,
                searchTerm: searchText,
                count: Number(process.env.REACT_APP_ATTENDANCE_COUNT),
                skip: skipCount
            });
        }
    }, [
        refetchDebounced
    ]);

    const performSearch = () => {
        if (refetchDebounced && (data || onApiError)) {
            dispatch({
                type: "subheader/title",
                payload: "",
            });
            dispatch({ type: "loader/showandhide", payload: { show: true, message: t('search_loading') } });
            setCurrentPage(1);
            refetchDebounced({
                searchTerm: searchText,
            });
        }
    };

    useEffect(() => {
        const abc = loading;
        dispatch({ type: "loader/showandhide", payload: { show: abc, message: t('loading_attendees') } });
    }, [loading]);

    const currentDate = new Date();
    const handleChangeDate = (e: any, learnerId: string) => {
        if (!e) {
            const completionDates = { ...selectedCompletionDates };
            delete completionDates[learnerId];
            setSelectedCompletionDates(completionDates);
        } else {
            const selectedDate = new Date(e?.target.value).toISOString().split("T")[0]
            if (selectedDate <= currentDate.toISOString().split("T")[0]) {
                setSelectedCompletionDates({
                    ...selectedCompletionDates,
                    [learnerId]: e.target.value
                });
            }
        }
    };

    const handleChangeAll = (e: any) => {
        if (!e) {
            return;
        }
        const selectedDate = new Date(e?.target.value).toISOString().split("T")[0];
        if (selectedDate <= currentDate.toISOString().split("T")[0]) {
            const toBeUpdatedLearnerCompletionDates = {};
            attendeesData?.attendees.forEach(attendee => {
                if (!attendee.completionDate) {
                    toBeUpdatedLearnerCompletionDates[attendee.learnerId] = e?.target.value;
                }
            });
            setSelectedCompletionDates({
                ...selectedCompletionDates,
                ...toBeUpdatedLearnerCompletionDates
            });
        }
    };

    const handleSubmit = (event: FormEvent) => {
        event.preventDefault();
        handleSaveAttendance();
    };

    const [updateAttendance] = useMutation(COMPLETE_ACTIVITY);

    const handleSaveAttendance = () => {
        dispatch({ type: "loader/showandhide", payload: { show: true } });
        const postData = {
            activityId: attendeesData?.activityId,
            activityType: attendeesData?.activityType,
            programmeId: attendeesData?.programmeId,
            learnerIdCompletionDate: Object.keys(selectedCompletionDates).map((learnerId: any) => {
                return {
                    key: learnerId,
                    value: selectedCompletionDates[learnerId]
                }
            })
        };
        updateAttendance({ variables: { model: postData } })
            .then(() => {
                dispatch({ type: "loader/showandhide", payload: { show: false } });
                setIsSubmitted(true);
            })
            .catch(() => {
                dispatch({ type: "loader/showandhide", payload: { show: false } });
                dispatch({
                    type: "alert/show",
                    payload: {
                        type: "error",
                        title: 'Attendance Update',
                        message: 'Attendance Update Failed'
                    },
                });
            });
    };

    const getDate = (attendeeInformation: ActivityAttendees_activityAttendees_attendees) => {
        if (selectedCompletionDates.hasOwnProperty(attendeeInformation.learnerId)) {
            const selectedDate = selectedCompletionDates[attendeeInformation.learnerId];
            if (selectedDate) {
                return new Date(selectedDate)
            }
            return null;
        } else if (attendeeInformation.completionDate) {
            return new Date(attendeeInformation?.completionDate);
        }
        return null;
    };

    const modifiedAttendeesTotal = Object.keys(selectedCompletionDates).length

    return (<>
        <Box display={{ xs: "none", sm: "block" }}>
            <SubHeader
                contentType={SUB_HEADER_CONTENT_TYPE.ACTIVITY_COMPLETION}
                breadCrumbData={breadCrumbData}
                handleBreadCrumbClick={handleBreadCrumbClick}
            />
        </Box>
        <Box paddingTop={{ xs: "30px", sm: "0" }}>
            <Container background={!!background} mobile={mobile}>
                {isSubmitted ? <ActivityConfirmation
                    programName={attendeesData?.programmeName}
                    activityName={attendeesData?.activityName}
                    totalLearnersSubmitted={modifiedAttendeesTotal}
                    navigateToStart={() => history.push(`/attendance-confirmation/activity`)}
                    navigateToLanding={() => history.push(`/`)}
                /> :
                    <Box style={{ maxWidth: mobile ? undefined : "1100px", width: `100%` }}>
                        <Box style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <Box style={{ width: '48%' }}>
                                <Box style={{ fontSize: '22px', fontWeight: 400 }} paddingBottom="15px">{t('3_confirm_activity_confirmation', { activityName: attendeesData?.activityName })}</Box>
                                <form noValidate
                                    onSubmit={handleSubmit}
                                    aria-label={t('Press_Escape_key_To_Clear')}>
                                    <Box boxShadow={0}
                                        className={focusClass.focusItem}>
                                        <InputBase
                                            tabIndex={0}
                                            placeholder={t('search_attendee')}
                                            inputProps={{
                                                "title": t('search_attendee'),
                                                "placeholder": t('search_attendee')
                                            }}
                                            value={searchText}
                                            onChange={(event) => updateSearchText(event.target.value)}
                                            type="search"
                                            className={focusClass.focusItem}
                                        />
                                        {mobile && searchText ? (
                                            <IconButton
                                                type="button"
                                                className={focusClass.focusItem}
                                                aria-label={t('aria_label_clear_search')}
                                                onClick={(e) => {
                                                    e.preventDefault();
                                                    updateSearchText("");
                                                }}
                                            >
                                                <CloseIcon fontSize={background ? "large" : "inherit"} />
                                            </IconButton>
                                        ) : (
                                            <SearchIconButton
                                                onClick={(e) => {
                                                    e.preventDefault();
                                                    performSearch();
                                                }}
                                                type="submit" aria-label={t('search').toLowerCase()} style={{ height: "48px", width: "48px" }} className={focusClass.focusItem}>
                                                <SvgIcon
                                                    component={searchIcon}
                                                    style={{
                                                        position: "absolute",
                                                        margin: "16px 6px 8px 10px",
                                                        fontSize: background ? "30px" : "22px",
                                                    }}
                                                />
                                            </SearchIconButton>
                                        )}
                                    </Box>
                                </form>
                            </Box>
                            <Box paddingTop={{ xs: "30px", sm: "0" }} paddingRight={{ xs: `30px` }} style={{ maxWidth: `30%` }} >
                                <HeaderField style={{
                                    fontSize: '12px', borderBottom: `1px solid ${theme.palette.grey['300']}`
                                }}>
                                    <div style={{ paddingBottom: `10px` }}>
                                        {t('course')}
                                    </div>
                                </HeaderField>
                                <HeaderField>
                                    <span style={{ fontSize: '14px', color: `${theme.palette.primary.main}`, overflowWrap: `break-word` }}>{attendeesData?.programmeName}</span>
                                </HeaderField>
                            </Box>
                        </Box>
                        <Box margin="30px 0px">
                            {loading || attendeesData?.attendees?.length ?
                                (<><Box marginBottom={{ xs: "10px", sm: "20px" }} style={{ display: "flex" }}>
                                    <TableContainer>
                                        <Table aria-label={t('aria_label_activity_attendees_table')}>
                                            <TableHead>
                                                <TableRow>
                                                    {mobile ? (
                                                        <>
                                                            <TableCell align="left" style={{ fontWeight: 700 }}>
                                                                {t('attendee')}
                                                            </TableCell>
                                                            <TableCell></TableCell>
                                                        </>
                                                    ) : (
                                                        <>
                                                            <TableCell align="left" style={{ fontWeight: 700, minWidth: `200px` }} scope="col">
                                                                {t('attendee')}
                                                            </TableCell>
                                                            <TableCell align="center" scope="col" width={`100%`} >
                                                                <Box style={{ fontWeight: 400, fontSize: '16px', color: theme.palette.grey["200"], display: "inline-block" }} paddingRight="10px">{modifiedAttendeesTotal
                                                                }</Box>{t('total')}
                                                            </TableCell>
                                                            <TableCell align="center" style={{ fontWeight: 700, minWidth: `200px` }} scope="col">
                                                                {t('date_completed')} {attendeesData?.attendees?.length > 0 && <span>
                                                                    <LocalizationProvider language={"en-US"}>
                                                                        <IntlProvider locale={"en"}>
                                                                            <DatePicker
                                                                                id="assignToAll"
                                                                                max={currentDate}
                                                                                dateInput={() => null}
                                                                                format="dd MMM yyyy"
                                                                                title={t('date_picker_startdate_title')}
                                                                                className={DateSyles.datePicker}
                                                                                calendar={(props: any) => (
                                                                                    <MultiViewCalendar
                                                                                        max={currentDate} views={1} ref={props._ref} value={props.value} onChange={props.onChange} />
                                                                                )}
                                                                                formatPlaceholder="formatPattern"
                                                                                placeholder="dd MMM yyyy"
                                                                                toggleButton={(props) => (
                                                                                    <CalendarIcon
                                                                                        {...props}
                                                                                        fill={theme.palette.common.black}
                                                                                        style={{ padding: "0 5px", fontSize: "24px" }}
                                                                                    >
                                                                                        {props.children}
                                                                                    </CalendarIcon>
                                                                                )}
                                                                                pickerWrap={CustomPickerWrap}
                                                                                popupSettings={{ popupClass: DateSyles.calendarPopup, appendTo: document.body }}
                                                                                onChange={handleChangeAll}
                                                                            />
                                                                        </IntlProvider>
                                                                    </LocalizationProvider>
                                                                </span>}
                                                            </TableCell>
                                                        </>
                                                    )}
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                {mobile
                                                    ? attendeesData?.attendees?.map((row, index) => {
                                                        return (
                                                            <React.Fragment key={"mobile_" + index}>
                                                                <TableRow>
                                                                    <TableCell align="left" >
                                                                        <Box>{row?.firstName + ' ' + row?.lastName}</Box>
                                                                    </TableCell>
                                                                </TableRow>
                                                            </React.Fragment>
                                                        );
                                                    })
                                                    : attendeesData?.attendees?.map((row, index) => {
                                                        return (
                                                            <React.Fragment key={index}>
                                                                {row && (
                                                                    <TableRow key={index} style={{ minHeight: `44px` }}>
                                                                        <TableCell align="left" width={`100%`} colSpan={2}>
                                                                            {row?.firstName + ' ' + row?.lastName}
                                                                        </TableCell>
                                                                        <TableCell align="center" style={{ minWidth: `200px` }}>
                                                                            {row.completionDate ? new Date(row.completionDate).toLocaleDateString() : (
                                                                                <Box
                                                                                    className={DateSyles.root}
                                                                                    display="flex"
                                                                                    justifyContent="flex-end"
                                                                                    alignItems="center"
                                                                                    fontSize="10px"
                                                                                >
                                                                                    <LocalizationProvider language={"en-US"}>
                                                                                        <IntlProvider locale={"en"}>
                                                                                            <DatePicker
                                                                                                id="startdate"
                                                                                                max={currentDate}
                                                                                                value={getDate(row)}
                                                                                                format="dd MMM yyyy"
                                                                                                title={t('date_picker_startdate_title')}
                                                                                                calendar={(props: any) => (
                                                                                                    <MultiViewCalendar
                                                                                                        max={currentDate} views={1} ref={props._ref} value={props.value} onChange={props.onChange} />
                                                                                                )}
                                                                                                formatPlaceholder="formatPattern"
                                                                                                toggleButton={ToggleCalendarButton}
                                                                                                placeholder="dd MMM yyyy"
                                                                                                popupSettings={{ popupClass: DateSyles.calendarPopup, appendTo: document.body }}
                                                                                                onChange={(e) => handleChangeDate(e, row.learnerId)}
                                                                                            />
                                                                                            <CloseIcon
                                                                                                fill={theme.palette.common.black}
                                                                                                onClick={() => { handleChangeDate(null, row.learnerId) }}
                                                                                                style={{ padding: "15px", cursor: "pointer", visibility: getDate(row) ? 'visible' : 'hidden' }}
                                                                                                className={focusClass.focusItem}
                                                                                                tabIndex={0}
                                                                                            />
                                                                                        </IntlProvider>
                                                                                    </LocalizationProvider>
                                                                                </Box>)}
                                                                        </TableCell>
                                                                    </TableRow>
                                                                )}
                                                            </React.Fragment>
                                                        );
                                                    })}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Box>
                                    <Box>
                                        <Paginator
                                            pages={pages}
                                            currentPage={currentPage}
                                            isMobile={mobile}
                                            onChange={setCurrentPage}
                                        />
                                    </Box>
                                    <Box display={'flex'} justifyContent='space-between'>
                                        <Button variant="outlined"
                                            onClick={() => history.push('/attendance-confirmation/activity')}
                                            className={buttonStyles.back}
                                            aria-label={t('back_activity')}
                                        >
                                            <span role="link">{t('back_activity')}</span>
                                        </Button>
                                        <Box style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
                                            <Button variant="outlined"
                                                role="link"
                                                onClick={() => handleSaveAttendance()}
                                                className={`${focusClass.focusItem} ${modifiedAttendeesTotal === 0 ? buttonStyles.disabled : buttonStyles.active}`}
                                                disabled={modifiedAttendeesTotal === 0}
                                                aria-label={t('submit')}
                                            >
                                                <span role="link">{t('submit')}</span>
                                            </Button>
                                            <Box style={{ marginTop: '16px' }}>
                                                {t('completion_date_cannot_be_changed')}
                                            </Box>
                                        </Box>
                                    </Box>
                                </>) : <div style={{ textAlign: 'center' }}>
                                    {t('no_learners_for_activity')}
                                </div>
                            }
                        </Box>
                    </Box>}
            </Container>
        </Box>
    </>);
};