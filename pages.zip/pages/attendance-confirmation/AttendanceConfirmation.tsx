/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect } from 'react';
import { Box, Button, Radio, RadioProps, RadioGroup, FormControlLabel } from "@material-ui/core";
import { Theme, withStyles, makeStyles } from "@material-ui/core/styles";
import { useState } from "react";
import { CSSProperties } from "@material-ui/core/styles/withStyles";
import { useTranslation } from "react-i18next";
import { useBreadCrumbs } from "hooks";
import {
    SubHeader,
    theme,
} from "components";
import { useHistory } from "react-router-dom";
import { SUB_HEADER_CONTENT_TYPE } from "utils/constants";
import clsx from "clsx";
import portalSettingsManager from "utils/portalSettingsManager";

const CONFIRMATION_TYPES = {
    ACTIVITY: "activity",
    SESSION: "session",
}

const formLabel: CSSProperties = {
    alignItems: "start",
    height: `135px`,
    maxWidth: `306px`,
    fontSize: `30px`,
    letterSpacing: 0,
    lineHeight: `45px`,
    color: theme.palette.grey["800"],
    paddingBottom: `${theme.spacing(2)}px`,
    paddingLeft: `${theme.spacing()}px`,
}

const useStyles = makeStyles((theme: Theme) => ({
    root: {
        marginLeft: "1px",
        "&:hover": {
            backgroundColor: "transparent",
        },
    },
    icon: {
        borderRadius: "50%",
        width: 14,
        height: 14,
        border: `1px solid ${theme.palette.grey["A100"]}`,
        backgroundColor: theme.palette.common.white,
    },
    checkedIcon: {
        backgroundColor: portalSettingsManager?.application?.common?.themeColor || theme.palette.primary.main,
    },
    button: {
        paddingTop: "16px",
        paddingBottom: "16px",
        borderRadius: "0px",
        marginTop: "20px",
        fontSize: "11px",
        color: portalSettingsManager?.application?.common?.themeColor || theme.palette.primary.main,
        borderColor: portalSettingsManager?.application?.common?.themeColor || theme.palette.primary.main,
        fontWeight: "bold",
    },
    formLabel: {
        ...formLabel
    },
    formLabelSelected: {
        ...formLabel,
        color: portalSettingsManager?.application?.common?.themeColor || theme.palette.primary.main,
        borderBottom: `2px solid ${portalSettingsManager?.application?.common?.themeColor || theme.palette.primary.main
            }`
    },
    attendRadio: {
        border:"2px solid #000 !important"
    }
}));

const StyledRadio = (props: RadioProps): JSX.Element => {
    const classes = useStyles();
    return (
        <Radio
            focusVisibleClassName={classes.attendRadio}
            className={classes.root}
            disableRipple
            color="default"
            checkedIcon={<span className={clsx(classes.icon, classes.checkedIcon)} />}
            icon={<span className={classes.icon} />}
            {...props}
        />
    );
};

const Container = withStyles((theme: Theme) => ({
    root: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "100%",
        height: (props: any) => (props.background ? "150px" : "auto"),
        position: "relative",
        marginLeft: (props: any) => (props.background || props.mobile ? "0" : "20px"),
        zIndex: 1,
        "& > div": {
            background: "transparent",
        },
        "& form": {
            display: "flex",
            alignItems: "center",
            backgroundColor: (props: any) => (props.background ? "rgba(255, 255, 255, 0.8)" : "#F5F5F5"),
            backgroundPosition: "center center",
            backgroundSize: "cover",
            backgroundRepeat: "no-repeat",
            width: "90%",
            maxWidth: (props: any) => (props.background ? "1240px" : "420px"),
            height: (props: any) => (props.background ? "70px" : "100%"),
            borderRadius: 0,
            "& > div": {
                width: "100%",
                "& > div": {
                    width: (props: any) => (props.background ? "calc(100% - 65px)" : "calc(100% - 48px)"),
                    "& input": {
                        padding: "0 20px",
                        fontSize: (props: any) => (props.background ? "22px" : "16px"),
                        color: theme.palette.grey["800"],
                        position: "relative",
                        top: "3px",
                        "&::placeholder": {
                            opacity: (props: any) => (props.background ? 1 : 0.4),
                        },
                    },
                },
            },
        },
    },
}))(Box);

const AttendanceConfirmationFormLabel = withStyles(() => ({
    root: {
        alignItems: "start",
        paddingRight: "20px",
    }
}))(FormControlLabel);

export const AttendanceConfirmation = ({ background, mobile = false }: any): JSX.Element => {
    const history = useHistory();
    const { t } = useTranslation();
    const classes = useStyles();
    const [selectedConfirmation, setSelectedConfirmation] = useState('');

    const { handleBreadCrumb, handleBreadCrumbNavigation, breadCrumbData } = useBreadCrumbs();

    useEffect(() => {
        handleBreadCrumb([
            { title: t('home'), path: "/" },
            { title: t('attendace_activity_completion'), path: "/attendance-confirmation" },
        ], "override", "");
    }, []);

    const handleBreadCrumbClick = (path: string, breadCrumbKey: any) => {
        handleBreadCrumbNavigation(path, breadCrumbKey);
    };

    const navigateToNextStep = () => {
        if (selectedConfirmation === CONFIRMATION_TYPES.ACTIVITY) {
            history.push("/attendance-confirmation/activity");
        } else if (selectedConfirmation === CONFIRMATION_TYPES.SESSION) {
            history.push(`/attendance`)
        }
    };

    const handleConfirmationChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        setSelectedConfirmation(event.target.value);
    };

    return (<>
        <Box display={{ xs: "none", sm: "block" }}>
            <SubHeader
                contentType={SUB_HEADER_CONTENT_TYPE.ATTENDANCE_CONFIRMATION}
                breadCrumbData={breadCrumbData}
                handleBreadCrumbClick={handleBreadCrumbClick} />
        </Box>
        <Box paddingTop={{ xs: "30px", sm: "0" }}>
            <Container background={!!background} mobile={mobile}>
                <Box>
                    <div style={{
                        fontSize: '24px',
                        color: theme.palette.grey['800'],
                        margin: '20px 0',
                        fontWeight: 400
                    }}>{t('1_choose_confirmation_type')}</div>
                    <Box margin="30px 0px">
                        <Box marginBottom={{ xs: "10px", sm: "20px" }} style={{ display: "flex", justifyContent: "space-evenly" }}>
                            <RadioGroup
                                row
                                aria-label="radio"
                                value={selectedConfirmation}
                                onChange={handleConfirmationChange}
                                name={t('confirmation_type')}
                            >
                                <AttendanceConfirmationFormLabel
                                    value={CONFIRMATION_TYPES.ACTIVITY}
                                    aria-required="true"
                                    aria-label={t('confirm_completion_for_activity')}
                                    control={<StyledRadio />}
                                    label={<div
                                        className={selectedConfirmation === CONFIRMATION_TYPES.ACTIVITY ? classes.formLabelSelected : classes.formLabel}
                                    >
                                        {t('confirm_completion_for_activity')}
                                    </div>} />
                                <AttendanceConfirmationFormLabel
                                    value={CONFIRMATION_TYPES.SESSION}
                                    aria-required="true"
                                    aria-label={t('confirm_attendance_for_session')}
                                    control={<StyledRadio />}
                                    label={<div
                                        className={selectedConfirmation === CONFIRMATION_TYPES.SESSION ? classes.formLabelSelected : classes.formLabel}
                                    >
                                        {t('confirm_attendance_for_session')}
                                    </div>} />
                            </RadioGroup>
                        </Box>
                        {selectedConfirmation && <Box display={'flex'} justifyContent='flex-end'>
                            <Button variant="outlined"
                                onClick={navigateToNextStep}
                                className={classes.button}
                            >
                                {selectedConfirmation === CONFIRMATION_TYPES.SESSION ? t('next_colon_sessions') : t('next_colon_activities')}
                            </Button>
                        </Box>}
                    </Box>
                </Box>
            </Container>
        </Box>
    </>);
};
